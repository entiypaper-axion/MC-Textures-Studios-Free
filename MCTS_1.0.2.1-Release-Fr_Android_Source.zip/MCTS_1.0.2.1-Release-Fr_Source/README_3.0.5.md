# MCTS 3.0.5

Android 包名 `com.axion.pompreview.studio3`，版本码 30500；Android 8.0 及以上。源码项目使用 JDK 17、Gradle 8.11.1、Android SDK 35，执行 `gradle :app:assembleRelease :app:lintRelease`。发布签名密钥及密码不包含在源码包内；与 3.0.1 相同的签名证书可用于覆盖安装。

本版功能：导航只保留移动的选中框；法语、西班牙语界面；滑块端点拉伸及松手回弹；可开关 Sun UI 小窗口；导入本地视频作为静音循环背景；默认关闭的透明界面模式及可读性提示；预览编辑/双方式编辑，立体模型上的画笔和像素网格；模板分类与 16–512 分辨率选择；多面方块的顶/侧/底贴图合成与可解析的静态模型盒；移除“新建素材”界面入口。项目、图层和历史记录仍可使用。

在项目设置中可明确选择下载官方模型包到**当前项目私有目录**，也可从系统文件选择器导入官方 JAR/ZIP。应用并不随 APK 或源码分发额外的 Minecraft 游戏模型档案。已有的十套纹理模板沿用此前发布内容。

当前模型预览解析 Java 方块状态与父模型的静态元素、Bedrock `minecraft:geometry` 的静态骨骼盒。旋转、专用 UV、动画、复杂实体姿态及部分非方块素材不能保证与游戏逐像素一致；画笔只能修改当前打开的贴图面，切到别的面请先打开相应模板。设备 GPU 上的实际着色和触摸体验仍需真机确认。

测试命令：`bash test-core.sh`；`python3 verification/test_template_gate.py`；`python3 tools/verify_package.py app/build/outputs/apk/release/app-release.apk`。独立 JVM 校验命令见 `verification/run.py` 与 `verification_gl`。详细结果见 `VALIDATION_3.0.5.md`。
