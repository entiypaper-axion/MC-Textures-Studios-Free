# Alpha02 verification · 2026-09-26

- Android build: `:app:assembleDebug :app:lintDebug` — BUILD SUCCESSFUL.
- Lint: 0 errors, 11 warnings. Remaining warnings concern a Compose Modifier default, backup configuration, application icon, preference KTX convenience, and inherited GL touch accessibility.
- Core JVM suite: 83 checks passed (document editing, undo, PNG and pack output, project storage).
- Project integration: 122 checks passed against compiled Kotlin Projects with JVM file/image adapters. Covers all 10 profiles, template loading, original resource paths, edited/unedited exports, pack metadata, project isolation, stable UUIDs, and old Bedrock PBR gating.
- APK outer CRC, all 10 embedded template archive CRCs, and their sources.json SHA-256 values passed.
- APK signature verified: v2, RSA 3072. Certificate SHA-256: e5fd9c926f8ccce3cd2697ac4819dc3ad7ffbbff30b3b02a6672f0a9006231d7.
- ZIP alignment: `zipalign -c 4` passed.
- AAPT package metadata: com.axion.pompreview.studio3; versionCode 30002; versionName 3.0.0-alpha02; min SDK 26; target SDK 35.
- APK SHA-256: fe0dfb3e2eea8bf5260cb48f0b8e13587e0a703e7213d0c4a6ddc0d5664b4b85

No Android device/emulator or in-game import tests were available. This is an alpha test build; JVM adapters do not validate Compose interactions or GPU drivers. Install alongside the old app and keep old projects. Templates preserve assets but do not add a model rig editor or frame timeline.

## Reproduce
Run `bash test-core.sh`, the Android build, then `python3 verification/run.py /path/to/org-json-20240303.jar`. The integration harness is outside the Android application sources and is not packaged in the APK. Template provenance is in assets/templates/sources.json.
