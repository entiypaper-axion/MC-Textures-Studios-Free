package com.mcts.core;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import static com.mcts.core.MaterialDocument.Channel.*;

public final class CoreTest {
    private static int passed;
    static void check(boolean condition,String message) { if(!condition) throw new AssertionError(message); passed++; }
    public static void main(String[] args) throws Exception {
        Path output=Paths.get(args[0]); Files.createDirectories(output);
        Path root=Files.createTempDirectory(output,"run-");
        for(int size:new int[]{16,32,64,128,256,512}) {
            MaterialDocument doc=new MaterialDocument("stone",MaterialDocument.Kind.BLOCK,size,size);
            int[] before=doc.composite(HEIGHT);
            doc.beginStroke(0,HEIGHT); doc.paint(size-1,size-1,0xffffffff); doc.paint(0,0,0xff000000); doc.endStroke();
            check((before[0]&255)==128,"Baseline aliased to edit");
            int[] after=doc.composite(HEIGHT); check(after[size*size-1]==0xffffffff,"HD pixel not editable");
            after[0]=0xffff0000; check(doc.composite(HEIGHT)[0]!=after[0],"Public array aliases document");
            doc.undo(); check(Arrays.equals(before,doc.composite(HEIGHT)),"Stroke undo");
            doc.redo(); check(doc.composite(HEIGHT)[size*size-1]==0xffffffff,"Stroke redo");
            int top=doc.addLayer("Top"); doc.fill(top,COLOR,0xffff0000); doc.setOpacity(top,.5f);
            check((doc.composite(COLOR)[0]>>>24)==128,"Layer opacity");
            doc.setVisible(top,false); check(doc.composite(COLOR)[0]==0,"Layer visibility");
            doc.undo(); check(doc.composite(COLOR)[0]!=0,"Layer property undo");
            ByteArrayOutputStream encoded=new ByteArrayOutputStream(); ProjectStore.write(doc,encoded);
            MaterialDocument restored=ProjectStore.read(new ByteArrayInputStream(encoded.toByteArray()));
            check(Arrays.equals(doc.composite(COLOR),restored.composite(COLOR)),"Layer project round trip");
            check(Arrays.equals(doc.composite(HEIGHT),restored.composite(HEIGHT)),"PBR project round trip");
        }
        MaterialDocument doc=new MaterialDocument("stone",MaterialDocument.Kind.BLOCK,512,512);
        ProjectStore store=new ProjectStore(root.resolve("workspace"));
        doc.fill(0,COLOR,0xffbbaa77); doc.fill(0,HEIGHT,0xffcccccc); String key=store.save(doc);
        doc.fill(0,COLOR,0xff112233); store.save(doc);
        check(store.list().size()==1,"Local asset index"); check(store.versions(key).size()==1,"Version snapshot");
        check(store.openVersion(key,store.versions(key).get(0)).composite(COLOR)[0]==0xffbbaa77,"Version restores pixels");
        try { store.open("../escape"); throw new AssertionError("Traversal allowed"); } catch(IOException expected) { passed++; }
        try { new MaterialDocument("../bad",MaterialDocument.Kind.BLOCK,16,16); throw new AssertionError("Bad name allowed"); }
        catch(IllegalArgumentException expected) { passed++; }
        check(((PackExport.labSpecular(255,255,0,0,10,0)>>>24)&255)==254,"Lab emission 255 sentinel");
        check(((PackExport.labSpecular(255,0,255,0,10,0)>>>8)&255)==255,"Lab generic metal");
        check((PackExport.labSpecular(0,0,255,255,10,0)&255)==255,"Lab SSS encoding");
        check((PackExport.labSpecular(0,0,255,0,10,255)&255)==64,"Lab porosity encoding");
        for(PackExport.Target target:PackExport.Target.values()) {
            Path out=root.resolve(target==PackExport.Target.JAVA_LABPBR?"test_java.zip":"test_bedrock.mcpack");
            final int[] progress={0};
            PackExport.export(store,store.list(),target,46,Files.newOutputStream(out),(n,total,name)->progress[0]=n);
            check(progress[0]==1,"Export progress");
            try(ZipFile zip=new ZipFile(out.toFile())) {
                String path=PackExport.path(doc,target);
                check(zip.getEntry(path+".png")!=null,"Color missing");
                check(zip.getEntry("mcts_export_report.txt")!=null,"Compatibility report missing");
                if(target==PackExport.Target.JAVA_LABPBR) check(zip.getEntry(path+"_s.png")!=null,"Lab specular missing");
                else {
                    String json=new String(zip.getInputStream(zip.getEntry(path+".texture_set.json")).readAllBytes(),"UTF-8");
                    check(json.contains("\"normal\"")&&!json.contains("heightmap"),"Invalid Bedrock binding");
                }
            }
        }
        // Data-texture RGB must survive alpha=0, even though the pixel is transparent.
        int[] data=new int[256]; data[0]=0x00abcdef;
        byte[] png=Png.rgba(16,16,data); ByteArrayOutputStream idat=new ByteArrayOutputStream();
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(png)); in.skipBytes(8);
        while(in.available()>0) { int n=in.readInt(); String type=new String(in.readNBytes(4),"US-ASCII"); byte[] bytes=in.readNBytes(n); int crc=in.readInt();
            CRC32 expected=new CRC32(); expected.update(type.getBytes("US-ASCII")); expected.update(bytes);
            check((int)expected.getValue()==crc,"PNG CRC"); if(type.equals("IDAT")) idat.write(bytes); }
        byte[] rgba=new InflaterInputStream(new ByteArrayInputStream(idat.toByteArray())).readAllBytes();
        check((rgba[1]&255)==0xab && (rgba[2]&255)==0xcd && (rgba[3]&255)==0xef && rgba[4]==0,"Premultiplication destroyed LabPBR data");
        for(int i=0;i<50;i++) doc.fill(0,COLOR,0xff000000|i);
        check(doc.getHistoryBytes()<=32L*1024*1024,"Undo budget exceeded");
        doc.undo(); doc.fill(0,COLOR,0xfffefefe); check(!doc.canRedo(),"Redo branch not discarded");
        System.out.println("PASS: "+passed+" checks; sizes 16–512; layers/history; isolated snapshots; persistence; exports; PNG CRC/RGBA; bounded undo.");
    }
}
