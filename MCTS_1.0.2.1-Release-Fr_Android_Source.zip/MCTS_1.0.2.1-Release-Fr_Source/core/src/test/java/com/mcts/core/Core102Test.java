package com.mcts.core;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/** 1.0.2: texture packs (1.0 – 1.5.2) and the pure-Java PNG reader. Run by test-core.sh. */
public final class Core102Test {
    private static int checks;
    private static void check(boolean ok, String what) { if (!ok) throw new AssertionError(what); checks++; }
    private static int[] tile(int seed, int t) { Random r = new Random(seed); int[] a = new int[t * t]; for (int i = 0; i < a.length; i++) a[i] = 0xff000000 | r.nextInt(0xffffff); return a; }
    private static void zip(File f, Map<String, byte[]> m) throws IOException { try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f))) { for (Map.Entry<String, byte[]> e : m.entrySet()) { z.putNextEntry(new ZipEntry(e.getKey())); z.write(e.getValue()); z.closeEntry(); } } }
    private static byte[] read(ZipFile z, String n) throws IOException { try (InputStream in = z.getInputStream(z.getEntry(n))) { return in.readAllBytes(); } }

    public static void main(String[] args) throws Exception {
        File dir = new File(args.length > 0 ? args[0] : "build/test-output", "core102"); dir.mkdirs();
        // PNG reader round trip (straight alpha, RGB kept at alpha 0)
        int[] px = tile(7, 32); px[3] = 0x00123456;
        PngDecoder.Image back = PngDecoder.decode(Png.templateRgba(32, 32, px));
        check(back.width == 32 && back.height == 32 && Arrays.equals(back.argb, px), "png round trip");
        check(Arrays.equals(PngDecoder.size(Png.templateRgba(5, 9, new int[45])), new int[]{5, 9}), "png size");

        // Fake 1.4-style jar: terrain.png + gui/items.png atlases and loose files
        int t = 16; int[] terrain = new int[256 * 256], items = new int[256 * 256];
        for (int i = 0; i < 200; i++) { int[] tl = tile(i, t); int ox = i % 16 * t, oy = i / 16 * t; for (int y = 0; y < t; y++) for (int x = 0; x < t; x++) terrain[(oy + y) * 256 + ox + x] = tl[y * t + x]; }
        for (int i = 0; i < 150; i++) { int[] tl = tile(1000 + i, t); int ox = i % 16 * t, oy = i / 16 * t; for (int y = 0; y < t; y++) for (int x = 0; x < t; x++) items[(oy + y) * 256 + ox + x] = tl[y * t + x]; }
        Map<String, byte[]> jar = new LinkedHashMap<>();
        jar.put("terrain.png", Png.templateRgba(256, 256, terrain)); jar.put("gui/items.png", Png.templateRgba(256, 256, items));
        jar.put("mob/pig.png", Png.templateRgba(64, 32, new int[64 * 32])); jar.put("net/minecraft/client/Minecraft.class", new byte[]{1});
        File jf = new File(dir, "client-1.4.jar"); zip(jf, jar);
        Map<String, byte[]> ref = new LinkedHashMap<>();
        ref.put("textures/blocks/stone.png", Png.templateRgba(16, 16, tile(1, 16)));
        int[] strip = Arrays.copyOf(tile(3, 16), 512); ref.put("textures/blocks/water.png", Png.templateRgba(16, 32, strip));
        ref.put("textures/items/apple.png", Png.templateRgba(16, 16, tile(1010, 16)));
        File rf = new File(dir, "client-1.5.2.jar"); zip(rf, ref);
        File cache = new File(dir, "cache.zip"); cache.delete();
        LegacyPack.buildTemplate(jf, rf, true, cache, new TemplateArchive.Control() { public void check() {} public void progress(float f) {} });
        try (ZipFile z = new ZipFile(cache)) {
            check(z.getEntry("assets/minecraft/textures/blocks/stone.png") != null, "tile named from 1.5.2");
            check(z.getEntry("assets/minecraft/textures/blocks/water.png") != null, "animated strip matched by first frame");
            check(z.getEntry("assets/minecraft/textures/items/apple.png") != null, "item tile named");
            check(z.getEntry("assets/minecraft/textures/blocks/terrain_002.png") != null, "unmatched tile keeps index name");
            check(z.getEntry("assets/minecraft/textures/mob/pig.png") != null, "loose file kept");
            check(z.getEntry(LegacyPack.MAP) != null && z.getEntry("mcts_legacy/terrain.png") != null, "map + original atlas");
            check(z.getEntry("net/minecraft/client/Minecraft.class") == null, "no code copied");
        }
        // Export: one tile edited at 32 px → atlas scales to 512, other cells keep their pixels
        Map<String, byte[]> modern = new LinkedHashMap<>();
        int[] red = new int[32 * 32]; Arrays.fill(red, 0xffff0000);
        modern.put("assets/minecraft/textures/blocks/stone.png", Png.templateRgba(32, 32, red));
        try (ZipFile z = new ZipFile(cache)) { for (ZipEntry e : Collections.list(z.entries())) if (!modern.containsKey(e.getName())) modern.put(e.getName(), read(z, e.getName())); }
        File mf = new File(dir, "modern.zip"); zip(mf, modern);
        File pack = new File(dir, "pack.zip");
        LegacyPack.toTexturePack(mf, cache, "My pack", "Made with MCTS", pack);
        try (ZipFile z = new ZipFile(pack)) {
            check(new String(read(z, "pack.txt"), "UTF-8").equals("My pack\nMade with MCTS"), "pack.txt");
            PngDecoder.Image atlas = PngDecoder.decode(read(z, "terrain.png"));
            check(atlas.width == 512 && atlas.argb[5 * 512 + 32 + 5] == 0xffff0000, "edited tile stitched at index 1");
            check(atlas.argb[0] == terrain[0], "untouched cell kept");
            check(z.getEntry("gui/items.png") != null && z.getEntry("mob/pig.png") != null, "paths restored");
            check(z.getEntry("pack.mcmeta") == null && z.getEntry("mcts_legacy/map.txt") == null, "no modern/internal files");
        }
        // Import the exported texture pack back onto the template
        File base = new File(dir, "base.zip");
        LegacyPack.Imported r = LegacyPack.importPack(pack, true, cache, base);
        try (ZipFile z = new ZipFile(base)) {
            PngDecoder.Image stone = PngDecoder.decode(read(z, "assets/minecraft/textures/blocks/stone.png"));
            check(r.imported > 300 && stone.width == 32 && stone.argb[0] == 0xffff0000, "import splits the HD atlas with template names");
            check(z.getEntry(LegacyPack.MAP) != null, "import keeps the map");
        }
        // A modern resource pack is refused for a texture-pack project
        Map<String, byte[]> modernPack = new LinkedHashMap<>(); modernPack.put("pack.mcmeta", "{}".getBytes()); modernPack.put("assets/minecraft/textures/block/stone.png", Png.templateRgba(16, 16, tile(1, 16)));
        File mp = new File(dir, "modern-pack.zip"); zip(mp, modernPack);
        try { LegacyPack.importPack(mp, true, cache, new File(dir, "x.zip")); check(false, "modern pack must be refused"); }
        catch (IOException e) { check("PACK_EDITION".equals(e.getMessage()), "PACK_EDITION for modern pack"); }
        // Bedrock archive layouts
        check("textures/blocks/stone.png".equals(TemplateArchive.texturePath("packs-x/stable/resource/textures/blocks/stone.png", "bedrock_1_17_0")), "bedrock.dev layout");
        check(TemplateArchive.texturePath("packs-x/beta/resource/textures/blocks/stone.png", "bedrock_1_17_0") == null, "beta ignored");
        check("textures/blocks/stone.png".equals(TemplateArchive.texturePath("bedrock-samples-x/resource_pack/textures/blocks/stone.png", "bedrock_1_21_30")), "Mojang samples layout");
        System.out.println("Core102Test passed " + checks + " checks");
    }
}
