package com.mcts.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** 1.0.2.1: model side archive for the 3D preview and the Minecraft font built from a client.jar. Run by test-core.sh. */
public final class Core1021Test {
    private static int checks;
    private static void check(boolean ok, String what) { if (!ok) throw new AssertionError(what); checks++; }
    private static void zip(File f, Map<String, byte[]> m) throws IOException { try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f))) { for (Map.Entry<String, byte[]> e : m.entrySet()) { z.putNextEntry(new ZipEntry(e.getKey())); z.write(e.getValue()); z.closeEntry(); } } }
    private static byte[] utf8(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    private static final TemplateArchive.Control NONE = new TemplateArchive.Control() { public void check() {} public void progress(float f) {} };

    public static void main(String[] args) throws Exception {
        File dir = new File(args.length > 0 ? args[0] : "build/test-output", "core1021"); dir.mkdirs();

        // ---- model side archive: only model / blockstate JSON of the same jar, nothing else.
        Map<String, byte[]> jar = new LinkedHashMap<>();
        jar.put("assets/minecraft/models/block/oak_slab.json", utf8("{\"parent\":\"block/slab\"}"));
        jar.put("assets/minecraft/blockstates/oak_slab.json", utf8("{\"variants\":{\"type=bottom\":{\"model\":\"block/oak_slab\"}}}"));
        jar.put("assets/minecraft/textures/block/stone.png", Png.templateRgba(16, 16, new int[256]));
        jar.put("assets/minecraft/models/../evil.json", utf8("{}"));
        jar.put("net/minecraft/Main.class", new byte[]{1});
        File jf = new File(dir, "client.jar"); zip(jf, jar);
        File models = new File(dir, "models.zip"); models.delete();
        int n = TemplateArchive.extractModels(jf, "java_1214", models, NONE);
        check(n == 2, "two model files kept: " + n);
        try (ZipFile z = new ZipFile(models)) {
            check(z.getEntry("assets/minecraft/blockstates/oak_slab.json") != null, "blockstate kept");
            check(z.getEntry("assets/minecraft/textures/block/stone.png") == null, "no textures in the model archive");
            check(z.getEntry("net/minecraft/Main.class") == null, "no code");
        }
        // Bedrock sample layout → resource_pack/models
        Map<String, byte[]> bed = new LinkedHashMap<>();
        bed.put("bedrock-samples-1.21/resource_pack/models/entity/chest.geo.json", utf8("{}"));
        bed.put("bedrock-samples-1.21/resource_pack/textures/blocks/stone.png", Png.templateRgba(16, 16, new int[256]));
        File bf = new File(dir, "bedrock.zip"); zip(bf, bed);
        File bm = new File(dir, "bedrock-models.zip"); bm.delete();
        check(TemplateArchive.extractModels(bf, "bedrock_12120", bm, NONE) == 1, "bedrock geometry kept");
        try (ZipFile z = new ZipFile(bm)) { check(z.getEntry("resource_pack/models/entity/chest.geo.json") != null, "bedrock path normalised"); }
        // A jar without models produces no file.
        File empty = new File(dir, "empty-models.zip"); empty.delete();
        Map<String, byte[]> old = new LinkedHashMap<>(); old.put("terrain.png", Png.templateRgba(16, 16, new int[256]));
        File of = new File(dir, "old.jar"); zip(of, old);
        check(TemplateArchive.extractModels(of, "java_1_7_10", empty, NONE) == 0 && !empty.exists(), "no models → no archive");

        // ---- Minecraft font: bitmap sheet + space + unihex (with the game's trailing commas), filters respected.
        int[] sheet = new int[16 * 8 * 8 * 2];
        // 'A' at column 1 row 0: a 3-wide block; 'B' at column 2: a single pixel at x=0.
        for (int y = 0; y < 8; y++) for (int x = 0; x < 3; x++) sheet[y * 128 + 8 + x] = 0xffffffff;
        sheet[0 * 128 + 16] = 0xffffffff;
        Map<String, byte[]> font = new LinkedHashMap<>();
        font.put("assets/minecraft/font/default.json", utf8("{\"providers\":[{\"type\":\"reference\",\"id\":\"minecraft:include/space\"},{\"type\":\"reference\",\"id\":\"minecraft:include/default\",\"filter\":{\"uniform\":false}},{\"type\":\"reference\",\"id\":\"minecraft:include/unifont\"},]}"));
        font.put("assets/minecraft/font/include/space.json", utf8("{\"providers\":[{\"type\":\"space\",\"advances\":{\" \":4}}]}"));
        StringBuilder row = new StringBuilder("\\u0000AB");
        for (int i = 3; i < 16; i++) row.append((char) ('C' + i - 3));
        StringBuilder row2 = new StringBuilder(); for (int i = 0; i < 16; i++) row2.append((char) ('a' + i));
        StringBuilder rows = new StringBuilder();
        // 95 printable chars are required; add more rows of the same sheet (empty glyphs) to reach that.
        String[] extra = {"0123456789!?.,:;", "PQRSTUVWXYZ[]()*", "pqrstuvwxyz{}<>=", "+-_/\\\\|@#$%^&~'\\\""};
        rows.append('"').append(row).append("\",\"").append(row2).append('"');
        for (String e : extra) rows.append(",\"").append(e).append('"');
        font.put("assets/minecraft/font/include/default.json", utf8("{\"providers\":[{\"type\":\"bitmap\",\"file\":\"minecraft:font/ascii.png\",\"ascent\":7,\"chars\":[" + rows + "]},{\"type\":\"bitmap\",\"file\":\"minecraft:font/ascii.png\",\"ascent\":7,\"chars\":[\"\\u4e2d\"],\"filter\":{\"jp\":true}}]}"));
        int sheetRows = 2 + extra.length;
        int[] big = new int[128 * 8 * sheetRows]; System.arraycopy(sheet, 0, big, 0, sheet.length);
        font.put("assets/minecraft/textures/font/ascii.png", Png.templateRgba(128, 8 * sheetRows, big));
        // Unifont: 中 (16 wide) and a narrow 'Ā'
        ByteArrayOutputStream hz = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(hz)) {
            z.putNextEntry(new ZipEntry("unifont.hex"));
            StringBuilder h = new StringBuilder("4E2D:");
            for (int y = 0; y < 16; y++) h.append(y == 8 ? "FFFF" : "0180");
            h.append('\n').append("0100:");
            for (int y = 0; y < 16; y++) h.append(y < 2 ? "00" : "7E");
            h.append('\n');
            z.write(h.toString().getBytes(StandardCharsets.US_ASCII)); z.closeEntry();
        }
        font.put("assets/minecraft/font/unifont.zip", hz.toByteArray());
        font.put("assets/minecraft/font/include/unifont.json", utf8("{\"providers\":[{\"type\":\"unihex\",\"hex_file\":\"minecraft:font/unifont.zip\",\"size_overrides\":[{\"from\":\"\\u4e00\",\"to\":\"\\u9fff\",\"left\":0,\"right\":15,},],},]}"));
        File fj = new File(dir, "font.jar"); zip(fj, font);
        File ttf = new File(dir, "minecraft.ttf"); ttf.delete();
        int glyphs = MinecraftFont.build(fj, ttf, () -> {});
        check(glyphs >= 95 && ttf.length() > 1000, "font written: " + glyphs);
        byte[] b = java.nio.file.Files.readAllBytes(ttf.toPath());
        check(b[0] == 0 && b[1] == 1 && b[2] == 0 && b[3] == 0, "TrueType signature");
        check(MinecraftFont.TrueType.checksum(b) == 0xB1B0AFBA, "whole-font checksum");
        // Glyph metrics from the sources (via the internal model): 'A' 3 px + 1, space 4 px, 中 8 px + 1.
        check(advance(fj, 'A') == 4 * MinecraftFont.UNIT, "bitmap advance = inked width + 1");
        check(advance(fj, ' ') == 4 * MinecraftFont.UNIT, "space advance");
        check(advance(fj, 0x4E2D) == 9 * MinecraftFont.UNIT, "unifont at half scale with override");
        check(advance(fj, 0x0100) == (6 * MinecraftFont.UNIT / 2) + MinecraftFont.UNIT, "narrow unifont glyph");
        // Outline: a 3×8 block is one rectangle (4 corners).
        MinecraftFont.Glyph block = new MinecraftFont.Glyph('A', 4, 8, blockBits(), MinecraftFont.UNIT, 0, MinecraftFont.ASCENT, 4 * MinecraftFont.UNIT);
        List<int[]> c = MinecraftFont.outline(block);
        check(c.size() == 1 && c.get(0).length == 8, "rectangle outline");
        // Clockwise in y-up (signed area < 0 by the shoelace formula).
        check(area(c.get(0)) < 0, "outer contour clockwise");
        System.out.println("Core1021Test OK (" + checks + " checks)");
    }
    private static boolean[] blockBits() { boolean[] on = new boolean[32]; for (int y = 0; y < 8; y++) for (int x = 0; x < 3; x++) on[y * 4 + x] = true; return on; }
    private static long area(int[] p) { long s = 0; for (int i = 0; i < p.length; i += 2) { int j = (i + 2) % p.length; s += (long) p[i] * p[j + 1] - (long) p[j] * p[i + 1]; } return s; }
    /** Reads the advance of [cp] back from the font file (cmap format 4 + hmtx). */
    private static int advance(File jar, int cp) throws IOException {
        File out = File.createTempFile("mcfont", ".ttf"); out.deleteOnExit();
        MinecraftFont.build(jar, out, () -> {});
        byte[] b = java.nio.file.Files.readAllBytes(out.toPath());
        int num = u16(b, 4); int cmap = -1, hmtx = -1;
        for (int i = 0; i < num; i++) { String tag = new String(b, 12 + i * 16, 4, StandardCharsets.US_ASCII); int off = (int) u32(b, 12 + i * 16 + 8); if (tag.equals("cmap")) cmap = off; if (tag.equals("hmtx")) hmtx = off; }
        int sub = cmap + (int) u32(b, cmap + 8);
        int segX2 = u16(b, sub + 6); int ends = sub + 14, starts = ends + segX2 + 2, deltas = starts + segX2;
        for (int s = 0; s < segX2 / 2; s++) {
            int end = u16(b, ends + s * 2), start = u16(b, starts + s * 2);
            if (cp >= start && cp <= end) { int gid = (cp + (short) u16(b, deltas + s * 2)) & 0xFFFF; return u16(b, hmtx + gid * 4); }
        }
        return -1;
    }
    private static int u16(byte[] b, int o) { return ((b[o] & 255) << 8) | (b[o + 1] & 255); }
    private static long u32(byte[] b, int o) { return ((long) u16(b, o) << 16) | u16(b, o + 2); }
}
