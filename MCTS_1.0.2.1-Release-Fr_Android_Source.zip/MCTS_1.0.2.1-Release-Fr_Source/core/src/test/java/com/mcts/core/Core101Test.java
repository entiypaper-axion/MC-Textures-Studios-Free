package com.mcts.core;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import static com.mcts.core.MaterialDocument.Channel.*;

/** 1.0.1 additions: brushes, fill, pixel-perfect revert, undo limit, pack import. */
public final class Core101Test {
    private static int passed;
    static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); passed++; }
    static int count(boolean[] mask) { int c = 0; for (boolean b : mask) if (b) c++; return c; }
    public static void main(String[] args) throws Exception {
        // Brush footprints
        check(PixelTools.brushOffsets(1, false).length == 2, "1px brush");
        check(PixelTools.brushOffsets(3, false).length == 18, "3px square");
        check(PixelTools.brushOffsets(3, true).length == 10, "3px round is a plus (5 px)");
        check(PixelTools.brushOffsets(8, false).length == 128, "8px square");
        check(PixelTools.brushOffsets(99, false).length == 128, "brush clamps to 8");
        int[] four = PixelTools.brushOffsets(4, true); check(four.length / 2 == 12, "4px round drops corners: " + four.length / 2);
        // Fill
        int[] px = new int[16]; Arrays.fill(px, 0xff000000); px[5] = 0xffffffff; px[6] = 0xffffffff; px[15] = 0xffffffff;
        check(count(PixelTools.fillMask(px, 4, 4, 1, 1, 0, true)) == 2, "contiguous fill");
        check(count(PixelTools.fillMask(px, 4, 4, 1, 1, 0, false)) == 3, "global fill");
        int[] near = {0xff101010, 0xff121212, 0xff808080, 0xff111111};
        check(count(PixelTools.fillMask(near, 4, 1, 0, 0, 1, true)) == 2, "tolerance 1% stops at grey");
        check(count(PixelTools.fillMask(near, 4, 1, 0, 0, 1, false)) == 3, "tolerance global");
        check(count(PixelTools.fillMask(new int[]{0x00ff0000, 0x0000ff00}, 2, 1, 0, 0, 0, true)) == 2, "transparent pixels match");
        // Elbow
        check(PixelTools.isElbow(0, 0, 1, 0, 1, 1), "elbow detected");
        check(!PixelTools.isElbow(0, 0, 1, 0, 2, 0), "straight line is not an elbow");
        // Stroke revert and transparent erase
        MaterialDocument doc = new MaterialDocument("stone", MaterialDocument.Kind.BLOCK, 16, 16);
        doc.fill(0, COLOR, 0xff336699);
        doc.beginStroke(0, COLOR); doc.paint(1, 1, 0x00000000); doc.paint(2, 1, 0xffffffff);
        check(doc.revertStrokePixel(2, 1), "revert touched pixel");
        check(!doc.revertStrokePixel(3, 3), "untouched pixel not reverted");
        doc.endStroke();
        int[] c = doc.composite(COLOR);
        check(c[16 + 1] == 0, "erase makes pixel transparent");
        check(c[16 + 2] == 0xff336699, "reverted pixel restored");
        doc.undo(); check(doc.composite(COLOR)[17] == 0xff336699, "stroke undo after revert");
        check(doc.layerPixels(0, COLOR)[0] == 0xff336699, "layer pixel copy");
        check(doc.layerPixels(0, HEIGHT)[0] == 0xff808080, "default plane copy");
        // Undo limit
        doc.setUndoLimit(3);
        for (int i = 0; i < 6; i++) { doc.beginStroke(0, COLOR); doc.paint(i, 0, 0xff000000 + i); doc.endStroke(); }
        int undos = 0; while (doc.canUndo()) { doc.undo(); undos++; }
        check(undos == 3, "undo limit keeps 3, got " + undos);
        // Pack import (Java + Bedrock + edition mismatch + zip-slip)
        Path dir = Files.createTempDirectory("core101");
        File java = dir.resolve("pack.zip").toFile();
        byte[] png = Png.rgba(16, 16, new int[256]);
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(java))) {
            z.putNextEntry(new ZipEntry("MyPack/pack.mcmeta")); z.write("{\"pack\":{\"pack_format\":34,\"description\":\"§aHello pack\"}}".getBytes("UTF-8")); z.closeEntry();
            z.putNextEntry(new ZipEntry("MyPack/assets/minecraft/textures/block/stone.png")); z.write(png); z.closeEntry();
            z.putNextEntry(new ZipEntry("MyPack/assets/minecraft/textures/block/stone_n.png")); z.write(png); z.closeEntry();
            z.putNextEntry(new ZipEntry("MyPack/assets/minecraft/models/block/x.json")); z.write("{}".getBytes()); z.closeEntry();
        }
        File template = dir.resolve("template.zip").toFile();
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(template))) {
            z.putNextEntry(new ZipEntry("assets/minecraft/textures/block/stone.png")); z.write(Png.rgba(16, 16, new int[256])); z.closeEntry();
            z.putNextEntry(new ZipEntry("assets/minecraft/textures/block/dirt.png")); z.write(png); z.closeEntry();
        }
        File base = dir.resolve("base.zip").toFile();
        PackImport.Result r = PackImport.build(java, true, template, base);
        check(r.imported == 1 && "Hello pack".equals(r.description), "java import " + r.imported + " " + r.description);
        try (ZipFile z = new ZipFile(base)) {
            check(z.getEntry("assets/minecraft/textures/block/dirt.png") != null, "template kept");
            check(z.getEntry("assets/minecraft/textures/block/stone_n.png") == null, "PBR skipped");
            check(z.size() == 2, "no models copied");
        }
        try { PackImport.build(java, false, null, dir.resolve("b.zip").toFile()); check(false, "edition mismatch"); }
        catch (IOException e) { check("PACK_EDITION".equals(e.getMessage()), "edition error " + e.getMessage()); }
        File bedrock = dir.resolve("pack.mcpack").toFile();
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(bedrock))) {
            z.putNextEntry(new ZipEntry("manifest.json")); z.write("{\"header\":{\"name\":\"BR\",\"description\":\"d\"}}".getBytes("UTF-8")); z.closeEntry();
            z.putNextEntry(new ZipEntry("textures/blocks/stone.png")); z.write(png); z.closeEntry();
            z.putNextEntry(new ZipEntry("textures/blocks/stone_mer.png")); z.write(png); z.closeEntry();
        }
        PackImport.Result rb = PackImport.build(bedrock, false, null, dir.resolve("bb.zip").toFile());
        check(rb.imported == 1 && "BR".equals(rb.name), "bedrock import");
        File evil = dir.resolve("evil.zip").toFile();
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(evil))) {
            z.putNextEntry(new ZipEntry("../assets/minecraft/textures/block/stone.png")); z.write(png); z.closeEntry();
        }
        try { PackImport.build(evil, true, null, dir.resolve("e.zip").toFile()); check(false, "zip slip"); }
        catch (IOException e) { check("PACK_INVALID".equals(e.getMessage()), "zip slip rejected"); }
        System.out.println("Core101Test passed " + passed + " checks");
    }
}
