# MCTS Free 3.0.8-Fr

本次是 3.0.7-Fo 的改进更新。版本码 30800；包名继续使用 `com.axion.pompreview.studio3.free`，与 Plus 和 Ultra 不同，项目数据各自保存。本版延续 3.0.7-Fo 的签名，可覆盖该版升级；没有找到旧 3.0.6-Fo 签名密钥的历史情况仍不变。本源码只发布 Free 构建变体，未发布新 Plus/Ultra。

## 本轮修正

- Free 自绘消息卡片增加生命周期计时，普通消息约 4 秒自动关闭，长消息约 10 秒；遵循系统无障碍推荐时长。点击仍可提前关闭。新消息替换旧消息，切换开始界面／工作台后继续拥有关闭逻辑。
- 导出页固定说明只导出颜色与相关资源，不生成法线、MER、高度或 LabPBR 数据；导出包内报告同样明确版本与范围。
- 按钮、标签、颜色样本、复选和单选增加 80ms、0.97 倍轻微按压反馈及淡化，无弹簧、转场或装饰动画。透明模式也能看到按压变化。
- 统一 Free 功能策略，在 UI 和操作入口检查通道、模型导入／绘画、玻璃、视频壁纸及弹簧动效能力。被拒绝的公开操作显示提示，不仅依赖隐藏按钮。
- 文楷和 Monocraft 按应用界面五种语言、模板译名、数字与符号的实际用字裁剪，保留字体许可，并按 OFL 重命名为 MCTS WenKai / MCTS Pixel。字体统计见 assets/fonts/subset-report.json。用户自定义名称等未包含字符由 Android 系统字体回退；导入的自定义字体不会被裁剪。
- 修复仅按 `_normal`、`_n`、`_s` 后缀判断 PBR 时误删正常颜色素材的问题：保留活塞、铁轨、砂岩、书、矿车、UI 等已知原版颜色名称，以及 Java 粒子字母贴图。

## 开始界面与按需下载

APK 不再包含十个官方纹理 ZIP。Free 每次打开有开始界面，可以选择 Java／基岩及版本，点击下载所选模板，准备完成后命名并创建项目，也可以继续现有本地项目。其他版本在开始界面按需下载，不会首次一次性下载全部。

支持的目标版本与 3.0.7 保持相同：Java 1.16.5 / 1.20.1 / 1.21.1 / 1.21.11 / 26.2；基岩 1.16.200 / 1.20.0 / 1.21.20 / 1.21.130 / 26.30。Java 来自 Mojang 固定 client.jar；基岩来自 Mojang bedrock-samples 固定标签，1.16.200 使用 bedrock-dot-dev 的历史样例归档。下载源和 SHA-256 见 assets/templates/sources.json。

由于用户选择了应用内下载，本版保留 INTERNET 权限。设置说明已改为“下载模板时联网，编辑、保存和导出可离线使用”。下载的是原始官方文件，体积约 18–155MB，可能明显大于处理后的模板；界面显示进度、已下载数据、取消、原因与重试。请为下载、处理、缓存和项目副本预留空间。

下载只在用户点击后执行，工作在 IO 线程；定期同步下载数据到磁盘。支持服务器允许的 HTTP Range 续传；若服务器不支持则重新下载，不拼接错误内容。下载完成后校验原始 SHA-256，再提取颜色 PNG/TGA 与相关 metadata。TGA 转为 PNG 保持像素一致；官方样例中一个实际是 JPEG 的 legacy PNG 文件原样保留。处理文件和就绪标记先暂存并校验后替换，不使用半截模板；成功后删除原始下载，保留可离线用的颜色模板。重试会校验缓存，损坏缓存不能用于新建项目。

升级不重写现有项目的 base.zip 或编辑文件，因此已创建项目可直接继续离线使用。创建另一个同版本模板项目仍需要有有效缓存；没有缓存时在开始界面下载。APK 内的跨版本重复资源随内置纹理一并移除，本版没有宣称对所有本地项目副本做跨项目去重。

## Free 边界

颜色编辑、调色盘／取色器、图层、撤销／重做、网格、16–512、模板、多项目、只读立体预览及颜色资源包导出保持原范围。保留默认关闭的透明模式、静态背景、字体设置。没有新增 PBR、模型绘画、玻璃、视频壁纸、云同步或发布服务。预览不替代实际 Minecraft 验证。

## 构建与验证

JDK 17、Android SDK platform 35/build-tools 35.0.0，Gradle Wrapper 8.11.1，需要 Google Maven 和 Maven Central。最低 Android 8.0 / GLES 3.0。

```sh
./gradlew :app:assembleFreeRelease :app:lintFreeRelease
ANDROID_HOME=/your/android-sdk bash test-free-polish.sh
```

需要复跑所有旧项目和模板分类对照时，将 3.0.7 源码内的 templates 目录传入 `MCTS_TEMPLATE_FIXTURES`。源码中不复制这些官方纹理。Linux 配套 Mesa EGL/GLES 后设 `MCTS_TEST_MESA=1` 可复跑主机着色器检查。

```sh
ANDROID_HOME=/your/android-sdk MCTS_TEMPLATE_FIXTURES=/path/to/3.0.7/app/src/main/assets/templates MCTS_TEST_MESA=1 bash test-free-polish.sh
```

正式签名通过 `MCTS_SIGNING_KEY` 和 `MCTS_SIGNING_PASSWORD` 环境变量传入，别名 mcts，私钥和密码不在公开源码内。未配置时是本机调试密钥，不能覆盖本次正式签名包。Free 原有私钥备份继续适用。

字体调整文案后重新运行 tools/subset_fonts.py；可传原字体目录，或先用 tools/fetch_fonts.py 取回原始开源字体再裁剪。旧 tools/build_templates.py 已停用，避免误把官方纹理重新塞进 APK。

验证详情见 VALIDATION_3.0.8-Fr.md。本次主机测试不等同于 Android 真机的安装、通知计时、手势、GPU 或无障碍验证。
