# 验证 — Free 1.0.2.1-Release-Fr

这个环境里没有 Android SDK 和 Gradle，也没有真机，所以没有构建 APK。以下检查都是离线完成的。

- **整个 app 模块的类型检查：0 个错误。**
  - 检查方式：用 kotlinc 和 javac 编译 Java 核心、全部 Kotlin/Java 源码和生成的 BuildConfig/R，依赖换成 Android 和 Compose 的存根。
  - 新用到的接口都按 Compose 1.8 的真实源码补了存根：GraphicsLayer、record、drawLayer、rememberGraphicsLayer、modifierLocal、currentCompositeKeyHash。
  - 新增的 `Free1021Test` 和改过的 `Free102Test` 也通过了类型检查。
- **核心测试（`test-core.sh`）全部通过**：CoreTest 83 项、Core101Test 28 项、Core102Test 20 项、Core1021Test 16 项（新增）。Core1021Test 覆盖：
  - 模型附带文件只保留模型和方块状态 JSON；基岩版路径会被统一整理。
  - 从 jar 生成字体：位图字宽度、空格宽度、Unifont 半格宽度和宽度覆盖规则、TrueType 整体校验和、外形方向。
- **用真实的 1.21.4 官方模型和贴图在 JVM 上渲染了 30 种方块的预览**，台阶、楼梯、门、火把、栅栏、墙、玻璃板、草方块、花、灯笼、活板门、蛋糕、铁砧、漏斗、熔炉、箱子、潜影盒、告示牌、床等，逐张看图，和游戏一致。
- **`Free1021Test` 里的模型用例在真实 JVM 上通过**：
  - 台阶侧面取的是贴图下半部分。
  - 门的上下两半都画出来，高 32 像素。
  - 草方块侧面的叠加层正确识别。
- **用真实的 1.21.4 字体数据生成了字体**：57126 个字符，10.9 MB。
  - fontTools 能完整读取并重新保存。
  - Java2D 渲染了中英日韩俄希混排文字，逐张看图，和游戏的像素字一致。

**没有验证的部分：**
- 真机上的键盘焦点。
- 液态玻璃在具体 GPU 上的实时效果和耗电，包括 RenderEffect 模糊叠加 AGSL 着色器的效果。
- Robolectric 测试的实际运行，这需要 Gradle 环境。
