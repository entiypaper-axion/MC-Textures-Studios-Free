# 本次发布验证 — Free 1.0.0-Release-Fr

## 验证范围

- 三个 Release APK 均完成构建、发布关键 lint、ZIP 全条目 CRC 校验和 v2 / v3 签名验证；均为非调试构建，最低 Android 8.0。
- Robolectric / Compose 模拟 Android 8.0（API 26）与 Android 15（API 35）：Free 30 项，Plus 10 项，Ultra 10 项，全部通过。
- 全屏绘画测试实际操作宽屏与窄屏的撤销 / 重做按钮，校验像素恢复与新笔划清空重做历史。
- 导出合同测试检查 Java / 基岩的 MIME、系统文件名及 DocumentsUI 扩展名保留逻辑。
- Free 另验证镜像笔划、矩形贴图、项目复制隔离、删除恢复、真实 PNG 的修改统计、诊断字段、主题与最近颜色偏好记忆，以及 200% 字体下常用按钮的可达性。
- 三版 Java 核心各通过 83 项检查；Ultra 模型 / 体素核心另通过 2775 项检查。
- Free 扩展检查：20239 项基础打磨、427 项画板几何、66 项模板归档、4 项错误包拒绝、19 项下载生命周期、13 项渲染器上传适配。旧模板完整工程夹具测试未运行：需要额外配置历史模板夹具，源码与 Free APK 均不夹带这些资源。

以上是构建与模拟测试结果。没有完成真实安卓设备安装与触摸体验、Android 原生 GPU 全场景、OEM 文件管理器或 Minecraft 游戏内导入验证；不宣称已经实机验证。

## 安装包元数据

```json
{
  "edition": "free",
  "applicationId": "com.axion.pompreview.studio3.free",
  "versionName": "1.0.0-Release-Fr",
  "versionCode": 31000,
  "minSdk": 26,
  "bytes": 10960436,
  "sha256": "2f20c313196c878006f9268fed597eeb7f33377e1aeb72c3f93403069421b978",
  "certificate_sha256": "32a0895b3447b0d404d54c545ee0b6009d4542ff38f02a15504c0c21bf0c6ff6",
  "v2_v3_signature_verified": true,
  "release_not_debuggable": true,
  "zip_crc_verified": true,
  "template_zips": 0,
  "release_android_tests": {
    "tests": 30,
    "failures": 0,
    "errors": 0,
    "skipped": 0
  }
}
```
