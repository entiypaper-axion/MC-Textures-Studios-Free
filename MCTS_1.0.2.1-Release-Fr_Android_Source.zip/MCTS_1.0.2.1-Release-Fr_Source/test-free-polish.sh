#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash test-core.sh
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -cp build/core-test -d build/core-test verification/FreePolishTest.java verification/CanvasGeometryTest.java verification/TemplateArchiveTest.java
java -cp build/core-test FreePolishTest
java -cp build/core-test CanvasGeometryTest
java -cp build/core-test TemplateArchiveTest
python3 verification/test_template_gate.py
if [[ -n "${MCTS_TEMPLATE_FIXTURES:-}" ]]; then
  python3 verification/catalogue_test.py
fi
python3 verification/run.py '' freeRelease
sdk_path="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$sdk_path" || ! -f "$sdk_path/platforms/android-35/android.jar" ]]; then
  echo 'Set ANDROID_HOME to your Android SDK for the renderer adapter test.' >&2
  exit 1
fi
mkdir -p build/renderer-test
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -cp "$sdk_path/platforms/android-35/android.jar" -d build/renderer-test \
  verification_renderer/android/opengl/GLES30.java verification_renderer/android/opengl/Matrix.java \
  app/src/main/java/com/axion/pompreview/PreviewGeometry.java \
  app/src/main/java/com/axion/pompreview/PreviewHitTest.java \
  app/src/main/java/com/axion/pompreview/PomRenderer.java verification_renderer/RendererUploadTest.java
java -cp "build/renderer-test:$sdk_path/platforms/android-35/android.jar" com.axion.pompreview.RendererUploadTest
if [[ "${MCTS_TEST_MESA:-0}" == "1" ]]; then
  python3 verification_gl/shader_check.py
fi
python3 tools/verify_package.py app/build/outputs/apk/free/release/app-free-release.apk
