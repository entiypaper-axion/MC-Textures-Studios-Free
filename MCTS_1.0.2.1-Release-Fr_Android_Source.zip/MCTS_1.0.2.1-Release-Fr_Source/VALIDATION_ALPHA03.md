# Alpha03 verification — 2026-09-26

- Release build: `:app:assembleRelease :app:lintRelease` — BUILD SUCCESSFUL.
- Lint: 0 errors, 23 warnings. Full report: validation/lint-alpha03.txt. Warnings remain; they are not device test results.
- Core JVM checks: 83 passed.
- Compiled release Kotlin project/template export integration: 122 passed with JVM file/image adapters. These cover all 10 targets, isolation, original paths, edited/unedited texture output, stable UUIDs, metadata and historical Bedrock PBR gating.
- Python negative template regression checks: 4 passed (tmp, part, truncation, changed bytes).
- Actual Gradle pre-build gate: an intentionally injected .zip.tmp caused the expected build failure. Fixture removed afterward. This tests the build gate, not just the standalone script.
- Final APK outer CRC and all ten embedded archives: SHA256, CRC and PNG count passed. Exactly 34,838 PNG textures. Zero .tmp/.part entries. The former six staging files (38,419,281 bytes) are gone.
- Both bundled fonts parse successfully with fontTools; embedded font/license bytes match recorded SHA256. Monocraft: 1,475 cmap entries. WenKai: 46,490. These are open-source alternatives, not official game font files.
- APK signing verified with v2 and v3. Certificate SHA256: e5fd9c926f8ccce3cd2697ac4819dc3ad7ffbbff30b3b02a6672f0a9006231d7, identical to alpha02. Details: validation/signature-alpha03.txt.
- AAPT confirms package com.axion.pompreview.studio3, versionCode 30004, versionName 3.0.0-alpha03, min SDK 26, target SDK 35; release is not debuggable.
- `zipalign -c -P 16 4` passed.
- APK size: 110373088 bytes.
- APK SHA256: 1944dab904a340b36a81e1fe68cda2356a53ea79ca2e2f9a5a4f1d3108cca697

No device or emulator installation/rendering test was available. Live GPU effects, font/image pickers, animation feel and OEM installer behavior still need real-device verification. No claim of completed UI or in-game compatibility testing is made.

## On-device smoke checks

Install directly over alpha02, confirm existing projects still appear. Open Settings → Appearance; select a bundled font, resize text, change ink, choose a gradient/photo, close and reopen the app. Verify choices persist. Import an invalid font/image and confirm the previous selection survives. Test reduced motion and high contrast, paint with the palette and eyedropper, resize the two regions, switch projects and export.

## Reproduce

Run `bash test-core.sh`; `python3 verification/test_template_gate.py`; the Gradle release build; `python3 verification/run.py /path/to/json-20240303.jar release`; and `python3 tools/verify_package.py /path/to/app-release.apk`.
