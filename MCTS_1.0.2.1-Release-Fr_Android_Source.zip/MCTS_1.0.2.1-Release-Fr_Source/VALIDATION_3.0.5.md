# 3.0.5 验证记录

- `:app:assembleRelease :app:lintRelease`：成功；Lint 报 28 条非阻断警告，无错误。
- `test-core.sh`：83 项核心数据、历史、导出、PNG 校验通过。
- 项目与模板 Kotlin 实现通过 JVM 适配器：122 项检查，覆盖十套配置的独立项目、编辑导出、版本元数据及隔离性。
- 像素触点回归：19 项检查，覆盖 16、32、64、128、256、512 分辨率及旋转和植物形状。图层保留的 16→512→16 缩放通过。
- 模板污染负向回归：四项截断/改写/临时文件检查；发布 APK 十套模板 SHA256 和 ZIP CRC、34,838 个 PNG 均通过，无 `.tmp` / `.part`。
- `zipalign -c -P 16 4` 及 `apksigner verify` 通过。包名 `com.axion.pompreview.studio3`，版本 `3.0.5` / `30500`，证书 SHA256 `e5fd9c926f8ccce3cd2697ac4819dc3ad7ffbbff30b3b02a6672f0a9006231d7`。
- 未连接 Android 真机或模拟器；视频播放、官方模型下载、GPU 着色及手势动画为编译与静态检查，尚无设备端验证。
