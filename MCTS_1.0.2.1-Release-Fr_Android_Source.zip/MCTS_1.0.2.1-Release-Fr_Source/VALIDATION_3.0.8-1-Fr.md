# 3.0.8-1-Fr 验证记录

日期：2026-10-06。版本码 30801；包名 com.axion.pompreview.studio3.free。基于 3.0.8-Fr 的窗口和导出修复。

| 检查 | 结果 | 验证范围 |
| --- | --- | --- |
| assembleFreeRelease / lintFreeRelease / testFreeDebugUnitTest | 构建成功 | 0 lint error，28 warning |
| Free 窗口 Compose 回归 | 8 项通过 | API 26/35；长正文关闭按钮、焦点 Dialog 的系统返回、外部点击、内部点击、高对比度旧值忽略 |
| 导出 Android 回归 | 6 项通过 | API 26/35；实际 CreateDocument Intent、FileUtils 文件名处理、取消、返回 URI、5 个基岩目标的实际资源包 |
| 编辑与导出核心 | 83 项通过 | JVM |
| 连续画笔、历史、取消、缓存、保存与透明度 | 20239 项通过 | JVM 逻辑 |
| 画板坐标和边界 | 427 项通过 | 16–512 与缩放、移动 |
| 模板准备事务、TGA、路径和 Free 策略 | 66 项通过 | JVM |
| 下载生命周期 | 13 项通过 | 实际编译 Kotlin，记录式 HTTP 适配器；取消、续传、就绪原子化、离线复用、损坏缓存、哈希错误 |
| 模板打包门禁反向检查 | 4 项通过 | 拒绝临时文件、内置纹理 ZIP、无效源哈希 |
| APK 签名 | v2/v3 通过 | 同 3.0.7-Fo / 3.0.8-Fr 的 Free 正式证书 |
| APK 完整性／对齐 | CRC、zipalign -P 16 通过 | 对齐检查不等同于所有 16 KiB 真机的兼容性验证 |
| APK 内容 | 通过 | 字体哈希对应当前用字统计，包含新版关闭和导出代码，无官方纹理 ZIP 和打包残留 |

Robolectric 是主机上的 Android 测试实现，不是 Android Emulator 或真机。Compose 测试使用生产 StudioSheet，导出测试使用生产 ExportPackDocument 与 Projects.export。导出测试检查 root manifest.json、resources 模块、项目 UUID、颜色 PNG、无嵌套 ZIP 和无 PBR 通道；文件选择器测试调用 Android 的实际 FileUtils.splitFileName 实现。

正式 APK：10,877,753 字节（约 10.88 MB）。签名证书 SHA-256：32a0895b3447b0d404d54c545ee0b6009d4542ff38f02a15504c0c21bf0c6ff6。

文楷：25,575,676 → 682,980 字节，应用 1625 个用字的交集保留 1624 个 codepoint，另一字符由系统回退。Monocraft：210,192 → 44,700 字节，保留 127 个 codepoint，其余系统回退。关闭文案的中文、英语、日语、法语、西班牙语字形已核对。

本次未重跑未修改的十个官方源下载、旧模板逐像素对照、目录翻译和 GPU 渲染测试。以前版本的结果保留在各历史 VALIDATION 文档，不能当成本轮真机检查。由于源码不内置官方纹理，旧全模板项目测试仍需 MCTS_TEMPLATE_FIXTURES；本次未运行该可选旧素材检查。

仍需用户真机核验：安装覆盖升级、各厂商文件选择器实际文件名、手势与预测返回、横屏／键盘／大字号、Minecraft 导入结果。未进行游戏内验证。
