# 3.0.7-Fo 验证记录

验证日期：2026-10-06。交付为 `freeRelease`，版本名 3.0.7-Fo，版本码 30700，包名 com.axion.pompreview.studio3.free。

| 检查 | 结果 | 边界 |
| --- | --- | --- |
| Gradle assembleFreeRelease、lintFreeRelease | 成功 | Lint 0 error，28 warning，主要为 UseKtx；另有 ExifInterface、DataExtractionRules、IconLauncherShape、ClickableViewAccessibility |
| 原文档／导出核心 | 83 项通过 | JVM |
| Free 绘制、撤销、取消笔划、缓存、存储、透明度历史回归 | 20239 项通过 | 文档和笔划逻辑，不是 Android 触摸派发 |
| 画板统一几何、16–512、缩放边界 | 427 项通过 | JVM |
| 10 个项目模板的真实 Kotlin 集成导出 | 177 项通过 | JVM 文件／图片适配；包含 512 分辨率保存面绑定和 Free 无 PBR 导出 |
| 方块分类、面绑定、翻译 | 9633 项通过 | 数据检查 |
| 模板残留构建门禁 | 4 项反向检查通过 | 人为加入残留／损坏数据验证拒绝 |
| 生产渲染器更新调度 | 13 项通过 | 记录式 GLES 适配器；局部更新、不重复上传、分辨率、行方向、上下文恢复 |
| 生产着色器编译／网格／面采样 | 9 项通过 | 主机 Mesa GLES，非 Android GPU |
| APK 模板完整性 | 10 个模板，41544 PNG，SHA-256/CRC 通过 | 无 tmp/part 残留 |
| APK 签名和 ZIP 对齐 | v2/v3 通过；16 KiB 页面参数的 zipalign 检查通过 | 不表示所有原生库已在 16 KiB Android 设备实测 |

新 Free 签名证书 SHA-256：`32a0895b3447b0d404d54c545ee0b6009d4542ff38f02a15504c0c21bf0c6ff6`。与原 3.0.6-Fo 签名不同，不能直接覆盖旧 Free，安装前请按 README 备份。

未验证：Android 真机安装、连续触摸／多指竞争、竖屏及横屏实际显示、键盘和读屏操作、真实 GPU 性能及兼容性、后台恢复、Minecraft Java／基岩版实际载入。需要内测者重点完成修改→撤销→保存→重开→导出→游戏查看这一链路。测试结果不能替代这些实测。
