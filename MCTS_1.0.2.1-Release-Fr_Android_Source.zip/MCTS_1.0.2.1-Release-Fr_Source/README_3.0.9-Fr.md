# MCTS 3.0.9-Fr

Maintenance update based on 3.0.8-1-Fr. Package: com.axion.pompreview.studio3.free; version code: 30900. Keeps the existing Free signing certificate and remains separate from Plus/Ultra.

Implemented: storage preflight (twice source size); pinned URL lists; two automatic retries per source; HTTP Range resumption; expected-size check before hashing partial files; metered-network confirmation; partial-progress display; about/notices with unofficial statement, Mojang copyright, EULA and both font licenses; per-version cache usage and confirmed deletion; editor reopening for existing projects; remembered template selection.

Retained: popup dismissal, mcpack filename fixes, color-only Free policy and fonts subset to actual UI/catalogue text.

Background downloads may be terminated by Android. The start screen shows retained partial bytes and allows resumption. No foreground service/notification was added.

Bedrock fallback uses the upstream GitHub archive endpoint for the same repository/revision alongside codeload. Both remain dependent on GitHub; this is NOT a domestic CDN. No newly hosted Mojang files or unknown third-party mirror was added. Domestic acceleration requires reliable mirror URLs whose bytes pass the same pinned SHA-256.

Build with JDK 17, Android SDK 35 and Gradle 8.11.1: ./gradlew assembleFreeRelease testFreeDebugUnitTest lintFreeRelease. Supply MCTS_SIGNING_KEY and MCTS_SIGNING_PASSWORD to sign with the existing Free release certificate. Never include signing secrets in public source distributions.

Historical VALIDATION files describe historical builds only. See VALIDATION_3.0.9-Fr.md for this update's actual verification and limits.
