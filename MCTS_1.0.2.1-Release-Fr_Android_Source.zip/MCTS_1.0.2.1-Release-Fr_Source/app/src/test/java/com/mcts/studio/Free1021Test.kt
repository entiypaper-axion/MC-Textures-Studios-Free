package com.mcts.studio

import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** 1.0.2.1: glass switches and tuning, official-model preview meshes. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35])
class Free1021Test {
    @Test fun glassSwitchesAndOverrides(){
        val on=GlassConfig(true,GlassTuning.BIG,GlassTuning.SMALL,emptyMap())
        assertTrue(on.enabled("a",GlassCategory.BIG));assertTrue(on.enabled("a",GlassCategory.SMALL))
        val off=GlassConfig(false,GlassTuning.BIG,GlassTuning.SMALL,mapOf("x" to true,"y" to false))
        assertFalse(off.enabled("a",GlassCategory.SMALL));assertTrue(off.enabled("a",GlassCategory.BIG))
        assertTrue(off.enabled("x",GlassCategory.SMALL));assertFalse(off.enabled("y",GlassCategory.BIG))
        assertEquals(GlassTuning.SMALL,off.tuning(GlassCategory.SMALL))
    }
    @Test fun tuningScalesTheGlass(){
        val d=2f
        val base=glassParams(GlassKind.PANEL,400f,d,true,null,false,GlassTuning.BIG)
        assertEquals(GlassTuning.BIG.blurDp*d,base.blurPx,1e-3f)
        val clear=glassParams(GlassKind.PANEL,400f,d,true,null,false,GlassTuning(0f,0f,0f,0f))
        assertEquals(0f,clear.blurPx,0f);assertEquals(0f,clear.tintAlpha,0f);assertEquals(0f,clear.spec,0f);assertEquals(0f,clear.refraction,0f)
        val strong=glassParams(GlassKind.PANEL,400f,d,true,null,false,GlassTuning(20f,2f,2f,2f))
        assertTrue(strong.tintAlpha>base.tintAlpha&&strong.tintAlpha<=.95f);assertTrue(strong.dispersion>base.dispersion)
    }
    private fun zip(entries:Map<String,String>):File{
        val f=File.createTempFile("models",".zip");f.deleteOnExit()
        ZipOutputStream(f.outputStream()).use{z->entries.forEach{(k,v)->z.putNextEntry(ZipEntry(k));z.write(v.toByteArray());z.closeEntry()}}
        return f
    }
    @Test fun slabUsesTheGameUvs(){
        val f=zip(mapOf(
            "assets/minecraft/blockstates/oak_slab.json" to "{\"variants\":{\"type=top\":{\"model\":\"minecraft:block/oak_slab_top\"},\"type=bottom\":{\"model\":\"minecraft:block/oak_slab\"}}}",
            "assets/minecraft/models/block/oak_slab.json" to "{\"parent\":\"minecraft:block/slab\",\"textures\":{\"bottom\":\"minecraft:block/oak_planks\",\"top\":\"minecraft:block/oak_planks\",\"side\":\"minecraft:block/oak_planks\"}}",
            "assets/minecraft/models/block/slab.json" to "{\"elements\":[{\"from\":[0,0,0],\"to\":[16,8,16],\"faces\":{\"down\":{\"texture\":\"#bottom\"},\"up\":{\"texture\":\"#top\"},\"north\":{\"texture\":\"#side\"},\"south\":{\"texture\":\"#side\"},\"west\":{\"texture\":\"#side\"},\"east\":{\"texture\":\"#side\"}}}]}"))
        val mesh=OfficialModels.mesh(listOf(f),"minecraft:oak_slab")!!
        assertEquals(listOf("assets/minecraft/textures/block/oak_planks.png"),mesh.slots)
        assertEquals(6*21,mesh.quads.size)
        // South face (third face written: down, up, north, south…): top-down v runs 0.5 → 1 (the lower half of the texture).
        val south=mesh.quads.copyOfRange(3*21,4*21)
        val vs=(0..3).map{south[it*5+4]}
        assertEquals(.5f,vs.min(),1e-4f);assertEquals(1f,vs.max(),1e-4f)
        assertEquals(1f,south[20],0f)
    }
    @Test fun doorDrawsBothHalvesAndOverlaysAreComposited(){
        val f=zip(mapOf(
            "assets/minecraft/blockstates/oak_door.json" to "{\"variants\":{\"facing=south,half=lower,hinge=left,open=false,powered=false\":{\"model\":\"block/door_bottom\"},\"facing=south,half=upper,hinge=left,open=false,powered=false\":{\"model\":\"block/door_top\"}}}",
            "assets/minecraft/models/block/door_bottom.json" to "{\"textures\":{\"t\":\"block/oak_door_bottom\"},\"elements\":[{\"from\":[0,0,0],\"to\":[16,16,3],\"faces\":{\"north\":{\"texture\":\"#t\"}}}]}",
            "assets/minecraft/models/block/door_top.json" to "{\"textures\":{\"t\":\"block/oak_door_top\"},\"elements\":[{\"from\":[0,0,0],\"to\":[16,16,3],\"faces\":{\"north\":{\"texture\":\"#t\"}}}]}",
            "assets/minecraft/blockstates/grass_block.json" to "{\"variants\":{\"snowy=false\":{\"model\":\"block/grass_block\"}}}",
            "assets/minecraft/models/block/grass_block.json" to "{\"textures\":{\"side\":\"block/grass_block_side\",\"overlay\":\"block/grass_block_side_overlay\"},\"elements\":[{\"from\":[0,0,0],\"to\":[16,16,16],\"faces\":{\"north\":{\"texture\":\"#side\"}}},{\"from\":[0,0,0],\"to\":[16,16,16],\"faces\":{\"north\":{\"texture\":\"#overlay\",\"tintindex\":0}}}]}"))
        val door=OfficialModels.mesh(listOf(f),"minecraft:oak_door")!!
        assertEquals(2,door.slots.size)
        assertEquals(32f,(0 until door.quads.size/21).maxOf{q->(0..3).maxOf{door.quads[q*21+it*5+1]}},1e-4f)
        val grass=OfficialModels.mesh(listOf(f),"minecraft:grass_block")!!
        assertEquals(1,grass.quads.size/21)
        assertEquals("assets/minecraft/textures/block/grass_block_side_overlay.png",grass.overlays[0])
        assertNull(OfficialModels.mesh(listOf(f),"minecraft:missing_block"))
    }
}
