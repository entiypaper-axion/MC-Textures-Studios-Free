package com.mcts.studio
import androidx.activity.ComponentActivity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import com.mcts.core.MaterialDocument
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

/** 1.0.1: tools, profiles, keymap and the redesigned workspace. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35],qualifiers="w1280dp-h800dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class Free101Test {
    @get:Rule(order=0) val host=ComposeHostRule()
    @get:Rule(order=1) val compose=createAndroidComposeRule<ComponentActivity>()
    private lateinit var model:StudioModel
    private fun load(){
        compose.runOnUiThread{model=ViewModelProvider(compose.activity)[StudioModel::class.java];model.changeLanguage(Language.EN)}
        compose.waitUntil(10000){org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();!model.busy}
    }
    private fun pixel(x:Int,y:Int)=model.document.composite(MaterialDocument.Channel.COLOR)[y*model.document.width+x]

    @Test fun eraserPaintsWhiteAndEraseMakesTransparent(){
        load()
        compose.runOnIdle{
            model.chooseColor(0xff336699.toInt());model.selectTool(StudioModel.Tool.PENCIL);model.tapCanvas(1,1)
            assertEquals(0xff336699.toInt(),pixel(1,1))
            model.selectTool(StudioModel.Tool.ERASER);model.tapCanvas(1,1)
            assertEquals(0xffffffff.toInt(),pixel(1,1))
            model.selectTool(StudioModel.Tool.ERASE);model.tapCanvas(1,1)
            assertEquals(0,pixel(1,1) ushr 24)
            model.undo();assertEquals(0xffffffff.toInt(),pixel(1,1))
        }
    }
    @Test fun brushSizeAndFill(){
        load()
        compose.runOnIdle{
            model.selectTool(StudioModel.Tool.PENCIL);model.chooseColor(0xff000000.toInt());model.fill()
            model.changeBrushSize(3);model.chooseColor(0xffff0000.toInt());model.tapCanvas(5,5)
            for(y in 4..6)for(x in 4..6)assertEquals(0xffff0000.toInt(),pixel(x,y))
            assertEquals(0xff000000.toInt(),pixel(7,5))
            model.changeBrushSize(1);model.changeFill(contiguous=true,tolerance=0)
            model.chooseColor(0xff00ff00.toInt());model.selectTool(StudioModel.Tool.FILL);model.tapCanvas(5,5)
            assertEquals(0xff00ff00.toInt(),pixel(4,4));assertEquals(0xff000000.toInt(),pixel(0,0))
            model.changeFill(contiguous=false);model.chooseColor(0xff0000ff.toInt());model.tapCanvas(0,0)
            assertEquals(0xff0000ff.toInt(),pixel(15,15));assertEquals(0xff00ff00.toInt(),pixel(5,5))
        }
    }
    @Test fun profilesAndPairs(){
        // 1.0.2: every Java release 1.0 – 26.3 and every archived Bedrock sample from 1.16.20.
        assertEquals(103,offeredProfiles.count{it.java});assertEquals(51,offeredProfiles.count{!it.java})
        assertNull(profileById("java_164")!!.counterpart())
        assertEquals("bedrock_2650",profileById("java_263")!!.counterpart()!!.id)
        assertEquals("java_263",profileById("bedrock_2650")!!.counterpart()!!.id)
        assertNotNull(profileById("java_1201"));assertFalse(profileById("java_1201")!!.legacy)
        assertEquals(listOf(1,26,50),bedrockEngine("26.50"));assertEquals(listOf(1,21,130),bedrockEngine("1.21.130"))
        assertEquals("assets/minecraft/textures/block/oak_planks.png",LegacyNames.modern("assets/minecraft/textures/blocks/planks_oak.png"))
        assertEquals("assets/minecraft/textures/block/wheat_stage3.png",LegacyNames.modern("assets/minecraft/textures/blocks/wheat_stage_3.png"))
    }
    @Test fun keymapRoundTripAndRebind(){
        val defaults=Keymap.defaults()
        assertEquals(KeyAction.ERASE,defaults.action(KeyChord(android.view.KeyEvent.KEYCODE_E,shift=true)))
        val rebound=defaults.bind(KeyAction.FILL,KeyChord(android.view.KeyEvent.KEYCODE_B))
        assertEquals(KeyAction.FILL,rebound.action(KeyChord(android.view.KeyEvent.KEYCODE_B)))
        assertNull(rebound.chord(KeyAction.PENCIL))
        val reloaded=Keymap.load(rebound.save())
        assertEquals(KeyAction.FILL,reloaded.action(KeyChord(android.view.KeyEvent.KEYCODE_B)))
        assertEquals("Ctrl+Z",defaults.chord(KeyAction.UNDO)!!.label())
    }
    @Test fun workspaceShowsThreeBarGroupsAndMovesCanvas(){
        load()
        compose.runOnIdle{model.continueEditing();model.completeGuide();model.dismissGestureHint()}
        compose.setContent{ProWorkspace(model)}
        compose.waitForIdle()
        for(key in listOf("bar_project","bar_import","bar_export","bar_brush","bar_new","bar_delete","bar_layout","bar_canvas_left","bar_canvas_center","bar_canvas_right",
            "bar_keys","bar_a11y","bar_guide","bar_language","bar_home","bar_feedback","bar_settings"))
            compose.onNodeWithContentDescription(model.p(key)).assertExists()
        compose.onNodeWithContentDescription(model.p("bar_canvas_left")).performClick()
        compose.runOnIdle{assertEquals(StudioModel.CanvasAlign.LEFT,model.canvasAlign)}
        compose.onNodeWithContentDescription(model.p("bar_show_text")).performClick()
        compose.onNodeWithText(model.p("bar_project")).assertExists()
    }
}
