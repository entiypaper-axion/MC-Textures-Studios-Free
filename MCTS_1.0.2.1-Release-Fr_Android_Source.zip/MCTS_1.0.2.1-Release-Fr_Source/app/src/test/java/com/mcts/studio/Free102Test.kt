package com.mcts.studio

import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

/** 1.0.2: all versions, texture packs, custom UI presets, motion and glass parameters. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35])
class Free102Test {
    @Test fun everyListedVersionHasOnePinnedSource(){
        val context=RuntimeEnvironment.getApplication()
        val rows=JSONArray(context.assets.open("templates/sources.json").bufferedReader().use{it.readText()})
        val ids=(0 until rows.length()).map{rows.getJSONObject(it).getString("profile")}
        assertEquals(ids.size,ids.toSet().size)
        assertEquals(gameProfiles.map{it.id}.toSet(),ids.toSet())
        val java=gameProfiles.filter{it.java}.map{it.version}
        assertEquals("1.0",java.first());assertEquals("26.3",java.last())
        for(v in listOf("1.2.5","1.4.7","1.5.2","1.7.10","1.12.2","1.16.5","1.20.6","1.21.10","26.1.2"))assertTrue(v,v in java)
    }
    @Test fun textureEraFlagsAndFormats(){
        assertTrue(profileById("java_1_4_7")!!.atlas);assertTrue(profileById("java_1_5_2")!!.texturePack);assertFalse(profileById("java_1_5_2")!!.atlas)
        assertFalse(profileById("java_1_6_1")!!.texturePack);assertEquals(1,profileById("java_1_6_1")!!.format)
        assertEquals(69,profileById("java_1_21_9")!!.format);assertEquals(84,profileById("java_26_1")!!.format)
        assertEquals("1.0 – 1.4",profileById("java_1_2_5")!!.line);assertEquals("1.21",profileById("java_12111")!!.line)
        assertNull(profileById("java_1_8_8")!!.pair)
        assertNotNull(profileById("bedrock_1_16_20"));assertNotNull(profileById("bedrock_26_40"))
        assertEquals(listOf(1,16,20),bedrockEngine("1.16.20"))
    }
    @Test fun versionLinesAreNewestFirst(){
        val lines=versionLines(true).map{it.first}
        assertEquals("26.3",lines.first());assertEquals("1.0 – 1.4",lines.last())
        assertTrue(lines.indexOf("1.21")<lines.indexOf("1.9"))
    }
    @Test fun catalogueFallbackIsNearestOfSameEdition(){
        assertEquals("java_1165",catalogueFor("java_1_8_8"))
        assertEquals("java_12111",catalogueFor("java_1_21_10"))
        assertEquals("java_262",catalogueFor("java_26_1"))
        assertEquals("bedrock_116200",catalogueFor("bedrock_1_16_20"))
        assertTrue(isLegacyJava("java_1_12_1"));assertFalse(isLegacyJava("java_1_13"))
    }
    @Test fun layoutPresetsRoundTripAndStayOnScreen(){
        val dir=File(RuntimeEnvironment.getApplication().cacheDir,"layout-test").apply{deleteRecursively();mkdirs()}
        val store=LayoutStore(File(dir,"layouts.json"))
        val land=seedLayout("A",1280f,800f);val port=seedLayout("B",400f,860f)
        for(spec in listOf(land,port))for(b in Block.entries){val r=spec.rect(b)
            assertTrue("$b",r.x>=-.001f&&r.y>=-.001f&&r.x+r.w<=1.001f&&r.y+r.h<=1.001f)}
        store.put(true,land);store.put(false,port)
        assertTrue(store.rename(true,"A","Wide"))
        val reloaded=LayoutStore(File(dir,"layouts.json"))
        assertEquals("Wide",reloaded.active(true)!!.name);assertEquals(land.rect(Block.CANVAS),reloaded.active(true)!!.rect(Block.CANVAS))
        assertEquals("B",reloaded.active(false)!!.name)
        val (imported,landscape)=LayoutStore.import(LayoutStore.export(reloaded.active(true)!!,true))
        assertTrue(landscape);assertEquals(Block.entries.toSet(),imported.order.toSet())
        reloaded.select(true,null);assertNull(reloaded.active(true))
        try{LayoutStore.import("{\"mcts_layout\":2}".toByteArray());fail()}catch(e:java.io.IOException){}
    }
    @Test fun motionAndGlassNumbers(){
        assertEquals(.12f,ProMotion.bulge(40f),1e-4f);assertEquals(.03f,ProMotion.bulge(400f),1e-4f)
        assertTrue(GlassBlur.boxRadius(12f) in 9..13);assertEquals(0,GlassBlur.boxRadius(.2f))
        val px=IntArray(64*64){if(it%64<32)0xff000000.toInt() else 0xffffffff.toInt()}
        GlassBlur.blur(px,64,64,4f);val mid=px[32*64+32] and 255;assertTrue(mid in 60..200)
        val icon=glassParams(GlassKind.ICON,120f,2.75f,true,null,false,GlassTuning.SMALL);assertEquals(60f,icon.bevel,1e-3f)
        assertTrue(icon.blurPx<glassParams(GlassKind.PANEL,800f,2.75f,true,null,false,GlassTuning.BIG).blurPx)
    }
}
