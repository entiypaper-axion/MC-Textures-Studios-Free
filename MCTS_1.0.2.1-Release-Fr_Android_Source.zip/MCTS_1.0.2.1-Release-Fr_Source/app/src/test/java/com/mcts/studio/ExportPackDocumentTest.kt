package com.mcts.studio

import android.app.Activity
import android.content.Intent
import android.net.Uri
import com.mcts.core.MaterialDocument
import java.io.File
import java.util.zip.ZipFile
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35])
class ExportPackDocumentTest {
    @Test fun bedrockPickerPreservesMcpackWithoutZipMime() {
        val intent = ExportPackDocument().createIntent(RuntimeEnvironment.getApplication(), "MCTS_Project.mcpack")
        assertEquals(Intent.ACTION_CREATE_DOCUMENT, intent.action)
        assertEquals("MCTS_Project.mcpack", intent.getStringExtra(Intent.EXTRA_TITLE))
        assertEquals("application/octet-stream", intent.type)
        // Exercise Android's actual filename handling used by ExternalStorageProvider.
        val parts = Class.forName("android.os.FileUtils").getDeclaredMethod("splitFileName", String::class.java, String::class.java)
            .invoke(null, intent.type, intent.getStringExtra(Intent.EXTRA_TITLE)) as Array<*>
        assertEquals("MCTS_Project", parts[0])
        assertEquals("mcpack", parts[1])
    }

    @Test fun javaKeepsZipAndCancelledPickerHasNoDestination() {
        val contract = ExportPackDocument()
        val intent = contract.createIntent(RuntimeEnvironment.getApplication(), "MCTS_Project.zip")
        assertEquals("application/zip", intent.type)
        assertEquals("MCTS_Project.zip", intent.getStringExtra(Intent.EXTRA_TITLE))
        assertNull(contract.parseResult(Activity.RESULT_CANCELED, null))
        val uri = Uri.parse("content://test/pack.mcpack")
        assertEquals(uri, contract.parseResult(Activity.RESULT_OK, Intent().setData(uri)))
    }

    @Test fun exportedBedrockHasRootManifestAndColorTextureRatherThanNestedZip() {
        val context = RuntimeEnvironment.getApplication()
        val projects = Projects(context)
        gameProfiles.filter { !it.java }.forEach { profile ->
            val project = projects.create("Mcpack regression", profile, false)
            val document = MaterialDocument("stone", MaterialDocument.Kind.BLOCK, 16, 16)
            document.fill(0, MaterialDocument.Channel.COLOR, 0xff347abc.toInt())
            projects.store(project).save(document)
            val output = File(context.cacheDir, "${profile.id}.mcpack")
            projects.export(project, output, true)
            ZipFile(output).use { zip ->
                val manifest = JSONObject(zip.getInputStream(zip.getEntry("manifest.json")).bufferedReader().use { it.readText() })
                assertEquals(2, manifest.getInt("format_version"))
                assertEquals("resources", manifest.getJSONArray("modules").getJSONObject(0).getString("type"))
                assertEquals(project.header, manifest.getJSONObject("header").getString("uuid"))
                assertFalse(manifest.has("capabilities"))
                val color = zip.getInputStream(zip.getEntry("textures/blocks/stone.png")).use { it.readBytes() }
                assertTrue(color.size > 24)
                assertArrayEquals(byteArrayOf(-119,80,78,71,13,10,26,10), color.copyOf(8))
                assertFalse(zip.entries().asSequence().any { it.name.endsWith(".zip") || it.name.endsWith(".mcpack") })
                assertFalse(zip.entries().asSequence().any { it.name.endsWith("_normal.png") || it.name.endsWith("_mers.png") })
            }
        }
    }
}
