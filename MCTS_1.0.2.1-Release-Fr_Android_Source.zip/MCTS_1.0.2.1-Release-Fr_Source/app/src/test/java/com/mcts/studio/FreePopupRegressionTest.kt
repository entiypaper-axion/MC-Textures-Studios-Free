package com.mcts.studio

import android.app.Application
import androidx.activity.ComponentActivity
import androidx.activity.ComponentDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowDialog

/** Exercises the production Free dialog, including the real pointer-input boundary.
 * Robolectric Compose UI tests, not a phone/emulator or Minecraft test.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35], qualifiers = "w360dp-h640dp")
class FreePopupRegressionTest {
    @get:Rule(order=0) val host=ComposeHostRule()
    @get:Rule(order=1) val compose = createAndroidComposeRule<ComponentActivity>()

    private fun showPopup(longBody: Boolean = false): StudioModel {
        lateinit var model: StudioModel
        compose.runOnUiThread {
            val app = compose.activity.application as Application
            // Also checks that a legacy enabled contrast setting cannot survive removal.
            app.getSharedPreferences("studio3", 0).edit().putBoolean("contrast", true).commit()
            model = ViewModelProvider(compose.activity)[StudioModel::class.java]
            model.changeLanguage(Language.EN)
        }
        compose.setContent {
            var open by remember { mutableStateOf(true) }
            MaterialTheme {
                Text("Workspace")
                if (open) StudioSheet(model, { open = false }, MaterialTheme.colorScheme.surface) {
                    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                        Text("Popup body", Modifier.fillMaxWidth().height(60.dp).clickable { })
                        if (longBody) repeat(60) { Text("Long settings row $it", Modifier.padding(12.dp)) }
                    }
                }
            }
        }
        compose.waitForIdle()
        return model
    }

    @Test fun closeButtonStaysReachableWithLongSettings() {
        showPopup(longBody = true)
        compose.onNodeWithText("Close").assertIsDisplayed().performClick()
        compose.onNodeWithText("Popup body").assertDoesNotExist()
        compose.onNodeWithText("Workspace").assertIsDisplayed()
    }

    @Test fun systemBackReturnsToWorkspace() {
        showPopup()
        // A modal owns a separate window/dispatcher. Back is delivered to that
        // focused dialog, not to the Activity behind it.
        compose.runOnUiThread {
            (ShadowDialog.getLatestDialog() as ComponentDialog).onBackPressedDispatcher.onBackPressed()
        }
        compose.onNodeWithText("Popup body").assertDoesNotExist()
        compose.onNodeWithText("Workspace").assertIsDisplayed()
    }

    @Test fun backdropTapClosesButInnerTapKeepsPopupOpen() {
        showPopup()
        compose.onNodeWithText("Popup body").performTouchInput { click(center) }
        compose.onNodeWithText("Close").assertIsDisplayed()
        // Full-screen dialog root; its top-left corner is outside the centered card.
        compose.onNode(isDialog()).performTouchInput { click(Offset(2f, 2f)) }
        compose.onNodeWithText("Popup body").assertDoesNotExist()
        compose.onNodeWithText("Workspace").assertIsDisplayed()
    }

    @Test fun removedContrastIgnoresOldPreference() {
        assertFalse(showPopup().highContrast)
    }
}
