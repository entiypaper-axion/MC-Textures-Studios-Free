package com.mcts.studio
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.*
import androidx.lifecycle.ViewModelProvider
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35],qualifiers="w360dp-h800dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class FreeExperienceTest {
    @get:Rule(order=0) val host=ComposeHostRule()
    @get:Rule(order=1) val compose=createAndroidComposeRule<ComponentActivity>()
    private lateinit var model:StudioModel
    private fun createModel(full:Boolean=false){
        compose.runOnUiThread{
            model=ViewModelProvider(compose.activity)[StudioModel::class.java];model.changeLanguage(Language.EN)
            if(full){model.dismissGestureHint();model.changeHandMode(StudioModel.HandMode.RIGHT);model.changeThemeMode(StudioModel.ThemeMode.DARK)}
        }
        compose.setContent{
            if(full){
                val density=LocalDensity.current
                CompositionLocalProvider(LocalDensity provides Density(density.density,2f)){
                    StudioTheme(model){Box(Modifier.fillMaxSize()){EditorBody301(model,4,PaintViewport(),{}, {})}}
                }
            }else MaterialTheme{Text(if(model.busy)"Loading" else "Test workspace")}
        }
        compose.waitUntil(10000){org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();!model.busy}
        compose.waitForIdle()
    }
    @Test fun colorHistoryGestureAndThemePreferencesPersist(){
        createModel()
        compose.runOnIdle{
            for(color in listOf(0xff112233.toInt(),0xff556677.toInt(),0xff112233.toInt())){
                model.chooseColor(color);model.beginStroke(0,0);model.endStroke()
            }
            model.dismissGestureHint();model.changeThemeMode(StudioModel.ThemeMode.DARK);model.changeHandMode(StudioModel.HandMode.RIGHT)
        }
        compose.waitForIdle()
        val prefs=model.getApplication<android.app.Application>().getSharedPreferences("studio3",0)
        assertEquals(listOf("ff112233","ff556677"),prefs.getString("recentColors","")!!.split(',').take(2))
        assertEquals("DARK",prefs.getString("themeMode",""));assertEquals("RIGHT",prefs.getString("handMode",""));assertTrue(prefs.getBoolean("gestureHintSeen",false))
        compose.runOnIdle{
            val reloaded=ViewModelProvider(compose.activity).get("Reloaded",StudioModel::class.java)
            assertEquals(StudioModel.ThemeMode.DARK,reloaded.themeMode);assertEquals(StudioModel.HandMode.RIGHT,reloaded.handMode)
            assertFalse(reloaded.showGestureHint);assertEquals(0xff112233.toInt(),reloaded.recentColors().first())
        }
        assertEquals(0xff112233.toInt(),model.recentColors().first());assertEquals(model.recentColors().distinct(),model.recentColors())
    }
    @Test fun fullCanvasAt200PercentTextKeepsHistoryAndSettingsReachable(){
        createModel(full=true)
        compose.runOnUiThread{model.chooseColor(0xffabcd12.toInt());model.beginStroke(1,1);model.endStroke()}
        compose.onNodeWithText(model.t("undo")).performScrollTo().assertIsDisplayed().assertIsEnabled()
        compose.onNodeWithText(model.t("settings")).performScrollTo().assertIsDisplayed().performClick()
        val bounds=compose.onNodeWithText(model.t("undo")).performScrollTo().fetchSemanticsNode().boundsInRoot
        val px=compose.activity.resources.displayMetrics.density
        assertTrue("History target too small",bounds.height>=48*px)
    }
}
