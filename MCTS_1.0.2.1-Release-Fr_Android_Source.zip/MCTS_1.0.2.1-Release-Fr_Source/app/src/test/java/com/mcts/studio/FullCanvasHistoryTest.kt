package com.mcts.studio
import android.app.Application
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import com.mcts.core.MaterialDocument
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
/** Uses the real full-canvas UI; the missing parent recomposition used to keep Undo disabled. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35],qualifiers="w1000dp-h800dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class FullCanvasHistoryTest {
    @get:Rule(order=0) val host=ComposeHostRule()
    @get:Rule(order=1) val compose=createAndroidComposeRule<ComponentActivity>()
    private lateinit var model:StudioModel
    private fun start(width:Int){
        compose.runOnUiThread {
            model=ViewModelProvider(compose.activity)[StudioModel::class.java]
            model.changeLanguage(Language.EN)
        }
        compose.setContent {MaterialTheme{Box(Modifier.width(width.dp).fillMaxHeight()){EditorBody301(model,4,PaintViewport(),{}, {})}}}
        compose.waitUntil(10000){org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();!model.busy}
        compose.runOnUiThread{model.document.clearHistory();model.endStroke()}
    }
    private fun verifyStrokeAndHistory(){
        val old=model.document.composite(MaterialDocument.Channel.COLOR).clone()
        compose.onNodeWithText(model.t("undo")).assertIsNotEnabled()
        compose.runOnUiThread{model.chooseColor(0xff128acf.toInt());model.beginStroke(2,3);model.paintPath(7,3);model.endStroke()}
        val drawn=model.document.composite(MaterialDocument.Channel.COLOR).clone()
        assertFalse(old.contentEquals(drawn))
        compose.onNodeWithText(model.t("undo")).performScrollTo().assertIsEnabled().performClick()
        compose.runOnIdle{assertArrayEquals(old,model.document.composite(MaterialDocument.Channel.COLOR))}
        compose.onNodeWithText(model.t("redo")).performScrollTo().assertIsEnabled().performClick()
        compose.runOnIdle{assertArrayEquals(drawn,model.document.composite(MaterialDocument.Channel.COLOR))}
        compose.onNodeWithText(model.t("undo")).performScrollTo().performClick()
        compose.runOnUiThread{model.chooseColor(0xffef5562.toInt());model.beginStroke(1,1);model.endStroke()}
        compose.onNodeWithText(model.t("redo")).assertIsNotEnabled()
    }
    @Test fun wideFullCanvasUndoRedoUpdatesButtonsAndPixels(){start(1000);verifyStrokeAndHistory()}
    @Test fun narrowFullCanvasUndoRedoUpdatesButtonsAndPixels(){start(360);verifyStrokeAndHistory()}
}
