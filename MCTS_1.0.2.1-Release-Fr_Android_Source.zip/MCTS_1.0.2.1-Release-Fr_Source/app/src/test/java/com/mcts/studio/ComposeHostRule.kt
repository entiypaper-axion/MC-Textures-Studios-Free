package com.mcts.studio
import android.content.ComponentName
import androidx.activity.ComponentActivity
import org.junit.rules.TestRule
import org.junit.runner.Description
import org.junit.runners.model.Statement
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows
/** Unit-test host only. Registers the Compose Activity before ActivityScenario launches,
 * including Release tests where ui-test-manifest is deliberately absent from the APK. */
class ComposeHostRule:TestRule {
    override fun apply(base:Statement,description:Description):Statement=object:Statement(){
        override fun evaluate(){
            val app=RuntimeEnvironment.getApplication()
            val info=Shadows.shadowOf(app.packageManager).addActivityIfNotPresent(ComponentName(app,ComponentActivity::class.java))
            info.enabled=true;info.exported=false;info.applicationInfo=app.applicationInfo
            info.theme=android.R.style.Theme_Material_Light_NoActionBar
            base.evaluate()
        }
    }
}
