package com.axion.pompreview;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public final class PreviewGLView extends GLSurfaceView {
    private final PomRenderer renderer;
    private float previousX;
    private float previousY;
    private float previousSpan;
    private boolean paintMode;
    private boolean strokeActive;
    private PixelListener pixelListener;
    public interface PixelListener {
        boolean onBegin(int x,int y,int face,int surface);
        void onMove(int x,int y,int face,int surface);
        void onEnd();
    }
    public void setPixelListener(PixelListener listener){pixelListener=listener;}
    public void setPaintMode(boolean enabled){paintMode=enabled;renderer.setEditing(enabled);requestRender();if(!enabled&&strokeActive)endPaint();}
    public void setPixelGrid(boolean enabled){renderer.setGrid(enabled);requestRender();}
    public void setShape(String id){renderer.setBlockShape(id);requestRender();}
    public void setModelBoxes(float[] boxes){renderer.setModelBoxes(boxes);requestRender();}
    public void setMaterialFaces(int[][] color,int[][] normal,byte[][] height,int[][] mers,int size){renderer.setMaterialFaces(color,normal,height,mers,size);requestRender();}
    public void setFailureListener(Runnable listener){renderer.setFailureListener(listener==null?null:()->post(listener));}
    public void setBasic(boolean basic){renderer.setBasic(basic);requestRender();}
    private void endPaint(){if(strokeActive&&pixelListener!=null)pixelListener.onEnd();strokeActive=false;}

    public PreviewGLView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 24, 0);
        setPreserveEGLContextOnPause(true);
        renderer = new PomRenderer();
        setRenderer(renderer);
        // Every state mutation below explicitly schedules a frame. This avoids a
        // permanently hot GPU while guaranteeing that sliders and map edits are visible.
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
    }

    void setMaps(int[] albedo, int[] normalRgb, byte[] heights, int[] mers) {
        renderer.setMaps(albedo, normalRgb, heights, mers);
        requestRender();
    }

    public void setMaps(int[] albedo, int[] normalRgb, byte[] heights, int[] mers, int size) {
        renderer.setMaps(albedo, normalRgb, heights, mers, size);
        requestRender();
    }

    void setNormalMap(int[] normalRgb, byte[] heights) {
        renderer.setNormalMap(normalRgb, heights);
        requestRender();
    }

    void setMerMap(int[] mers) {
        renderer.setMerMap(mers);
        requestRender();
    }

    void setBlockShape(String blockId) {
        renderer.setBlockShape(blockId);
        requestRender();
    }

    public void setDepth(float depth) {
        renderer.setDepth(depth);
        requestRender();
    }

    void setRoughnessScale(float scale) {
        renderer.setRoughnessScale(scale);
        requestRender();
    }

    public void setEffectStrength(float strength) {
        renderer.setEffectStrength(strength);
        requestRender();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if(paintMode && pixelListener!=null){
            if(event.getPointerCount()>1){endPaint();return true;}
            if(action==MotionEvent.ACTION_DOWN){
                int[] pixel=renderer.pick(event.getX(),event.getY(),getWidth(),getHeight());
                strokeActive=pixel!=null&&pixelListener.onBegin(pixel[0],pixel[1],pixel[2],pixel[3]);return true;
            }
            if(action==MotionEvent.ACTION_MOVE&&strokeActive){
                int[] pixel=renderer.pick(event.getX(),event.getY(),getWidth(),getHeight());
                if(pixel!=null)pixelListener.onMove(pixel[0],pixel[1],pixel[2],pixel[3]);else pixelListener.onMove(-1,-1,-1,-1);return true;
            }
            if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){endPaint();return true;}
            return true;
        }
        if (event.getPointerCount() >= 2) {
            float dx = event.getX(0) - event.getX(1);
            float dy = event.getY(0) - event.getY(1);
            float span = (float) Math.sqrt(dx * dx + dy * dy);
            if (action == MotionEvent.ACTION_POINTER_DOWN || previousSpan <= 0.0f) {
                previousSpan = span;
            } else if (action == MotionEvent.ACTION_MOVE && span > 1.0f) {
                renderer.zoomBy(previousSpan / span);
                previousSpan = span;
                requestRender();
            }
            return true;
        }

        previousSpan = 0.0f;
        float x = event.getX();
        float y = event.getY();
        if (action == MotionEvent.ACTION_DOWN) {
            previousX = x;
            previousY = y;
            return true;
        }
        if (action == MotionEvent.ACTION_MOVE) {
            float density = getResources().getDisplayMetrics().density;
            renderer.orbitBy((x - previousX) / density * 0.32f, (y - previousY) / density * 0.32f);
            previousX = x;
            previousY = y;
            requestRender();
            return true;
        }
        return true;
    }
}
