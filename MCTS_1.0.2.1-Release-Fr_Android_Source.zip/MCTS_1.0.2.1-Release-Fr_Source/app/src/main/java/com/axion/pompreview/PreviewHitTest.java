package com.axion.pompreview;

/** CPU triangle picking uses the same camera angles, mesh and UV as the GL preview. */
public final class PreviewHitTest {
    private PreviewHitTest() { }
    public static int[] pick(float[] vertices,int stride,int size,float yawDegrees,float pitchDegrees,
                             float distance,int width,int height,float touchX,float touchY) {
        if(width<=0||height<=0||size<1)return null;
        double yaw=Math.toRadians(yawDegrees),pitch=Math.toRadians(pitchDegrees),
            cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch),
            cameraX=distance*cp*sy,cameraY=distance*sp,cameraZ=distance*cp*cy,
            tan=Math.tan(Math.toRadians(22)),aspect=(double)width/height;
        double best=Double.POSITIVE_INFINITY;int[] hit=null;
        for(int base=0;base+stride*3<=vertices.length;base+=stride*3){
            double[][] v=new double[3][5];boolean valid=true;
            for(int i=0;i<3;i++){
                int off=base+i*stride;double x=vertices[off],y=vertices[off+1],z=vertices[off+2];
                double depth=distance-(x*cp*sy+y*sp+z*cp*cy);
                if(depth<=.1){valid=false;break;}
                double horizontal=x*cy-z*sy,vertical=y*cp-(x*sy+z*cy)*sp;
                v[i][0]=width*(.5+horizontal/(depth*tan*aspect)*.5);
                v[i][1]=height*(.5-vertical/(depth*tan)*.5);
                v[i][2]=depth;v[i][3]=vertices[off+6];v[i][4]=vertices[off+7];
            }
            if(!valid)continue;
            double denom=(v[1][1]-v[2][1])*(v[0][0]-v[2][0])+(v[2][0]-v[1][0])*(v[0][1]-v[2][1]);
            if(Math.abs(denom)<1e-8)continue;
            double a=((v[1][1]-v[2][1])*(touchX-v[2][0])+(v[2][0]-v[1][0])*(touchY-v[2][1]))/denom;
            double b=((v[2][1]-v[0][1])*(touchX-v[2][0])+(v[0][0]-v[2][0])*(touchY-v[2][1]))/denom;
            double c=1-a-b;if(a<0||b<0||c<0)continue;
            double reciprocal=a/v[0][2]+b/v[1][2]+c/v[2][2],depth=1/reciprocal;
            if(depth>=best)continue;
            double u=(a*v[0][3]/v[0][2]+b*v[1][3]/v[1][2]+c*v[2][3]/v[2][2])/reciprocal;
            double texV=(a*v[0][4]/v[0][2]+b*v[1][4]/v[1][2]+c*v[2][4]/v[2][2])/reciprocal;
            int px=Math.min(size-1,Math.max(0,(int)Math.floor(u*size)));
            int py=Math.min(size-1,Math.max(0,(int)Math.floor((1-texV)*size)));
            best=depth;hit=new int[]{px,py,stride>14?(int)vertices[base+14]:0,base/(stride*6)};
        }
        return hit;
    }
}
