package com.axion.pompreview;

import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Arrays;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

final class PomRenderer implements GLSurfaceView.Renderer {
    private static final String TAG = "MCTSPBR";
    private static final int FLOATS_PER_VERTEX = PreviewGeometry.FLOATS_PER_VERTEX;

    private final Object mapLock = new Object();
    private final Object meshLock = new Object();
    private int[][] pendingColors=new int[6][256],pendingNormals=new int[6][256],pendingMers=new int[6][256];
    private byte[][] pendingHeights=new byte[6][256];
    private int pendingTextureSize = 16;
    private volatile int uploadedTextureSize = 16;
    private volatile boolean mapsDirty = true;
    private int dirtyColors=63,dirtyNormals=63,dirtyMers=63,textureStorageSize;
    private ByteBuffer uploadBuffer;
    private PreviewGeometry.Result pendingGeometry = PreviewGeometry.build("minecraft:stone");
    private volatile boolean meshDirty = true;
    private int vertexCount = 36;

    private volatile float yawDegrees = 38.0f;
    private volatile float pitchDegrees = 24.0f;
    private volatile float cameraDistance = 4.25f;
    private volatile float depth = 0.055f;
    private volatile float roughnessScale = 1.0f;
    private volatile float effectStrength = 1.55f;

    private int program;
    private volatile Runnable failureListener;
    void setFailureListener(Runnable next){failureListener=next;}
    private int vertexBuffer;
    private int vertexArray;
    private int albedoTexture;
    private int normalTexture;
    private int merTexture;
    private volatile boolean editing=false,basic=false;
    private int uniformEditing,uniformBasic;
    private volatile boolean showGrid=false;
    private int uniformShowGrid;
    private int uniformMvp;
    private int uniformModel;
    private int uniformCamera;
    private int uniformLight;
    private int uniformDepth;
    private int uniformRoughnessScale;
    private int uniformEffectStrength;
    private int uniformGrid;
    private final float[] projection = new float[16];
    private final float[] view = new float[16];
    private final float[] model = new float[16];
    private final float[] viewProjection = new float[16];
    private final float[] mvp = new float[16];

    void setMaps(int[] colors,int[] normal,byte[] heights,int[] mers){setMaps(colors,normal,heights,mers,16);}
    void setMaps(int[] colors,int[] normal,byte[] heights,int[] mers,int size){
        int[][] c=new int[6][],n=new int[6][],m=new int[6][];byte[][] h=new byte[6][];
        for(int f=0;f<6;f++){c[f]=colors;n[f]=normal;m[f]=mers;h[f]=heights;}
        setMaterialFaces(c,n,h,m,size);
    }
    void setMaterialFaces(int[][] colors,int[][] normals,byte[][] heights,int[][] mers,int size){
        if(colors.length!=6||normals.length!=6||heights.length!=6||mers.length!=6||size<16||size>512)throw new IllegalArgumentException("FACE_MAPS");
        int count=size*size;
        synchronized(mapLock){
            for(int f=0;f<6;f++){
                if(colors[f].length!=count||normals[f].length!=count||heights[f].length!=count||mers[f].length!=count)throw new IllegalArgumentException("FACE_SIZE");
                if(size!=pendingTextureSize || !Arrays.equals(colors[f],pendingColors[f])){pendingColors[f]=Arrays.copyOf(colors[f],count);dirtyColors|=1<<f;}
                if(size!=pendingTextureSize || !Arrays.equals(normals[f],pendingNormals[f]) || !Arrays.equals(heights[f],pendingHeights[f])){pendingNormals[f]=Arrays.copyOf(normals[f],count);pendingHeights[f]=Arrays.copyOf(heights[f],count);dirtyNormals|=1<<f;}
                if(size!=pendingTextureSize || !Arrays.equals(mers[f],pendingMers[f])){pendingMers[f]=Arrays.copyOf(mers[f],count);dirtyMers|=1<<f;}
            }
            pendingTextureSize=size;mapsDirty=dirtyColors!=0||dirtyNormals!=0||dirtyMers!=0;
        }
    }
    void setEditing(boolean enabled){editing=enabled;}
    void setBasic(boolean enabled){basic=enabled;}
    void setGrid(boolean visible){showGrid=visible;}
    int[] pick(float x,float y,int width,int height){
        float[] mesh;int size; synchronized(mapLock){size=pendingTextureSize;}
        synchronized(meshLock){mesh=pendingGeometry.vertices;}
        return PreviewHitTest.pick(mesh,FLOATS_PER_VERTEX,size,yawDegrees,pitchDegrees,cameraDistance,width,height,x,y);
    }

    void setNormalMap(int[] normal,byte[] heights){synchronized(mapLock){for(int f=0;f<6;f++){pendingNormals[f]=Arrays.copyOf(normal,pendingTextureSize*pendingTextureSize);pendingHeights[f]=Arrays.copyOf(heights,pendingTextureSize*pendingTextureSize);}dirtyNormals=63;mapsDirty=true;}}
    void setMerMap(int[] mers){synchronized(mapLock){for(int f=0;f<6;f++)pendingMers[f]=Arrays.copyOf(mers,pendingTextureSize*pendingTextureSize);dirtyMers=63;mapsDirty=true;}}
    void setBlockShape(String blockId) {
        synchronized (meshLock) {
            pendingGeometry = PreviewGeometry.build(blockId);
            meshDirty = true;
        }
    }
    void setModelBoxes(float[] cuboids){
        synchronized(meshLock){pendingGeometry=PreviewGeometry.buildQuads(cuboids);meshDirty=true;}
    }

    void setDepth(float depth) {
        this.depth = Math.max(0.005f, Math.min(0.12f, depth));
    }

    void setRoughnessScale(float scale) {
        this.roughnessScale = Math.max(0.0f, Math.min(2.0f, scale));
    }

    void setEffectStrength(float strength) {
        effectStrength = Math.max(0.5f, Math.min(3.0f, strength));
    }

    void orbitBy(float yaw, float pitch) {
        yawDegrees += yaw;
        pitchDegrees = Math.max(-78.0f, Math.min(78.0f, pitchDegrees + pitch));
    }

    void zoomBy(float factor) {
        cameraDistance = Math.max(2.55f, Math.min(8.0f, cameraDistance * factor));
    }

    @Override
    public void onSurfaceCreated(GL10 ignored, EGLConfig config) {
        GLES30.glClearColor(0.025f, 0.032f, 0.047f, 1.0f);
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        GLES30.glDepthFunc(GLES30.GL_LEQUAL);
        GLES30.glEnable(GLES30.GL_CULL_FACE);
        GLES30.glCullFace(GLES30.GL_BACK);

        try{program = linkProgram(VERTEX_SHADER, FRAGMENT_SHADER);}
        catch(RuntimeException error){Log.e(TAG,"Preview shader failed",error);program=0;Runnable listener=failureListener;if(listener!=null)listener.run();return;}
        uniformMvp = GLES30.glGetUniformLocation(program, "uMvp");
        uniformModel = GLES30.glGetUniformLocation(program, "uModel");
        uniformCamera = GLES30.glGetUniformLocation(program, "uCameraPosition");
        uniformLight = GLES30.glGetUniformLocation(program, "uLightDirection");
        uniformDepth = GLES30.glGetUniformLocation(program, "uPomDepth");
        uniformRoughnessScale = GLES30.glGetUniformLocation(program, "uRoughnessScale");
        uniformEffectStrength = GLES30.glGetUniformLocation(program, "uEffectStrength");
        uniformGrid = GLES30.glGetUniformLocation(program, "uGrid");
        uniformShowGrid=GLES30.glGetUniformLocation(program,"uShowGrid");
        uniformEditing=GLES30.glGetUniformLocation(program,"uEditing");uniformBasic=GLES30.glGetUniformLocation(program,"uBasic");

        int[] ids = new int[1];
        GLES30.glGenVertexArrays(1, ids, 0);
        vertexArray = ids[0];
        GLES30.glBindVertexArray(vertexArray);

        GLES30.glGenBuffers(1, ids, 0);
        vertexBuffer = ids[0];
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vertexBuffer);
        float[] vertices;
        synchronized (meshLock) {
            vertices = Arrays.copyOf(pendingGeometry.vertices, pendingGeometry.vertices.length);
            vertexCount = pendingGeometry.vertexCount();
            meshDirty = false;
        }
        FloatBuffer buffer = ByteBuffer
            .allocateDirect(vertices.length * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer();
        buffer.put(vertices).position(0);
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER,
            vertices.length * 4,
            buffer,
            GLES30.GL_DYNAMIC_DRAW
        );

        int stride = FLOATS_PER_VERTEX * 4;
        enableAttribute(0, 3, stride, 0);
        enableAttribute(1, 3, stride, 3 * 4);
        enableAttribute(2, 2, stride, 6 * 4);
        enableAttribute(3, 3, stride, 8 * 4);
        enableAttribute(4, 3, stride, 11 * 4);
        enableAttribute(5, 1, stride, 14 * 4);
        GLES30.glBindVertexArray(0);

        GLES30.glGenTextures(1, ids, 0);
        albedoTexture = ids[0];
        configureTexture(albedoTexture);
        GLES30.glGenTextures(1, ids, 0);
        normalTexture = ids[0];
        configureTexture(normalTexture);
        GLES30.glGenTextures(1, ids, 0);
        merTexture = ids[0];
        configureTexture(merTexture);
        GLES30.glUseProgram(program);
        GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uAlbedo"), 0);
        GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uNormalHeight"), 1);
        GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uMers"), 2);
        Matrix.setIdentityM(model, 0);
        synchronized(mapLock){textureStorageSize=0;dirtyColors=dirtyNormals=dirtyMers=63;mapsDirty=true;}
    }

    private static void enableAttribute(int index, int count, int stride, int offset) {
        GLES30.glEnableVertexAttribArray(index);
        GLES30.glVertexAttribPointer(index, count, GLES30.GL_FLOAT, false, stride, offset);
    }

    private static void configureTexture(int texture) {
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY, texture);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);
    }

    @Override
    public void onSurfaceChanged(GL10 ignored, int width, int height) {
        GLES30.glViewport(0, 0, width, height);
        float aspect = height == 0 ? 1.0f : (float) width / (float) height;
        Matrix.perspectiveM(projection, 0, 44.0f, aspect, 0.1f, 40.0f);
    }

    @Override
    public void onDrawFrame(GL10 ignored) {
        uploadMapsIfNeeded();
        uploadMeshIfNeeded();
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);
        if (program == 0) {
            return;
        }

        float yaw = (float) Math.toRadians(yawDegrees);
        float pitch = (float) Math.toRadians(pitchDegrees);
        float horizontal = cameraDistance * (float) Math.cos(pitch);
        float cameraX = horizontal * (float) Math.sin(yaw);
        float cameraY = cameraDistance * (float) Math.sin(pitch);
        float cameraZ = horizontal * (float) Math.cos(yaw);

        Matrix.setLookAtM(
            view, 0,
            cameraX, cameraY, cameraZ,
            0.0f, 0.0f, 0.0f,
            0.0f, 1.0f, 0.0f
        );
        Matrix.multiplyMM(viewProjection, 0, projection, 0, view, 0);
        Matrix.multiplyMM(mvp, 0, viewProjection, 0, model, 0);

        GLES30.glUseProgram(program);
        GLES30.glUniformMatrix4fv(uniformMvp, 1, false, mvp, 0);
        GLES30.glUniformMatrix4fv(uniformModel, 1, false, model, 0);
        GLES30.glUniform3f(uniformCamera, cameraX, cameraY, cameraZ);
        GLES30.glUniform3f(uniformLight, 0.43f, 0.78f, 0.46f);
        GLES30.glUniform1f(uniformDepth, depth);
        GLES30.glUniform1f(uniformRoughnessScale, roughnessScale);
        GLES30.glUniform1f(uniformEffectStrength, effectStrength);
        // The uniform must describe the texture that has actually reached GL, not
        // a newer UI-thread request which may still be waiting for upload.
        GLES30.glUniform1f(uniformGrid, uploadedTextureSize);
        GLES30.glUniform1f(uniformShowGrid,showGrid?1f:0f);
        GLES30.glUniform1f(uniformEditing,editing?1f:0f);GLES30.glUniform1f(uniformBasic,basic?1f:0f);

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY, albedoTexture);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY, normalTexture);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY, merTexture);
        GLES30.glBindVertexArray(vertexArray);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, vertexCount);
        GLES30.glBindVertexArray(0);
    }

    private void uploadMeshIfNeeded() {
        if (!meshDirty || vertexBuffer == 0) return;
        float[] vertices;
        synchronized (meshLock) {
            if (!meshDirty) return;
            vertices = Arrays.copyOf(pendingGeometry.vertices, pendingGeometry.vertices.length);
            vertexCount = pendingGeometry.vertexCount();
            meshDirty = false;
        }
        FloatBuffer buffer = ByteBuffer.allocateDirect(vertices.length * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer();
        buffer.put(vertices).position(0);
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vertexBuffer);
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER, vertices.length * 4, buffer, GLES30.GL_DYNAMIC_DRAW
        );
    }

    private void uploadMapsIfNeeded() {
        if(!mapsDirty||albedoTexture==0||normalTexture==0||merTexture==0)return;
        int size,dc,dn,dm;int[][] colors,normals,mers;byte[][] heights;
        synchronized(mapLock){
            if(!mapsDirty)return;
            size=pendingTextureSize;colors=pendingColors.clone();normals=pendingNormals.clone();mers=pendingMers.clone();heights=pendingHeights.clone();
            dc=dirtyColors;dn=dirtyNormals;dm=dirtyMers;dirtyColors=dirtyNormals=dirtyMers=0;mapsDirty=false;
        }
        if(textureStorageSize!=size){
            for(int texture:new int[]{albedoTexture,normalTexture,merTexture}){
                GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY,texture);
                GLES30.glTexImage3D(GLES30.GL_TEXTURE_2D_ARRAY,0,GLES30.GL_RGBA8,size,size,6,0,GLES30.GL_RGBA,GLES30.GL_UNSIGNED_BYTE,null);
            }
            textureStorageSize=size;dc=dn=dm=63;
            uploadBuffer=ByteBuffer.allocateDirect(size*size*4);
        }
        // One reusable face buffer. No texture reallocation or neutral PBR upload per brush move.
        for(int face=0;face<6;face++){
            if((dc&(1<<face))!=0)uploadFace(albedoTexture,size,face,colors[face],null);
            if((dn&(1<<face))!=0)uploadFace(normalTexture,size,face,normals[face],heights[face]);
            if((dm&(1<<face))!=0)uploadFace(merTexture,size,face,mers[face],null);
        }
        uploadedTextureSize=size;
    }
    private void uploadFace(int texture,int size,int face,int[] pixels,byte[] heights){
        uploadBuffer.clear();
        for(int y=size-1;y>=0;y--)for(int x=0;x<size;x++){
            int i=y*size+x,p=pixels[i];uploadBuffer.put((byte)(p>>>16));uploadBuffer.put((byte)(p>>>8));uploadBuffer.put((byte)p);uploadBuffer.put(heights==null?(byte)(p>>>24):heights[i]);
        }
        uploadBuffer.flip();GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY,texture);
        GLES30.glTexSubImage3D(GLES30.GL_TEXTURE_2D_ARRAY,0,0,0,face,size,size,1,GLES30.GL_RGBA,GLES30.GL_UNSIGNED_BYTE,uploadBuffer);
    }

    private static int compileShader(int type, String source) {
        int shader = GLES30.glCreateShader(type);
        GLES30.glShaderSource(shader, source);
        GLES30.glCompileShader(shader);
        int[] result = new int[1];
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, result, 0);
        if (result[0] == 0) {
            String log = GLES30.glGetShaderInfoLog(shader);
            Log.e(TAG, "Shader compile failure: " + log);
            GLES30.glDeleteShader(shader);
            return 0;
        }
        return shader;
    }

    private static int linkProgram(String vertexSource, String fragmentSource) {
        int vertex = compileShader(GLES30.GL_VERTEX_SHADER, vertexSource);
        int fragment = compileShader(GLES30.GL_FRAGMENT_SHADER, fragmentSource);
        if (vertex == 0 || fragment == 0) {
            return 0;
        }
        int program = GLES30.glCreateProgram();
        GLES30.glAttachShader(program, vertex);
        GLES30.glAttachShader(program, fragment);
        GLES30.glLinkProgram(program);
        int[] result = new int[1];
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, result, 0);
        GLES30.glDeleteShader(vertex);
        GLES30.glDeleteShader(fragment);
        if (result[0] == 0) {
            Log.e(TAG, "Program link failure: " + GLES30.glGetProgramInfoLog(program));
            GLES30.glDeleteProgram(program);
            return 0;
        }
        return program;
    }

    private static float[] buildCubeVertices() {
        FloatCollector output = new FloatCollector(36 * FLOATS_PER_VERTEX);
        addFace(output,
            -1, -1,  1,   1, -1,  1,   1,  1,  1,  -1,  1,  1,
             0,  0,  1,   1,  0,  0,   0,  1,  0);
        addFace(output,
             1, -1, -1,  -1, -1, -1,  -1,  1, -1,   1,  1, -1,
             0,  0, -1,  -1,  0,  0,   0,  1,  0);
        addFace(output,
             1, -1,  1,   1, -1, -1,   1,  1, -1,   1,  1,  1,
             1,  0,  0,   0,  0, -1,   0,  1,  0);
        addFace(output,
            -1, -1, -1,  -1, -1,  1,  -1,  1,  1,  -1,  1, -1,
            -1,  0,  0,   0,  0,  1,   0,  1,  0);
        addFace(output,
            -1,  1,  1,   1,  1,  1,   1,  1, -1,  -1,  1, -1,
             0,  1,  0,   1,  0,  0,   0,  0, -1);
        addFace(output,
            -1, -1, -1,   1, -1, -1,   1, -1,  1,  -1, -1,  1,
             0, -1,  0,   1,  0,  0,   0,  0,  1);
        return output.values;
    }

    private static void addFace(
        FloatCollector output,
        float x0, float y0, float z0,
        float x1, float y1, float z1,
        float x2, float y2, float z2,
        float x3, float y3, float z3,
        float nx, float ny, float nz,
        float tx, float ty, float tz,
        float bx, float by, float bz
    ) {
        addVertex(output, x0, y0, z0, nx, ny, nz, 0, 0, tx, ty, tz, bx, by, bz);
        addVertex(output, x1, y1, z1, nx, ny, nz, 1, 0, tx, ty, tz, bx, by, bz);
        addVertex(output, x2, y2, z2, nx, ny, nz, 1, 1, tx, ty, tz, bx, by, bz);
        addVertex(output, x0, y0, z0, nx, ny, nz, 0, 0, tx, ty, tz, bx, by, bz);
        addVertex(output, x2, y2, z2, nx, ny, nz, 1, 1, tx, ty, tz, bx, by, bz);
        addVertex(output, x3, y3, z3, nx, ny, nz, 0, 1, tx, ty, tz, bx, by, bz);
    }

    private static void addVertex(
        FloatCollector output,
        float px, float py, float pz,
        float nx, float ny, float nz,
        float u, float v,
        float tx, float ty, float tz,
        float bx, float by, float bz
    ) {
        output.add(px); output.add(py); output.add(pz);
        output.add(nx); output.add(ny); output.add(nz);
        output.add(u); output.add(v);
        output.add(tx); output.add(ty); output.add(tz);
        output.add(bx); output.add(by); output.add(bz);
    }

    private static final class FloatCollector {
        final float[] values;
        int cursor;

        FloatCollector(int size) {
            values = new float[size];
        }

        void add(float value) {
            values[cursor++] = value;
        }
    }

    private static final String VERTEX_SHADER =
        "#version 300 es\n" +
        "precision highp float;\n" +
        "layout(location=0) in vec3 aPosition;\n" +
        "layout(location=1) in vec3 aNormal;\n" +
        "layout(location=2) in vec2 aUv;\n" +
        "layout(location=3) in vec3 aTangent;\n" +
        "layout(location=4) in vec3 aBitangent;\n" +
        "layout(location=5) in float aFace;\n" +
        "uniform mat4 uMvp;\n" +
        "uniform mat4 uModel;\n" +
        "out highp vec3 vWorldPosition;\n" +
        "out highp vec3 vNormal;\n" +
        "out highp vec3 vTangent;\n" +
        "out highp vec3 vBitangent;\n" +
        "out highp vec2 vUv;\n" +
        "flat out highp int vFace;\n" +
        "void main(){\n" +
        "  vec4 world=uModel*vec4(aPosition,1.0);\n" +
        "  vWorldPosition=world.xyz;\n" +
        "  vNormal=normalize(mat3(uModel)*aNormal);\n" +
        "  vTangent=normalize(mat3(uModel)*aTangent);\n" +
        "  vBitangent=normalize(mat3(uModel)*aBitangent);\n" +
        "  vUv=aUv;\n" +
        "  vFace=int(aFace+0.5);\n" +
        "  gl_Position=uMvp*vec4(aPosition,1.0);\n" +
        "}\n";

    private static final String FRAGMENT_SHADER =
        "#version 300 es\n" +
        "precision highp float;\n" +
        "precision highp int;\n" +
        "uniform highp sampler2DArray uAlbedo;\n" +
        "uniform highp sampler2DArray uNormalHeight;\n" +
        "uniform highp sampler2DArray uMers;\n" +
        "uniform vec3 uCameraPosition;\n" +
        "uniform vec3 uLightDirection;\n" +
        "uniform float uPomDepth;\n" +
        "uniform float uRoughnessScale;\n" +
        "uniform float uEffectStrength;\n" +
        "uniform float uGrid;\n" +
        "uniform float uShowGrid;\n" +
        "uniform float uEditing;\n" +
        "uniform float uBasic;\n" +
        "in highp vec3 vWorldPosition;\n" +
        "in highp vec3 vNormal;\n" +
        "in highp vec3 vTangent;\n" +
        "in highp vec3 vBitangent;\n" +
        "in highp vec2 vUv;\n" +
        "flat in highp int vFace;\n" +
        "out vec4 fragmentColor;\n" +
        "vec2 wrapUv(vec2 uv){ return fract(uv); }\n" +
        "vec2 voxelCell(vec2 uv){ return floor(wrapUv(uv)*uGrid); }\n" +
        "vec2 voxelCenter(vec2 uv){ return (voxelCell(uv)+vec2(0.5))/uGrid; }\n" +
        "float voxelHeight(vec2 uv){ return textureLod(uNormalHeight,vec3(voxelCenter(uv),float(vFace-1)),0.0).a; }\n" +
        "vec2 periodicDelta(vec2 targetCell,vec2 sourceCell){\n" +
        "  vec2 delta=targetCell-sourceCell;\n" +
        "  delta-=floor(delta/uGrid+vec2(0.5))*uGrid;\n" +
        "  return delta;\n" +
        "}\n" +
        "vec2 tracePom(vec2 baseUv,vec3 viewTs,vec3 lightTs,out float shade,out vec3 reliefNormal){\n" +
        "  float probeHeight=voxelHeight(baseUv);\n" +
        "  float rawViewZ=abs(viewTs.z);\n" +
        "  vec2 viewSlope=viewTs.xy/sqrt(rawViewZ*rawViewZ+0.0036);\n" +
        "  const float maximumSlope=1.6363636;\n" +
        "  viewSlope*=inversesqrt(1.0+dot(viewSlope,viewSlope)/(maximumSlope*maximumSlope));\n" +
        "  vec2 rayTravel=viewSlope*uPomDepth;\n" +
        "  vec2 previousUv=baseUv;\n" +
        "  float previousT=0.0;\n" +
        "  float previousHeight=probeHeight;\n" +
        "  vec2 previousCell=voxelCell(baseUv);\n" +
        "  vec2 currentUv=baseUv;\n" +
        "  float currentT=0.0;\n" +
        "  float currentHeight=probeHeight;\n" +
        "  vec2 currentCell=previousCell;\n" +
        "  vec2 sideDelta=vec2(0.0);\n" +
        "  bool sideHit=false;\n" +
        "  bool foundHit=false;\n" +
        "  for(int rayStep=0;rayStep<48;++rayStep){\n" +
        "    currentT=float(rayStep+1)/48.0;\n" +
        "    currentUv=wrapUv(baseUv-rayTravel*currentT);\n" +
        "    currentHeight=voxelHeight(currentUv);\n" +
        "    currentCell=voxelCell(currentUv);\n" +
        "    float rayHeight=1.0-currentT;\n" +
        "    if(rayHeight<=currentHeight){\n" +
        "      foundHit=true;\n" +
        "      sideDelta=periodicDelta(currentCell,previousCell);\n" +
        "      bool crossed=abs(sideDelta.x)>0.5||abs(sideDelta.y)>0.5;\n" +
        "      sideHit=crossed&&currentHeight>previousHeight+0.012&&rayHeight<currentHeight-0.006;\n" +
        "      break;\n" +
        "    }\n" +
        "    previousUv=currentUv; previousT=currentT; previousHeight=currentHeight; previousCell=currentCell;\n" +
        "  }\n" +
        "  if(!foundHit){ currentT=1.0; currentUv=wrapUv(baseUv-rayTravel); }\n" +
        "  float lowT=previousT;\n" +
        "  float highT=currentT;\n" +
        "  for(int refine=0;refine<5;++refine){\n" +
        "    float middleT=(lowT+highT)*0.5;\n" +
        "    vec2 middleUv=wrapUv(baseUv-rayTravel*middleT);\n" +
        "    if((1.0-middleT)<=voxelHeight(middleUv)){ highT=middleT; } else { lowT=middleT; }\n" +
        "  }\n" +
        "  vec2 hitUv=wrapUv(baseUv-rayTravel*highT);\n" +
        "  float hitHeight=voxelHeight(hitUv);\n" +
        "  vec2 refinedDelta=periodicDelta(voxelCell(hitUv),voxelCell(wrapUv(baseUv-rayTravel*lowT)));\n" +
        "  if(sideHit&&(abs(refinedDelta.x)>0.5||abs(refinedDelta.y)>0.5)){ sideDelta=refinedDelta; }\n" +
        "  vec2 pixelStep=vec2(1.0/uGrid);\n" +
        "  float hL=voxelHeight(hitUv-vec2(pixelStep.x,0.0));\n" +
        "  float hR=voxelHeight(hitUv+vec2(pixelStep.x,0.0));\n" +
        "  float hD=voxelHeight(hitUv-vec2(0.0,pixelStep.y));\n" +
        "  float hU=voxelHeight(hitUv+vec2(0.0,pixelStep.y));\n" +
        "  float hLD=voxelHeight(hitUv-pixelStep);\n" +
        "  float hRU=voxelHeight(hitUv+pixelStep);\n" +
        "  float hLU=voxelHeight(hitUv+vec2(-pixelStep.x,pixelStep.y));\n" +
        "  float hRD=voxelHeight(hitUv+vec2(pixelStep.x,-pixelStep.y));\n" +
        "  if(sideHit){\n" +
        "    reliefNormal=normalize(vec3(-sign(sideDelta),0.08));\n" +
        "  }else{\n" +
        "    vec2 localPixel=fract(hitUv*uGrid);\n" +
        "    const float bevelWidth=0.18;\n" +
        "    vec2 bevel=vec2(0.0);\n" +
        "    bevel.x-=max(hitHeight-hL,0.0)*(1.0-smoothstep(0.0,bevelWidth,localPixel.x))*9.0;\n" +
        "    bevel.x+=max(hitHeight-hR,0.0)*smoothstep(1.0-bevelWidth,1.0,localPixel.x)*9.0;\n" +
        "    bevel.y-=max(hitHeight-hD,0.0)*(1.0-smoothstep(0.0,bevelWidth,localPixel.y))*9.0;\n" +
        "    bevel.y+=max(hitHeight-hU,0.0)*smoothstep(1.0-bevelWidth,1.0,localPixel.y)*9.0;\n" +
        "    reliefNormal=normalize(vec3(bevel,1.0));\n" +
        "  }\n" +
        "  float cardinal=max(hL-hitHeight,0.0)+max(hR-hitHeight,0.0)+max(hD-hitHeight,0.0)+max(hU-hitHeight,0.0);\n" +
        "  float diagonal=max(hLD-hitHeight,0.0)+max(hRU-hitHeight,0.0)+max(hLU-hitHeight,0.0)+max(hRD-hitHeight,0.0);\n" +
        "  float cavity=clamp(cardinal*0.40+diagonal*0.18,0.0,0.72);\n" +
        "  float directionalShadow=1.0;\n" +
        "  if(lightTs.z>0.075){\n" +
        "    float remainingRise=max(1.0-hitHeight,0.0);\n" +
        "    for(int shadowStep=1;shadowStep<=8;++shadowStep){\n" +
        "      float rise=remainingRise*float(shadowStep)/8.0;\n" +
        "      vec2 shadowUv=wrapUv(hitUv+(lightTs.xy/max(lightTs.z,0.12))*uPomDepth*rise);\n" +
        "      float blocker=voxelHeight(shadowUv)-(hitHeight+rise+0.018);\n" +
        "      float blocked=smoothstep(-0.005,0.085,blocker);\n" +
        "      directionalShadow=min(directionalShadow,1.0-blocked*0.82);\n" +
        "    }\n" +
        "  }\n" +
        "  float sideDarkening=sideHit?0.58:1.0;\n" +
        "  shade=clamp((1.0-cavity)*directionalShadow*sideDarkening,0.12,1.0);\n" +
        "  if(sideHit){ return (voxelCell(hitUv)+vec2(0.5))/uGrid; }\n" +
        "  vec2 translatedTop=wrapUv(baseUv-rayTravel*(1.0-hitHeight));\n" +
        "  vec2 phase=clamp(fract(translatedTop*uGrid),vec2(0.001),vec2(0.999));\n" +
        "  return (voxelCell(hitUv)+phase)/uGrid;\n" +
        "}\n" +
        "vec3 previewEnvironment(vec3 direction,float roughness){\n" +
        "  vec3 d=normalize(direction);\n" +
        "  float skyBlend=smoothstep(-0.34,0.58,d.y);\n" +
        "  vec3 ground=mix(vec3(0.17,0.055,0.025),vec3(0.42,0.16,0.055),max(d.y+1.0,0.0)*0.5);\n" +
        "  vec3 sky=mix(vec3(0.12,0.34,0.78),vec3(0.46,0.70,1.00),max(d.y,0.0));\n" +
        "  vec3 result=mix(ground,sky,skyBlend);\n" +
        "  float horizon=exp(-abs(d.y)*mix(34.0,5.0,roughness));\n" +
        "  result+=vec3(1.00,0.34,0.075)*horizon*mix(0.48,0.18,roughness);\n" +
        "  float exponent=mix(240.0,7.0,roughness*roughness);\n" +
        "  float key=pow(max(dot(d,normalize(vec3(-0.58,0.64,0.50))),0.0),exponent);\n" +
        "  float fill=pow(max(dot(d,normalize(vec3(0.76,0.27,0.59))),0.0),exponent*0.72);\n" +
        "  float strip=pow(max(dot(d,normalize(vec3(0.03,0.44,-0.90))),0.0),exponent*0.46);\n" +
        "  float panelGain=mix(5.4,0.62,roughness);\n" +
        "  result+=vec3(1.00,0.94,0.76)*key*panelGain;\n" +
        "  result+=vec3(0.16,0.72,1.00)*fill*panelGain*0.78;\n" +
        "  result+=vec3(0.96,0.18,0.55)*strip*panelGain*0.52;\n" +
        "  float floorMask=1.0-smoothstep(-0.55,-0.02,d.y);\n" +
        "  float bands=0.5+0.5*cos(18.0*atan(d.z,d.x));\n" +
        "  result+=floorMask*mix(vec3(0.025,0.06,0.11),vec3(0.30,0.075,0.025),bands)*0.75;\n" +
        "  return result;\n" +
        "}\n" +
        "void main(){\n" +
        "  vec3 normal=normalize(vNormal);\n" +
        "  vec3 tangent=normalize(vTangent);\n" +
        "  vec3 bitangent=normalize(vBitangent);\n" +
        "  mat3 tbn=mat3(tangent,bitangent,normal);\n" +
        "  vec3 viewWorld=normalize(uCameraPosition-vWorldPosition);\n" +
        "  vec3 lightWorld=normalize(uLightDirection);\n" +
        "  vec3 viewTs=transpose(tbn)*viewWorld;\n" +
        "  vec3 lightTs=transpose(tbn)*lightWorld;\n" +
        "  float reliefShade=1.0;\n" +
        "  vec3 reliefNormal=vec3(0.0,0.0,1.0);\n" +
        "  vec2 uv=vUv; if(uEditing<0.5 && uBasic<0.5)uv=tracePom(vUv,viewTs,lightTs,reliefShade,reliefNormal);\n" +
        "  vec4 albedoSample=texture(uAlbedo,vec3(uv,float(vFace-1)));\n" +
        "  if(albedoSample.a<0.10){ discard; }\n" +
        "  vec3 albedo=albedoSample.rgb;\n" +
        "  if(uBasic>0.5){vec3 color=albedo*(0.50+0.50*max(dot(normal,lightWorld),0.0));if(uShowGrid>0.5){vec2 cell=fract(uv*uGrid);vec2 edge=min(cell,1.0-cell);float line=1.0-smoothstep(0.0,max(max(fwidth(uv*uGrid).x,fwidth(uv*uGrid).y)*0.6,0.002),min(edge.x,edge.y));float fade=1.0-smoothstep(0.25,1.0,max(fwidth(uv*uGrid).x,fwidth(uv*uGrid).y));color=mix(color,vec3(0.07,0.20,0.24),line*fade*0.45);}fragmentColor=vec4(color,albedoSample.a);return;}\n" +
        "  vec4 mers=texture(uMers,vec3(uv,float(vFace-1)));\n" +
        "  float metalness=clamp(mers.r,0.0,1.0);\n" +
        "  float emissive=clamp(mers.g,0.0,1.0);\n" +
        "  float roughness=clamp(mers.b*uRoughnessScale,0.04,1.0);\n" +
        "  float subsurface=clamp(mers.a,0.0,1.0);\n" +
        "  vec3 textureNormal=texture(uNormalHeight,vec3(uv,float(vFace-1))).rgb*2.0-1.0;\n" +
        "  if(dot(textureNormal,textureNormal)<0.05){ textureNormal=vec3(0.0,0.0,1.0); }\n" +
        "  vec3 normalTs=normalize(mix(normalize(textureNormal),reliefNormal,0.90));\n" +
        "  vec3 surfaceNormal=normalize(tbn*normalTs);\n" +
        "  float nDotL=max(dot(surfaceNormal,lightWorld),0.0);\n" +
        "  float nDotV=max(dot(surfaceNormal,viewWorld),0.001);\n" +
        "  vec3 halfVector=normalize(lightWorld+viewWorld);\n" +
        "  float nDotH=max(dot(surfaceNormal,halfVector),0.0);\n" +
        "  float vDotH=max(dot(viewWorld,halfVector),0.0);\n" +
        "  float alphaR=roughness*roughness;\n" +
        "  float alphaR2=alphaR*alphaR;\n" +
        "  float denominator=nDotH*nDotH*(alphaR2-1.0)+1.0;\n" +
        "  float distribution=alphaR2/max(3.14159265*denominator*denominator,0.0001);\n" +
        "  float k=(roughness+1.0)*(roughness+1.0)*0.125;\n" +
        "  float geometryL=nDotL/max(nDotL*(1.0-k)+k,0.0001);\n" +
        "  float geometryV=nDotV/max(nDotV*(1.0-k)+k,0.0001);\n" +
        "  vec3 f0=mix(vec3(0.04),albedo,metalness);\n" +
        "  vec3 fresnel=f0+(vec3(1.0)-f0)*pow(1.0-vDotH,5.0);\n" +
        "  vec3 specular=distribution*geometryL*geometryV*fresnel/max(4.0*nDotL*nDotV,0.001);\n" +
        "  vec3 diffuseWeight=(vec3(1.0)-fresnel)*(1.0-metalness);\n" +
        "  float effect=max(uEffectStrength,0.50);\n" +
        "  vec3 direct=(diffuseWeight*albedo/3.14159265+specular)*nDotL*(1.75+effect*0.28);\n" +
        "  vec3 reflectionDirection=reflect(-viewWorld,surfaceNormal);\n" +
        "  vec3 environmentReflection=previewEnvironment(reflectionDirection,roughness);\n" +
        "  vec3 environmentDiffuse=previewEnvironment(surfaceNormal,0.92)*albedo*(1.0-metalness)*0.31;\n" +
        "  vec3 fresnelIbl=f0+(vec3(1.0)-f0)*pow(1.0-nDotV,5.0);\n" +
        "  float reflectionGain=mix(1.28,0.52,roughness)*mix(0.72,1.72,metalness)*effect;\n" +
        "  vec3 environmentSpecular=environmentReflection*fresnelIbl*reflectionGain;\n" +
        "  float backLight=max(dot(-surfaceNormal,lightWorld),0.0);\n" +
        "  float rim=pow(1.0-nDotV,2.0);\n" +
        "  vec3 transmission=mix(albedo,vec3(1.0,0.38,0.14),0.20)*subsurface\n" +
        "    *(0.18+backLight*1.65+rim*0.82)*effect;\n" +
        "  vec3 color=(direct+environmentDiffuse)*reliefShade;\n" +
        "  color+=environmentSpecular*mix(0.48,1.0,reliefShade);\n" +
        "  color+=transmission*mix(0.60,1.0,reliefShade);\n" +
        "  color+=albedo*emissive*(3.2+effect*2.1)+vec3(emissive*0.10);\n" +
        "  color=color/(color+vec3(0.72));\n" +
        "  color=pow(max(color,vec3(0.0)),vec3(1.0/2.2));\n" +
        "  if(uShowGrid>0.5){vec2 cell=fract(uv*uGrid);vec2 edge=min(cell,1.0-cell);float line=1.0-smoothstep(0.0,max(max(fwidth(uv*uGrid).x,fwidth(uv*uGrid).y)*0.6,0.002),min(edge.x,edge.y));color=mix(color,vec3(0.06,0.20,0.24),line*0.30);}\n" +
        "  fragmentColor=vec4(color,albedoSample.a);\n" +
        "}\n";
}
