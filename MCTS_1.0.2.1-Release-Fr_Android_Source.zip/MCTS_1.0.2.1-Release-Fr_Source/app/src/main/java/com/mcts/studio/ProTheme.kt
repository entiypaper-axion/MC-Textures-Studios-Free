package com.mcts.studio

import android.graphics.Typeface
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** 1.0.1 "professional" palette: neutral graphite / paper, one mint accent, 8–12 dp corners. */
@Immutable internal data class ProColors(
    val dark:Boolean,val app:Color,val bar:Color,val group:Color,val raised:Color,val hover:Color,val line:Color,
    val tx:Color,val tx2:Color,val tx3:Color,val acc:Color,val accTx:Color,val accSoft:Color,val field:Color,
    val work:Color,val dot:Color,val danger:Color,val previewBg:Color,
)
internal fun proColors(dark:Boolean,strong:Boolean):ProColors{
    val base=if(dark)ProColors(true,Color(0xff0e1013),Color(0xff15171b),Color(0xff1c1f24),Color(0xff262a31),Color(0xff22262c),Color(0xff2a2e35),
        Color(0xffe6e9ee),Color(0xffa3aab4),Color(0xff7d8590),Color(0xff5eeac0),Color(0xff06221b),Color(0x215eeac0),Color(0xff131518),
        Color(0xff0b0d10),Color(0x0bffffff),Color(0xffff8a7a),Color(0xff08090b))
    else ProColors(false,Color(0xffeef0f3),Color(0xfff8f9fa),Color(0xffffffff),Color(0xffeef0f3),Color(0xfff1f3f5),Color(0xffe1e4e8),
        Color(0xff16191e),Color(0xff4c535d),Color(0xff68707a),Color(0xff0e8f6b),Color(0xffffffff),Color(0x1a0e8f6b),Color(0xfff4f5f7),
        Color(0xffe7eaee),Color(0x0f000000),Color(0xffc0392b),Color(0xff1a1d22))
    if(!strong)return base
    // Strong contrast: every secondary text becomes primary-ink-ish, borders become visible lines.
    return if(dark)base.copy(tx=Color.White,tx2=Color(0xffe6e9ee),tx3=Color(0xffc9ced6),line=Color(0xff8a929c),acc=Color(0xff7ff5d3))
    else base.copy(tx=Color.Black,tx2=Color(0xff1f2329),tx3=Color(0xff3a4048),line=Color(0xff5a626c),acc=Color(0xff006b4f))
}
internal val LocalPro=staticCompositionLocalOf{proColors(true,false)}

/**
 * 1.0.2 liquid glass palette: surfaces become translucent (the glass shader draws the real backdrop),
 * text is a touch brighter/darker for contrast over arbitrary wallpapers.
 */
internal fun proGlassColors(b:ProColors):ProColors=if(b.dark)b.copy(
    bar=Color(0x29ffffff),group=Color(0x33000000),raised=Color(0x14ffffff),hover=Color(0x1fffffff),line=Color(0x21ffffff),
    tx=Color(0xfff4f6f9),tx2=Color(0xcceef2f7),tx3=Color(0x94e4e9f2),acc=Color(0xff6bf0c8),accSoft=Color(0x296bf0c8),field=Color(0x2e000000),work=Color(0x14000000),dot=Color(0x12ffffff))
else b.copy(
    bar=Color(0x8cffffff),group=Color(0x59ffffff),raised=Color(0x59ffffff),hover=Color(0x66ffffff),line=Color(0x14000000),
    tx=Color(0xff0e1116),tx2=Color(0xbd0e1116),tx3=Color(0x850e1116),acc=Color(0xff0a8a66),accSoft=Color(0x290a8a66),field=Color(0x61ffffff),work=Color(0x1fffffff),dot=Color(0x0f000000))
internal val LocalProModel=staticCompositionLocalOf<StudioModel?>{null}
internal val ProMono=FontFamily.Monospace

@Composable internal fun proIsDark(model:StudioModel)=when(model.themeMode){
    StudioModel.ThemeMode.SYSTEM->isSystemInDarkTheme();StudioModel.ThemeMode.LIGHT->false;StudioModel.ThemeMode.DARK->true}

@Composable internal fun ProTheme(model:StudioModel,content:@Composable ()->Unit){
    val dark=proIsDark(model)
    val c=proColors(dark,model.strongContrast).let{if(model.glassActive)proGlassColors(it) else it}
    val context=LocalContext.current
    val a=model.appearance
    // The 1.0.1 UI defaults to the system sans; a font the user explicitly picked in Appearance still applies.
    val family=remember(a.font,a.fontPath,a.gameFontRevision){if(a.font.startsWith("game:"))runCatching{FontFamily(Typeface.Builder(a.gameFontFile(a.font.removePrefix("game:"))).build())}.getOrDefault(FontFamily.Default) else when(a.font){
        "serif"->FontFamily.Serif;"mono"->FontFamily.Monospace
        "pixel"->runCatching{FontFamily(Typeface.createFromAsset(context.assets,"fonts/Monocraft.ttf"))}.getOrDefault(FontFamily.Monospace)
        "adventure"->runCatching{FontFamily(Typeface.createFromAsset(context.assets,"fonts/LXGWWenKai-Regular.ttf"))}.getOrDefault(FontFamily.Default)
        "custom"->runCatching{FontFamily(Typeface.Builder(a.fontPath).build())}.getOrDefault(FontFamily.Default)
        else->FontFamily.Default
    }}
    SideEffect{(context as? android.app.Activity)?.window?.let{window->
        val controls=androidx.core.view.WindowInsetsControllerCompat(window,window.decorView)
        controls.isAppearanceLightStatusBars=!dark;controls.isAppearanceLightNavigationBars=!dark
    }}
    val fontScale=a.fontSize
    val typography=remember(family,fontScale,c){
        fun t(size:Int,weight:FontWeight,line:Int)=TextStyle(fontFamily=family,fontWeight=weight,fontSize=(size*fontScale).sp,lineHeight=(line*fontScale).sp,color=c.tx)
        Typography(displayLarge=t(40,FontWeight.Bold,48),displayMedium=t(34,FontWeight.Bold,42),displaySmall=t(28,FontWeight.Bold,36),
            headlineLarge=t(26,FontWeight.Bold,34),headlineMedium=t(22,FontWeight.Bold,30),headlineSmall=t(19,FontWeight.Bold,26),
            titleLarge=t(17,FontWeight.Bold,24),titleMedium=t(15,FontWeight.SemiBold,22),titleSmall=t(13,FontWeight.SemiBold,20),
            bodyLarge=t(15,FontWeight.Normal,22),bodyMedium=t(13,FontWeight.Normal,20),bodySmall=t(12,FontWeight.Normal,17),
            labelLarge=t(13,FontWeight.Medium,18),labelMedium=t(12,FontWeight.Medium,16),labelSmall=t(11,FontWeight.Medium,14))
    }
    val scheme=if(dark)darkColorScheme(primary=c.acc,onPrimary=c.accTx,primaryContainer=c.raised,onPrimaryContainer=c.tx,secondary=c.acc,onSecondary=c.accTx,
        secondaryContainer=c.raised,onSecondaryContainer=c.tx,background=c.app,onBackground=c.tx,surface=c.group,onSurface=c.tx,surfaceVariant=c.raised,onSurfaceVariant=c.tx2,
        outline=c.line,outlineVariant=c.line,error=c.danger,errorContainer=c.raised,onErrorContainer=c.tx,surfaceContainerLowest=c.app,surfaceContainerLow=c.bar,
        surfaceContainer=c.group,surfaceContainerHigh=c.raised,surfaceContainerHighest=c.hover)
    else lightColorScheme(primary=c.acc,onPrimary=c.accTx,primaryContainer=c.raised,onPrimaryContainer=c.tx,secondary=c.acc,onSecondary=c.accTx,
        secondaryContainer=c.raised,onSecondaryContainer=c.tx,background=c.app,onBackground=c.tx,surface=c.group,onSurface=c.tx,surfaceVariant=c.raised,onSurfaceVariant=c.tx2,
        outline=c.line,outlineVariant=c.line,error=c.danger,errorContainer=c.raised,onErrorContainer=c.tx,surfaceContainerLowest=c.app,surfaceContainerLow=c.bar,
        surfaceContainer=c.group,surfaceContainerHigh=c.raised,surfaceContainerHighest=c.hover)
    // UI scale (layout setting) and "large interface" (accessibility) multiply the density.
    val density=LocalDensity.current
    val scale=model.uiScale*(if(model.largeUi)1.15f else 1f)
    CompositionLocalProvider(LocalPro provides c,LocalProModel provides model,LocalFreeDark provides dark,LocalQuiet provides model.motionOff,LocalTransparent provides false,
        LocalDensity provides Density(density.density*scale,density.fontScale)){
        MaterialTheme(colorScheme=scheme,typography=typography,
            shapes=Shapes(extraSmall=RoundedCornerShape(6.dp),small=RoundedCornerShape(8.dp),medium=RoundedCornerShape(10.dp),large=RoundedCornerShape(12.dp),extraLarge=RoundedCornerShape(14.dp)),
            content=content)
    }
}
