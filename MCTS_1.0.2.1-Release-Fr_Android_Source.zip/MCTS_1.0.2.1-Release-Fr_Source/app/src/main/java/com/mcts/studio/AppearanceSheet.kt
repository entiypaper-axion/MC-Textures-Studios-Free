package com.mcts.studio

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.*
import kotlin.math.roundToInt

@Composable internal fun AppearanceSheet(model:StudioModel){
    val a=model.appearance
    val fonts=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(model::importUiFont)}
    val images=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(model::importBackground)}
    val videos=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(model::importVideoBackground)}
    Text(model.w("阳光 · 外观","Sunlight · Appearance","陽光・外観"),style=MaterialTheme.typography.headlineSmall)
    Text(model.w("修改立即生效，自动保存。仅改变界面，不影响材质与导出。","Live preview, saved automatically. Changes affect the interface only.","即時プレビュー・自動保存。テクスチャと出力には影響しません。"),style=MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(20.dp));Text(model.w("字体","Typeface","フォント"),style=MaterialTheme.typography.titleMedium)
    val choices=listOf("system" to model.w("系统基础","System","システム"),"serif" to model.w("基础衬线","Serif","明朝体"),"mono" to model.w("基础等宽","Monospace","等幅"),"pixel" to model.w("Java 像素风 · Monocraft","Java pixel style · Monocraft","Javaピクセル風・Monocraft"),"adventure" to model.w("幻想手写 · 霞鹜文楷","Fantasy handwriting · WenKai","幻想手書き・WenKai"))
    choices.forEach{(key,label)->SpringChip(a.font==key,{a.chooseFont(key)},label={Text(label)},enabled=!model.busy)}
    if(a.fontPath.isNotBlank())SpringChip(a.font=="custom",{a.chooseFont("custom")},label={Text(model.w("已导入字体","Imported font","読み込んだフォント"))},enabled=!model.busy)
    Text(model.w("Monocraft 是开源 Minecraft 风格字体，非官方原字；中文使用系统回退。文楷是开源字体，并非原神字体。原神等字体可从你有权使用的 TTF / OTF 文件导入。","Monocraft is an open-source Minecraft-inspired font, not the original; CJK uses system fallback. WenKai is not Genshin's font. Import a TTF/OTF you have permission to use for other game fonts.","MonocraftはMinecraft風のオープンフォント（公式ではありません）。文楷も原神のフォントではありません。利用可能なTTF/OTFを読み込めます。"),style=MaterialTheme.typography.bodySmall)
    Action(model.w("导入字体 · TTF / OTF / TTC","Import TTF / OTF / TTC","TTF / OTF / TTCを読み込む"),model,!model.busy){fonts.launch(arrayOf("*/*"))}
    Text(model.w("文字大小","Text size","文字サイズ")+" ${(a.fontSize*100).roundToInt()}%")
    ElasticSlider(a.fontSize,a::size,valueRange=.85f..1.4f,modifier=Modifier.semantics{contentDescription=model.w("文字大小","Text size","文字サイズ")})
    Text(model.w("在系统无障碍字号基础上叠加。","Also respects system accessibility text scaling.","システムの文字拡大設定にも対応します。"),style=MaterialTheme.typography.bodySmall)
    var editInk by remember{mutableStateOf(false)}
    SpringTextButton({editInk=!editInk}){Text(model.w("文字颜色","Text color","文字の色"));Box(Modifier.padding(start=8.dp).size(22.dp).background(Color(a.textColor),CircleShape))}
    if(editInk)UiColorField(model.w("文字颜色","Text color","文字の色"),a.textColor,a::ink)
    HorizontalDivider(Modifier.padding(vertical=18.dp));Text(model.w("背景","Background","背景"),style=MaterialTheme.typography.titleMedium)
    val backgrounds=listOf("sunrise" to model.w("柠檬日出","Lemon sunrise","レモンの日の出"),"lake" to model.w("天湖蓝","Sky lake","青い湖"),"lime" to model.w("青柠微风","Lime breeze","ライムの風"),"custom" to model.w("自选双色","Two custom colors","2色グラデーション"))
    backgrounds.forEach{(key,label)->SpringChip(a.background==key,{a.backdrop(key)},label={Text(label)})}
    if(a.background=="custom"){UiColorField(model.w("渐变起点","Gradient start","開始色"),a.colorA,a::first);UiColorField(model.w("渐变终点","Gradient end","終了色"),a.colorB,a::second)}
    Action(model.w("从相册选择背景","Choose background image","背景画像を選ぶ"),model,!model.busy){images.launch(arrayOf("image/*"))}
    if(a.imagePath.isNotBlank())SpringChip(a.background=="image",{a.backdrop("image")},label={Text(model.w("使用已保存图片","Use saved image","保存した画像を使用"))})
    if(a.background=="image"){
        Text(model.w("图片柔光遮罩","Image light veil","画像の明るいベール")+" ${(a.veil*100).roundToInt()}%")
        ElasticSlider(a.veil,a::wash,valueRange=.15f..95f/100,modifier=Modifier.semantics{contentDescription=model.w("图片遮罩强度","Image veil strength","画像のベール強度")})
        Text(model.w("等比铺满，居中裁切；图片复制到本机，离线可用。","Center-cropped to fill. Copied locally for offline use.","中央を基準に画面全体へ配置。端末にコピーしオフラインでも利用可能。"),style=MaterialTheme.typography.bodySmall)
    }
    if(!model.isFree){
    Action(model.t("import_video"),model,!model.busy){videos.launch(arrayOf("video/*"))}
    if(a.videoPath.isNotBlank())SpringChip(a.background=="video",{a.backdrop("video")},label={Text(model.t("saved_video"))})
    if(a.background=="video"){
        Text(model.t("video_veil")+" ${(a.veil*100).roundToInt()}%")
        ElasticSlider(a.veil,a::wash,valueRange=.15f..95f/100,modifier=Modifier.semantics{contentDescription=model.t("video_veil")})
        Text(model.t("video_hint"),style=MaterialTheme.typography.bodySmall)
    }
    }
    HorizontalDivider(Modifier.padding(vertical=18.dp))
    Row(verticalAlignment=Alignment.CenterVertically){if(model.isFree)StudioCheck(a.sound,a::sounds)else Switch(a.sound,a::sounds);Text(model.w("完成提示音（默认关闭）","Completion sound (off by default)","完了サウンド（初期値オフ）"),Modifier.padding(start=10.dp))}
    if(model.allows(com.mcts.core.EditionPolicy.Feature.SPRING_MOTION))Row(verticalAlignment=Alignment.CenterVertically){Switch(model.reducedMotion,model::setMotion);Text(model.t("motion"),Modifier.padding(start=10.dp))}
    Action(model.w("恢复默认外观","Reset appearance","外観を初期化"),model){a.reset()}
}

@Composable private fun UiColorField(label:String,value:Int,onChange:(Int)->Unit){
    val hsv=remember(value){FloatArray(3).also{android.graphics.Color.colorToHSV(value,it)}}
    var area by remember{mutableStateOf(IntSize(1,1))};val latest by rememberUpdatedState(hsv);val update by rememberUpdatedState(onChange)
    fun pick(p:Offset){update(android.graphics.Color.HSVToColor(floatArrayOf(latest[0],(p.x/area.width.coerceAtLeast(1)).coerceIn(0f,1f),(1-p.y/area.height.coerceAtLeast(1)).coerceIn(0f,1f))))}
    Text(label,style=MaterialTheme.typography.labelLarge)
    Row(Modifier.horizontalScroll(rememberScrollState())){listOf(0xff163945,0xff185dab,0xff813863,0xff9c3e19,0xff157552,0xff000000,0xffffffff).forEach{v->val source=remember(v){MutableInteractionSource()};Box(Modifier.then(if(BuildConfig.IS_FREE)freePress(source)else Modifier).size(48.dp).padding(5.dp).background(Color(v),CircleShape).then(if(LocalTransparent.current)Modifier else Modifier.border(1.dp,Color(0xff7a9999),CircleShape)).clickable(interactionSource=source,indication=if(BuildConfig.IS_FREE)null else LocalIndication.current){onChange(v.toInt())}.semantics{contentDescription="$label #${v.toString(16).takeLast(6)}"})}}
    Canvas(Modifier.fillMaxWidth().height(100.dp).onSizeChanged{area=it}.semantics{contentDescription=label}.pointerInput(Unit){detectTapGestures{pick(it)}}.pointerInput(Unit){detectDragGestures(onDragStart={pick(it)}){change,_->change.consume();pick(change.position)}}){
        drawRect(Color.hsv(hsv[0],1f,1f));drawRect(Brush.horizontalGradient(listOf(Color.White,Color.Transparent)));drawRect(Brush.verticalGradient(listOf(Color.Transparent,Color.Black)))
        val at=Offset(hsv[1]*size.width,(1-hsv[2])*size.height);drawCircle(Color.Black,7.dp.toPx(),at,style=Stroke(4.dp.toPx()));drawCircle(Color.White,7.dp.toPx(),at,style=Stroke(2.dp.toPx()))
    }
    Text("H ${hsv[0].roundToInt()} · S ${(hsv[1]*100).roundToInt()} · V ${(hsv[2]*100).roundToInt()}",style=MaterialTheme.typography.labelSmall)
    ElasticSlider(hsv[0],{onChange(android.graphics.Color.HSVToColor(floatArrayOf(it,hsv[1],hsv[2])))},valueRange=0f..359.99f,modifier=Modifier.semantics{contentDescription="$label H"})
    ElasticSlider(hsv[1],{onChange(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0],it,hsv[2])))},modifier=Modifier.semantics{contentDescription="$label S"})
    ElasticSlider(hsv[2],{onChange(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0],hsv[1],it)))},modifier=Modifier.semantics{contentDescription="$label V"})
}
