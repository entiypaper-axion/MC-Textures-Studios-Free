package com.mcts.studio

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp

@Composable internal fun SunTextField(value:String,onValueChange:(String)->Unit,modifier:Modifier=Modifier,
    label:(@Composable ()->Unit)?=null,enabled:Boolean=true,singleLine:Boolean=false){
    val clear=LocalTransparent.current
    if(BuildConfig.IS_FREE){
        Column(modifier.padding(vertical=4.dp)){
            label?.invoke()
            BasicTextField(value,onValueChange,enabled=enabled,singleLine=singleLine,
                textStyle=MaterialTheme.typography.bodyLarge.copy(color=MaterialTheme.colorScheme.onSurface),
                cursorBrush=SolidColor(MaterialTheme.colorScheme.primary),
                modifier=Modifier.fillMaxWidth().then(if(clear)Modifier else Modifier.background(MaterialTheme.colorScheme.surface,RoundedCornerShape(12.dp)).border(1.dp,MaterialTheme.colorScheme.outline,RoundedCornerShape(12.dp))).padding(12.dp))
        };return
    }
    OutlinedTextField(value,onValueChange,modifier=modifier,label=label,enabled=enabled,singleLine=singleLine,
        colors=OutlinedTextFieldDefaults.colors(
            focusedBorderColor=if(clear)Color.Transparent else MaterialTheme.colorScheme.primary,
            unfocusedBorderColor=if(clear)Color.Transparent else MaterialTheme.colorScheme.outline,
            disabledBorderColor=if(clear)Color.Transparent else MaterialTheme.colorScheme.outlineVariant))
}
