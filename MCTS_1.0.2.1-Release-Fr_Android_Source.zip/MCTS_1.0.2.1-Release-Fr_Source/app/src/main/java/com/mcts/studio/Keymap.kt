package com.mcts.studio

import android.view.KeyEvent

/** Keyboard shortcuts. Codes are Android KeyEvent key codes so they survive layout/language changes. */
enum class KeyAction(val zh:String,val en:String,val ja:String,val fr:String,val es:String){
    PENCIL("画笔","Pencil","ペン","Crayon","Lápiz"),
    ERASER("橡皮（白色）","Eraser (white)","消しゴム（白）","Gomme (blanc)","Goma (blanco)"),
    ERASE("擦除（透明）","Erase (transparent)","消去（透明）","Effacer (transparent)","Borrar (transparente)"),
    FILL("填充","Fill","塗りつぶし","Remplir","Rellenar"),
    PICKER("吸管","Eyedropper","スポイト","Pipette","Cuentagotas"),
    MOVE("移动","Move","移動","Déplacer","Mover"),
    MIRROR("镜像","Mirror","ミラー","Miroir","Espejo"),
    GRID("网格","Grid","グリッド","Grille","Cuadrícula"),
    UNDO("撤销","Undo","元に戻す","Annuler","Deshacer"),
    REDO("重做","Redo","やり直す","Rétablir","Rehacer"),
    REDO_ALT("重做（备用）","Redo (alternate)","やり直す（予備）","Rétablir (autre)","Rehacer (alternativo)"),
    BRUSH_DOWN("笔刷变小","Smaller brush","ブラシを小さく","Pinceau plus petit","Pincel más pequeño"),
    BRUSH_UP("笔刷变大","Larger brush","ブラシを大きく","Pinceau plus grand","Pincel más grande"),
    SWAP("交换主副色","Swap colours","メイン色とサブ色を入替","Inverser les couleurs","Intercambiar colores"),
    SAVE("保存","Save","保存","Enregistrer","Guardar"),
    EXPORT("导出","Export","書き出し","Exporter","Exportar"),
    ZOOM_IN("放大","Zoom in","拡大","Zoom avant","Acercar"),
    ZOOM_OUT("缩小","Zoom out","縮小","Zoom arrière","Alejar"),
    FIT("适配","Fit","全体表示","Ajuster","Ajustar");
    fun label(language:Language)=when(language){Language.ZH->zh;Language.EN->en;Language.JA->ja;Language.FR->fr;Language.ES->es}
}

data class KeyChord(val code:Int,val ctrl:Boolean=false,val shift:Boolean=false,val alt:Boolean=false){
    fun label():String{
        val name=when(code){
            KeyEvent.KEYCODE_LEFT_BRACKET->"[";KeyEvent.KEYCODE_RIGHT_BRACKET->"]";KeyEvent.KEYCODE_EQUALS->"=";KeyEvent.KEYCODE_MINUS->"-"
            KeyEvent.KEYCODE_SPACE->"Space";KeyEvent.KEYCODE_PLUS->"+"
            else->KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_").let{if(it.length==1)it else it.lowercase().replaceFirstChar{c->c.uppercaseChar()}}
        }
        // "Shift+3" is shown as "#" (US layout), matching the shortcut list in the guide.
        if(shift&&!ctrl&&!alt&&code==KeyEvent.KEYCODE_3)return "#"
        return listOfNotNull(if(ctrl)"Ctrl" else null,if(alt)"Alt" else null,if(shift)"Shift" else null,name).joinToString("+")
    }
    fun encode()="$code,${if(ctrl)1 else 0},${if(shift)1 else 0},${if(alt)1 else 0}"
    companion object{
        fun decode(text:String):KeyChord?{val p=text.split(',');if(p.size!=4)return null;val code=p[0].toIntOrNull()?:return null
            return KeyChord(code,p[1]=="1",p[2]=="1",p[3]=="1")}
        /** Modifier keys alone can never be a shortcut. */
        fun isModifier(code:Int)=code in setOf(KeyEvent.KEYCODE_CTRL_LEFT,KeyEvent.KEYCODE_CTRL_RIGHT,KeyEvent.KEYCODE_SHIFT_LEFT,KeyEvent.KEYCODE_SHIFT_RIGHT,
            KeyEvent.KEYCODE_ALT_LEFT,KeyEvent.KEYCODE_ALT_RIGHT,KeyEvent.KEYCODE_META_LEFT,KeyEvent.KEYCODE_META_RIGHT,KeyEvent.KEYCODE_FUNCTION,KeyEvent.KEYCODE_CAPS_LOCK)
    }
}

class Keymap private constructor(private val map:Map<KeyAction,KeyChord>){
    fun chord(action:KeyAction)=map[action]
    fun action(chord:KeyChord)=map.entries.firstOrNull{it.value==chord}?.key
    /** A chord belongs to one action only: binding it moves it away from any previous owner. */
    fun bind(action:KeyAction,chord:KeyChord)=Keymap(map.filterValues{it!=chord}+(action to chord))
    fun save()=map.entries.joinToString(";"){"${it.key.name}=${it.value.encode()}"}
    companion object{
        fun defaults()=Keymap(mapOf(
            KeyAction.PENCIL to KeyChord(KeyEvent.KEYCODE_B),KeyAction.ERASER to KeyChord(KeyEvent.KEYCODE_E),KeyAction.ERASE to KeyChord(KeyEvent.KEYCODE_E,shift=true),
            KeyAction.FILL to KeyChord(KeyEvent.KEYCODE_G),KeyAction.PICKER to KeyChord(KeyEvent.KEYCODE_I),KeyAction.MOVE to KeyChord(KeyEvent.KEYCODE_V),
            KeyAction.MIRROR to KeyChord(KeyEvent.KEYCODE_M),KeyAction.GRID to KeyChord(KeyEvent.KEYCODE_3,shift=true),
            KeyAction.UNDO to KeyChord(KeyEvent.KEYCODE_Z,ctrl=true),KeyAction.REDO to KeyChord(KeyEvent.KEYCODE_Y,ctrl=true),KeyAction.REDO_ALT to KeyChord(KeyEvent.KEYCODE_Z,ctrl=true,shift=true),
            KeyAction.BRUSH_DOWN to KeyChord(KeyEvent.KEYCODE_LEFT_BRACKET),KeyAction.BRUSH_UP to KeyChord(KeyEvent.KEYCODE_RIGHT_BRACKET),KeyAction.SWAP to KeyChord(KeyEvent.KEYCODE_X),
            KeyAction.SAVE to KeyChord(KeyEvent.KEYCODE_S,ctrl=true),KeyAction.EXPORT to KeyChord(KeyEvent.KEYCODE_E,ctrl=true),
            KeyAction.ZOOM_IN to KeyChord(KeyEvent.KEYCODE_EQUALS,ctrl=true),KeyAction.ZOOM_OUT to KeyChord(KeyEvent.KEYCODE_MINUS,ctrl=true),KeyAction.FIT to KeyChord(KeyEvent.KEYCODE_0,ctrl=true)))
        fun load(text:String?):Keymap{
            if(text.isNullOrBlank())return defaults()
            val parsed=text.split(';').mapNotNull{entry->val k=entry.substringBefore('=');val v=entry.substringAfter('=',"")
                val action=KeyAction.entries.firstOrNull{it.name==k}?:return@mapNotNull null
                KeyChord.decode(v)?.let{action to it}}.toMap()
            // Actions added in later versions fall back to their defaults.
            return Keymap(defaults().map.filterKeys{it !in parsed}.filterValues{it !in parsed.values}+parsed)
        }
    }
}
