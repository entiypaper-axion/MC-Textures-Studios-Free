package com.mcts.studio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionOnScreen
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.modifier.modifierLocalOf
import androidx.compose.ui.modifier.modifierLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Liquid glass (Android 13+, off by default). Modelled on iOS 26 "Liquid Glass": a frosted backdrop, a thick rounded
 * bevel that refracts what is behind it with a slight chromatic split, and a specular rim lit from the top left.
 *
 * 1.0.2.1: the backdrop is the LIVE interface, not the wallpaper alone. Every glass element records what lies under it
 * — the wallpaper, the drawing canvas, and the glass of the panel it sits on — into its own layer, blurs it with a
 * RenderEffect and runs the glass shader over the result. Dialogs (separate windows) see a snapshot of the whole
 * workspace that refreshes when the workspace redraws. Blur, opacity, refraction and highlights are adjustable for big
 * and small UI separately, and every element can be switched on or off on its own.
 */
internal object LiquidGlass {
    /** RuntimeShader needs API 33; below that the setting is unavailable and the 1.0.1 surfaces stay. */
    val supported get()=Build.VERSION.SDK_INT>=33&&!broken
    /** Set if the shader ever fails on this device (driver bug): glass then quietly falls back to the 1.0.1 surfaces. */
    @Volatile var broken=false

    /**
     * mode 0 = body: [wall] is the element's (blurred) backdrop layer, [inset] = where the element starts inside it.
     * mode 1 = rim/specular overlay drawn over the content ([wall] unused).
     */
    const val AGSL="""
uniform shader wall;
uniform float2 size;
uniform float2 inset;
uniform float radius;
uniform float bevel;
uniform float refraction;
uniform float4 tint;
uniform float sat;
uniform float spec;
uniform float edge;
uniform float lift;
uniform float mode;
uniform float shade;
uniform float disp;
uniform float2 light;

float sdf(float2 p) {
    float2 h = size * 0.5;
    float2 q = abs(p - h) - (h - radius);
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
}

half4 main(float2 coord) {
    float2 p = coord - inset;
    float d = sdf(p);
    float cov = clamp(0.5 - d, 0.0, 1.0);
    if (cov <= 0.0) { return half4(0.0); }
    // Wide finite differences smooth the creases of the rounded-rect distance field.
    float e = max(1.0, bevel * 0.25);
    float2 g = float2(sdf(p + float2(e, 0.0)) - sdf(p - float2(e, 0.0)), sdf(p + float2(0.0, e)) - sdf(p - float2(0.0, e)));
    float2 n = g / max(length(g), 0.0001);
    float inside = max(-d, 0.0);
    float t = clamp(1.0 - inside / max(bevel, 0.001), 0.0, 1.0);
    float prof = 1.0 - sqrt(clamp(1.0 - t * t, 0.0, 1.0));
    if (mode < 0.5) {
        float m = refraction * prof;
        float r = float(wall.eval(coord - n * m * (1.0 + disp)).r);
        float gg = float(wall.eval(coord - n * m).g);
        float b = float(wall.eval(coord - n * m * (1.0 - disp * 1.17)).b);
        float3 col = float3(r, gg, b);
        float l = dot(col, float3(0.2126, 0.7152, 0.0722));
        col = mix(float3(l), col, sat);
        col = mix(col, tint.rgb, tint.a);
        col = col * (1.0 - shade * prof) + float3(lift);
        col = clamp(col, 0.0, 1.0);
        return half4(half3(col * cov), half(cov));
    }
    float dt = -(n.x * light.x + n.y * light.y);
    float hi = pow(prof, 2.2) * (0.55 * pow(max(dt, 0.0), 1.4) + 0.28 * pow(max(-dt, 0.0), 1.6)) * spec;
    float k = inside / 1.1;
    float line = exp(-k * k) * edge * (0.55 + 0.45 * abs(dt));
    float a = clamp(hi + line, 0.0, 1.0) * cov;
    return half4(half3(a), half(a));
}
"""
    private val LIGHT=Offset(-.55f,-.83f).let{val l=kotlin.math.sqrt(it.x*it.x+it.y*it.y);Offset(it.x/l,it.y/l)}

    /** The rim shader never samples [wall], but every child shader must be bound. */
    private val dummy by lazy{BitmapShader(Bitmap.createBitmap(1,1,Bitmap.Config.ARGB_8888),Shader.TileMode.CLAMP,Shader.TileMode.CLAMP)}

    /** The user's wallpaper fitted to the window (the bottom of every backdrop); null = plain app colour. */
    @RequiresApi(33) fun prepare(path:String?,width:Int,height:Int):ImageBitmap?{
        if(width<8||height<8||path==null)return null
        val decoded=runCatching{
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(path,bounds)
            var sample=1;while(bounds.outWidth/(sample*2)>=width&&bounds.outHeight/(sample*2)>=height)sample*=2
            BitmapFactory.decodeFile(path,BitmapFactory.Options().apply{inSampleSize=sample})
        }.getOrNull()?:return null
        val src=IntArray(decoded.width*decoded.height);decoded.getPixels(src,0,decoded.width,0,0,decoded.width,decoded.height)
        val sharp=GlassBlur.cover(src,decoded.width,decoded.height,width,height)
        decoded.recycle()
        return Bitmap.createBitmap(sharp,width,height,Bitmap.Config.ARGB_8888).asImageBitmap()
    }

    @RequiresApi(33) internal fun configure(s:RuntimeShader,mode:Float,w:Float,h:Float,inset:Float,radius:Float,p:GlassParams,lift:Float){
        if(mode>.5f)s.setInputShader("wall",dummy)
        s.setFloatUniform("size",w,h);s.setFloatUniform("inset",inset,inset)
        s.setFloatUniform("radius",radius.coerceAtMost(minOf(w,h)/2f));s.setFloatUniform("bevel",p.bevel);s.setFloatUniform("refraction",p.refraction)
        s.setFloatUniform("tint",p.tint.red,p.tint.green,p.tint.blue,p.tintAlpha);s.setFloatUniform("sat",p.saturation)
        s.setFloatUniform("spec",p.spec);s.setFloatUniform("edge",p.edge);s.setFloatUniform("lift",lift);s.setFloatUniform("mode",mode)
        s.setFloatUniform("shade",p.shade);s.setFloatUniform("disp",p.dispersion);s.setFloatUniform("light",LIGHT.x,LIGHT.y)
    }

    /** Blur (if any) then the glass shader over the element's backdrop layer. */
    @RequiresApi(33) internal fun effect(body:RuntimeShader,blurPx:Float):android.graphics.RenderEffect{
        val glass=android.graphics.RenderEffect.createRuntimeShaderEffect(body,"wall")
        return if(blurPx<.5f)glass else android.graphics.RenderEffect.createChainEffect(glass,android.graphics.RenderEffect.createBlurEffect(blurPx,blurPx,Shader.TileMode.CLAMP))
    }
}

/** Which glass: decides category (big / small), thickness and tint. CONTROL = buttons, fields, switches, sliders, segments. */
internal enum class GlassKind { PANEL, WORK, DIALOG, PREVIEW, BAR, ICON, CHIP, CONTROL }

/** Big = home, side panels, the canvas card, dialogs. Small = icon buttons, controls, chips and floating panels. */
internal enum class GlassCategory { BIG, SMALL }

/** User tuning of one category (1.0.2.1). blurDp: how blurred things under the glass are; the others are multipliers (1 = design). */
@Immutable internal data class GlassTuning(val blurDp:Float,val opacity:Float,val refraction:Float,val highlight:Float){
    companion object {
        val BIG=GlassTuning(20f,1f,1f,1f)
        val SMALL=GlassTuning(3f,1f,1f,1f)
        const val MAX_BLUR=40f
    }
}

/** Everything the glass needs from the settings. [overrides] = per-element switches by element id. */
@Immutable internal class GlassConfig(val small:Boolean,val big:GlassTuning,val smallTuning:GlassTuning,val overrides:Map<String,Boolean>){
    fun tuning(category:GlassCategory)=if(category==GlassCategory.BIG)big else smallTuning
    fun defaultOn(category:GlassCategory)=category==GlassCategory.BIG||small
    fun enabled(id:String,category:GlassCategory)=overrides[id]?:defaultOn(category)
}

internal class GlassParams(val bevel:Float,val refraction:Float,val tint:Color,val tintAlpha:Float,val saturation:Float,val spec:Float,val edge:Float,val shade:Float,val dispersion:Float,val blurPx:Float)

/** Glass parameters in px for an element of [minSide] px. Matches the 1.0.2 design images at the default tuning. */
internal fun glassParams(kind:GlassKind,minSide:Float,density:Float,dark:Boolean,accent:Color?,strong:Boolean,t:GlassTuning):GlassParams{
    val panelTint=if(dark)Color(0xff0c0e14) else Color.White
    val boost=(if(strong)1.5f else 1f)*t.opacity
    val r=t.refraction;val h=t.highlight
    fun p(bevel:Float,refr:Float,tint:Color,alpha:Float,sat:Float,spec:Float,edge:Float,shade:Float)=
        GlassParams(bevel*r.coerceAtLeast(.2f),refr*r,tint,(alpha*boost).coerceIn(0f,.95f),sat,spec*h,edge*h,shade,.06f*h,t.blurDp*density)
    return when(kind){
        GlassKind.PANEL->p(12*density,15*density,panelTint,if(dark).36f else .40f,1.25f,1f,.35f,if(dark).10f else .03f)
        GlassKind.DIALOG->p(15*density,18*density,panelTint,if(dark).44f else .50f,1.25f,1f,.35f,if(dark).10f else .03f)
        GlassKind.WORK->p(11*density,11*density,panelTint,if(dark).30f else .32f,1.2f,.9f,.3f,if(dark).08f else .03f)
        GlassKind.BAR->p(10*density,12*density,panelTint,if(dark).30f else .36f,1.25f,1f,.35f,if(dark).10f else .03f)
        GlassKind.PREVIEW->p(10*density,10*density,Color(0xff06080c),.62f,1.1f,.8f,.3f,.08f)
        GlassKind.CHIP->p(minSide*.30f,minSide*.22f,accent?:Color.White,if(accent!=null)(if(dark).22f else .16f) else if(dark).05f else .30f,1.25f,.8f,.28f,if(dark).10f else .03f)
        GlassKind.CONTROL->p(minOf(minSide*.42f,14*density),minOf(minSide*.30f,10*density),accent?:panelTint,if(accent!=null)(if(dark).40f else .34f) else if(dark).22f else .30f,1.25f,.9f,.32f,if(dark).10f else .03f)
        GlassKind.ICON->p(minSide*.5f,minSide*.42f,accent?:Color.White,if(accent!=null)(if(dark).24f else .18f) else if(dark).03f else .10f,1.35f,1.25f,.42f,if(dark).10f else .03f)
    }
}

/** A glass element in the layout tree: the backdrop layer it draws is part of the backdrop of glass placed on it. */
internal class GlassNode(val parent:GlassNode?){
    var layer:GraphicsLayer?=null
    var pos by mutableStateOf(Offset.Zero)
    var pad=0f
    var ready by mutableStateOf(false)
    fun isAncestorOf(other:GlassNode?):Boolean{var n=other;while(n!=null){if(n===this)return true;n=n.parent};return false}
}
internal val ModifierLocalGlassNode=modifierLocalOf<GlassNode?>{null}

/** Live content under the glass: the wallpaper and the drawing canvas. [owner] = the glass element it lies on. */
internal class GlassSource(val owner:GlassNode?,val layer:GraphicsLayer,val base:Boolean){
    var pos by mutableStateOf(Offset.Zero)
    var version by mutableIntStateOf(0)
}

/** One glass-capable element on screen (for picking elements in the layout editor). */
internal class GlassEntry(val rect:Rect,val category:GlassCategory)

/** Per-window glass state, provided by [ProvideGlass]. */
@Stable internal class GlassState(val on:Boolean,val dark:Boolean,val strong:Boolean,initial:GlassConfig){
    /** Switches and tuning; changing them must not rebuild the state (sources and the wallpaper stay). */
    var config by mutableStateOf(initial)
    var rootOnScreen by mutableStateOf(Offset.Zero)
    var wallpaper by mutableStateOf<ImageBitmap?>(null)
    val sources=mutableStateListOf<GlassSource>()
    /** Snapshot of the whole workspace for glass in dialog windows. */
    var screen by mutableStateOf<ImageBitmap?>(null)
    val elements=mutableStateMapOf<String,GlassEntry>()
}
internal val LocalGlass=staticCompositionLocalOf{GlassState(false,true,false,GlassConfig(true,GlassTuning.BIG,GlassTuning.SMALL,emptyMap()))}
/** True inside a dialog window: the backdrop is the workspace snapshot. */
internal val LocalGlassWindow=staticCompositionLocalOf{false}
/** Set inside a custom-UI block: its outermost glass counts as a "floating panel" (small UI). */
internal val LocalFloatingBlock=staticCompositionLocalOf{false}

/** Creates the glass state for the whole workspace, dialogs included. */
@Composable internal fun ProvideGlass(model:StudioModel,content:@Composable ()->Unit){
    val c=LocalPro.current
    val on=model.glassActive
    val config=remember(model.glassSmall,model.glassBigTuning,model.glassSmallTuning,model.glassOverrides){GlassConfig(model.glassSmall,model.glassBigTuning,model.glassSmallTuning,model.glassOverrides)}
    val state=remember(on,c.dark,model.strongContrast){GlassState(on,c.dark,model.strongContrast,config)}
    SideEffect{state.config=config}
    CompositionLocalProvider(LocalGlass provides state,content=content)
}

/**
 * Root of the workspace: wallpaper (or the plain app colour) at the bottom of every backdrop, and the workspace snapshot
 * that glass in dialogs sees. When glass is off this is just the 1.0.1 background.
 */
@Composable internal fun GlassRoot(model:StudioModel,modifier:Modifier=Modifier,content:@Composable BoxScope.()->Unit){
    val c=LocalPro.current
    val state=LocalGlass.current;val on=state.on
    var size by remember{mutableStateOf(IntSize.Zero)}
    val path=model.appearance.wallpaperPath.takeIf{it.isNotBlank()&&File(it).isFile}
    LaunchedEffect(state,on,path,size){
        state.wallpaper=if(on&&Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU)withContext(Dispatchers.Default){runCatching{LiquidGlass.prepare(path,size.width,size.height)}.getOrNull()} else null
    }
    val screenLayer=rememberGraphicsLayer()
    var screenVersion by remember{mutableIntStateOf(0)}
    // Dialog glass: refresh the workspace snapshot while dialogs are open (live settings, theme changes…).
    LaunchedEffect(state,on,model.dialogsOpen>0){
        if(!on||model.dialogsOpen<=0){state.screen=null;return@LaunchedEffect}
        snapshotFlow{screenVersion}.collectLatest{
            delay(60)
            state.screen=runCatching{screenLayer.toImageBitmap()}.getOrNull()
        }
    }
    Box(modifier.fillMaxSize().background(c.app).onSizeChanged{size=it}.onGloballyPositioned{state.rootOnScreen=it.positionOnScreen()}
        .then(if(on)Modifier.drawWithContent{screenLayer.record{this@drawWithContent.drawContent()};drawLayer(screenLayer);screenVersion++} else Modifier)){
        // The bottom of every backdrop: wallpaper or app colour.
        // glassSource first, so the recorded backdrop includes the app colour under the wallpaper.
        Box(Modifier.fillMaxSize().then(if(on)Modifier.glassSource(base=true) else Modifier).background(c.app)){
            state.wallpaper?.let{Image(it,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)}
        }
        content()
    }
}

/** Marks live content (wallpaper, the drawing canvas) that glass elements show, blurred, through themselves. */
@Composable internal fun Modifier.glassSource(base:Boolean=false):Modifier{
    val g=LocalGlass.current
    if(!g.on||!LiquidGlass.supported)return this
    val layer=rememberGraphicsLayer()
    var owner by remember{mutableStateOf<GlassNode?>(null)}
    val source=remember(layer,owner){GlassSource(owner,layer,base)}
    DisposableEffect(source,g){g.sources.add(source);onDispose{g.sources.remove(source)}}
    return this
        .modifierLocalConsumer{owner=ModifierLocalGlassNode.current}
        .onGloballyPositioned{source.pos=it.positionOnScreen()}
        .drawWithContent{
            layer.record{this@drawWithContent.drawContent()}
            drawLayer(layer)
            source.version++
        }
}

/**
 * Glass body under the content and specular rim over it; falls back to [fallback] when glass is off for this element.
 * [id] tells elements of the same call site apart (icon / label). The element must not be clipped by a parent that hides its rim.
 */
@Composable internal fun Modifier.glass(kind:GlassKind,radius:Dp,accent:Color?=null,lift:State<Float>?=null,id:String?=null,fallback:Modifier=Modifier.clip(RoundedCornerShape(radius))):Modifier{
    val g=LocalGlass.current
    if(!g.on||!LiquidGlass.supported)return this.then(fallback)
    val inDialog=LocalGlassWindow.current
    val floating=LocalFloatingBlock.current
    val key=currentCompositeKeyHash.toString(36)+":"+(id?:kind.name)
    var parent by remember{mutableStateOf<GlassNode?>(null)}
    val category=when{kind==GlassKind.ICON||kind==GlassKind.CHIP||kind==GlassKind.CONTROL->GlassCategory.SMALL;floating&&parent==null&&!inDialog->GlassCategory.SMALL;else->GlassCategory.BIG}
    val enabled=g.config.enabled(key,category)
    // Register for the layout editor's "pick glass" mode, on or off.
    DisposableEffect(key,g){onDispose{g.elements.remove(key)}}
    val register=Modifier.onGloballyPositioned{val p=it.positionOnScreen();g.elements[key]=GlassEntry(Rect(p,Size(it.size.width.toFloat(),it.size.height.toFloat())),category)}
    if(!enabled)return this.modifierLocalConsumer{parent=ModifierLocalGlassNode.current}.then(register).then(fallback)
    val shaders=remember{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU)runCatching{RuntimeShader(LiquidGlass.AGSL) to RuntimeShader(LiquidGlass.AGSL)}.onFailure{LiquidGlass.broken=true}.getOrNull() else null}
    if(shaders==null)return this.then(fallback)
    val (body,rim)=shaders
    val layer=rememberGraphicsLayer()
    val self=remember(parent){GlassNode(parent).also{it.layer=layer}}
    val density=LocalDensity.current.density
    val shape=RoundedCornerShape(radius)
    val elevation=when(kind){GlassKind.ICON,GlassKind.CHIP,GlassKind.CONTROL->3.dp;GlassKind.DIALOG->18.dp;else->8.dp}
    val tuning=g.config.tuning(category)
    return this
        .modifierLocalConsumer{parent=ModifierLocalGlassNode.current}
        .modifierLocalProvider(ModifierLocalGlassNode){self}
        .then(register)
        .shadow(elevation,shape,clip=false,ambientColor=Color.Black.copy(alpha=if(g.dark).5f else .25f),spotColor=Color.Black.copy(alpha=if(g.dark).5f else .25f))
        .onGloballyPositioned{self.pos=it.positionOnScreen()}
        .drawWithContent{
            val p=glassParams(kind,minOf(size.width,size.height),density,g.dark,accent,g.strong,tuning)
            val r=radius.toPx();val l=lift?.value?:0f
            val pad=(p.blurPx*2f+p.refraction+2f).coerceAtMost(160f)
            self.pad=pad
            val ok=Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU&&runCatching{
                val w=size.width;val h=size.height;val me=self.pos
                layer.record(IntSize((w+2*pad).toInt().coerceAtLeast(1),(h+2*pad).toInt().coerceAtLeast(1))){
                    drawBackdrop(g,self,me,pad,inDialog)
                }
                LiquidGlass.configure(body,0f,w,h,pad,r,p,l)
                layer.renderEffect=LiquidGlass.effect(body,p.blurPx).asComposeRenderEffect()
                LiquidGlass.configure(rim,1f,w,h,0f,r,p,l)
            }.onFailure{LiquidGlass.broken=true}.isSuccess
            if(ok){
                translate(-pad,-pad){drawLayer(layer)}
                self.ready=true
                drawContent()
                drawRect(ShaderBrush(rim))
            }else{
                drawRoundRect(p.tint.copy(alpha=.6f),cornerRadius=CornerRadius(r))
                drawContent()
            }
        }
        .clip(shape)
}

/**
 * What lies under [self] at [me] (screen px), drawn into its backdrop layer offset by [pad]: the wallpaper / workspace
 * snapshot, then the glass bodies it sits on (outermost first), then live content that is not inside it (the canvas).
 */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBackdrop(g:GlassState,self:GlassNode,me:Offset,pad:Float,inDialog:Boolean){
    if(inDialog){
        g.screen?.let{img->translate(g.rootOnScreen.x-me.x+pad,g.rootOnScreen.y-me.y+pad){drawImage(img)}}
    }else{
        g.sources.firstOrNull{it.base}?.let{s->s.version;translate(s.pos.x-me.x+pad,s.pos.y-me.y+pad){drawLayer(s.layer)}}
    }
    val chain=ArrayList<GlassNode>();var n=self.parent;while(n!=null){chain.add(0,n);n=n.parent}
    for(a in chain){
        val l=a.layer?:continue
        if(!a.ready)continue
        translate(a.pos.x-a.pad-me.x+pad,a.pos.y-a.pad-me.y+pad){drawLayer(l)}
    }
    if(!inDialog)for(s in g.sources){
        if(s.base||self.isAncestorOf(s.owner))continue
        s.version
        translate(s.pos.x-me.x+pad,s.pos.y-me.y+pad){drawLayer(s.layer)}
    }
}

/**
 * Surface for every Pro panel/control: liquid glass when on (and on for this element), otherwise the 1.0.1 fill + 1 dp border.
 * Always clips to the rounded shape.
 */
@Composable internal fun Modifier.proSurface(kind:GlassKind,radius:Dp,color:Color,border:Color?=LocalPro.current.line,accent:Color?=null,lift:State<Float>?=null,id:String?=null):Modifier{
    val shape=RoundedCornerShape(radius)
    val plain=Modifier.clip(shape).background(color).then(if(border!=null)Modifier.border(1.dp,border,shape)else Modifier)
    return this.glass(kind,radius,accent,lift,id,plain)
}

/** True when liquid glass is drawing (for small tweaks such as the softened icons under glass). */
internal val glassOn:Boolean @Composable get()=LocalGlass.current.on&&LiquidGlass.supported

/** True when small UI gets glass by default (the global small-UI switch). Single elements may still differ. */
internal val smallGlassOn:Boolean @Composable get()=glassOn&&LocalGlass.current.config.small

/**
 * "Pick glass" mode (from the glass settings or the layout editor): outlines every glass-capable element
 * (solid accent = glass on, dashed = off); tapping one switches its glass. The pill on top ends the mode.
 */
@Composable internal fun GlassPickOverlay(model:StudioModel,modifier:Modifier=Modifier){
    val g=LocalGlass.current
    val c=LocalPro.current
    var origin by remember{mutableStateOf(Offset.Zero)}
    Box(modifier.fillMaxSize().onGloballyPositioned{origin=it.positionOnScreen()}){
        Canvas(Modifier.fillMaxSize().pointerInput(g){
            detectTapGestures{at->
                val p=at+origin
                val hit=g.elements.entries.filter{it.value.rect.contains(p)}.minByOrNull{it.value.rect.width*it.value.rect.height}?:return@detectTapGestures
                model.toggleGlassElement(hit.key,!g.config.enabled(hit.key,hit.value.category))
            }
        }){
            drawRect(Color.Black.copy(alpha=.18f))
            val dash=PathEffect.dashPathEffect(floatArrayOf(8f,6f))
            for((id,e) in g.elements){
                val on=g.config.enabled(id,e.category)
                val tl=e.rect.topLeft-origin
                drawRoundRect(if(on)c.acc else Color.White.copy(alpha=.75f),tl,e.rect.size,CornerRadius(6.dp.toPx()),
                    style=Stroke(width=if(on)2.5f else 1.5f,pathEffect=if(on)null else dash))
            }
        }
        // Plain (non-glass) controls so the pill itself is not pickable.
        Row(Modifier.align(Alignment.TopCenter).padding(top=10.dp,start=12.dp,end=12.dp).clip(RoundedCornerShape(14.dp)).background(c.tx.copy(alpha=.92f))
            .padding(start=14.dp,end=6.dp,top=6.dp,bottom=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Text(model.p("glass_pick_hint"),style=MaterialTheme.typography.bodySmall,color=c.app,modifier=Modifier.weight(1f,fill=false))
            if(model.glassOverrides.isNotEmpty())Text(model.p("glass_pick_clear"),style=MaterialTheme.typography.labelLarge,color=c.app,
                modifier=Modifier.clip(RoundedCornerShape(10.dp)).clickable{model.clearGlassOverrides()}.padding(horizontal=10.dp,vertical=8.dp))
            Text(model.p("layout_done"),style=MaterialTheme.typography.labelLarge,color=c.accTx,
                modifier=Modifier.clip(RoundedCornerShape(10.dp)).background(c.acc).clickable{model.glassPicking=false}.padding(horizontal=12.dp,vertical=8.dp))
        }
    }
}
