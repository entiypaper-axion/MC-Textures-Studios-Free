package com.mcts.studio

import android.content.Context
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContracts

/** ZIP MIME makes DocumentsUI append .zip to unknown .mcpack extensions.
 * Keep Java's ZIP type, but let Bedrock's exact title survive the file picker.
 */
internal class ExportPackDocument : ActivityResultContracts.CreateDocument("application/octet-stream") {
    override fun createIntent(context: Context, input: String): Intent =
        super.createIntent(context, input).setType(mimeType(input))

    companion object {
        fun mimeType(fileName: String): String =
            if (fileName.endsWith(".mcpack", ignoreCase = true)) "application/octet-stream"
            else "application/zip"
    }
}
