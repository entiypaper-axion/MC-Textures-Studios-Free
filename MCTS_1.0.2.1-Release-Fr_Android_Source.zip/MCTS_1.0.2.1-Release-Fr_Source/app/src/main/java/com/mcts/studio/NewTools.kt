package com.mcts.studio
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.selection.selectable
import androidx.compose.ui.semantics.Role
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.*
import com.mcts.core.MaterialDocument
import kotlin.math.roundToInt

internal fun StudioModel.w(zh:String,en:String,ja:String)=when(language){Language.ZH->zh;Language.EN->en;Language.JA->ja;Language.FR->InlineWords.fr[en]?:en;Language.ES->InlineWords.es[en]?:en}

@Composable internal fun ColorBoard(model:StudioModel){
    val initial=remember{FloatArray(3).also{android.graphics.Color.colorToHSV(0xff000000.toInt() or (model.rgb.toIntOrNull(16)?:0),it)}}
    var hue by remember{mutableFloatStateOf(initial[0])};var sat by remember{mutableFloatStateOf(initial[1])};var light by remember{mutableFloatStateOf(initial[2])}
    var area by remember{mutableStateOf(IntSize(1,1))};val colors=model.recentColors()
    fun apply(){model.chooseColor(android.graphics.Color.HSVToColor(floatArrayOf(hue,sat,light)))}
    fun select(p:Offset){sat=(p.x/area.width.coerceAtLeast(1)).coerceIn(0f,1f);light=(1-p.y/area.height.coerceAtLeast(1)).coerceIn(0f,1f);apply()}
    Text(model.w("调色盘","Color palette","カラーパレット"),style=MaterialTheme.typography.headlineSmall)
    Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(48.dp).background(Color.hsv(hue,sat,light),CircleShape).then(if(model.transparentUi)Modifier else Modifier.border(1.dp,Color.White,CircleShape)));Text("  #${model.rgb.uppercase()}")}
    Spacer(Modifier.height(12.dp))
    Canvas(Modifier.fillMaxWidth().height(180.dp).onSizeChanged{area=it}.semantics{contentDescription=model.w("颜色板，下方滑杆也可调整","Color field; sliders also available","色パネル・スライダーでも調整可能")}
        .pointerInput(model.busy){if(!model.busy)detectTapGestures{select(it)}}
        .pointerInput(model.busy){if(!model.busy)detectDragGestures(onDragStart={select(it)}){change,_->change.consume();select(change.position)}}){
        drawRect(Color.hsv(hue,1f,1f));drawRect(Brush.horizontalGradient(listOf(Color.White,Color.Transparent)));drawRect(Brush.verticalGradient(listOf(Color.Transparent,Color.Black)))
        val at=Offset(sat*size.width,(1-light)*size.height);drawCircle(Color.Black,9.dp.toPx(),at,style=androidx.compose.ui.graphics.drawscope.Stroke(4.dp.toPx()));drawCircle(Color.White,9.dp.toPx(),at,style=androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
    }
    Spacer(Modifier.height(12.dp));Box(Modifier.fillMaxWidth().height(12.dp).background(Brush.horizontalGradient((0..6).map{Color.hsv((it*60f).coerceAtMost(359.99f),1f,1f)})))
    Text(model.w("色相","Hue","色相"));ElasticSlider(hue,{hue=it;apply()},valueRange=0f..359.99f,enabled=!model.busy,modifier=Modifier.semantics{contentDescription=model.w("色相","Hue","色相")})
    Text(model.w("饱和度","Saturation","彩度"));ElasticSlider(sat,{sat=it;apply()},enabled=!model.busy,modifier=Modifier.semantics{contentDescription=model.w("饱和度","Saturation","彩度")})
    Text(model.w("明度","Brightness","明度"));ElasticSlider(light,{light=it;apply()},enabled=!model.busy,modifier=Modifier.semantics{contentDescription=model.w("明度","Brightness","明度")})
    Text(model.t("recent_colors"),style=MaterialTheme.typography.labelLarge)
    BoxWithConstraints{val columns=if(maxWidth<400.dp)4 else 6
    colors.chunked(columns).forEach{row->Row(Modifier.fillMaxWidth()) {row.forEach{color->
        ColorSwatch(model,color,Modifier.weight(1f)){val hsv=FloatArray(3);android.graphics.Color.colorToHSV(color,hsv);hue=hsv[0];sat=hsv[1];light=hsv[2];apply()}
    }}}
    }
    SpringTextButton(onClick={model.keepSwatch()},enabled=!model.busy){Text(model.w("收藏当前颜色","Save swatch","この色を保存"))}
}

@Composable internal fun ProjectSheet(model:StudioModel,done:()->Unit){
    var name by remember{mutableStateOf("")};var profile by remember{mutableStateOf(model.pack.profile)};var template by remember{mutableStateOf(true)}
    Text(model.w("资源包项目","Resource pack projects","リソースパックプロジェクト"),style=MaterialTheme.typography.headlineSmall)
    ProjectManager(model,done)
    HorizontalDivider(Modifier.padding(vertical=16.dp));Text(model.w("创建独立项目","Create independent project","独立プロジェクトを作成"),style=MaterialTheme.typography.titleLarge)
    SunTextField(name,{name=it.take(80)},label={Text(model.w("项目名称","Project name","プロジェクト名"))},singleLine=true,modifier=Modifier.fillMaxWidth())
    Row {SpringChip(profile.java,{if(!profile.java)profile=gameProfiles.first{it.java&&it.version==profile.pair}},label={Text("Java")});SpringChip(!profile.java,{if(profile.java)profile=gameProfiles.first{!it.java&&it.version==profile.pair}},label={Text(model.w("基岩版","Bedrock","統合版"))})}
    Row(Modifier.horizontalScroll(rememberScrollState())){gameProfiles.filter{it.java==profile.java}.forEach{p->SpringChip(profile==p,{profile=p},label={Text(p.version)})}}
    Text(model.w("对应内容时期：","Paired content era: ","対応する内容の時期：")+profile.pair)
    Row {SpringChip(template,{template=true},label={Text(model.w("纹理模板","Texture template","テクスチャテンプレート"))});SpringChip(!template,{template=false},label={Text(model.w("空白项目","Blank project","空白プロジェクト"))})}
    if(!model.isFree&&!profile.java&&!profile.vv)Text(model.w("此旧版本尚无 Vibrant Visuals。导出普通资源包，PBR 数据保留在项目中。","This historical version predates Vibrant Visuals; exports color resources and retains PBR in the project.","この旧版はVibrant Visuals非対応。色のみ出力しPBRは保持。"))
    Text(model.t("template_start_hint"))
    if(model.isFree)SpringTextButton({done();model.showStartPage()},enabled=!model.busy){Text(model.t("start_home"))}
    if(template&&profile.id !in model.availableTemplates)Text(model.t("download_required"))
    Action(model.t("create"),model,!model.busy&&name.isNotBlank()&&(!template||profile.id in model.availableTemplates)){model.createPack(name,profile,template);done()}
}

@Composable internal fun ColumnScope.SplitEditor(model:StudioModel,palette:()->Unit,tools:()->Unit){
    val revision=model.revision
    Text("${model.document.name} · ${model.document.width} × ${model.document.height}",style=MaterialTheme.typography.labelSmall,maxLines=1)
    Row(Modifier.horizontalScroll(rememberScrollState()),verticalAlignment=Alignment.CenterVertically){
        SpringTextButton(onClick=model::undo,enabled=!model.busy&&model.undoEnabled){Text(model.t("undo"))};SpringTextButton(onClick=model::redo,enabled=!model.busy&&model.redoEnabled){Text(model.t("redo"))}
        SpringTextButton(onClick=palette,enabled=!model.busy){Box(Modifier.size(20.dp).background(Color(0xff000000.toInt() or (model.rgb.toIntOrNull(16)?:0)),CircleShape));Text(model.w(" 调色盘"," Palette"," パレット"))}
        SpringChip(model.sampler,model::toggleSampler,label={Text(model.w("吸管","Eyedropper","スポイト"))},enabled=!model.busy)
        SpringTextButton(onClick=tools){Text(model.w("工具","Tools","ツール"))}
    }
    Row(Modifier.horizontalScroll(rememberScrollState())){model.channels.forEach{c->SpringChip(model.channel==c,{model.selectChannel(c)},enabled=!model.busy,label={Text(model.t(c.name))})}}
    if(model.channel!=MaterialDocument.Channel.COLOR&&model.channel!=MaterialDocument.Channel.NORMAL)Row(verticalAlignment=Alignment.CenterVertically){Text("${model.value}");ElasticSlider(model.value.toFloat(),{model.changeBrushValue(it.roundToInt())},valueRange=0f..255f,onValueChangeFinished=model::finishValue,enabled=!model.busy,modifier=Modifier.weight(1f))}
    if(model.sampler)Text(model.w("点击画布取样；不会修改像素。再点吸管取消。","Tap canvas to sample without painting; tap Eyedropper to cancel.","キャンバスをタップして採色。再度スポイトで解除。"),style=MaterialTheme.typography.labelSmall)
    Row(verticalAlignment=Alignment.CenterVertically){Text(model.w("预览","Preview","プレビュー")+" ${(model.previewRatio*100).roundToInt()}%",style=MaterialTheme.typography.labelSmall);ElasticSlider(model.previewRatio,model::resizePreview,valueRange=.15f..85f/100,onValueChangeFinished=model::saveRatio,modifier=Modifier.weight(1f).semantics{contentDescription=model.w("预览占比","Preview ratio","プレビュー比率")});SpringTextButton(onClick={model.resizePreview(.4f);model.saveRatio()}){Text(model.w("重置","Reset","リセット"))}}
    BoxWithConstraints(Modifier.fillMaxWidth().weight(1f)){
        val horizontal=maxWidth>maxHeight*1.2f;var area by remember{mutableStateOf(IntSize(1,1))}
        val drag=Modifier.pointerInput(horizontal,area){detectDragGestures(onDragEnd=model::saveRatio,onDragCancel=model::saveRatio){change,amount->change.consume();model.resizePreview(model.previewRatio+(if(horizontal)amount.x/area.width.coerceAtLeast(1)else amount.y/area.height.coerceAtLeast(1)))}}
        if(horizontal)Row(Modifier.fillMaxSize().onSizeChanged{area=it}){
            Preview(model,Modifier.weight(model.previewRatio).fillMaxHeight());Box(Modifier.width(24.dp).fillMaxHeight().then(drag),contentAlignment=Alignment.Center){Box(Modifier.width(4.dp).height(56.dp).background(MaterialTheme.colorScheme.primary))};PixelCanvas(model,Modifier.weight(1-model.previewRatio).fillMaxHeight())
        }else Column(Modifier.fillMaxSize().onSizeChanged{area=it}){
            Preview(model,Modifier.weight(model.previewRatio).fillMaxWidth());Box(Modifier.height(24.dp).fillMaxWidth().then(drag),contentAlignment=Alignment.Center){Box(Modifier.height(4.dp).width(56.dp).background(MaterialTheme.colorScheme.primary))};PixelCanvas(model,Modifier.weight(1-model.previewRatio).fillMaxWidth())
        }
    }
}

/** Selected colors stay recognizable even for white, yellow and black swatches. */
@Composable internal fun ColorSwatch(model:StudioModel,color:Int,modifier:Modifier=Modifier,onClick:()->Unit={model.chooseColor(color)}){
    val selected=(color and 0xffffff)==(model.brushColor and 0xffffff)
    val source=remember{MutableInteractionSource()}
    val ink=if(((color ushr 16 and 255)*299+(color ushr 8 and 255)*587+(color and 255)*114)>145000)Color.Black else Color.White
    Box(modifier.height(56.dp).padding(4.dp).background(Color(color),RoundedCornerShape(12.dp))
        .then(if(model.transparentUi)Modifier else Modifier.border(if(selected)2.dp else 1.dp,if(selected)MaterialTheme.colorScheme.primary else Color(0xff6a7f80),RoundedCornerShape(12.dp)))
        .then(if(model.isFree)freePress(source,!model.busy)else Modifier)
        .selectable(selected=selected,interactionSource=source,indication=null,role=Role.RadioButton,enabled=!model.busy,onClick=onClick)
        .semantics{contentDescription=model.t("paint")+" #"+Integer.toHexString(color).takeLast(6).uppercase()},contentAlignment=Alignment.Center){
        if(selected)Text("✓",color=ink)
    }
}
