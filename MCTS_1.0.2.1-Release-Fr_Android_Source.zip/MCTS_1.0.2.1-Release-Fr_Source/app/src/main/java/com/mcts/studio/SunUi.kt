package com.mcts.studio

import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlin.math.*

internal val LocalFreeDark=staticCompositionLocalOf{false}
internal val LocalQuiet=staticCompositionLocalOf{false}
internal val LocalTransparent=staticCompositionLocalOf{false}
internal val SunInk=Color(0xff163945)
internal val SunCoral=Color(0xffff996c)
internal val SunPink=Color(0xffffadc5)
internal val SunCyan=Color(0xff83ecec)
internal val SunYellow=Color(0xffffe78a)
private val MaterialFreeProgressColor=Color(0xff007c87)

@OptIn(ExperimentalMaterial3Api::class)
@Composable internal fun StudioTheme(model:StudioModel,content:@Composable ()->Unit){
    val a=model.appearance;val context=LocalContext.current
    val family=remember(a.font,a.fontPath){when(a.font){
        "serif"->FontFamily.Serif;"mono"->FontFamily.Monospace
        "pixel"->runCatching{FontFamily(Typeface.createFromAsset(context.assets,"fonts/Monocraft.ttf"))}.getOrDefault(FontFamily.Monospace)
        "adventure"->runCatching{FontFamily(Typeface.createFromAsset(context.assets,"fonts/LXGWWenKai-Regular.ttf"))}.getOrDefault(FontFamily.Serif)
        "custom"->runCatching{FontFamily(Typeface.Builder(a.fontPath).build())}.getOrDefault(FontFamily.Default)
        else->FontFamily.Default
    }}
    val dark=model.isFree&&when(model.themeMode){StudioModel.ThemeMode.SYSTEM->isSystemInDarkTheme();StudioModel.ThemeMode.LIGHT->false;StudioModel.ThemeMode.DARK->true}
    val customInk=Color(a.textColor)
    val ink=if(dark&&customInk.luminance()<.45f)Color(0xffe5f4f0)else if(model.highContrast)Color(0xff07222d)else customInk
    SideEffect{(context as? android.app.Activity)?.window?.let{window->
        val controls=androidx.core.view.WindowInsetsControllerCompat(window,window.decorView)
        controls.isAppearanceLightStatusBars=!dark;controls.isAppearanceLightNavigationBars=!dark
    }}
    val typography=remember(family,a.fontSize,ink){val base=Typography();fun style(s:TextStyle)=s.copy(fontFamily=family,fontSize=s.fontSize*a.fontSize,lineHeight=s.lineHeight*a.fontSize,color=ink)
        Typography(displayLarge=style(base.displayLarge),displayMedium=style(base.displayMedium),displaySmall=style(base.displaySmall),headlineLarge=style(base.headlineLarge),headlineMedium=style(base.headlineMedium),headlineSmall=style(base.headlineSmall),titleLarge=style(base.titleLarge),titleMedium=style(base.titleMedium),titleSmall=style(base.titleSmall),bodyLarge=style(base.bodyLarge),bodyMedium=style(base.bodyMedium),bodySmall=style(base.bodySmall),labelLarge=style(base.labelLarge),labelMedium=style(base.labelMedium),labelSmall=style(base.labelSmall))}
    CompositionLocalProvider(LocalFreeDark provides dark,LocalQuiet provides model.reducedMotion,LocalTransparent provides model.transparentUi,LocalRippleConfiguration provides if(model.isFree)null else RippleConfiguration()){MaterialTheme(
        colorScheme=if(dark)freeDarkColors(ink)else lightColorScheme(primary=Color(0xff007c87),onPrimary=Color.White,primaryContainer=SunCyan,onPrimaryContainer=ink,secondary=Color(0xffad4c24),secondaryContainer=SunYellow,onSecondaryContainer=ink,tertiary=Color(0xffb74364),tertiaryContainer=SunPink,onTertiaryContainer=ink,background=Color(0xfffffcf5),onBackground=ink,surface=Color(0xfffffdf8),onSurface=ink,surfaceVariant=Color(0xffeaf6f1),onSurfaceVariant=ink,outline=Color(0xff718d8e),outlineVariant=Color(0xffc9dedc),surfaceContainer=Color(0xfff9fcf5),surfaceContainerHigh=Color(0xfff1f9f2)),
        typography=typography,shapes=Shapes(small=RoundedCornerShape(16.dp),medium=RoundedCornerShape(20.dp),large=RoundedCornerShape(24.dp),extraLarge=RoundedCornerShape(28.dp)),content=content)}
}

@Composable internal fun ambientPhase(model:StudioModel,duration:Int=9000):State<Float> {
    val lifecycle=LocalLifecycleOwner.current.lifecycle;var active by remember{mutableStateOf(lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))}
    DisposableEffect(lifecycle){val observer=LifecycleEventObserver{_,_->active=lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)};lifecycle.addObserver(observer);onDispose{lifecycle.removeObserver(observer)}}
    if(!active||model.reducedMotion||model.highContrast)return rememberUpdatedState(0f)
    val transition=rememberInfiniteTransition(label="sunlit breathing")
    return transition.animateFloat(0f,1f,infiniteRepeatable(tween(duration,easing=LinearEasing)),label="water phase")
}

@Composable internal fun SunBackground(model:StudioModel,modifier:Modifier=Modifier){
    val a=model.appearance;val phase=ambientPhase(model);val dark=LocalFreeDark.current;val background=MaterialTheme.colorScheme.background
    val context=LocalContext.current;val lifecycle=LocalLifecycleOwner.current.lifecycle
    val video=remember(context){if(model.isFree)null else VideoWallpaperView(context)}
    if(video!=null)DisposableEffect(video,lifecycle,a.background){
        val observer=LifecycleEventObserver{_,_->if(a.background=="video"&&lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))video.resume()else video.pause()}
        lifecycle.addObserver(observer)
        if(a.background=="video"&&lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))video.resume()
        onDispose{lifecycle.removeObserver(observer);video.pause()}
    }
    val photo by produceState<ImageBitmap?>(null,a.imagePath){value=if(a.imagePath.isBlank())null else withContext(Dispatchers.IO){runCatching{BitmapFactory.decodeFile(a.imagePath)?.asImageBitmap()}.getOrNull()}}
    val colors=when(a.background){"lake"->listOf(Color(0xffb0ecff),Color(0xffc7fff0));"lime"->listOf(Color(0xffedff91),Color(0xffb9f7c8));"custom"->listOf(Color(a.colorA),Color(a.colorB));else->listOf(SunYellow,SunPink)}
    Box(modifier){
        Canvas(Modifier.matchParentSize()){
            drawRect(background)
            if(dark)drawRect(Brush.linearGradient(colors.map{it.copy(alpha=.055f)}))
            if(!model.highContrast&&!dark){
                drawRect(Brush.linearGradient(colors.map{it.copy(alpha=.65f)},start=Offset.Zero,end=Offset(size.width,size.height)))
                val angle=phase.value*2*PI.toFloat();val glow=Offset(size.width*(.16f+.08f*sin(angle)),size.height*(.23f+.04f*cos(angle)))
                drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha=.96f),Color.White.copy(alpha=0f)),center=glow,radius=size.width*.8f),size.width*.8f,glow)
                drawCircle(Brush.radialGradient(listOf(SunCyan.copy(alpha=.5f),SunCyan.copy(alpha=0f)),center=Offset(size.width*.95f,size.height*.62f),radius=size.width*.75f),size.width*.75f,Offset(size.width*.95f,size.height*.62f))
                for(i in 0..2){val path=Path();val y=size.height*(.38f+i*.18f);path.moveTo(-60f,y);path.cubicTo(size.width*.3f,y-85f*sin(angle+i),size.width*.6f,y+100f*cos(angle+i),size.width+60f,y+30f);drawPath(path,Color.White.copy(alpha=.22f),style=Stroke(2.dp.toPx()))}
            }
        }
        if(a.background=="image"&&photo!=null&&!model.highContrast){Image(photo!!,null,Modifier.matchParentSize(),contentScale=ContentScale.Crop);Box(Modifier.matchParentSize().background(if(dark)Color.Black.copy(alpha=a.veil.coerceAtLeast(.65f))else Color.White.copy(alpha=a.veil)))}
        if(video!=null&&a.background=="video"&&a.videoPath.isNotBlank()&&!model.highContrast){
            AndroidView(factory={video},update={it.show(a.videoPath)},modifier=Modifier.matchParentSize())
            Box(Modifier.matchParentSize().background(if(dark)Color.Black.copy(alpha=a.veil.coerceAtLeast(.65f))else Color.White.copy(alpha=a.veil)))
        }
    }
}

@Composable private fun pressScale(source:MutableInteractionSource):Float{
    val pressed by source.collectIsPressedAsState();val quiet=LocalQuiet.current
    return animateFloatAsState(if(pressed&&!quiet).925f else 1f,if(quiet)snap()else spring(dampingRatio=.50f,stiffness=1100f),label="sun bounce").value
}
/** The only Free motion: short, linear press feedback, no spring or page transition. */
@Composable internal fun freePress(source:MutableInteractionSource,enabled:Boolean=true):Modifier {
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if(pressed&&enabled).97f else 1f,tween(80,easing=LinearEasing),label="free press")
    return Modifier.graphicsLayer{scaleX=scale;scaleY=scale;alpha=if(pressed&&enabled).86f else 1f}
}
@Composable internal fun SpringTextButton(onClick:()->Unit,modifier:Modifier=Modifier,enabled:Boolean=true,content:@Composable RowScope.()->Unit){
    if(BuildConfig.IS_FREE){
        val source=remember{MutableInteractionSource()};val pressed by source.collectIsPressedAsState()
        Row(modifier.then(freePress(source,enabled)).defaultMinSize(minWidth=48.dp,minHeight=48.dp).clip(RoundedCornerShape(16.dp))
            .then(if(pressed&&!LocalTransparent.current)Modifier.background(MaterialTheme.colorScheme.primaryContainer)else Modifier)
            .clickable(interactionSource=source,indication=null,role=Role.Button,enabled=enabled,onClick=onClick).padding(horizontal=12.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){
            ProvideTextStyle(MaterialTheme.typography.labelLarge.copy(color=MaterialTheme.colorScheme.onSurface.copy(alpha=if(enabled)1f else .42f))){content()}
        };return
    }
    val interaction=remember{MutableInteractionSource()};val scale=pressScale(interaction)
    TextButton(onClick=onClick,modifier=modifier.graphicsLayer{scaleX=scale;scaleY=scale},enabled=enabled,interactionSource=interaction,content=content)
}
@Composable internal fun SpringChip(selected:Boolean,onClick:()->Unit,label:@Composable ()->Unit,modifier:Modifier=Modifier,enabled:Boolean=true){
    if(BuildConfig.IS_FREE){
        val clear=LocalTransparent.current;val source=remember{MutableInteractionSource()};val pressed by source.collectIsPressedAsState()
        Box(modifier.then(freePress(source,enabled)).padding(end=4.dp).defaultMinSize(minWidth=48.dp,minHeight=48.dp).clip(RoundedCornerShape(16.dp))
            .then(if(clear)Modifier else Modifier.background(if(selected||pressed)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh))
            .selectable(selected,interactionSource=source,indication=null,role=Role.Tab,enabled=enabled,onClick=onClick).padding(12.dp)){
            ProvideTextStyle(MaterialTheme.typography.labelLarge.copy(color=MaterialTheme.colorScheme.onSurface.copy(alpha=if(enabled)1f else .42f))){
                Row{if(selected)Text("✓ ");label()}
            }
        };return
    }
    val source=remember{MutableInteractionSource()};val scale=pressScale(source)
    val clear=LocalTransparent.current
    FilterChip(selected,onClick,label,modifier=modifier.padding(end=4.dp).graphicsLayer{scaleX=scale;scaleY=scale},enabled=enabled,shape=RoundedCornerShape(50),interactionSource=source,
        colors=FilterChipDefaults.filterChipColors(containerColor=if(clear)Color.Transparent else Color.White.copy(alpha=.46f),selectedContainerColor=if(clear)Color.Transparent else SunCyan.copy(alpha=.68f)),border=if(clear)null else FilterChipDefaults.filterChipBorder(enabled,selected,borderColor=Color.White,selectedBorderColor=Color(0xff27aeb5)))
}
@Composable internal fun SunButton(text:String,enabled:Boolean=true,onClick:()->Unit){
    if(BuildConfig.IS_FREE){
        val clear=LocalTransparent.current;val source=remember{MutableInteractionSource()};val pressed by source.collectIsPressedAsState()
        Box(Modifier.then(freePress(source,enabled)).padding(vertical=5.dp).defaultMinSize(minWidth=48.dp,minHeight=48.dp).clip(RoundedCornerShape(16.dp))
            .then(if(clear)Modifier else Modifier.background(if(!enabled)MaterialTheme.colorScheme.surfaceContainerHigh else if(pressed)MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primaryContainer))
            .clickable(interactionSource=source,indication=null,role=Role.Button,enabled=enabled,onClick=onClick).padding(horizontal=20.dp,vertical=14.dp)){
            Text(text,color=MaterialTheme.colorScheme.onSurface.copy(alpha=if(enabled)1f else .42f))
        };return
    }
    val source=remember{MutableInteractionSource()};val scale=pressScale(source);val shape=RoundedCornerShape(50)
    val clear=LocalTransparent.current
    Button(onClick,modifier=Modifier.padding(vertical=5.dp).defaultMinSize(minWidth=48.dp,minHeight=48.dp).graphicsLayer{scaleX=scale;scaleY=scale}
        .then(if(clear)Modifier else Modifier.shadow(if(enabled)7.dp else 0.dp,shape,ambientColor=SunCoral.copy(alpha=.26f),spotColor=SunCoral.copy(alpha=.3f))
        .background(Brush.linearGradient(if(enabled)listOf(SunYellow,SunCoral,SunPink)else listOf(Color(0xffe8eded),Color(0xffe8eded))),shape)
        .border(1.dp,Brush.verticalGradient(listOf(Color.White,Color.White.copy(alpha=.2f))),shape)),
        enabled=enabled,interactionSource=source,shape=shape,colors=ButtonDefaults.buttonColors(containerColor=Color.Transparent,contentColor=SunInk,disabledContainerColor=Color.Transparent)) {Text(text)}
}
@Composable internal fun WaveItem(index:Int,content:@Composable ()->Unit){
    if(BuildConfig.IS_FREE){Box(Modifier.fillMaxWidth().padding(vertical=3.dp).then(if(LocalTransparent.current)Modifier else Modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh,RoundedCornerShape(16.dp)))){content()};return}
    val quiet=LocalQuiet.current;val enter=remember{Animatable(if(quiet)1f else 0f)}
    val clear=LocalTransparent.current
    LaunchedEffect(quiet){if(quiet)enter.snapTo(1f)else{delay((index.coerceAtMost(5)*22).toLong());enter.animateTo(1f,tween(180,easing=FastOutSlowInEasing))}}
    val shape=RoundedCornerShape(18.dp)
    Box(Modifier.fillMaxWidth().padding(vertical=3.dp).graphicsLayer{alpha=enter.value;translationY=(1-enter.value)*10.dp.toPx();scaleX=.985f+.015f*enter.value;scaleY=scaleX}
        .clip(shape).then(if(clear)Modifier else Modifier.background(Color.White.copy(alpha=.40f)).border(1.dp,Color.White.copy(alpha=.7f),shape))){content()}
}
@Composable internal fun FlowProgress(model:StudioModel){
    if(model.isFree){
        val track=MaterialTheme.colorScheme.surfaceVariant;val fill=MaterialTheme.colorScheme.primary
        Column(Modifier.fillMaxWidth()){
            Text(model.t("working")+if(model.progress>0f)" ${(model.progress*100).roundToInt()}%" else "",style=MaterialTheme.typography.labelSmall,modifier=Modifier.semantics{liveRegion=LiveRegionMode.Polite})
            Canvas(Modifier.fillMaxWidth().height(4.dp).semantics{progressBarRangeInfo=if(model.progress>0f)ProgressBarRangeInfo(model.progress.coerceIn(0f,1f),0f..1f)else ProgressBarRangeInfo.Indeterminate}){
                drawRect(track);drawRect(fill,size=androidx.compose.ui.geometry.Size(size.width*(if(model.progress>0f)model.progress else .35f),size.height))
            }
        };return
    }
    val phase=ambientPhase(model,1300);val progress=model.progress
    Canvas(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).semantics{liveRegion=LiveRegionMode.Polite;progressBarRangeInfo=if(progress>0f)ProgressBarRangeInfo(progress.coerceIn(0f,1f),0f..1f)else ProgressBarRangeInfo.Indeterminate}){
        drawRect(Color.White.copy(alpha=.7f));val x=phase.value*size.width*2-size.width*.5f
        if(progress>0f)drawRect(Brush.horizontalGradient(listOf(SunCoral,SunPink,SunCyan)),size=androidx.compose.ui.geometry.Size(size.width*progress.coerceIn(0f,1f),size.height))
        else if(model.reducedMotion||model.highContrast)drawRect(SunCyan,size=androidx.compose.ui.geometry.Size(size.width*.35f,size.height))
        else drawRect(Brush.linearGradient(listOf(SunYellow,SunCoral,SunCyan,SunYellow),start=Offset(x,0f),end=Offset(x+size.width,0f)))
    }
}
@Composable internal fun SuccessGlow(model:StudioModel){
    if(model.isFree){
        val tone=remember(model.appearance.sound){if(model.appearance.sound)runCatching{ToneGenerator(AudioManager.STREAM_MUSIC,20)}.getOrNull()else null}
        DisposableEffect(tone){onDispose{tone?.release()}}
        LaunchedEffect(model.successPulse){if(model.successPulse>0)tone?.startTone(ToneGenerator.TONE_PROP_ACK,65)}
        return
    }
    val shine=remember{Animatable(0f)};val quiet=model.reducedMotion
    val tone=remember(model.appearance.sound){if(model.appearance.sound)runCatching{ToneGenerator(AudioManager.STREAM_MUSIC,20)}.getOrNull()else null}
    DisposableEffect(tone){onDispose{tone?.release()}}
    LaunchedEffect(model.successPulse){if(model.successPulse>0){tone?.startTone(ToneGenerator.TONE_PROP_ACK,65);if(!quiet){shine.snapTo(1f);shine.animateTo(0f,tween(650))}}}
    Canvas(Modifier.fillMaxSize()){
        if(shine.value>0f&&!quiet){val fade=shine.value;val center=Offset(size.width*.83f,size.height*.12f);val radius=(1f-fade)*80.dp.toPx()+10.dp.toPx();drawCircle(SunYellow.copy(alpha=fade*.6f),radius,center,style=Stroke(2.dp.toPx()));for(i in 0..7){val angle=i*PI.toFloat()/4;drawCircle(if(i%2==0)SunCyan.copy(alpha=fade)else SunCoral.copy(alpha=fade),3.dp.toPx()*fade,center+Offset(cos(angle)*radius,sin(angle)*radius))}}
    }
}
@Composable internal fun PageGlow(page:Int,model:StudioModel){
    if(model.isFree)return
    val reveal=remember{Animatable(0f)}
    LaunchedEffect(page,model.reducedMotion){if(model.reducedMotion)reveal.snapTo(0f)else{reveal.snapTo(1f);reveal.animateTo(0f,tween(240,easing=FastOutSlowInEasing))}}
    Canvas(Modifier.fillMaxSize()){
        val p=reveal.value
        if(p>0){val radius=(1-p)*size.width*.8f+size.width*.1f;val center=Offset(size.width*.5f,size.height*.35f)
            drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha=p*.18f),SunCyan.copy(alpha=p*.08f),Color.Transparent),center,radius),radius,center)}
    }
}
