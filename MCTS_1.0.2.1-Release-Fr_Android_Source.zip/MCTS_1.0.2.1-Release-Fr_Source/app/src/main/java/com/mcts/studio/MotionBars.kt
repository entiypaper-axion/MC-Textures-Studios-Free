package com.mcts.studio

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.*
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.*

/** One continuous glass track; the highlight follows the measured label, not an assumed equal width. */
@Composable internal fun SlidingBar(labels:List<String>,selected:Int,onSelect:(Int)->Unit,modifier:Modifier=Modifier,vertical:Boolean=false,enabled:Boolean=true){
    if(BuildConfig.IS_FREE){
        val clear=LocalTransparent.current
        val item:@Composable (Int,String)->Unit={i,label->
            val source=remember(i){MutableInteractionSource()}
            Box((if(vertical)Modifier.fillMaxWidth()else Modifier).then(freePress(source,enabled))
                .then(if(clear||i!=selected)Modifier else Modifier.background(MaterialTheme.colorScheme.primaryContainer,RoundedCornerShape(16.dp)))
                .selectable(selected=i==selected,enabled=enabled,role=Role.Tab,interactionSource=source,indication=null,onClick={onSelect(i)}).defaultMinSize(minHeight=48.dp).padding(12.dp)){
                Text(if(clear&&i==selected)"✓ $label" else label,style=MaterialTheme.typography.labelLarge)
            }
        }
        if(vertical)Column(modifier){labels.forEachIndexed{i,label->item(i,label)}}
        else Row(modifier.horizontalScroll(rememberScrollState())){labels.forEachIndexed{i,label->item(i,label)}}
        return
    }
    val bounds=remember(labels,vertical){mutableStateMapOf<Int,Rect>()};val target=bounds[selected]?:Rect.Zero
    val quiet=LocalQuiet.current
    val clear=LocalTransparent.current
    val spec:AnimationSpec<Float> = if(quiet)snap()else spring(dampingRatio=.60f,stiffness=850f)
    val x by animateFloatAsState(target.left,spec,label="selection x");val y by animateFloatAsState(target.top,spec,label="selection y")
    val width by animateFloatAsState(target.width,spec,label="selection width");val height by animateFloatAsState(target.height,spec,label="selection height")
    val shape=RoundedCornerShape(22.dp)
    Box(modifier.clip(shape).then(if(clear)Modifier else Modifier.background(Color.White.copy(alpha=.44f)).border(1.dp,Color.White.copy(alpha=.92f),shape))){
        Box(if(vertical)Modifier.fillMaxWidth()else Modifier.horizontalScroll(rememberScrollState())){
            Canvas(Modifier.matchParentSize()){
                if(width>0&&height>0){
                    val at=Offset(x+2.dp.toPx(),y+2.dp.toPx());val area=Size((width-4.dp.toPx()).coerceAtLeast(1f),(height-4.dp.toPx()).coerceAtLeast(1f));val corner=CornerRadius(19.dp.toPx())
                    drawRoundRect(Brush.linearGradient(listOf(SunCyan.copy(alpha=.9f),SunYellow.copy(alpha=.85f))),at,area,corner)
                    if(!clear)drawRoundRect(Color(0xff249aa5).copy(alpha=.65f),at,area,corner,style=Stroke(1.dp.toPx()))
                }
            }
            val item:@Composable (Int,String)->Unit={i,label->
                val source=remember(i){MutableInteractionSource()}
                Box((if(vertical)Modifier.fillMaxWidth()else Modifier).onGloballyPositioned{c->val r=c.boundsInParent();if(bounds[i]!=r)bounds[i]=r}
                    .selectable(i==selected,enabled=enabled,role=Role.Tab,interactionSource=source,indication=null,onClick={onSelect(i)}).defaultMinSize(minHeight=48.dp).padding(horizontal=12.dp,vertical=10.dp),contentAlignment=Alignment.Center){
                    Text(label,style=MaterialTheme.typography.labelLarge,maxLines=if(vertical)2 else 1)
                }
            }
            if(vertical)Column(Modifier.fillMaxWidth()){labels.forEachIndexed{i,label->item(i,label)}}else Row{labels.forEachIndexed{i,label->item(i,label)}}
        }
    }
}

@Composable internal fun <T> DirectionalContent(target:T,index:(T)->Int,modifier:Modifier=Modifier,content:@Composable (T)->Unit){
    if(BuildConfig.IS_FREE){Box(modifier){content(target)};return}
    val quiet=LocalQuiet.current
    AnimatedContent(targetState=target,modifier=modifier.clip(RoundedCornerShape(20.dp)),transitionSpec={
        val transform=if(quiet)fadeIn(snap()) togetherWith fadeOut(snap())
        else {
            val direction=if(index(targetState)>index(initialState))1 else -1
            (slideInHorizontally(spring(dampingRatio=.70f,stiffness=850f)){it*direction}+fadeIn(tween(110))) togetherWith
                (slideOutHorizontally(spring(dampingRatio=.78f,stiffness=850f)){-it*direction}+fadeOut(tween(180)))
        }
        transform.using(SizeTransform(clip=true))
    },label="directional page"){state->
        Box(Modifier.fillMaxSize().pointerInput(state,target){if(state!=target)awaitPointerEventScope{while(true)awaitPointerEvent(PointerEventPass.Initial).changes.forEach{it.consume()}}}){content(state)}
    }
}

@Composable internal fun CommandBar(modifier:Modifier=Modifier,scrollable:Boolean=true,content:@Composable RowScope.()->Unit){
    val clear=LocalTransparent.current
    if(BuildConfig.IS_FREE){Row(modifier.then(if(clear)Modifier else Modifier.background(Color(0xffeef4f3),RoundedCornerShape(16.dp))).then(if(scrollable)Modifier.horizontalScroll(rememberScrollState())else Modifier),verticalAlignment=Alignment.CenterVertically,content=content);return}
    Row(modifier.clip(RoundedCornerShape(22.dp)).then(if(clear)Modifier else Modifier.background(Color.White.copy(alpha=.5f)).border(1.dp,Color.White,RoundedCornerShape(22.dp))).then(if(scrollable)Modifier.horizontalScroll(rememberScrollState())else Modifier),verticalAlignment=Alignment.CenterVertically,content=content)
}
