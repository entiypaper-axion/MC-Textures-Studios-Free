package com.mcts.studio

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filterNotNull

/** One entry of the top bar (1.0.1 sketch: left 7 / centre 3 / right 9). */
private class BarItem(val icon:String,val label:String,val selected:Boolean=false,val enabled:Boolean=true,val onLongClick:(()->Unit)?=null,val onClick:()->Unit)

@Composable private fun BarGroup(items:List<BarItem>,labels:Boolean){
    ProGroup{items.forEach{ProIconButton(it.icon,it.label,it.onClick,selected=it.selected,enabled=it.enabled,showLabel=labels,onLongClick=it.onLongClick,tile=true)}}
}

/** The three top-bar groups (left 7 / centre 3 / right 9). */
private fun topBarItems(model:StudioModel,onDialog:(String)->Unit,editing:Boolean,dark:Boolean):Triple<List<BarItem>,List<BarItem>,List<BarItem>>{
    val free=!model.busy
    val left=listOf(
        BarItem("project",model.p("bar_project"),enabled=free){onDialog("projects")},
        BarItem("import",model.p("bar_import"),enabled=free){onDialog("import")},
        BarItem("export",model.p("bar_export"),enabled=free&&editing){onDialog("export")},
        BarItem("brush_settings",model.p("bar_brush"),enabled=editing){onDialog("brush")},
        BarItem("new",model.p("bar_new"),enabled=free){model.showStartPage()},
        BarItem("delete",model.p("bar_delete"),enabled=free&&editing){onDialog("delete")},
        BarItem("ui_layout",model.p("bar_layout")){onDialog("layout")})
    val mid=listOf(
        BarItem("canvas_left",model.p("bar_canvas_left"),selected=editing&&model.canvasAlign==StudioModel.CanvasAlign.LEFT,enabled=editing){model.changeCanvasAlign(StudioModel.CanvasAlign.LEFT)},
        BarItem("canvas_center",model.p("bar_canvas_center"),selected=editing&&model.canvasAlign==StudioModel.CanvasAlign.CENTER,enabled=editing){model.changeCanvasAlign(StudioModel.CanvasAlign.CENTER)},
        BarItem("canvas_right",model.p("bar_canvas_right"),selected=editing&&model.canvasAlign==StudioModel.CanvasAlign.RIGHT,enabled=editing){model.changeCanvasAlign(StudioModel.CanvasAlign.RIGHT)})
    val right=listOf(
        BarItem("keyboard_mouse",model.p("bar_keys")){onDialog("keys")},
        BarItem("accessibility",model.p("bar_a11y")){onDialog("a11y")},
        BarItem("label_toggle",model.p(if(model.labelMode)"bar_show_icons" else "bar_show_text"),selected=model.labelMode){model.toggleLabelMode()},
        BarItem("guide",model.p("bar_guide")){onDialog("guide")},
        BarItem(if(dark)"theme_dark" else "theme_light",model.p(if(dark)"bar_theme_dark" else "bar_theme_light"),onLongClick={onDialog("theme")}){model.toggleTheme(dark)},
        BarItem("language",model.p("bar_language")){onDialog("language")},
        BarItem("home",model.p("bar_home"),selected=!editing,enabled=free&&editing){model.goHome()},
        BarItem("feedback",model.p("bar_feedback")){onDialog("feedback")},
        BarItem("settings",model.p("bar_settings")){onDialog("settings")})
    return Triple(left,mid,right)
}

/** One top-bar group as a floating block (custom UI): scrolls when made narrower than its buttons. */
@Composable private fun BarBlock(model:StudioModel,which:Int,onDialog:(String)->Unit){
    val items=topBarItems(model,onDialog,!model.showStart,proIsDark(model)).toList()[which]
    Box(Modifier.fillMaxSize(),contentAlignment=Alignment.CenterStart){
        Row(Modifier.horizontalScroll(rememberScrollState())){BarGroup(items,model.labelMode)}
    }
}

/** Top bar. editing=false on the start screen: editor-only buttons are disabled and "home" is selected. */
@Composable internal fun ProTopBar(model:StudioModel,onDialog:(String)->Unit,editing:Boolean,compact:Boolean){
    val c=LocalPro.current
    val dark=proIsDark(model)
    val (left,mid,right)=topBarItems(model,onDialog,editing,dark)
    val labels=model.labelMode
    val glass=glassOn
    Box(Modifier.fillMaxWidth().then(if(glass)Modifier else Modifier.background(c.bar).drawBehind{drawLine(c.line,Offset(0f,size.height-1f),Offset(size.width,size.height-1f),1f)})
        .padding(horizontal=12.dp,vertical=if(compact)6.dp else 8.dp)){
        if(compact||labels){
            // Label mode / phone: everything in one scrollable row so nothing overlaps.
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                BarGroup(left,labels);BarGroup(mid,labels);BarGroup(right,labels)
            }
        }else{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){BarGroup(left,false);BarGroup(right,false)}
            Box(Modifier.align(Alignment.Center)){BarGroup(mid,false)}
        }
    }
}

@Composable private fun ProProgress(model:StudioModel){
    val c=LocalPro.current
    Box(Modifier.fillMaxWidth().height(3.dp).background(c.raised).semantics{progressBarRangeInfo=if(model.progress>0f)ProgressBarRangeInfo(model.progress.coerceIn(0f,1f),0f..1f)else ProgressBarRangeInfo.Indeterminate}){
        Box(Modifier.fillMaxHeight().fillMaxWidth(if(model.progress>0f)model.progress.coerceIn(0f,1f)else .35f).background(c.acc))
    }
}

/** Canvas column: dotted work area + drawing surface + status pill. */
@Composable internal fun ProCanvasArea(model:StudioModel,view:PaintViewport,modifier:Modifier=Modifier,onTouch:()->Unit={}){
    val c=LocalPro.current
    Box(modifier.proSurface(GlassKind.WORK,14.dp,c.work)
        // Touching the canvas hands keyboard focus back to the workspace so shortcuts work after typing in a field.
        .pointerInput(Unit){awaitEachGesture{awaitFirstDown(requireUnconsumed=false);onTouch()}}
        .drawBehind{
        val step=16.dp.toPx();val r=1.dp.toPx()
        var y=step;while(y<size.height){var x=step;while(x<size.width){drawCircle(c.dot,r,Offset(x,y));x+=step};y+=step}
    }){
        ProCanvas(model,view,Modifier.fillMaxSize().padding(start=16.dp,end=16.dp,top=16.dp,bottom=52.dp))
        if(model.showGestureHint)Row(Modifier.align(Alignment.TopCenter).padding(10.dp).proSurface(GlassKind.BAR,10.dp,c.group).padding(start=12.dp,end=4.dp),
            verticalAlignment=Alignment.CenterVertically){
            Text(model.p("gesture_hint"),style=MaterialTheme.typography.bodySmall,color=c.tx2,modifier=Modifier.weight(1f,fill=false))
            ProIconButton("close",model.t("got_it"),model::dismissGestureHint,size=32.dp)
        }
        ProStatusBar(model,view,Modifier.align(Alignment.BottomCenter).padding(bottom=10.dp))
    }
}

/** Phone bottom bar: colour, tools, undo/redo and the panels that live in the sidebar on tablets. */
@Composable private fun PhoneToolbar(model:StudioModel,onDialog:(String)->Unit){
    val c=LocalPro.current;val revision=model.revision
    val right=model.handMode==StudioModel.HandMode.RIGHT
    Row(Modifier.fillMaxWidth().then(if(glassOn)Modifier.padding(horizontal=8.dp,vertical=4.dp).glass(GlassKind.BAR,14.dp,fallback=Modifier.clip(RoundedCornerShape(14.dp)).background(c.bar)) else Modifier.background(c.bar).drawBehind{drawLine(c.line,Offset(0f,0f),Offset(size.width,0f),1f)})
        .horizontalScroll(rememberScrollState()).padding(horizontal=8.dp,vertical=6.dp),
        horizontalArrangement=if(right)Arrangement.spacedBy(4.dp,Alignment.End)else Arrangement.spacedBy(4.dp),verticalAlignment=Alignment.CenterVertically){
        val color=0xff000000.toInt() or (model.rgb.toIntOrNull(16)?:0)
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(Color(color)).border(1.dp,c.line,RoundedCornerShape(8.dp))
            .clickable(role=Role.Button){onDialog("color")}.semantics{contentDescription=model.p("color")+" #"+model.rgb.uppercase()})
        proTools.forEach{(tool,icon)->ProIconButton(icon,model.p("tool_"+tool.name.lowercase()),{model.selectTool(tool)},Modifier.popOn(model.tool==tool),selected=model.tool==tool,enabled=!model.busy,showLabel=model.labelMode,tile=true)}
        ProIconButton("undo",model.p("undo"),model::undo,enabled=!model.busy&&model.undoEnabled,showLabel=model.labelMode,tile=true)
        ProIconButton("redo",model.p("redo"),model::redo,enabled=!model.busy&&model.redoEnabled,showLabel=model.labelMode,tile=true)
        ProIconButton("image",model.p("tab_assets"),{onDialog("assets")},showLabel=model.labelMode,tile=true)
        ProIconButton("layers",model.p("tab_layers"),{onDialog("layers")},showLabel=model.labelMode,tile=true)
        ProIconButton("cube",model.p("preview_3d"),{onDialog("preview")},showLabel=model.labelMode,tile=true)
    }
}

@Composable private fun DeleteBanner(model:StudioModel){
    val c=LocalPro.current
    if(model.deletedProject==null)return
    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=6.dp).clip(RoundedCornerShape(10.dp)).background(c.raised).padding(start=12.dp,end=4.dp)
        .semantics{liveRegion=LiveRegionMode.Polite},verticalAlignment=Alignment.CenterVertically){
        Text(model.t("project_deleted"),style=MaterialTheme.typography.bodySmall,color=c.tx2,modifier=Modifier.weight(1f))
        ProButton(model.t("undo"),model::undoProjectDelete,kind=ProKind.GHOST,enabled=!model.busy)
    }
}

/** Keyboard shortcuts. Uses onKeyEvent (bubbling) so text fields keep the keys they type. */
private fun handleKey(model:StudioModel,view:PaintViewport,event:KeyEvent,onDialog:(String)->Unit):Boolean{
    if(event.key==Key.Spacebar){model.spaceHeld=event.type==KeyEventType.KeyDown;return true}
    if(event.type!=KeyEventType.KeyDown||model.showStart)return false
    val chord=KeyChord(event.key.nativeKeyCode,event.isCtrlPressed,event.isShiftPressed,event.isAltPressed)
    val action=model.keymap.action(chord)?:return false
    when(action){
        KeyAction.PENCIL->model.selectTool(StudioModel.Tool.PENCIL)
        KeyAction.ERASER->model.selectTool(StudioModel.Tool.ERASER)
        KeyAction.ERASE->model.selectTool(StudioModel.Tool.ERASE)
        KeyAction.FILL->model.selectTool(StudioModel.Tool.FILL)
        KeyAction.PICKER->model.selectTool(StudioModel.Tool.PICKER)
        KeyAction.MOVE->model.selectTool(StudioModel.Tool.MOVE)
        KeyAction.MIRROR->model.setMirror(!(model.mirrorX||model.mirrorY),false)
        KeyAction.GRID->model.setGrid(!model.pixelGrid)
        KeyAction.UNDO->model.undo()
        KeyAction.REDO,KeyAction.REDO_ALT->model.redo()
        KeyAction.BRUSH_DOWN->model.changeBrushSize(model.brushSize-1)
        KeyAction.BRUSH_UP->model.changeBrushSize(model.brushSize+1)
        KeyAction.SWAP->model.swapColors()
        KeyAction.SAVE->model.save()
        KeyAction.EXPORT->onDialog("export")
        KeyAction.ZOOM_IN->view.scale(view.zoom*1.25f)
        KeyAction.ZOOM_OUT->view.scale(view.zoom/1.25f)
        KeyAction.FIT->view.fit()
    }
    return true
}

/** Panel widths (dp) for the sidebar / tool panel. */
private fun sidebarDp(model:StudioModel):Dp=when(model.sidebarWidth){StudioModel.PanelWidth.NARROW->280.dp;StudioModel.PanelWidth.STANDARD->328.dp;StudioModel.PanelWidth.WIDE->384.dp}

/** 1.0.1 workspace. Replaces the 1.0.0 tab layout for the Free edition. */
@Composable internal fun ProWorkspace(model:StudioModel){
    ProTheme(model){ProvideGlass(model){
        val c=LocalPro.current
        val context=LocalContext.current
        var dialog by remember{mutableStateOf<String?>(null)}
        val open:(String)->Unit={dialog=it}
        var resolutionTexture by remember{mutableStateOf<TemplateTexture?>(null)}
        val view=remember(model.document){PaintViewport()}
        val snackbar=remember{SnackbarHostState()}
        var pendingPack by remember{mutableStateOf<Uri?>(null)}
        var exportMeta by remember(model.pack.id){mutableStateOf(ExportMeta())}
        val importLayer=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(model::importPng)}
        val importReplace=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(model::importReplace)}
        val importPack=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){pendingPack=uri;dialog="pack_import"}}
        val exportPack=rememberLauncherForActivityResult(ExportPackDocument()){uri->uri?.let{model.exportPack(it,exportMeta)}}
        val exportTexture=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")){uri->uri?.let(model::exportTexture)}
        val pickIcon=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->uri?.let{model.loadIcon(it){bytes->exportMeta=exportMeta.copy(icon=bytes)}}}
        val pickWallpaper=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->uri?.let(model::importWallpaper)}
        var layoutExportLandscape by remember{mutableStateOf(true)}
        val exportLayout=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->uri?.let{model.exportLayout(it,layoutExportLandscape)}}
        val importLayout=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->uri?.let(model::importLayout)}
        val launchers=ProLaunchers(
            importLayer={importLayer.launch(arrayOf("image/png","image/*"))},
            importReplace={importReplace.launch(arrayOf("image/png","image/*"))},
            importPack={importPack.launch(arrayOf("application/zip","application/octet-stream","*/*"))},
            exportPack={exportPack.launch(model.exportFileName())},
            exportTexture={exportTexture.launch(model.document.name.substringAfterLast('/')+".png")},
            pickIcon={pickIcon.launch(arrayOf("image/*"))},
            pickWallpaper={pickWallpaper.launch(arrayOf("image/*"))},
            exportLayout={landscape->layoutExportLandscape=landscape;exportLayout.launch((model.layouts.active(landscape)?.name?:"layout").replace(Regex("[\\\\/:*?\"<>|]"),"_")+".mctslayout.json")},
            importLayout={importLayout.launch(arrayOf("application/json","application/octet-stream","*/*"))})
        LaunchedEffect(model){snapshotFlow{model.message}.filterNotNull().collectLatest{key->model.message=null;snackbar.showSnackbar(model.p(key))}}
        // Autosave timer + save when the app goes to the background.
        LaunchedEffect(model.autosave,model.autosaveMinutes){while(model.autosave){delay(model.autosaveMinutes*60_000L);model.autosaveNow()}}
        val lifecycle=LocalLifecycleOwner.current.lifecycle
        DisposableEffect(lifecycle){
            val observer=LifecycleEventObserver{_,event->if(event==Lifecycle.Event.ON_PAUSE&&model.autosave)model.autosaveNow()}
            lifecycle.addObserver(observer);onDispose{lifecycle.removeObserver(observer)}
        }
        // Back on the start screen returns to the open project (as in 1.0.0).
        androidx.activity.compose.BackHandler(enabled=model.showStart&&!model.busy&&model.packs.isNotEmpty()){model.continueEditing()}
        val focus=remember{FocusRequester()}
        LaunchedEffect(Unit){runCatching{focus.requestFocus()}}
        val onTemplate:(TemplateTexture)->Unit={t->if(!model.openTemplateDefault(t)){resolutionTexture=t;dialog="resolution"}}
        val quiet=LocalQuiet.current
        // Liquid glass: the workspace blurs behind open dialogs.
        val backdropBlur by animateDpAsState(if(model.glassActive&&model.dialogsOpen>0)18.dp else 0.dp,if(quiet)snap() else ProMotion.settle(),label="backdrop")
        GlassRoot(model,Modifier.focusRequester(focus).focusable().onKeyEvent{handleKey(model,view,it,open)}.then(if(backdropBlur>0.dp)Modifier.blur(backdropBlur) else Modifier)){
            // 1.0.2.1: the layout is decided from the area WITHOUT the keyboard. With safeDrawing (which includes the IME) a
            // tablet in landscape dropped below 500 dp when the keyboard opened, switched TABLET → PHONE_LANDSCAPE, rebuilt the
            // sidebar, lost the search field's focus and closed the keyboard again ("keyboard pops up and vanishes").
            BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars.union(WindowInsets.displayCutout))){
                val area=WorkspaceArea(maxWidth.value,maxHeight.value);val areaWidth=maxWidth
                SideEffect{model.workspaceArea=area}
                LaunchedEffect(area.landscape){if(model.layoutEditing!=null&&model.layoutEditLandscape!=area.landscape)model.cancelLayoutEdit()}
                val shape=workspaceShape(model,maxWidth,maxHeight)
                val editingSpec=model.layoutEditing?.takeIf{model.layoutEditLandscape==area.landscape}
                val custom=editingSpec?:model.customLayout(area.landscape)
                val page=when{model.showStart->0;custom!=null->2;else->1}
                val focusCanvas={runCatching{focus.requestFocus()}.let{}}
                @Composable fun Pages(target:Int){
                    when(target){
                        0->Column(Modifier.fillMaxSize()){
                            ProTopBar(model,open,editing=false,compact=shape!=WorkspaceShape.TABLET)
                            if(model.busy&&!model.quietBusy)ProProgress(model) else Spacer(Modifier.height(3.dp))
                            DeleteBanner(model)
                            ProStart(model,open,launchers,shape==WorkspaceShape.PHONE_PORTRAIT,Modifier.fillMaxWidth().weight(1f))
                        }
                        2->Box(Modifier.fillMaxSize()){
                            FloatingWorkspace(model,custom?:return@Box,editingSpec!=null,model::updateLayoutEdit){block->
                                when(block){
                                    Block.BAR_LEFT->BarBlock(model,0,open);Block.BAR_MID->BarBlock(model,1,open);Block.BAR_RIGHT->BarBlock(model,2,open)
                                    Block.SIDEBAR->ProSidebar(model,onTemplate,open,launchers.importLayer,Modifier.fillMaxSize(),showPreview=false)
                                    Block.PREVIEW->ProPreviewCard(model,null,Modifier.fillMaxSize())
                                    Block.CANVAS->ProCanvasArea(model,view,Modifier.fillMaxSize(),focusCanvas)
                                    Block.COLOR->ProPanel(Modifier.fillMaxSize()){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)){ProColorBlock(model)}}
                                    Block.TOOLS->ProPanel(Modifier.fillMaxSize()){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){ProToolsSection(model,open)}}
                                    Block.HISTORY->ProPanel(Modifier.fillMaxSize()){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){ProHistorySection(model,view)}}
                                }
                            }
                            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth()){
                                if(model.busy&&!model.quietBusy)ProProgress(model)
                                DeleteBanner(model)
                            }
                        }
                        else->Column(Modifier.fillMaxSize()){
                            ProTopBar(model,open,editing=true,compact=shape!=WorkspaceShape.TABLET)
                            if(model.busy&&!model.quietBusy)ProProgress(model) else Spacer(Modifier.height(3.dp))
                            DeleteBanner(model)
                            ResponsiveEditor(model,shape,view,open,launchers,onTemplate,focusCanvas,areaWidth,Modifier.fillMaxWidth().weight(1f))
                        }
                    }
                }
                // The keyboard only shrinks the content (same composables, same focus); it never changes the layout above.
                Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.ime)){
                    if(quiet)Pages(page)
                    else AnimatedContent(page,Modifier.fillMaxSize(),transitionSpec={
                        (fadeIn(ProMotion.settle())+scaleIn(ProMotion.settle(),initialScale=.97f)).togetherWith(fadeOut(tween(120)))
                    },label="page"){Pages(it)}
                }
                // 1.0.2.1: "pick glass" over the whole workspace.
                if(model.glassPicking&&glassOn)GlassPickOverlay(model)
                SnackbarHost(snackbar,Modifier.align(Alignment.BottomCenter).padding(bottom=72.dp)){data->
                    Text(data.visuals.message,Modifier.clip(RoundedCornerShape(10.dp)).background(c.tx).padding(horizontal=14.dp,vertical=10.dp).semantics{liveRegion=LiveRegionMode.Polite},
                        color=c.app,style=MaterialTheme.typography.bodyMedium)
                }
            }
        }
        ProDialogs(model,dialog,{dialog=it},view,launchers,resolutionTexture,pendingPack,exportMeta,{exportMeta=it})
        model.error?.let{key->
            ProDialog(model,model.t("error"),{model.error=null},icon="info"){
                Text(model.p(key),style=MaterialTheme.typography.bodyMedium,color=c.tx,modifier=Modifier.semantics{liveRegion=LiveRegionMode.Assertive})
                if(model.lastErrorCode.startsWith("SAVE_"))Text(model.t("save_next"),style=MaterialTheme.typography.bodySmall,color=c.tx2)
                if(model.lastErrorCode.startsWith("EXPORT_"))Text(model.t("export_next"),style=MaterialTheme.typography.bodySmall,color=c.tx2)
                ProButton(model.p("ok"),{model.error=null},kind=ProKind.PRIMARY)
            }
        }
        if(model.exportGuidePending)ProExportSteps(model,onDone={model.exportGuidePending=false})
        if(model.showOnboarding&&dialog==null&&model.error==null)ProOnboarding(model){model.completeGuide()}
    }}
}

/** File pickers owned by the workspace, handed to dialogs and the start screen. */
internal class ProLaunchers(val importLayer:()->Unit,val importReplace:()->Unit,val importPack:()->Unit,val exportPack:()->Unit,val exportTexture:()->Unit,val pickIcon:()->Unit,
                             val pickWallpaper:()->Unit,val exportLayout:(Boolean)->Unit,val importLayout:()->Unit)

/** Safe-area size (dp) of the workspace; the layout editor and custom presets are per orientation. */
internal data class WorkspaceArea(val width:Float,val height:Float){val landscape get()=width>height}

/** 1.0.2 responsive default (replaces the per-device table): phone portrait, phone landscape, tablet. */
internal enum class WorkspaceShape { PHONE_PORTRAIT, PHONE_LANDSCAPE, TABLET }
internal fun workspaceShape(model:StudioModel,w:Dp,h:Dp):WorkspaceShape=when(model.deviceLayout){
    StudioModel.DeviceLayout.PHONE->if(w>h)WorkspaceShape.PHONE_LANDSCAPE else WorkspaceShape.PHONE_PORTRAIT
    StudioModel.DeviceLayout.TABLET->WorkspaceShape.TABLET
    StudioModel.DeviceLayout.AUTO->when{w<600.dp->WorkspaceShape.PHONE_PORTRAIT;h<500.dp->WorkspaceShape.PHONE_LANDSCAPE;else->WorkspaceShape.TABLET}
}

/**
 * Default editor: phone portrait = canvas + bottom toolbar; phone landscape = tool rail + big canvas (+ sidebar when ≥ 840 dp);
 * tablet = sidebar / canvas / tool panel (switches to the rail below 960 dp so the canvas keeps its room).
 */
@Composable private fun ResponsiveEditor(model:StudioModel,shape:WorkspaceShape,view:PaintViewport,open:(String)->Unit,launchers:ProLaunchers,
                                         onTemplate:(TemplateTexture)->Unit,focusCanvas:()->Unit,maxWidth:Dp,modifier:Modifier){
    when(shape){
        WorkspaceShape.PHONE_PORTRAIT->Column(modifier){
            ProCanvasArea(model,view,Modifier.fillMaxWidth().weight(1f).padding(8.dp),focusCanvas)
            PhoneToolbar(model,open)
        }
        WorkspaceShape.PHONE_LANDSCAPE->Row(modifier.padding(start=8.dp,end=8.dp,bottom=8.dp,top=4.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            val right=model.handMode==StudioModel.HandMode.RIGHT
            val sidebar=maxWidth>=840.dp
            if(!right)ProToolRail(model,view,open,Modifier.width(60.dp).fillMaxHeight())
            if(sidebar&&right)ProSidebar(model,onTemplate,open,launchers.importLayer,Modifier.width(minOf(300.dp,maxWidth*.3f)).fillMaxHeight(),showPreview=false)
            ProCanvasArea(model,view,Modifier.weight(1f).fillMaxHeight(),focusCanvas)
            if(sidebar&&!right)ProSidebar(model,onTemplate,open,launchers.importLayer,Modifier.width(minOf(300.dp,maxWidth*.3f)).fillMaxHeight(),showPreview=false)
            if(right)ProToolRail(model,view,open,Modifier.width(60.dp).fillMaxHeight())
        }
        WorkspaceShape.TABLET->Row(modifier.padding(start=12.dp,end=12.dp,bottom=12.dp,top=7.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
            val order=when(model.canvasAlign){
                StudioModel.CanvasAlign.LEFT->listOf("CA","SB","TB")
                StudioModel.CanvasAlign.CENTER->listOf("SB","CA","TB")
                StudioModel.CanvasAlign.RIGHT->listOf("SB","TB","CA")
            }
            val rail=model.compactToolbar||maxWidth<960.dp
            order.forEach{slot->when(slot){
                "SB"->ProSidebar(model,onTemplate,open,launchers.importLayer,Modifier.width(if(maxWidth<960.dp)minOf(sidebarDp(model),280.dp) else sidebarDp(model)).fillMaxHeight())
                "CA"->ProCanvasArea(model,view,Modifier.weight(1f).fillMaxHeight(),focusCanvas)
                else->if(rail)ProToolRail(model,view,open,Modifier.width(64.dp).fillMaxHeight())
                      else ProToolPanel(model,view,open,Modifier.width(236.dp).fillMaxHeight())
            }}
        }
    }
}
