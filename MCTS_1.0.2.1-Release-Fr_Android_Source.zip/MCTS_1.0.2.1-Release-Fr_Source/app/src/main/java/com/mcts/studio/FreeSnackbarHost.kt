package com.mcts.studio
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalAccessibilityManager
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** Free has no Material SnackbarHost transition, so explicitly owns its lifetime. */
@Composable internal fun FreeSnackbarHost(state:SnackbarHostState){
    val data=state.currentSnackbarData
    val accessibility=LocalAccessibilityManager.current
    LaunchedEffect(data,accessibility){
        if(data!=null){
            val base=when(data.visuals.duration){SnackbarDuration.Short->4000L;SnackbarDuration.Long->10000L;SnackbarDuration.Indefinite->Long.MAX_VALUE}
            if(base!=Long.MAX_VALUE){delay(accessibility?.calculateRecommendedTimeoutMillis(base,containsIcons=false,containsText=true,containsControls=true)?:base);data.dismiss()}
        }
    }
    if(data!=null)Surface(Modifier.padding(12.dp).semantics{liveRegion=LiveRegionMode.Polite}.clickable{data.dismiss()},shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.inverseSurface){
        Text(data.visuals.message,Modifier.padding(16.dp),color=MaterialTheme.colorScheme.inverseOnSurface)
    }
}
