package com.mcts.studio

import android.content.Context
import android.graphics.SurfaceTexture
import android.graphics.Matrix
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import java.io.File

/** Muted local video stays inside the app window, so it follows layout and lifecycle. */
internal class VideoWallpaperView(context:Context):TextureView(context),TextureView.SurfaceTextureListener {
    private var player:MediaPlayer?=null
    private var path=""
    private var active=false
    private var videoWidth=0
    private var videoHeight=0
    init{surfaceTextureListener=this;isOpaque=false}
    fun show(file:String){if(path==file)return;path=file;restart()}
    fun resume(){active=true;if(player==null)restart()else runCatching{player?.start()}}
    fun pause(){active=false;runCatching{player?.pause()}}
    private fun stop(){player?.setSurface(null);player?.release();player=null}
    private fun restart(){
        stop();if(!active||!isAvailable||!File(path).isFile)return
        val surface=Surface(surfaceTexture)
        try{
            val next=MediaPlayer()
            next.setDataSource(path);next.setSurface(surface);next.isLooping=true;next.setVolume(0f,0f)
            next.setOnVideoSizeChangedListener{_,w,h->videoWidth=w;videoHeight=h;crop()}
            next.setOnPreparedListener{if(active)it.start()}
            next.setOnErrorListener{_,_,_->stop();true}
            player=next;next.prepareAsync()
        }catch(_:Exception){stop()}finally{surface.release()}
    }
    private fun crop(){
        if(width<1||height<1||videoWidth<1||videoHeight<1)return
        val viewRatio=width.toFloat()/height;val videoRatio=videoWidth.toFloat()/videoHeight
        val scaleX=if(videoRatio>viewRatio)videoRatio/viewRatio else 1f
        val scaleY=if(videoRatio<viewRatio)viewRatio/videoRatio else 1f
        setTransform(Matrix().apply{setScale(scaleX,scaleY,width/2f,height/2f)})
    }
    override fun onSurfaceTextureAvailable(surface:SurfaceTexture,width:Int,height:Int){restart()}
    override fun onSurfaceTextureSizeChanged(surface:SurfaceTexture,width:Int,height:Int){crop()}
    override fun onSurfaceTextureDestroyed(surface:SurfaceTexture):Boolean{stop();return true}
    override fun onSurfaceTextureUpdated(surface:SurfaceTexture)=Unit
    override fun onDetachedFromWindow(){stop();super.onDetachedFromWindow()}
}
