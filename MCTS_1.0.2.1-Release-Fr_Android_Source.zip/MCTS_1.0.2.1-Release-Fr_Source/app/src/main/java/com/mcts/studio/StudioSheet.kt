package com.mcts.studio

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.selection.selectable
import androidx.compose.ui.semantics.Role
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.*

/** Free dialogs enter instantly; full dialogs keep the user's Sun UI preference. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable internal fun StudioSheet(model:StudioModel,onDismissRequest:()->Unit,containerColor:Color,content:@Composable ColumnScope.()->Unit){
    if(!model.isFree){ModalBottomSheet(onDismissRequest=onDismissRequest,containerColor=containerColor,content=content);return}
    val dismiss by rememberUpdatedState(onDismissRequest)
    Dialog(onDismissRequest,properties=DialogProperties(usePlatformDefaultWidth=false,dismissOnBackPress=true,dismissOnClickOutside=true)){
        BackHandler { dismiss() }
        val view=LocalView.current
        DisposableEffect(view,model.transparentUi){(view.parent as? DialogWindowProvider)?.window?.apply{setWindowAnimations(0);setDimAmount(if(model.transparentUi)0f else .32f)};onDispose{}}
        // The full-screen Dialog owns its backdrop, so Android's outside-window
        // dismissal alone cannot see these taps. Inner taps are consumed by the card.
        BoxWithConstraints(Modifier.fillMaxSize().pointerInput(Unit){detectTapGestures{dismiss()}}.safeDrawingPadding().imePadding().padding(12.dp),contentAlignment=Alignment.Center){
            Surface(Modifier.widthIn(max=680.dp).fillMaxWidth().heightIn(max=maxHeight.coerceAtMost(700.dp)).pointerInput(Unit){detectTapGestures{}},shape=RoundedCornerShape(20.dp),color=if(model.transparentUi)Color.Transparent else containerColor){
                Column(Modifier.fillMaxWidth()){
                    // Outside the scrollable body: always reachable on small screens / IME.
                    Row(Modifier.fillMaxWidth().padding(horizontal=8.dp),horizontalArrangement=Arrangement.End){
                        SpringTextButton({dismiss()}){Text(model.t("close_popup"))}
                    }
                    Column(Modifier.fillMaxWidth().weight(1f,fill=false),content=content)
                }
            }
        }
    }
}
@Composable internal fun StudioCheck(checked:Boolean,onCheckedChange:((Boolean)->Unit)?,modifier:Modifier=Modifier,enabled:Boolean=true){
    if(!BuildConfig.IS_FREE){Checkbox(checked,onCheckedChange,modifier,enabled);return}
    val source=remember{MutableInteractionSource()}
    Box(modifier.then(freePress(source,enabled)).size(48.dp).toggleable(value=checked,interactionSource=source,indication=null,role=Role.Checkbox,enabled=enabled&&onCheckedChange!=null,onValueChange={onCheckedChange?.invoke(it)}),contentAlignment=Alignment.Center){Text(if(checked)"☑" else "☐",color=if(enabled)MaterialTheme.colorScheme.primary else Color.Gray)}
}
@Composable internal fun StudioRadio(selected:Boolean,onClick:(()->Unit)?,modifier:Modifier=Modifier,enabled:Boolean=true){
    if(!BuildConfig.IS_FREE){RadioButton(selected,onClick,modifier,enabled);return}
    val source=remember{MutableInteractionSource()}
    Box(modifier.then(freePress(source,enabled)).size(48.dp).selectable(selected=selected,interactionSource=source,indication=null,role=Role.RadioButton,enabled=enabled&&onClick!=null,onClick={onClick?.invoke()}),contentAlignment=Alignment.Center){Text(if(selected)"●" else "○")}
}
