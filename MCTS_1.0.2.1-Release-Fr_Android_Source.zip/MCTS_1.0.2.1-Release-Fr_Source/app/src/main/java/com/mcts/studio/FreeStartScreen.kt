package com.mcts.studio
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp

@Composable internal fun FreeStartScreen(model:StudioModel,snackbar:SnackbarHostState){
    var confirmDownload by remember{mutableStateOf(false)}
    var utility by remember{mutableStateOf<String?>(null)}
    var profileId by rememberSaveable{mutableStateOf(model.templateProfileId)}
    LaunchedEffect(profileId){model.rememberTemplateChoice(profileId)}
    val profile=gameProfiles.first{it.id==profileId}
    fun download(){if(model.isMetered())confirmDownload=true else model.prepareTemplate(profile)}
    var name by rememberSaveable{mutableStateOf("My resource pack")}
    val ready=profile.id in model.availableTemplates
    Scaffold(containerColor=MaterialTheme.colorScheme.background,contentWindowInsets=WindowInsets.safeDrawing,
        snackbarHost={FreeSnackbarHost(snackbar)}){padding->
        Column(Modifier.fillMaxSize().padding(padding).imePadding().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Image(painterResource(R.drawable.mcts_logo),null,Modifier.size(64.dp));Spacer(Modifier.width(14.dp))
                Column{Text("MCTS Free",style=MaterialTheme.typography.headlineMedium);Text(BuildConfig.VERSION_NAME,style=MaterialTheme.typography.labelLarge)}
            }
            Row(Modifier.horizontalScroll(rememberScrollState())){Language.entries.forEach{language->
                SpringChip(model.language==language,{model.changeLanguage(language)},label={Text(when(language){Language.ZH->"中文";Language.EN->"English";Language.JA->"日本語";Language.FR->"Français";Language.ES->"Español"})})
            }}
            ThemeSettings(model)
            Text(model.t("start_title"),style=MaterialTheme.typography.titleLarge)
            Text(model.t("template_notice"),style=MaterialTheme.typography.bodyMedium)
            Text(model.t("template_reason"),style=MaterialTheme.typography.bodySmall)
            Row{SpringChip(profile.java,{profileId=gameProfiles.first{it.java&&it.version==profile.pair}.id},enabled=!model.busy,label={Text("Java")});SpringChip(!profile.java,{profileId=gameProfiles.first{!it.java&&it.version==profile.pair}.id},enabled=!model.busy,label={Text(model.w("基岩版","Bedrock","統合版"))})}
            Row(Modifier.horizontalScroll(rememberScrollState())){gameProfiles.filter{it.java==profile.java}.forEach{p->SpringChip(profile.id==p.id,{profileId=p.id},enabled=!model.busy,label={Text(p.version)})}}
            Text(profile.label+" · "+model.t(if(ready)"template_cached" else "template_not_cached"),style=MaterialTheme.typography.labelLarge,modifier=Modifier.semantics{liveRegion=LiveRegionMode.Polite})
            if(model.downloading){
                Text(model.t(model.downloadStage),modifier=Modifier.semantics{liveRegion=LiveRegionMode.Polite})
                if(model.downloadBytes>0)Text("${model.downloadBytes/1024/1024} MB"+if(model.downloadTotal>0)" / ${model.downloadTotal/1024/1024} MB" else "")
                Text(model.t("background_hint"),style=MaterialTheme.typography.bodySmall)
                FlowProgress(model)
                DownloadWalkthrough(model)
                SpringTextButton(model::cancelDownload){Text(model.t("cancel"))}
            }else if(!ready){
                val partial=model.projectFiles.templates.partialBytes(profile)
                if(partial>0)Text("${model.t("resume_download")}: ${partial/1024/1024} MB / ${model.projectFiles.templates.expectedSize(profile)/1024/1024} MB")
                Text(model.t("download_size_hint"),style=MaterialTheme.typography.bodySmall)
                SunButton(model.t("template_download"),enabled=!model.busy){download()}
            }
            model.downloadError?.let{key->
                Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.errorContainer){Text(model.t(key),Modifier.padding(12.dp),color=MaterialTheme.colorScheme.onErrorContainer)}
                SunButton(model.t("retry"),enabled=!model.busy){download()}
            }
            if(ready&&!model.downloading){
                SunTextField(name,{name=it.take(80)},label={Text(model.t("project_name"))},singleLine=true,enabled=!model.busy,modifier=Modifier.fillMaxWidth())
                SunButton(model.t("start_create"),enabled=!model.busy&&name.isNotBlank()){model.createPack(name,profile,true)}
            }
            SpringTextButton({utility="about"}){Text(model.t("about_notice"))}
            SpringTextButton({utility="cache"},enabled=!model.busy){Text(model.t("cache_manage"))}
            HorizontalDivider()
            SpringTextButton(model::continueEditing,enabled=!model.busy){Text(model.t("start_resume"))}
            ProjectUndo(model)
            if(model.packs.isNotEmpty()){
                Text(model.t("start_projects"),style=MaterialTheme.typography.titleMedium)
                model.packs.forEach{p->SpringTextButton({model.openPack(p)},enabled=!model.busy,modifier=Modifier.fillMaxWidth()){Text("${p.name} · ${p.profile.label}")}}
            }
            Text(model.t("free_export_color"),style=MaterialTheme.typography.bodySmall)
        }
    }
    if(confirmDownload)StudioSheet(model,{confirmDownload=false},MaterialTheme.colorScheme.surface){
        Text(model.t("metered_notice"));SpringTextButton({confirmDownload=false;model.prepareTemplate(profile)}){Text(model.t("template_download"))}
    }
    utility?.let{kind->StudioSheet(model,{utility=null},MaterialTheme.colorScheme.surface){if(kind=="about")AboutNotices(model)else TemplateCachePage(model)}}
}
