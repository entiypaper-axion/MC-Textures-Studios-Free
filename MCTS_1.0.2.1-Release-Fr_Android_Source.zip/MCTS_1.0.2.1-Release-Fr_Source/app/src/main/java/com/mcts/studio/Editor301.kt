package com.mcts.studio

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.*
import com.mcts.core.MaterialDocument
import kotlin.math.*

@Composable internal fun EditorBody301(model:StudioModel,page:Int,view:PaintViewport,onSheet:(String)->Unit,onTemplate:(TemplateTexture)->Unit){
    if(page==4){FullPainter(model,view,onSheet);return}
    BoxWithConstraints(Modifier.fillMaxSize()){
    if(model.isFree && (maxWidth<600.dp||model.handMode!=StudioModel.HandMode.AUTO)){CompactEditor(model,page,view,onSheet,onTemplate);return@BoxWithConstraints}
    Box(Modifier.fillMaxSize()){
        var width by remember{mutableIntStateOf(1)}
        val previewOnly=model.editMode==StudioModel.EditMode.PREVIEW&&page==1
        Row(Modifier.fillMaxSize().onSizeChanged{width=it.width}){
            Column(Modifier.weight(model.workspaceLeft).fillMaxHeight()){
                Column(Modifier.fillMaxWidth().weight(if(previewOnly)1f else .55f).verticalScroll(rememberScrollState())){
                    SpringTextButton({onSheet("projects")},enabled=!model.busy,modifier=Modifier.fillMaxWidth()) {Text("${model.pack.name} ▾",maxLines=1)}
                    UndoTools(model,onSheet)
                    Spacer(Modifier.height(6.dp))
                    ChannelBar(model)
                    ChannelValue(model)
                    Row(verticalAlignment=Alignment.CenterVertically){Text(model.w("画板","Canvas","画面"),style=MaterialTheme.typography.labelSmall);ElasticSlider(1-model.workspaceLeft,{model.resizeWorkspaceLeft(1-it)},valueRange=.5f..75f/100,onValueChangeFinished=model::saveWorkspaceRatio,modifier=Modifier.weight(1f).semantics{contentDescription=model.w("画板宽度占比","Canvas width ratio","キャンバス幅")})}
                    Text(model.w("拖动分隔线调整左右比例","Drag the divider to resize","仕切りをドラッグして調整"),style=MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(6.dp))
                }
                if(!previewOnly){Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().weight(.45f)){
                    if(page!=2)Preview(model,Modifier.fillMaxSize())
                    else Column(Modifier.fillMaxSize().padding(8.dp)){Text(model.w("实时预览","Live preview","リアルタイム表示"),style=MaterialTheme.typography.titleSmall);Text(model.w("拖动旋转 · 双指缩放\n修改像素后实时更新","Drag to orbit · pinch to zoom\nPixel edits update immediately","ドラッグで回転・ピンチで拡大\n編集は即時反映"),style=MaterialTheme.typography.bodySmall)}
                }}
            }
            Box(Modifier.width(12.dp).fillMaxHeight().pointerInput(width){detectDragGestures(onDragEnd=model::saveWorkspaceRatio,onDragCancel=model::saveWorkspaceRatio){change,drag->change.consume();model.resizeWorkspaceLeft(model.workspaceLeft+drag.x/width.coerceAtLeast(1))}},contentAlignment=Alignment.Center){Box(Modifier.width(3.dp).height(56.dp).background(SunCyan,RoundedCornerShape(50)))}
            Column(Modifier.weight(1-model.workspaceLeft).fillMaxHeight()){
                when(page){
                    0->AssetBrowser(model,onTemplate)
                    2->Preview(model,Modifier.fillMaxSize())
                    3->Layers(model)
                    else->if(previewOnly)Preview(model,Modifier.fillMaxSize())else ChannelCanvas(model,view,Modifier.fillMaxSize())
                }
            }
        }
    }
    }
}

@Composable internal fun ChannelCanvas(model:StudioModel,view:PaintViewport,modifier:Modifier=Modifier){
    DirectionalContent(model.channel,{it.ordinal},modifier){channel->PaintSurface(model,view,channel,Modifier.fillMaxSize())}
}

@Composable internal fun ChannelBar(model:StudioModel,vertical:Boolean=false){
    val channels=model.channels
    SlidingBar(channels.map{model.t(it.name)},channels.indexOf(model.channel),{model.selectChannel(channels[it])},Modifier.fillMaxWidth(),vertical=vertical,enabled=!model.busy)
}

@Composable private fun UndoTools(model:StudioModel,onSheet:(String)->Unit){
    val actions=listOf(
        Triple(model.t("undo"),!model.busy&&model.undoEnabled,model::undo),
        Triple(model.t("redo"),!model.busy&&model.redoEnabled,model::redo),
        Triple(model.w("调色","Palette","色"),!model.busy,{onSheet("palette")}),
        Triple(model.w("吸管","Pick","採色")+if(model.sampler)" ✓"else "",!model.busy,model::toggleSampler),
        Triple(model.w("移动","Pan","移動")+if(model.panCanvas)" ✓"else "",!model.busy,model::toggleCanvasPan),
        Triple(model.w("工具","Tools","ツール"),!model.busy,{onSheet("tools")})
    )
    val right=model.handMode==StudioModel.HandMode.RIGHT
    val scroll=rememberScrollState()
    LaunchedEffect(right,scroll.maxValue){if(right)scroll.scrollTo(scroll.maxValue)}
    Row(Modifier.fillMaxWidth().horizontalScroll(scroll),horizontalArrangement=if(right)Arrangement.End else Arrangement.Start){
        (if(right)actions.reversed()else actions).forEach{(label,enabled,action)->SpringTextButton(action,enabled=enabled){Text(label)}}
    }
}

@Composable private fun ChannelValue(model:StudioModel){
    if(model.channel==MaterialDocument.Channel.COLOR||model.channel==MaterialDocument.Channel.NORMAL){
        Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(24.dp).background(Color(0xff000000.toInt() or(model.rgb.toIntOrNull(16)?:0)),CircleShape));Text(" #${model.rgb.uppercase()}",style=MaterialTheme.typography.labelSmall)}
    }else{
        Text("${model.t(model.channel.name)}: ${model.value}",style=MaterialTheme.typography.labelMedium)
        ElasticSlider(model.value.toFloat(),{model.changeBrushValue(it.roundToInt())},valueRange=0f..255f,onValueChangeFinished=model::finishValue,enabled=!model.busy,modifier=Modifier.semantics{contentDescription=model.t(model.channel.name)})
        Row{SpringTextButton({model.changeBrushValue((model.value-1).coerceAtLeast(0));model.finishValue()},enabled=!model.busy){Text("−1")};SpringTextButton({model.changeBrushValue((model.value+1).coerceAtMost(255));model.finishValue()},enabled=!model.busy){Text("+1")}}
    }
    if(model.sampler)Text(model.w("点画板取值，不会落笔","Tap to sample without painting","タップで採色（描画なし）"),style=MaterialTheme.typography.labelSmall)
}

@Composable private fun FullPainter(model:StudioModel,view:PaintViewport,onSheet:(String)->Unit){
    BoxWithConstraints(Modifier.fillMaxSize()){
        if(model.isFree&&(maxWidth<600.dp||model.handMode!=StudioModel.HandMode.AUTO)){CompactPainter(model,view,onSheet);return@BoxWithConstraints}
        val rail=if(maxWidth<600.dp)82.dp else 136.dp
        Row(Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Column(Modifier.width(rail).fillMaxHeight().verticalScroll(rememberScrollState())){
                Text(model.w("通道","Channels","チャンネル"),style=MaterialTheme.typography.labelLarge)
                ChannelBar(model,vertical=true);Spacer(Modifier.height(8.dp));ChannelValue(model)
            }
            ChannelCanvas(model,view,Modifier.weight(1f).fillMaxHeight())
            Column(Modifier.width(rail).fillMaxHeight().verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally){
                MiniPalette(model)
                SpringTextButton({onSheet("palette")},enabled=!model.busy){Text(model.w("调色盘","Palette","色設定"))}
                SpringTextButton(model::toggleSampler,enabled=!model.busy){Text(model.w("吸管","Pick","採色")+if(model.sampler)" ✓"else "")}
                SpringTextButton(model::undo,enabled=!model.busy&&model.undoEnabled){Text(model.t("undo"))}
                SpringTextButton(model::redo,enabled=!model.busy&&model.redoEnabled){Text(model.t("redo"))}
                SpringTextButton(model::toggleCanvasPan,enabled=!model.busy){Text(model.w("移动/缩放","Pan/zoom","移動/拡大")+if(model.panCanvas)" ✓"else "")}
                SpringTextButton({model.setGrid(!model.pixelGrid)}){Text(model.w("网格","Grid","格子")+if(model.pixelGrid)" ✓"else "")}
                SpringTextButton(model::fill,enabled=!model.busy){Text(model.w("填充","Fill","塗る"))}
                SpringTextButton({onSheet("tools")}){Text(model.w("更多","More","その他"))}
                SpringTextButton(model::save,enabled=!model.busy){Text(model.w("保存","Save","保存"))}
                SpringTextButton({onSheet("export")},enabled=!model.busy){Text(model.t("export"))}
            }
        }
    }
}

@Composable private fun MiniPalette(model:StudioModel){
    val hsv=remember(model.rgb){FloatArray(3).also{android.graphics.Color.colorToHSV(0xff000000.toInt()or(model.rgb.toIntOrNull(16)?:0),it)}}
    var area by remember{mutableStateOf(IntSize(1,1))};val latest by rememberUpdatedState(hsv)
    fun select(p:Offset){model.chooseColor(android.graphics.Color.HSVToColor(floatArrayOf(latest[0],(p.x/area.width.coerceAtLeast(1)).coerceIn(0f,1f),(1-p.y/area.height.coerceAtLeast(1)).coerceIn(0f,1f))))}
    Canvas(Modifier.fillMaxWidth().aspectRatio(1f).onSizeChanged{area=it}.pointerInput(model.busy){if(!model.busy)detectTapGestures{select(it)}}.pointerInput(model.busy){if(!model.busy)detectDragGestures(onDragStart={select(it)}){change,_->change.consume();select(change.position)}}.semantics{contentDescription=model.w("绘画颜色","Paint color","描画色")}){
        drawRect(Color.hsv(hsv[0],1f,1f));drawRect(Brush.horizontalGradient(listOf(Color.White,Color.Transparent)));drawRect(Brush.verticalGradient(listOf(Color.Transparent,Color.Black)))
        val at=Offset(hsv[1]*size.width,(1-hsv[2])*size.height);drawCircle(Color.Black,6.dp.toPx(),at,style=androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()));drawCircle(Color.White,6.dp.toPx(),at,style=androidx.compose.ui.graphics.drawscope.Stroke(1.5.dp.toPx()))
    }
    ElasticSlider(hsv[0],{model.chooseColor(android.graphics.Color.HSVToColor(floatArrayOf(it,hsv[1],hsv[2])))},valueRange=0f..359.99f,enabled=!model.busy,modifier=Modifier.semantics{contentDescription=model.w("色相","Hue","色相")})
    model.recentColors().take(8).chunked(2).forEach{colors->Row(Modifier.fillMaxWidth()){colors.forEach{color->ColorSwatch(model,color,Modifier.weight(1f))}}}
}

/** Narrow-screen controls remain reachable; drawing keeps the remaining height. */
@Composable private fun CompactEditor(model:StudioModel,page:Int,view:PaintViewport,onSheet:(String)->Unit,onTemplate:(TemplateTexture)->Unit){
    Column(Modifier.fillMaxSize()){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            SpringTextButton({onSheet("projects")},enabled=!model.busy,modifier=Modifier.weight(1f)){Text(model.pack.name+" ▾",maxLines=1)}
            SpringTextButton({onSheet("palette")},enabled=!model.busy){Box(Modifier.size(20.dp).background(Color(model.brushColor),CircleShape));Text(" #"+model.rgb.uppercase(),style=MaterialTheme.typography.labelSmall)}
        }
        if(model.handMode==StudioModel.HandMode.AUTO)UndoTools(model,onSheet)
        if(model.sampler)Text(model.t("sample_hint"),style=MaterialTheme.typography.labelSmall)
        if(page==1){
            Row(verticalAlignment=Alignment.CenterVertically){
                Text(model.t("preview_ratio")+" ${(model.previewRatio*100).roundToInt()}%",style=MaterialTheme.typography.labelSmall)
                ElasticSlider(model.previewRatio,model::resizePreview,valueRange=.15f..85f/100,onValueChangeFinished=model::saveRatio,modifier=Modifier.weight(1f).semantics{contentDescription=model.t("preview_ratio")})
            }
            Preview(model,Modifier.fillMaxWidth().weight(model.previewRatio))
            ChannelCanvas(model,view,Modifier.fillMaxWidth().weight(1-model.previewRatio))
        }else Box(Modifier.fillMaxWidth().weight(1f)){
            when(page){0->Column(Modifier.fillMaxSize()){AssetBrowser(model,onTemplate)};2->Preview(model,Modifier.fillMaxSize());3->Layers(model)}
        }
        if(model.handMode!=StudioModel.HandMode.AUTO)UndoTools(model,onSheet)
    }
}

@Composable private fun CompactPainter(model:StudioModel,view:PaintViewport,onSheet:(String)->Unit){
    Column(Modifier.fillMaxSize()){
        ChannelCanvas(model,view,Modifier.fillMaxWidth().weight(1f))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),verticalAlignment=Alignment.CenterVertically){
            SpringTextButton({onSheet("palette")},enabled=!model.busy){Box(Modifier.size(20.dp).background(Color(model.brushColor),CircleShape));Text(" #"+model.rgb.uppercase())}
            model.recentColors().take(6).forEach{ColorSwatch(model,it,Modifier.width(56.dp))}
        }
        UndoTools(model,onSheet)
        MirrorControls(model)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=if(model.handMode==StudioModel.HandMode.RIGHT)Arrangement.End else Arrangement.Start){
            SpringTextButton({onSheet("projects")},enabled=!model.busy){Text(model.t("project_name"))}
            SpringTextButton({onSheet("settings")}){Text(model.t("settings"))}
            SpringTextButton(model::save,enabled=!model.busy){Text(model.t("save"))}
            SpringTextButton({onSheet("export")},enabled=!model.busy){Text(model.t("export"))}
        }
    }
}
