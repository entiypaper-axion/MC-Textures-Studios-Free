package com.mcts.studio

import android.content.Context
import android.graphics.*
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.*
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** Interface preferences are separate from all resource-pack documents. */
class Appearance(private val context:Context) {
    private val prefs=context.getSharedPreferences("appearance",0)
    var font by mutableStateOf(prefs.getString("font","system")!!); private set
    var fontSize by mutableFloatStateOf(prefs.getFloat("fontSize",1f).coerceIn(.85f,1.4f)); private set
    var textColor by mutableIntStateOf(prefs.getInt("textColor",0xff163945.toInt())); private set
    var background by mutableStateOf(prefs.getString("background","sunrise")!!.let{if(BuildConfig.IS_FREE&&it=="video")"sunrise" else it}); private set
    var colorA by mutableIntStateOf(prefs.getInt("colorA",0xffffdf88.toInt())); private set
    var colorB by mutableIntStateOf(prefs.getInt("colorB",0xffffafbd.toInt())); private set
    var veil by mutableFloatStateOf(prefs.getFloat("veil",.62f).coerceIn(.15f,.95f)); private set
    var sound by mutableStateOf(prefs.getBoolean("sound",false)); private set
    var fontPath by mutableStateOf(prefs.getString("fontPath","")!!); private set
    var imagePath by mutableStateOf(prefs.getString("imagePath","")!!); private set
    var videoPath by mutableStateOf(prefs.getString("videoPath","")!!); private set
    /** 1.0.2 liquid-glass wallpaper (user image only; nothing is bundled). */
    var wallpaperPath by mutableStateOf(prefs.getString("wallpaperPath","")!!); private set
    fun chooseFont(v:String){font=v;prefs.edit().putString("font",v).apply()}
    // 1.0.2.1 game fonts: "game:<key>" = filesDir/appearance/game-<key>.ttf (Minecraft built from the official jar; others imported).
    var gameFontRevision by mutableIntStateOf(0); private set
    fun gameFontFile(key:String)=File(File(context.filesDir,"appearance").apply{mkdirs()},"game-$key.ttf")
    fun hasGameFont(key:String)=gameFontFile(key).isFile
    fun useGameFont(key:String,file:File?=null){
        if(file!=null&&file.absolutePath!=gameFontFile(key).absolutePath)Files.move(file.toPath(),gameFontFile(key).toPath(),StandardCopyOption.REPLACE_EXISTING)
        gameFontRevision++;chooseFont("game:$key")
    }
    fun removeGameFont(key:String){gameFontFile(key).delete();gameFontRevision++;if(font=="game:$key")chooseFont("system")}
    fun size(v:Float){fontSize=v.coerceIn(.85f,1.4f);prefs.edit().putFloat("fontSize",fontSize).apply()}
    fun ink(v:Int){textColor=v or 0xff000000.toInt();prefs.edit().putInt("textColor",textColor).apply()}
    fun backdrop(v:String){if(!com.mcts.core.EditionPolicy(BuildConfig.IS_FREE).allows(com.mcts.core.EditionPolicy.Feature.VIDEO_WALLPAPER)&&v=="video")throw IOException("FREE_UNAVAILABLE");background=v;prefs.edit().putString("background",v).apply()}
    fun first(v:Int){colorA=v or 0xff000000.toInt();prefs.edit().putInt("colorA",colorA).apply()}
    fun second(v:Int){colorB=v or 0xff000000.toInt();prefs.edit().putInt("colorB",colorB).apply()}
    fun wash(v:Float){veil=v.coerceIn(.15f,.95f);prefs.edit().putFloat("veil",veil).apply()}
    fun sounds(v:Boolean){sound=v;prefs.edit().putBoolean("sound",v).apply()}
    private fun copyInput(uri:Uri,limit:Long):File {
        val tmp=File.createTempFile("appearance-",".part",context.cacheDir)
        try{context.contentResolver.openInputStream(uri)?.use{input->tmp.outputStream().use{out->
            val buffer=ByteArray(16384);var total=0L
            while(true){val n=input.read(buffer);if(n<0)break;total+=n;if(total>limit)throw IOException("APPEARANCE_LARGE");out.write(buffer,0,n)}
        }}?:throw IOException("APPEARANCE_READ");return tmp}catch(e:Exception){tmp.delete();throw e}
    }
    fun prepareFont(uri:Uri):File {
        val tmp=copyInput(uri,32L*1024*1024)
        try {
            val head=ByteArray(4);tmp.inputStream().use{if(it.read(head)!=4)throw IOException("FONT_INVALID")}
            val magic=head.fold(0){a,b->(a shl 8) or (b.toInt() and 255)}
            if(magic !in listOf(0x00010000,0x4f54544f,0x74746366,0x74727565))throw IOException("FONT_INVALID")
            try{Typeface.Builder(tmp).build()}catch(e:Exception){throw IOException("FONT_INVALID",e)}
            val dir=File(context.filesDir,"appearance").apply{mkdirs()};val next=File(dir,"font-${System.nanoTime()}.ttf")
            Files.move(tmp.toPath(),next.toPath(),StandardCopyOption.REPLACE_EXISTING);return next
        }finally{tmp.delete()}
    }
    fun useFont(file:File){val old=fontPath;fontPath=file.absolutePath;prefs.edit().putString("fontPath",fontPath).apply();chooseFont("custom");if(old!=fontPath&&old.isNotBlank())File(old).delete()}
    fun prepareImage(uri:Uri):File {
        val input=copyInput(uri,40L*1024*1024);var bitmap:Bitmap?=null
        try {
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(input.path,bounds)
            if(bounds.outWidth<=0||bounds.outHeight<=0||bounds.outWidth.toLong()*bounds.outHeight>100_000_000)throw IOException("BACKGROUND_INVALID")
            val options=BitmapFactory.Options().apply{inSampleSize=1};while(maxOf(bounds.outWidth,bounds.outHeight)/options.inSampleSize>1800)options.inSampleSize*=2
            bitmap=BitmapFactory.decodeFile(input.path,options)?:throw IOException("BACKGROUND_INVALID")
            val orientation=runCatching{ExifInterface(input.path).getAttributeInt(ExifInterface.TAG_ORIENTATION,1)}.getOrDefault(1)
            val matrix=Matrix().apply{when(orientation){2->setScale(-1f,1f);3->setRotate(180f);4->setScale(1f,-1f);5->{setRotate(90f);postScale(-1f,1f)};6->setRotate(90f);7->{setRotate(-90f);postScale(-1f,1f)};8->setRotate(-90f)}}
            val oriented=Bitmap.createBitmap(bitmap,0,0,bitmap.width,bitmap.height,matrix,true)
            if(oriented!==bitmap){bitmap.recycle();bitmap=oriented}
            val dir=File(context.filesDir,"appearance").apply{mkdirs()};val staging=File.createTempFile("image-",".part",dir);val next=File(dir,"image-${System.nanoTime()}.png")
            try{staging.outputStream().use{if(!bitmap.compress(Bitmap.CompressFormat.PNG,100,it))throw IOException("BACKGROUND_INVALID")};Files.move(staging.toPath(),next.toPath(),StandardCopyOption.REPLACE_EXISTING)}finally{staging.delete()}
            return next
        }finally{bitmap?.recycle();input.delete()}
    }
    fun useImage(file:File){val old=imagePath;imagePath=file.absolutePath;prefs.edit().putString("imagePath",imagePath).apply();backdrop("image");if(old!=imagePath&&old.isNotBlank())File(old).delete()}
    fun useWallpaper(file:File){val old=wallpaperPath;wallpaperPath=file.absolutePath;prefs.edit().putString("wallpaperPath",wallpaperPath).apply();if(old!=wallpaperPath&&old.isNotBlank())File(old).delete()}
    fun clearWallpaper(){val old=wallpaperPath;wallpaperPath="";prefs.edit().putString("wallpaperPath","").apply();if(old.isNotBlank())File(old).delete()}
    fun prepareVideo(uri:Uri):File {
        if(!com.mcts.core.EditionPolicy(BuildConfig.IS_FREE).allows(com.mcts.core.EditionPolicy.Feature.VIDEO_WALLPAPER))throw IOException("FREE_UNAVAILABLE")
        val input=copyInput(uri,200L*1024*1024)
        try {
            val retriever=MediaMetadataRetriever()
            try {
                retriever.setDataSource(input.absolutePath)
                val w=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()?:0
                val h=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()?:0
                val duration=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0
                if(w<1||h<1||w.toLong()*h>3840L*2160L||duration !in 500L..300_000L)throw IOException("VIDEO_INVALID")
            }finally{retriever.release()}
            val dir=File(context.filesDir,"appearance").apply{mkdirs()};val next=File(dir,"video-${System.nanoTime()}.mp4")
            Files.move(input.toPath(),next.toPath(),StandardCopyOption.REPLACE_EXISTING);return next
        }finally{input.delete()}
    }
    fun useVideo(file:File){val old=videoPath;videoPath=file.absolutePath;prefs.edit().putString("videoPath",videoPath).apply();backdrop("video");if(old!=videoPath&&old.isNotBlank())File(old).delete()}
    fun reset(){chooseFont("system");size(1f);ink(0xff163945.toInt());backdrop("sunrise");first(0xffffdf88.toInt());second(0xffffafbd.toInt());wash(.62f);sounds(false)}
}
