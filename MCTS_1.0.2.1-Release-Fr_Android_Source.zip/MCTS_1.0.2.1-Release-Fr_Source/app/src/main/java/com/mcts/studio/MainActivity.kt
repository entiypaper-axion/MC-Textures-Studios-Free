package com.mcts.studio

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.axion.pompreview.PreviewGLView
import com.mcts.core.MaterialDocument
import dev.chrisbanes.haze.*
import kotlin.math.*
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.collectLatest

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState); enableEdgeToEdge(statusBarStyle=SystemBarStyle.light(android.graphics.Color.TRANSPARENT,android.graphics.Color.TRANSPARENT),navigationBarStyle=SystemBarStyle.light(android.graphics.Color.TRANSPARENT,android.graphics.Color.TRANSPARENT))
        setContent {
            val model:StudioModel=viewModel()
            // 1.0.2: the promo's logo animation on every cold start (saved state keeps it from replaying on rotation).
            var intro by rememberSaveable{mutableStateOf(true)}
            // Follow the system "remove animations" (animator duration scale 0) on every return to the app.
            val lifecycle=androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
            DisposableEffect(lifecycle){
                fun read(){model.systemReducedMotion=runCatching{android.provider.Settings.Global.getFloat(contentResolver,android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,1f)==0f}.getOrDefault(false)}
                read()
                val observer=androidx.lifecycle.LifecycleEventObserver{_,event->if(event==androidx.lifecycle.Lifecycle.Event.ON_RESUME)read()}
                lifecycle.addObserver(observer);onDispose{lifecycle.removeObserver(observer)}
            }
            Box(Modifier.fillMaxSize()){
                // 1.0.1: the Free edition uses the redesigned workspace (top bar + sidebar + canvas + tool panel).
                if(model.isFree)ProWorkspace(model) else StudioTheme(model) { Workspace(model) }
                if(intro)LogoIntro(BuildConfig.VERSION_NAME,model.motionOff){intro=false}
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Workspace(model:StudioModel) {
    val context=LocalContext.current
    val haze=remember { HazeState() }
    var sheet by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(sheet,model.pack.id){if(sheet=="export")model.refreshExportSummary()}
    var templateForResolution by remember { mutableStateOf<TemplateTexture?>(null) }
    var templateSize by remember { mutableIntStateOf(16) }
    var tab by rememberSaveable { mutableIntStateOf(1) }
    LaunchedEffect(model.editMode){if(model.editMode==StudioModel.EditMode.PREVIEW&&tab==4)tab=1}
    val paintView=remember(model.document){PaintViewport()}
    BackHandler(enabled=tab==4&&!model.showStart){tab=1}
    BackHandler(enabled=model.isFree&&model.showStart&&!model.busy){model.continueEditing()}
    var format by remember { mutableStateOf("46") }
    val snackbar=remember { SnackbarHostState() }
    val importer=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(model::importPng) }
    val modelImporter=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(model::importModelArchive)}
    val export=rememberLauncherForActivityResult(ExportPackDocument()) { uri ->
        uri?.let { model.exportPack(it) }
    }
    LaunchedEffect(model){snapshotFlow{model.message}.filterNotNull().collectLatest{key->model.message=null;snackbar.showSnackbar(model.t(key))}}
    if(model.isFree&&model.showStart){
        FreeStartScreen(model,snackbar)
        if(model.error!=null)StudioSheet(model,{model.error=null},MaterialTheme.colorScheme.surface){
            Column(Modifier.padding(20.dp)){Text(model.t(model.error!!));SpringTextButton({model.error=null}){Text(model.t("done"))}}
        }
        return
    }
    Box(Modifier.fillMaxSize()) {
        SunBackground(model,Modifier.fillMaxSize().then(if(model.isFree)Modifier else Modifier.hazeSource(haze)))
        Scaffold(containerColor=Color.Transparent,contentWindowInsets=WindowInsets.safeDrawing,snackbarHost={if(model.isFree)FreeSnackbarHost(snackbar)else SnackbarHost(snackbar)}) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).imePadding()) {
                GlassPanel(haze,model,Modifier.fillMaxWidth().weight(1f),contentPadding=6.dp) {
                    val pages=listOf(model.t("assets"),model.t("edit"),model.w("预览","Preview","プレビュー"),model.t("layers"))+
                        if(model.editMode==StudioModel.EditMode.PREVIEW)emptyList() else listOf(model.w("全屏绘画","Full canvas","全画面描画"))
                    SlidingBar(pages,tab.coerceAtMost(pages.lastIndex),{if(it!=tab){model.finishValue();model.endStroke();tab=it}},Modifier.fillMaxWidth(),enabled=!model.busy)
                    if(model.busy)FlowProgress(model)
                    ProjectUndo(model)
                    Spacer(Modifier.height(6.dp))
                    DirectionalContent(tab,{it},Modifier.fillMaxWidth().weight(1f)){page->
                        EditorBody301(model,page,paintView,{sheet=it}){texture->templateForResolution=texture;templateSize=texture.width;sheet="resolution"}
                    }
                }
                if(tab!=4)Row(Modifier.fillMaxWidth().then(if(model.transparentUi)Modifier else if(model.isFree)Modifier.background(MaterialTheme.colorScheme.surface,RoundedCornerShape(22.dp)) else Modifier.background(Brush.linearGradient(listOf(Color.White.copy(alpha=.92f),SunYellow.copy(alpha=.78f))),RoundedCornerShape(22.dp))).padding(start=10.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text("MCTS",style=MaterialTheme.typography.titleSmall)
                    Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),verticalAlignment=Alignment.CenterVertically){
                        CommandBar(scrollable=false) {
                            SpringTextButton(model::save,enabled=!model.busy){Text(model.w("保存","Save","保存"))}
                            SpringTextButton({importer.launch(arrayOf("image/png"))},enabled=!model.busy){Text(model.t("import"))}
                            SpringTextButton({sheet="export"},enabled=!model.busy){Text(model.t("export"))}
                        }
                        if(model.isFree)SpringTextButton(model::showStartPage,enabled=!model.busy){Text(model.t("start_home"))}
                        SpringTextButton({sheet="settings"}){Text(model.t("settings"))}
                        SpringTextButton({sheet="help"}){Text(model.t("help"))}
                    }
                }
            }
        }
        SuccessGlow(model)
    }
    if(model.error!=null) StudioSheet(model,onDismissRequest={model.error=null},containerColor=if(model.sunSheets)Color.Transparent else MaterialTheme.colorScheme.surface) {
        SunSheetSurface(model,haze){Column(Modifier.padding(24.dp)) {
            Text(model.t("error"),style=MaterialTheme.typography.headlineSmall)
            Text(model.t(model.error!!),modifier=Modifier.semantics { liveRegion=LiveRegionMode.Assertive })
            if(model.lastErrorCode.startsWith("SAVE_"))Text(model.t("save_next"))
            if(model.lastErrorCode.startsWith("EXPORT_"))Text(model.t("export_next"))
            SpringTextButton(onClick={model.error=null}){ Text(model.t("cancel")) }
        }}
    }
    if(model.exportGuidePending)ExportGuide(model)
    if(model.showOnboarding) Guide(model) { model.completeGuide() }
    else if(sheet!=null) StudioSheet(model,onDismissRequest={sheet=null},containerColor=if(model.sunSheets)Color.Transparent else MaterialTheme.colorScheme.surface) {
        SunSheetSurface(model,haze){Column(Modifier.fillMaxWidth().heightIn(max=680.dp).verticalScroll(rememberScrollState()).padding(if(model.isFree)16.dp else 24.dp).navigationBarsPadding()) {
            when(sheet) {
                "resolution"->templateForResolution?.let{texture->
                    Text(model.assetName(texture.path),style=MaterialTheme.typography.titleMedium)
                    Text(model.t("resolution"),style=MaterialTheme.typography.titleLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState())){texture.sizes().forEach{size->
                        SpringChip(templateSize==size,{templateSize=size},label={Text("${size} × ${size*texture.height/texture.width}")})
                    }}
                    Text("${texture.width} × ${texture.height} → ${templateSize} × ${templateSize*texture.height/texture.width}")
                    Action(model.t("edit"),model,!model.busy){model.openTemplate(texture,templateSize);sheet=null}
                }
                "palette"->ColorBoard(model)
                "projects"->ProjectSheet(model){sheet=null}
                "tools"->{MirrorControls(model);EditorControls(model){sheet="batch"}}
                "help"-> { Text(model.t("help"),style=MaterialTheme.typography.headlineSmall); (1..4).forEach { Text(model.t("step$it"),modifier=Modifier.padding(vertical=12.dp)) } }
                "appearance"->AppearanceSheet(model)
                "about"->AboutNotices(model)
                "cache"->TemplateCachePage(model)
                "settings"-> {
                    Action(model.t("about_notice"),model){sheet="about"}
                    Action(model.t("cache_manage"),model,!model.busy){sheet="cache"}
                    Text("MCTS ${BuildConfig.VERSION_NAME}",style=MaterialTheme.typography.labelLarge)
                    Text(model.t("settings"),style=MaterialTheme.typography.headlineSmall)
                    Action(model.w("外观 · 字体与背景","Appearance · Fonts & background","外観・フォントと背景"),model){sheet="appearance"}
                    Row(Modifier.horizontalScroll(rememberScrollState())) { Language.entries.forEach { language -> SpringChip(selected=model.language==language,onClick={model.changeLanguage(language)},label={Text(when(language){Language.ZH->"中文";Language.EN->"English";Language.JA->"日本語";Language.FR->"Français";Language.ES->"Español"})}) } }
                    if(model.isFree){
                        ThemeSettings(model)
                        HandSettings(model)
                        Row(verticalAlignment=Alignment.CenterVertically){StudioCheck(model.transparentUi,model::changeTransparentUi,enabled=!model.busy);Text(model.t("transparent_ui"))}
                        if(model.transparentUi)Text(model.t("transparent_warning"),style=MaterialTheme.typography.bodySmall)
                    }
                    if(model.allows(com.mcts.core.EditionPolicy.Feature.SPRING_MOTION)){
                    Row(verticalAlignment=Alignment.CenterVertically) { StudioCheck(model.reducedMotion,model::setMotion); Text(model.t("motion")) }
                    Row(verticalAlignment=Alignment.CenterVertically){Switch(model.sunSheets,model::changeSunSheets);Text(model.t("sun_sheets"),Modifier.padding(start=10.dp))}
                    Row(verticalAlignment=Alignment.CenterVertically){Switch(model.transparentUi,model::changeTransparentUi);Text(model.t("transparent_ui"),Modifier.padding(start=10.dp))}
                    if(model.transparentUi)Text(model.t("transparent_warning"),style=MaterialTheme.typography.bodySmall)
                    Text(model.t("edit_mode"),style=MaterialTheme.typography.titleMedium)
                    Row(Modifier.horizontalScroll(rememberScrollState())){
                        SpringChip(model.editMode==StudioModel.EditMode.PREVIEW,{model.changeEditMode(StudioModel.EditMode.PREVIEW)},label={Text(model.t("preview_edit"))})
                        SpringChip(model.editMode==StudioModel.EditMode.BOTH,{model.changeEditMode(StudioModel.EditMode.BOTH)},label={Text(model.t("preview_draw"))})
                    }
                    }
                    Row(verticalAlignment=Alignment.CenterVertically){if(model.isFree)StudioCheck(model.chooseBlock,model::changeChooseBlock,enabled=!model.busy)else Switch(model.chooseBlock,model::changeChooseBlock);Text(model.t("choose_block"),Modifier.padding(start=10.dp))}
                    Text(model.t("choose_block_hint"),style=MaterialTheme.typography.bodySmall)
                    if(model.allows(com.mcts.core.EditionPolicy.Feature.MODEL_IMPORT)){Text(model.t("model_source"),style=MaterialTheme.typography.titleMedium)
                    Text(model.t("model_binding_hint"),style=MaterialTheme.typography.bodySmall)
                    Action(model.t("download_models"),model,!model.busy){model.downloadOfficialModels()}
                    Action(model.t("import_models"),model,!model.busy){modelImporter.launch(arrayOf("application/zip","application/java-archive","*/*"))}
                    Text(model.t("model_notice"),style=MaterialTheme.typography.bodySmall)}
                    Text(model.t(if(model.isFree)"free_offline" else "offline"))
                    SpringTextButton(onClick={model.restorePrevious();sheet=null},enabled=!model.busy) { Text(model.t("restore")) }
                }
                "batch"-> {
                    Text(model.t("batch_confirm"))
                    Action(model.t("batch"),model,!model.busy && model.selection.isNotEmpty()) {model.batchFill();sheet=null}
                }
                "export"-> {
                    Text("${model.pack.name} · ${model.pack.profile.label}")
                    Text(model.w("导出此项目的全部编辑和原始模板，格式自动匹配所选版本。","Export all edits and template files using this project's target version.","対象バージョンに合わせ、全編集とテンプレートを書き出します。"))
                    if(model.isFree){Text(model.t("free_export_color"));ExportContents(model)}
                    if(!model.isFree&&!model.pack.profile.java&&!model.pack.profile.vv)Text(model.w("此旧基岩版本只导出颜色资源；PBR 保留在项目中。","This historical Bedrock target exports color only; PBR stays in the project.","この旧統合版は色のみ出力。PBRはプロジェクトに保持。"))
                    Action(model.t("export"),model,!model.busy) {sheet=null;export.launch(if(model.pack.profile.java)"MCTS_Project.zip" else "MCTS_Project.mcpack")}
                    Action(model.t("share"),model,!model.busy) {
                        sheet=null
                        model.exportPack(null) { file ->
                            val uri=FileProvider.getUriForFile(context,"${context.packageName}.files",file)
                            val send=Intent(Intent.ACTION_SEND).setType(ExportPackDocument.mimeType(file.name)).putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            context.startActivity(Intent.createChooser(send,model.t("share")))
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }}
    }
}

@Composable private fun SunSheetSurface(model:StudioModel,haze:HazeState,content:@Composable ColumnScope.()->Unit){
    if(model.sunSheets)GlassPanel(haze,model,Modifier.fillMaxWidth(),contentPadding=0.dp,fillContent=false,content=content)
    else Column(Modifier.fillMaxWidth(),content=content)
}

@Composable
internal fun Action(text:String,model:StudioModel,enabled:Boolean=true,onClick:()->Unit) {
    SunButton(text,enabled,onClick)
}

@Composable
internal fun AssetBrowser(model:StudioModel,onTemplate:(TemplateTexture)->Unit) {
    var query by remember(model.pack.id){mutableStateOf("")};var templates by remember(model.pack.id){mutableStateOf(true)}
    var category by remember{mutableStateOf<TemplateCategory?>(null)}
    var expanded by remember(model.pack.id){mutableStateOf<BlockAsset?>(null)}
    val group=expanded.takeIf{model.chooseBlock}
    Text(model.t("assets"),style=MaterialTheme.typography.titleLarge)
    SunTextField(query,{query=it},label={Text(model.w("搜索纹理","Search textures","テクスチャ検索"))},singleLine=true,modifier=Modifier.fillMaxWidth())
    Row {SpringChip(!templates,{templates=false;expanded=null},label={Text(model.w("项目素材","Project assets","プロジェクト素材"))});SpringChip(templates,{templates=true},label={Text(model.w("模板纹理库","Template library","テンプレート一覧"))})}
    if(templates){
        if(group!=null){
            SpringTextButton({expanded=null}){Text(model.t("back_blocks"))}
            Text(group.label(model.language),style=MaterialTheme.typography.titleMedium)
            Text(model.t("whole_block_hint"),style=MaterialTheme.typography.bodySmall)
            val textures=group.paths.mapNotNull{path->model.templateTextures.firstOrNull{it.path==path}}
            LazyColumn(Modifier.fillMaxWidth().fillMaxSize()){itemsIndexed(textures,key={_,t->t.path}){index,t->WaveItem(index){
                val directions=group.faces.mapIndexedNotNull{face,path->if(path==t.path)model.t("face${face+1}")else null}
                Column(Modifier.fillMaxWidth().clickable(enabled=!model.busy&&t.editable&&t.sizes().isNotEmpty()){onTemplate(t)}.padding(12.dp)){
                    Text(model.assetName(t.path));Text(directions.joinToString(" · ")+" · ${t.width} × ${t.height}",style=MaterialTheme.typography.labelSmall)
                }
            }}};return
        }
        val choices=listOf<TemplateCategory?>(null)+TemplateCategory.entries
        SlidingBar(choices.map{it?.label(model.language)?:model.w("全部","All","すべて")},choices.indexOf(category),{category=choices[it]},Modifier.fillMaxWidth())
        val catalogue=remember(model.pack.id){model.blocks()}
        val blocks=if(model.chooseBlock)catalogue.filter{g->(category==null||g.category==category)&&(g.label(model.language).contains(query,true)||g.paths.any{it.contains(query,true)})}else emptyList()
        val used=remember(catalogue,model.chooseBlock){if(model.chooseBlock)catalogue.flatMap{it.paths}.toSet()else emptySet()}
        val textures=model.templateTextures.filter{it.path !in used&&(category==null||it.category==category)&&(it.path.contains(query,true)||model.assetName(it.path).contains(query,true))}
        Text("${blocks.size+textures.size} · "+model.t("assets"))
        LazyColumn(Modifier.fillMaxWidth().fillMaxSize()){
            itemsIndexed(blocks,key={_,g->"block:"+g.id}){index,g->WaveItem(index){
                Column(Modifier.fillMaxWidth().clickable(enabled=!model.busy){expanded=g;model.openBlock(g)}.padding(12.dp)){
                    Text(g.label(model.language));Text("${g.category.label(model.language)} · ${g.paths.size} "+model.t("face_textures")+" ›",style=MaterialTheme.typography.labelSmall)
                }
            }}
            itemsIndexed(textures,key={_,t->t.path}){index,t->WaveItem(index){
                Column(Modifier.fillMaxWidth().clickable(enabled=!model.busy&&t.editable&&t.sizes().isNotEmpty()){onTemplate(t)}.padding(12.dp)){
                    Text(model.assetName(t.path));Text("${t.category.label(model.language)} · ${t.width} × ${t.height}",style=MaterialTheme.typography.labelSmall)
                }
            }}
        };return
    }
    LazyColumn(Modifier.fillMaxWidth().fillMaxSize().padding(bottom=64.dp)){
        itemsIndexed(model.assets.filter{it.name.contains(query,true)},key={_,a->a.key}){index,asset->WaveItem(index){
            val path=model.projectFiles.paths(model.pack).getProperty(asset.key)
            Row(Modifier.fillMaxWidth().clickable(enabled=!model.busy){model.open(asset.key)}.padding(6.dp),verticalAlignment=Alignment.CenterVertically){
                StudioCheck(asset.key in model.selection,{model.toggleAsset(asset.key)},enabled=!model.busy)
                Column{Text(if(path!=null)model.assetName(path)else asset.name);Text("${model.t(asset.kind.name)} · ${asset.size}",style=MaterialTheme.typography.labelSmall)}
            }
        }}
    }
}

@Composable
internal fun Layers(model:StudioModel) {
    val revision=model.revision
    Text(model.t("layers"),style=MaterialTheme.typography.titleLarge)
    Action(model.t("add_layer"),model,!model.busy && model.document.layers.size<MaterialDocument.MAX_LAYERS,model::addLayer)
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom=68.dp)) {
        model.document.layers.forEachIndexed { i,layer ->
            Row(verticalAlignment=Alignment.CenterVertically) {
                StudioRadio(model.activeLayer==i,{model.selectLayer(i)},enabled=!model.busy)
                Text(layer.name,Modifier.weight(1f))
                StudioCheck(layer.isVisible,{model.visibility(i,it)},enabled=!model.busy,modifier=Modifier.semantics {contentDescription=model.t("visible")+" "+layer.name})
            }
        }
        Text(model.t("opacity"))
        Text("${(model.document.layers[model.activeLayer].opacity*100).roundToInt()}%",style=MaterialTheme.typography.labelSmall)
        ElasticSlider(value=model.document.layers[model.activeLayer].opacity,onValueChange=model::opacity,onValueChangeFinished=model::finishOpacity,enabled=!model.busy,modifier=Modifier.semantics{contentDescription=model.t("opacity")})
    }
}

@Composable
private fun EditorControls(model:StudioModel,onBatch:()->Unit) {
    val revision=model.revision
    Text("${model.document.name} · ${model.document.width} × ${model.document.height}",style=MaterialTheme.typography.titleMedium)
    Row { SpringTextButton(onClick=model::undo,enabled=!model.busy && model.undoEnabled){Text(model.t("undo"))};SpringTextButton(onClick=model::redo,enabled=!model.busy && model.redoEnabled){Text(model.t("redo"))} }
    Row(Modifier.horizontalScroll(rememberScrollState())) { model.channels.forEach { item ->
        SpringChip(model.channel==item,{model.selectChannel(item)},enabled=!model.busy,label={Text(model.t(item.name))})
    } }
    if(!model.isFree)Text("${model.t("value")}: ${model.value}  ${model.selectedPixel?.let { "${model.t("pixel")}: ${it.first}, ${it.second}" }?:""}")
    if(model.channel==MaterialDocument.Channel.COLOR || model.channel==MaterialDocument.Channel.NORMAL)
        SunTextField(model.rgb,model::changeBrushRgb,label={Text(model.t("rgb"))},enabled=!model.busy,singleLine=true)
    else ElasticSlider(model.value.toFloat(),{model.changeBrushValue(it.roundToInt())},valueRange=0f..255f,onValueChangeFinished=model::finishValue,enabled=!model.busy,
            modifier=Modifier.semantics {contentDescription=model.t(model.channel.name)+" "+model.t("value")})
    var coordinates by remember {mutableStateOf(false)}
    SpringTextButton(onClick={coordinates=!coordinates}) {Text(model.t("coordinates"))}
    if(coordinates) {
        var x by remember {mutableStateOf("0")};var y by remember {mutableStateOf("0")}
        Row(verticalAlignment=Alignment.CenterVertically) {
            SunTextField(x,{x=it.filter(Char::isDigit).take(3)},label={Text("X: 0–${model.document.width-1}")},modifier=Modifier.weight(1f),singleLine=true)
            SunTextField(y,{y=it.filter(Char::isDigit).take(3)},label={Text("Y: 0–${model.document.height-1}")},modifier=Modifier.weight(1f),singleLine=true)
            SpringTextButton(onClick={model.beginStroke(x.toInt(),y.toInt());model.endStroke()},
                enabled=!model.busy && (x.toIntOrNull()?:-1) in 0 until model.document.width && (y.toIntOrNull()?:-1) in 0 until model.document.height) {Text(model.t("apply_pixel"))}
        }
    }
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        SpringTextButton(onClick=model::fill,enabled=!model.busy){Text(model.t("fill"))}
        SpringTextButton(onClick=onBatch,enabled=!model.busy && model.selection.isNotEmpty()){Text(model.t("batch"))}
    }
}

@Composable
internal fun PixelCanvas(model:StudioModel,modifier:Modifier) {
    val viewport=remember(model.document){PaintViewport()}
    PaintSurface(model,viewport,model.channel,modifier)
}

@Composable
internal fun Preview(model:StudioModel,modifier:Modifier=Modifier) {
    val frame=remember(model.document,model.revision,model.previewFaceSet,model.chooseBlock,model.activeBlock,model.modelMesh) {model.preview()}
    val context=LocalContext.current; val lifecycle=LocalLifecycleOwner.current.lifecycle
    val gl=remember(model.previewAttempt) {PreviewGLView(context)}
    val lastFrame=remember(gl) {arrayOfNulls<PreviewFrame>(1)}
    val lastShape=remember(gl){arrayOfNulls<String>(1)}
    val lastBoxes=remember(gl){arrayOfNulls<FloatArray>(1)}
    val listener=remember(gl,model){object:PreviewGLView.PixelListener{
        override fun onBegin(x:Int,y:Int,face:Int,surface:Int)=model.previewStrokeBegin(x,y,face,surface)
        override fun onMove(x:Int,y:Int,face:Int,surface:Int)=model.previewStrokeMove(x,y,face,surface)
        override fun onEnd()=model.endStroke()
    }}
    DisposableEffect(gl,lifecycle) {
        val observer=LifecycleEventObserver { _,event ->when(event){Lifecycle.Event.ON_RESUME->gl.onResume();Lifecycle.Event.ON_PAUSE->gl.onPause();else->Unit} }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer);gl.setPixelListener(null);gl.setFailureListener(null);gl.onPause() }
    }
    Box(modifier){
        AndroidView(factory={gl},update={
            it.setFailureListener{model.previewError()};it.setPixelListener(if(model.isFree)null else listener);it.setBasic(model.isFree);it.setPaintMode(!model.isFree&&model.previewPainting);it.setPixelGrid(model.pixelGrid)
            val shape=if(model.chooseBlock)frame.shape else "minecraft:stone"
            val boxes=if(model.chooseBlock)model.modelMesh?.quads else null
            if(lastShape[0]!=shape||lastBoxes[0]!==boxes){
                if(boxes!=null)it.setModelBoxes(boxes)else it.setShape(shape)
                lastShape[0]=shape;lastBoxes[0]=boxes
            }
            if(lastFrame[0]!==frame){
                it.setMaterialFaces(frame.color,frame.normal,frame.height,frame.mers,frame.size)
                lastFrame[0]=frame
            }
        },modifier=Modifier.matchParentSize().semantics{contentDescription=model.t("preview")+": "+model.document.name})
        if(model.previewFailed)Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).padding(12.dp),verticalArrangement=Arrangement.Center){
            Text(model.t("error_preview"),style=MaterialTheme.typography.bodySmall)
            SpringTextButton(model::retryPreview){Text(model.t("retry"))}
        }
        if(!model.isFree)Column(Modifier.align(Alignment.TopEnd).background(Color.Black.copy(alpha=if(model.transparentUi)0f else .46f),RoundedCornerShape(18.dp))){
            SpringTextButton({model.changePreviewPainting(!model.previewPainting)},enabled=!model.busy){
                Text(model.t(if(model.previewPainting)"orbit_model" else "paint_model"),color=Color.White)
            }
            if(model.previewPainting)Text(model.selectedPixel?.let{"${it.first}, ${it.second} · ${model.t(model.channel.name)} ${if(model.channel==MaterialDocument.Channel.COLOR)"#${model.rgb}" else model.value}"}?:model.t("paint_model"),color=Color.White,style=MaterialTheme.typography.labelSmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Guide(model:StudioModel,onDone:()->Unit) {
    var step by remember {mutableIntStateOf(1)}
    val haze=remember{HazeState()}
    StudioSheet(model,onDismissRequest=onDone,containerColor=if(model.sunSheets)Color.Transparent else MaterialTheme.colorScheme.surface) {
        SunSheetSurface(model,haze){
        Column(Modifier.fillMaxWidth().padding(24.dp).animateContentSize(if(model.reducedMotion)snap() else spring())) {
            Text(model.t("help"),style=MaterialTheme.typography.headlineSmall)
            Text(model.t("step$step"),modifier=Modifier.padding(vertical=24.dp))
            Action(model.t(if(step<4)"next" else "done"),model) {if(step<4)step++ else onDone()}
            Spacer(Modifier.navigationBarsPadding())
        }
        }
    }
}
