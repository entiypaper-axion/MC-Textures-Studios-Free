package com.mcts.studio
/** The explicit field list excludes project names, filenames, account IDs and content. */
internal object Diagnostics {
    fun report(version:String,code:Int,manufacturer:String,model:String,android:String,sdk:Int,language:String,error:String):String =
        "MCTS Free diagnostics\nApp: $version ($code)\nDevice: $manufacturer $model\nAndroid: $android (API $sdk)\nLanguage: $language\nLast error code: $error\nNo project content or file paths included."
}
