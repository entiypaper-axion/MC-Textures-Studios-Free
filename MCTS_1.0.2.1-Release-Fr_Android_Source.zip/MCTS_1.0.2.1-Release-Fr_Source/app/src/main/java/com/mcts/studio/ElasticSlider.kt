package com.mcts.studio

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** At either limit the handle stretches once; release gives its vertical bar a short spring. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable internal fun ElasticSlider(value:Float,onValueChange:(Float)->Unit,modifier:Modifier=Modifier,
    valueRange:ClosedFloatingPointRange<Float> =0f..1f,enabled:Boolean=true,onValueChangeFinished:(()->Unit)?=null){
    if(BuildConfig.IS_FREE){Slider(value,onValueChange,modifier=modifier,enabled=enabled,valueRange=valueRange,onValueChangeFinished=onValueChangeFinished,
        thumb={Box(Modifier.width(5.dp).height(30.dp).background(SunCoral,RoundedCornerShape(50)))},track={SliderDefaults.Track(it,enabled=enabled)});return}
    val quiet=LocalQuiet.current;val scale=remember{Animatable(1f)};val scope=rememberCoroutineScope()
    var atLimit by remember{mutableStateOf(false)}
    val limit=value<=valueRange.start+.0001f||value>=valueRange.endInclusive-.0001f
    LaunchedEffect(limit,quiet){
        if(limit&&!atLimit&&!quiet){scale.snapTo(1.45f);scale.animateTo(1f,spring(dampingRatio=.43f,stiffness=900f))}
        atLimit=limit
    }
    Slider(value,onValueChange,modifier=modifier,enabled=enabled,valueRange=valueRange,
        onValueChangeFinished={onValueChangeFinished?.invoke();if(!quiet)scope.launch{scale.snapTo(.72f);scale.animateTo(1f,spring(dampingRatio=.45f,stiffness=850f))}},
        thumb={Box(Modifier.width(5.dp).height(30.dp).graphicsLayer{scaleY=scale.value;scaleX=1f+(scale.value-1f)*.35f}
            .background(Brush.verticalGradient(listOf(SunCoral,SunCyan)),RoundedCornerShape(50)))},
        track={SliderDefaults.Track(it,enabled=enabled)})
}
