package com.mcts.studio
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.selection.SelectionContainer
@Composable internal fun AboutNotices(model:StudioModel){
    val context=LocalContext.current
    val notice=remember{listOf("MINECRAFT_ASSETS_NOTICE.txt","THIRD_PARTY_NOTICES.md","fonts/LXGWWenKai-OFL.txt","fonts/Monocraft-OFL.txt").joinToString("\n\n"){name->context.assets.open(name).bufferedReader().use{it.readText()}}}
    Text(model.t("about_notice"),style=MaterialTheme.typography.titleLarge)
    Text(model.t("unofficial"))
    Text("MCTS Free ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
    Text(model.t("diagnostics_hint"),style=MaterialTheme.typography.bodySmall)
    SpringTextButton({
        val clipboard=context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("MCTS diagnostics",model.diagnostics()))
        model.message="diagnostics_copied"
    }){Text(model.t("copy_diagnostics"))}
    SpringTextButton({runCatching{context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse("https://www.minecraft.net/en-us/eula")))}}){Text("Minecraft EULA ↗")}
    SelectionContainer{Text(notice,style=MaterialTheme.typography.bodySmall)}
}
@Composable internal fun TemplateCachePage(model:StudioModel){
    var pending by remember{mutableStateOf<GameProfile?>(null)}
    val revision=model.cacheRevision
    Text(model.t("cache_manage"),style=MaterialTheme.typography.titleLarge)
    gameProfiles.forEach{profile->
        val bytes=remember(profile.id,revision){model.projectFiles.templates.cacheBytes(profile)}
        Text("${profile.label} · ${bytes/1024/1024} MB")
        SpringTextButton({pending=profile},enabled=!model.busy&&bytes>0){Text(model.t("cache_delete"))}
    }
    pending?.let{profile->
        Text(model.t("cache_confirm"));Text(profile.label)
        SpringTextButton({pending=null;model.deleteTemplate(profile)},enabled=!model.busy){Text(model.t("cache_delete"))}
        SpringTextButton({pending=null}){Text(model.t("cancel"))}
    }
}
