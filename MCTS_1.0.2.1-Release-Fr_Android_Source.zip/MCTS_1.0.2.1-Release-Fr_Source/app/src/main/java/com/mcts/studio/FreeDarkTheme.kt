package com.mcts.studio
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
internal fun freeDarkColors(ink:Color=Color(0xffe5f4f0))=darkColorScheme(
    primary=Color(0xff80d8da),onPrimary=Color(0xff00383c),primaryContainer=Color(0xff16454c),onPrimaryContainer=ink,
    secondary=Color(0xffffba91),onSecondary=Color(0xff4b210c),secondaryContainer=Color(0xff583923),onSecondaryContainer=ink,
    tertiary=Color(0xffffb4ca),tertiaryContainer=Color(0xff543344),onTertiaryContainer=ink,
    background=Color(0xff0d191d),onBackground=ink,surface=Color(0xff122126),onSurface=ink,
    surfaceVariant=Color(0xff2c4045),onSurfaceVariant=ink,outline=Color(0xff91a7ab),outlineVariant=Color(0xff3a4d52),
    surfaceContainerLowest=Color(0xff091317),surfaceContainerLow=Color(0xff16282d),surfaceContainer=Color(0xff1b3036),
    surfaceContainerHigh=Color(0xff23383f),surfaceContainerHighest=Color(0xff2b4249))
@Composable internal fun ThemeSettings(model:StudioModel){
    Text(model.t("theme_mode"),style=MaterialTheme.typography.titleMedium)
    // Vertical options stay readable with 200% system text scaling.
    Column{StudioModel.ThemeMode.entries.forEach{mode->SpringChip(model.themeMode==mode,{model.changeThemeMode(mode)},label={Text(model.t(when(mode){StudioModel.ThemeMode.SYSTEM->"theme_system";StudioModel.ThemeMode.LIGHT->"theme_light";StudioModel.ThemeMode.DARK->"theme_dark"}))})}}
}
