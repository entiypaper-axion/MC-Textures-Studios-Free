package com.mcts.studio

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp

@Composable internal fun MirrorControls(model:StudioModel){
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),verticalAlignment=Alignment.CenterVertically){
        Text(model.t("mirror"),style=MaterialTheme.typography.labelLarge)
        SpringChip(model.mirrorX,{model.setMirror(!model.mirrorX,model.mirrorY)},enabled=!model.busy,label={Text(model.t("mirror_x"))})
        SpringChip(model.mirrorY,{model.setMirror(model.mirrorX,!model.mirrorY)},enabled=!model.busy,label={Text(model.t("mirror_y"))})
    }
}

@Composable internal fun HandSettings(model:StudioModel){
    Text(model.t("hand_mode"),style=MaterialTheme.typography.titleMedium)
    Column{
        StudioModel.HandMode.entries.forEach{hand->
            SpringChip(model.handMode==hand,{model.changeHandMode(hand)},label={Text(model.t(when(hand){StudioModel.HandMode.AUTO->"hand_auto";StudioModel.HandMode.LEFT->"hand_left";StudioModel.HandMode.RIGHT->"hand_right"}))})
        }
    }
    Text(model.t("hand_hint"),style=MaterialTheme.typography.bodySmall)
}

@Composable internal fun ProjectUndo(model:StudioModel){
    if(model.deletedProject==null)return
    Surface(color=MaterialTheme.colorScheme.secondaryContainer,shape=RoundedCornerShape(16.dp)){
        Column(Modifier.fillMaxWidth().padding(8.dp)){
            Text(model.t("project_deleted"),style=MaterialTheme.typography.bodySmall,modifier=Modifier.semantics{liveRegion=LiveRegionMode.Polite})
            SpringTextButton(model::undoProjectDelete,enabled=!model.busy){Text(model.t("undo"))}
        }
    }
}

@Composable internal fun ProjectManager(model:StudioModel,done:()->Unit){
    var target by remember{mutableStateOf<PackProject?>(null)}
    var operation by remember{mutableStateOf("")}
    var name by remember{mutableStateOf("")}
    model.packs.forEach{project->
        Surface(color=MaterialTheme.colorScheme.surfaceContainerLow,shape=RoundedCornerShape(16.dp),modifier=Modifier.padding(vertical=4.dp)){
            Column(Modifier.fillMaxWidth().padding(6.dp)){
                SpringTextButton({model.openPack(project);done()},enabled=!model.busy,modifier=Modifier.fillMaxWidth()){Text("${project.name} · ${project.profile.label}")}
                Row(Modifier.horizontalScroll(rememberScrollState())){
                    SpringTextButton({target=project;operation="rename";name=project.name},enabled=!model.busy){Text(model.t("project_rename"))}
                    SpringTextButton({target=project;operation="copy";name=project.name.take(72)+" (copy)"},enabled=!model.busy){Text(model.t("project_copy"))}
                    SpringTextButton({target=project;operation="delete"},enabled=!model.busy){Text(model.t("project_delete"))}
                }
                if(target?.id==project.id){
                    if(operation=="delete")Text(model.t("project_delete_confirm"))
                    else SunTextField(name,{name=it.take(80)},label={Text(model.t("project_name"))},singleLine=true,modifier=Modifier.fillMaxWidth())
                    SpringTextButton({
                        when(operation){"rename"->model.renamePack(project,name);"copy"->model.duplicatePack(project,name);"delete"->model.deletePack(project)}
                        target=null
                    },enabled=!model.busy&&(operation=="delete"||name.isNotBlank())){Text(model.t(when(operation){"rename"->"project_rename";"copy"->"project_copy";else->"project_delete"}))}
                    SpringTextButton({target=null},enabled=!model.busy){Text(model.t("cancel"))}
                }
            }
        }
    }
    ProjectUndo(model)
}

@Composable internal fun ExportContents(model:StudioModel){
    val summary=model.exportSummary
    if(summary==null)Text(model.t("summary_loading"))
    else{
        Text("${summary.edited} "+model.t("summary_edited"))
        Text("${summary.unchanged} "+model.t("summary_original"))
        Text("${summary.total} "+model.t("summary_total"),style=MaterialTheme.typography.titleMedium)
    }
}

@Composable internal fun ExportGuide(model:StudioModel){
    StudioSheet(model,{model.exportGuidePending=false},MaterialTheme.colorScheme.surface){
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())){
            Text(model.t("export_how"),style=MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            Text(model.t(if(model.exportedForJava)"export_java_steps" else "export_bedrock_steps"))
            Spacer(Modifier.height(12.dp));Text(model.t("export_verify"),style=MaterialTheme.typography.bodySmall)
            SpringTextButton({model.exportGuidePending=false}){Text(model.t("got_it"))}
        }
    }
}

/** Original vector illustrations, independent of game assets; never imply a download is complete. */
@Composable internal fun DownloadWalkthrough(model:StudioModel){
    Text(model.t("waiting_learn"),style=MaterialTheme.typography.titleMedium)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(12.dp)){
        repeat(4){index->
            Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surfaceContainerLow,modifier=Modifier.width(260.dp)){
                Column(Modifier.padding(16.dp)){
                    Canvas(Modifier.fillMaxWidth().height(100.dp)){
                        val u=size.height/8;val left=(size.width-u*8)/2
                        for(y in 0..7)for(x in 0..7){
                            val color=when(index){
                                0->if((x+y)%3==0)Color(0xffffba71)else if(y<3)Color(0xffa4dfa9)else Color(0xff88dada)
                                1->if(x>3)Color(0xff3bb8c7)else if(y<3)Color(0xffffd471)else Color(0xff82dbcf)
                                2->if(x==y||x==7-y)Color(0xffffbc72)else Color(0xffd6f0ed)
                                else->if(x in 2..5&&y in 2..5)Color(0xff4baea9)else Color(0xffffdfaa)
                            }
                            drawRect(color,Offset(left+x*u,y*u),Size(u-1,u-1))
                        }
                    }
                    Spacer(Modifier.height(10.dp));Text(model.t("demo${index+1}"))
                }
            }
        }
    }
}
