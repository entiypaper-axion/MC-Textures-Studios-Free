package com.mcts.studio

import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp
import dev.chrisbanes.haze.*

/** Refracts only the captured background, never text or the live GL preview. */
@Composable
fun GlassPanel(state:HazeState,model:StudioModel,modifier:Modifier=Modifier,contentPadding:Dp=16.dp,fillContent:Boolean=true,content:@Composable ColumnScope.()->Unit){
    if(model.transparentUi){Column(modifier.padding(contentPadding),content=content);return}
    if(model.isFree){Column(modifier.background(MaterialTheme.colorScheme.surface,RoundedCornerShape(20.dp)).padding(contentPadding),content=content);return}
    var size by remember{mutableStateOf(IntSize.Zero)};val context=LocalContext.current;val phase=ambientPhase(model)
    val radius=with(LocalDensity.current){26.dp.toPx()};val shape=RoundedCornerShape(26.dp)
    val shader=remember(model.highContrast){if(Build.VERSION.SDK_INT>=33&&!model.highContrast)runCatching{RuntimeShader(context.assets.open("agsl/mcts_liquid_glass.agsl").bufferedReader().use{it.readText()})}.getOrNull()else null}
    Box(modifier.shadow(if(model.highContrast)0.dp else 12.dp,shape,ambientColor=SunCoral.copy(alpha=.14f),spotColor=Color(0xff68b8af).copy(alpha=.15f))
        .clip(shape).onSizeChanged{size=it}.border(1.dp,Brush.linearGradient(listOf(Color.White,Color.White.copy(alpha=.35f),SunCyan.copy(alpha=.45f))),shape)){
        if(!model.highContrast)Box(Modifier.matchParentSize().graphicsLayer{
            renderEffect=if(Build.VERSION.SDK_INT>=33&&shader!=null&&size.width>0&&size.height>0)runCatching{
                shader.setFloatUniform("size",size.width.toFloat(),size.height.toFloat());shader.setFloatUniform("radius",radius)
                shader.setFloatUniform("refractionAmount",12f);shader.setFloatUniform("dispersion",.45f);shader.setFloatUniform("time",phase.value)
                android.graphics.RenderEffect.createRuntimeShaderEffect(shader,"content").asComposeRenderEffect()
            }.getOrNull()else null
        }.hazeEffect(state){blurRadius=18.dp})
        Box(Modifier.matchParentSize().background(if(model.highContrast)Brush.verticalGradient(listOf(Color.White,Color.White))else Brush.verticalGradient(listOf(Color.White.copy(alpha=.80f),Color.White.copy(alpha=.50f),Color(0xfff6fff9).copy(alpha=.66f)))))
        Column((if(fillContent)Modifier.fillMaxSize()else Modifier.fillMaxWidth()).padding(contentPadding),content=content)
    }
}
