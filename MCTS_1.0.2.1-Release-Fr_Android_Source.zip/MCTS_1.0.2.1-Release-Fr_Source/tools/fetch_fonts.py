import concurrent.futures,subprocess,pathlib,hashlib,json
p=pathlib.Path(__file__).resolve().parents[1]/'app/src/main/assets/fonts'
urls={'Monocraft.ttf':'https://raw.githubusercontent.com/IdreesInc/Monocraft/main/dist/Monocraft-ttf/Monocraft.ttf','Monocraft-OFL.txt':'https://raw.githubusercontent.com/IdreesInc/Monocraft/main/LICENSE','LXGWWenKai-Regular.ttf':'https://raw.githubusercontent.com/lxgw/LxgwWenKai/main/fonts/TTF/LXGWWenKai-Regular.ttf','LXGWWenKai-OFL.txt':'https://raw.githubusercontent.com/lxgw/LxgwWenKai/main/OFL.txt'}
def get(pair):
 name,url=pair;subprocess.run(['curl','-fLsS','--retry','2','--max-time','120',url,'-o',str(p/name)],check=True)
 if name.endswith('.ttf'):
  from fontTools.ttLib import TTFont
  assert len(TTFont(p/name).getBestCmap())>100
 return {'file':name,'url':url,'sha256':hashlib.sha256((p/name).read_bytes()).hexdigest()}
p.mkdir(exist_ok=True,parents=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:result=list(pool.map(get,urls.items()))
(p/'sources.json').write_text(json.dumps(result,indent=2));print('Fonts validated')
