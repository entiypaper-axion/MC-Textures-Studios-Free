"""Subset bundled fonts to characters used by app UI and template labels. Run after text changes."""
import pathlib,re,json,hashlib,sys
from fontTools import subset
from fontTools.ttLib import TTFont
root=pathlib.Path(__file__).resolve().parents[1]
chars=set('0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
for p in (root/'app/src/main/java').rglob('*'):
 if p.suffix not in ('.kt','.java'):continue
 text=p.read_text()
 for token in re.findall(r'"(?:\\.|[^"\\])*"',text):
  try:chars.update(json.loads(token))
  except json.JSONDecodeError:chars.update(token[1:-1])
for p in (root/'app/src/main/assets/catalogue').glob('*.json'):
 def add(value):
  if isinstance(value,str):chars.update(value)
  elif isinstance(value,list):
   for item in value:add(item)
  elif isinstance(value,dict):
   for item in value.values():add(item)
 add(json.loads(p.read_text()))
for p in (root/'app/src').rglob('*.xml'):
 chars.update(''.join(re.findall(r'>([^<]+)<',p.read_text())))
chars={c for c in chars if ord(c)>=32}
folder=root/'app/src/main/assets/fonts'
backup=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else folder
report=[]
for name,family in [('LXGWWenKai-Regular.ttf','MCTS WenKai'),('Monocraft.ttf','MCTS Pixel')]:
 source=backup/name;target=folder/name
 source_hash=hashlib.file_digest(source.open('rb'),'sha256').hexdigest();source_size=source.stat().st_size
 font=TTFont(source);font.recalcTimestamp=False;original=set(font.getBestCmap());keep=original&{ord(c) for c in chars}
 options=subset.Options();options.name_IDs=['*'];options.name_legacy=True;options.name_languages=['*'];options.notdef_glyph=True;options.notdef_outline=True
 sub=subset.Subsetter(options=options);sub.populate(unicodes=keep);sub.subset(font)
 for record in font['name'].names:
  if record.nameID in (1,16):record.string=family.encode(record.getEncoding())
  elif record.nameID in (3,4):record.string=(family+' Regular 1.0.0').encode(record.getEncoding())
  elif record.nameID==6:record.string=family.replace(' ','').encode(record.getEncoding())
 font.save(target)
 new=TTFont(target).getBestCmap();assert keep<=new.keys()
 report.append({'file':name,'source_sha256':source_hash,'original_bytes':source_size,'subset_bytes':target.stat().st_size,'app_character_count':len(chars),'retained_codepoints':len(new),'missing_app_characters_use_system_fallback':len({ord(c) for c in chars}-new.keys()),'subset_sha256':hashlib.file_digest(target.open('rb'),'sha256').hexdigest()})
(folder/'subset-report.json').write_text(json.dumps(report,indent=2)+'\n')
(folder/'app-characters.txt').write_text(''.join(sorted(chars,key=ord)))
manifest=folder/'sources.json'
if manifest.exists():
 sources=json.loads(manifest.read_text())
 for row in sources:
  match=next((s for s in report if s['file']==row['file']),None)
  if match:row.update(source_sha256=match['source_sha256'],sha256=match['subset_sha256'],processing='Subset to app UI and catalogue characters; renamed per OFL')
 manifest.write_text(json.dumps(sources,indent=2)+'\n')
print(json.dumps(report,indent=2))
