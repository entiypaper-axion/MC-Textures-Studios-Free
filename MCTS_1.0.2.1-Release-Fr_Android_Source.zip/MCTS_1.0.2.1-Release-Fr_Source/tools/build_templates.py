"""3.0.8-Fr downloads textures on-device. Bundling official ZIPs is intentionally disabled."""
raise SystemExit('Templates are no longer bundled. Choose a version on the app start screen and download it there. For source validation, see README_3.0.8-Fr.md.')
