"""Check download metadata, no packaged official textures, and APK integrity."""
import json,pathlib,sys,zipfile,re
PROFILES={'java_1165','java_1201','java_1211','java_12111','java_262','bedrock_116200','bedrock_1200','bedrock_12120','bedrock_121130','bedrock_2630'}
def templates(names,read):
 if set(names)!={'sources.json'}:raise ValueError('Unexpected/missing template files: '+str(set(names)^{'sources.json'}))
 rows=json.loads(read('sources.json'))
 if len(rows)!=10 or {r['profile']for r in rows}!=PROFILES:raise ValueError('Invalid template catalogue')
 for row in rows:
  if not row['url'].startswith('https://') or not re.fullmatch('[a-f0-9]{64}',row['source_sha256']):raise ValueError('Invalid pinned source')
  if not row.get('urls') or any(not u.startswith('https://') for u in row['urls']):raise ValueError('Invalid backup URLs')
  if not 0 < row.get('size_bytes',0) <= 512*1024*1024:raise ValueError('Invalid source size')
 return rows
def verify(path):
 p=pathlib.Path(path)
 if p.is_dir():templates([f.name for f in p.iterdir()],lambda n:(p/n).read_bytes())
 else:
  with zipfile.ZipFile(p)as z:
   if z.testzip() is not None:raise ValueError('APK CRC failure')
   if any(n.endswith(('.tmp','.part','.download','.building'))for n in z.namelist()):raise ValueError('Temporary file in APK')
   templates([n.removeprefix('assets/templates/')for n in z.namelist()if n.startswith('assets/templates/')],lambda n:z.read('assets/templates/'+n))
   if any(n.startswith('assets/') and n.endswith('.zip') for n in z.namelist()):raise ValueError('Bundled official template ZIP')
   if z.getinfo('assets/fonts/LXGWWenKai-Regular.ttf').file_size>8*1024*1024:raise ValueError('Font was not subset')
   if z.getinfo('resources.arsc').compress_type!=zipfile.ZIP_STORED:raise ValueError('Compressed resource table')
 print('PASS: 10 pinned HTTPS sources, no bundled template ZIPs, no staging files')
if __name__=='__main__':verify(sys.argv[1])
