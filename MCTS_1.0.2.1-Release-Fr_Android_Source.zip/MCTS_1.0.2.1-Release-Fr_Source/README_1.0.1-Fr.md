# MCTS Free 1.0.1-Release-Fr

Based on the 1.0.0-Release-Fr source. versionCode 31010, versionName `1.0.1-Release` + `-Fr`. Package name and signing key are unchanged, so 1.0.0 installs upgrade in place.

## What's new
### New UI (Free edition)
- Top bar in three groups:
  - Left: Projects / Import / Export / Brush settings / New / Delete current / UI layout
  - Centre: Canvas left / centre / right
  - Right: Keyboard & mouse / Accessibility / Text↔icon labels / Guide / Light↔dark / Language / Home / Feedback / Settings
- Canvas position switches the three-column order:
  - Left = canvas | sidebar | tools
  - Centre = sidebar | canvas | tools
  - Right = sidebar | tools | canvas
- Sidebar: project header, Assets/Layers tabs, and the 3D preview at the bottom. Hidden, normal and large preview sizes are available.
- Wide tool panel:
  - Colour block on top: main/second colour, HEX, saturation/value field, hue, opacity, and swatches (transparent + this texture's colours + recent colours).
  - Tools below. **Eraser = opaque white #FFFFFF**; **Erase = transparent (alpha 0)**. They have different icons, chips and descriptions.
  - Brush 1–8 px, mirror, grid, undo/redo, current-tool hint card, and zoom.
- Phone layout (auto under 600 dp, or chosen manually): scrollable top bar plus a bottom toolbar. Assets, layers, colour and preview open as dialogs. One-hand mode moves the toolbar toward the chosen hand.
- New line-icon set (`ProIcons.kt`, generated from the design SVGs), neutral graphite/paper palette, 8–12 dp corners, system font by default. A font picked in Appearance still applies.
- New logo: one isometric pixel plate with an "M". Adaptive launcher icon (foreground, background and Android 13 themed monochrome) plus the in-app logo.

### Features (function tree; all new except where noted)
- **Projects**
  - Open, rename, copy, and delete with 8 s undo (existing).
  - Save now, autosave (on/off, 1/2/5/10 min, also on app pause), and project info.
- **Import**
  - PNG as a layer (existing).
  - PNG to replace the current texture (same aspect ratio, resampled).
  - Paste an image from the clipboard.
  - **Import a resource pack (.zip / .mcpack) as a new project.** Colour textures only. Zip-slip, size and CRC checks apply. A cached template of the same version fills in untouched textures.
- **Export**
  - Pack name and description, and pack icon (template / current texture / chosen image).
  - Pre-export check: warns when nothing is edited, when resolutions are mixed, or when an opaque block texture became transparent.
  - Save / share, and export the current texture as PNG.
- **Brush settings:** size 1–8, square/round, opacity, mirror (off / left-right / up-down / four-way), fill contiguous/global with tolerance 0–100 %, and pixel-perfect lines.
- **Delete current:** delete the project (8 s undo), or reset the current texture to the template original (the old version stays in history).
- **UI layout:** device auto/phone/tablet, one-hand mode, sidebar width, 3D preview size, full/compact tool panel, UI scale 90/100/115 %, and reset.
- **Keyboard & mouse**
  - Customisable shortcuts: B, E, Shift+E, G, I, V, M, #, Ctrl+Z/Y, [ ], X, Ctrl+S/E, Ctrl+= / - / 0.
  - Wheel zoom; Space-drag or middle-button pan; right-button action (picker / erase / none).
  - Stylus side button action; stylus-only drawing (palm rejection). The stylus eraser end always erases.
- **Accessibility:** screen-reader labels on every control, announce pixel position and colour, large UI, high contrast, colour names on swatches, reduce motion, haptics.
- **Guide:** 5-step intro (shown once to everyone after upgrading), export steps, eraser vs erase, shortcut sheet, FAQ.
- **Theme:** tap toggles light/dark; long press opens Light / Dark / System. **Language:** 5 languages. **Home:** saves first.
- **Feedback:** copy diagnostics, GitHub issue, QQ channel pd48299172 (copied), and a screenshot shared together with diagnostics.
- **Settings:**
  - Appearance: theme, language, font, text size.
  - Templates: cache manager, metered-network confirmation, whole-block view.
  - Editing: default resolution, undo-step limit, long-press eyedropper, restore previous version.
  - About.

### Template versions
- **Java (12):** 1.6.4, 1.7.10, 1.8.9, 1.12.2, 1.16.5, 1.20.6, 1.21, 1.21.1, 1.21.4, 1.21.11, 26.2, 26.3
- **Bedrock (8):** 1.16.200, 1.20.80, 1.21.0, 1.21.20, 1.21.50, 1.21.130, 26.30, 26.50
- Pairings: 1.16.5↔1.16.200, 1.20.6↔1.20.80, 1.21↔1.21.0, 1.21.1↔1.21.20, 1.21.4↔1.21.50, 1.21.11↔1.21.130, 26.2↔26.30, 26.3↔26.50 (Wilderness Bound, both released 2026-09-15).
- Java 1.6.4–1.12.2 have no Bedrock counterpart. Pocket Edition of that era had no resource packs, and no archived vanilla sample exists. The UI says so.
- Java 1.20.1 and Bedrock 1.20.0 are kept as **legacy** profiles. Existing projects still open and export, but these versions are no longer offered for new projects.
- **New Java sources** are pinned by Mojang's own SHA-1 (the same hash that appears in the piston-data URL). Download order: piston-data.mojang.com → launcher.mojang.com → BMCLAPI mirror (for mainland China). Every file is verified against the SHA-1, and a hash mismatch moves on to the next URL instead of retrying the same one 3×.
- **New Bedrock sources** are commit-addressed GitHub URLs of Mojang/bedrock-samples (an immutable commit, not a tag). The archive is validated by TemplateArchive when it is built, and the local SHA-256 is recorded in the ready marker as before.
- Client-jar URLs and sizes were cross-checked against two independent sources: Mojang's version JSONs and Prism Launcher's meta repo. Bedrock tags and commits came from `git ls-remote` of Mojang/bedrock-samples.
- Pack formats:
  - 1.6.4–1.8.9 → 1, 1.12.2 → 3, 1.20.6 → 32, 1.21/1.21.1 → 34, 1.21.4 → 46.
  - 26.3 → 97.1 (min_format [97,0] / max_format [97,1]).
  - Bedrock `min_engine_version` is now derived for any version (26.50 → [1,26,50]).
- Catalogue (display names): new versions borrow the nearest bundled index, filtered to textures that actually exist. Pre-1.13 Java names are mapped to modern names for display only (`LegacyNames.kt`). Files keep their legacy paths on export.

## Files
- Core (Java, tested): `MaterialDocument` (undo-step limit, layer pixel copy, stroke-pixel revert), `PixelTools` (brush footprints, flood fill, elbow test), `PackImport`.
- App:
  - `ProTheme`, `ProIcons`, `ProComponents`, `ProShell` (workspace, top bar, layouts, shortcuts, autosave)
  - `ProSidebar`, `ProToolPanel`, `ProCanvas`, `ProMenus` (every top-bar dialog), `ProStart`, `ProWords` (strings ×5)
  - `Keymap`, `LegacyNames`
- Modified: `StudioModel`, `Projects`, `TemplateStore`, `BlockCatalogue`, `MainActivity` (the Free edition now uses `ProWorkspace`; the 1.0.0 composables are left in place, unused).
- Tests: `core/.../Core101Test.java` and `app/src/test/.../Free101Test.kt` (Robolectric). `ReleasePolishTest` now picks its profile by id.

## Verification done here
- `test-core.sh`: CoreTest 83 checks + Core101Test 28 checks — PASS.
- FreePolishTest (20239), CanvasGeometryTest (427), TemplateArchiveTest (66), test_template_gate.py (4) — PASS.
- The whole app module (42 Kotlin files) type-checks with zero errors against an offline stub harness (Android/Compose signatures).

## NOT verified here — please run before release
- No Gradle/Android build: this sandbox has no Android SDK or Google Maven. The stub harness does **not** apply Compose-compiler rules or exact library signatures. **Run CI** (`gradle :app:assembleFreeRelease :app:lintFreeRelease :app:testFreeDebugUnitTest`, then `test-free-polish.sh`) and fix anything it reports.
- Robolectric tests (including the new Free101Test) were not run.
- Real-device checks:
  - Tablet landscape: all three canvas positions.
  - Phone layout.
  - Eraser vs Erase, long-press picker.
  - Mouse wheel and right button; stylus.
  - Downloading one old Java version (1.8.9) and one new Bedrock version (26.50).
  - Importing a .zip and a .mcpack.
  - Exporting and loading in game (Java 26.3 format 97.1, Bedrock 26.50).
