# 3.0.0-alpha02 · 2026-09-26

新增可视化 HSV 调色盘、颜色收藏、画布吸管、同屏预览/画布可拖动比例（15%–85%）、
Java/基岩版选择、独立资源包项目，以及十套离线原版纹理模板。

点顶部项目名称即可新建/切换项目。创建时选择平台、版本、模板或空白项目。
素材页的「模板纹理库」可搜索并打开原版贴图。颜色通道中用调色盘选色；吸管读取当前通道，
不会落笔。拖动预览与画布之间的分隔条或比例滑杆可以调整两者大小。
收藏色和布局比例在重启后保留。

| Java | 基岩版对应内容时期 | Java 资源格式 |
|---|---|---|
| 1.16.5 | 1.16.200 | 6 |
| 1.20.1 | 1.20.0 | 15 |
| 1.21.1 | 1.21.20 | 34 |
| 1.21.11 | 1.21.130 | 75.0 |
| 26.2 | 26.30 | 88.0 |

这表示对应内容时期，不是补丁一一等价。Java 原版客户端的 version.json 和官方 SHA-1
用于核对版本及资源格式。基岩较新四套来自 Mojang/bedrock-samples 正式版本标签；
1.16.200 来自 bedrock-dot-dev/packs 保存的 Mojang 1.16.200.2 历史样本，固定提交
649931106d425c4ca948b9db5ae0dc3eaba4b922。完整网址和 SHA-256 在
`app/src/main/assets/templates/sources.json`。总计 34,838 张真实 PNG。

模板原样保留 PNG/TGA/相关 JSON 与 mcmeta；当前编辑尺寸为各边 16–512 二次幂。
不满足尺寸的纹理仍随包导出，不会删除或强行缩放。动画条带保留，但没有帧时间线。
矩形纹理仅在材质测试方块的预览中映射为方形，编辑/导出仍保持原始宽高。

每个项目拥有独立文件夹、历史记录、原始模板、目标版本与固定 Bedrock UUID。
切换项目先保存；导出包含当前项目所有编辑和未编辑模板文件，不混入其他项目。
Java 导出 ZIP，基岩导出 MCPACK。前三个旧基岩目标没有 Vibrant Visuals，导出颜色资源，
PBR 数据留在本地项目；后两个目标导出 VV normal/MERS/texture_set。
基岩项目仍是资源/PBR 包，不编译 RenderDragon .material.bin。模型骨骼、云协作不在本次范围。

## 安装与签名

包名 `com.axion.pompreview.studio3`，版本码 30002，Android 8.0+。
与旧 alpha01/2.x 并存安装；旧测试签名已丢失，因此不覆盖它们，也不会自动迁移私有工程。
请保留旧 App。此次签名备份单独保存，用于后续同签名升级，不在源码中。
构建时可设置 `MCTS_SIGNING_KEY`（绝对路径）和 `MCTS_SIGNING_PASSWORD`，别名 mcts。

## 构建

JDK 17、Gradle 8.11.1、SDK 35 / build-tools 35.0.0。
`bash test-core.sh`；`gradle :app:assembleDebug :app:lintDebug`。
十套模板已内置；`python3 tools/build_templates.py` 可重新获取，失败即停止。
本工具不是 Mojang 官方产品。原版纹理版权属于 Mojang/Microsoft，适用 Minecraft EULA：
https://www.minecraft.net/en-us/eula 。不含 Minecraft 客户端程序代码。

本轮恢复后通过的检查与 APK 核验结果另见 `VALIDATION_ALPHA02.md`；没有真机测试。
