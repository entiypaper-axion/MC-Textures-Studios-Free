# 3.0.9-Fr verification

2026-10-06. Based on 3.0.8-1-Fr; versionCode 30900; package com.axion.pompreview.studio3.free.

- assembleFreeRelease, testFreeDebugUnitTest and lintFreeRelease: successful build (see final test XML/lint summary).
- Download lifecycle: 19 checks of real compiled Kotlin with recording HTTP adapters, including cancellation, Range resumption, atomic ready marker, offline reuse, corrupt-cache repair, SHA-256 rejection, low-storage rejection before connection, automatic retry, alternate URL fallback and cache deletion.
- Android regressions: 8 popup tests and 6 export tests, API 26/35 via Robolectric. These are host tests, not phone or Minecraft tests.
- APK SHA-256, ZIP integrity, source-metadata gate, release certificate and alignment checked before delivery. Certificate SHA-256: 32a0895b3447b0d404d54c545ee0b6009d4542ff38f02a15504c0c21bf0c6ff6 (same as previous Free releases).

Limits: no device/emulator or Minecraft import test. Actual ten-source downloads were not repeated; pinned sizes/hashes come from the previous source-download-validation.json. URL fallback was tested with an HTTP adapter; the alternate upstream GitHub route is not a domestic CDN and does not guarantee availability in China. Foreground service/notification was not added; process termination requires resumption from the start screen. Full-template project integration requires optional fixtures and was skipped.

Old VALIDATION files refer to their own historical versions, not this release.

Final lint: 0 errors, 33 warnings. Full regression script: 83 core, 20,239 Free edit/history, 427 canvas geometry, 66 template/edition, 4 negative metadata, 19 download lifecycle and 13 renderer adapter checks passed. APK zipalign -P 16 check passed. These checks do not replace device/GPU/game verification.
