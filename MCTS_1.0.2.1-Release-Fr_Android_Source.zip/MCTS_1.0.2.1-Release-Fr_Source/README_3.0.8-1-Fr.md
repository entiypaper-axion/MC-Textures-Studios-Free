# MCTS Free 3.0.8-1-Fr

基于 3.0.8-Fr 的修复版本，版本码 30801。包名保持 `com.axion.pompreview.studio3.free`，沿用 Free 正式签名；可升级 3.0.7-Fo / 3.0.8-Fr，与 Plus 和 Ultra 共存。

## 修复与调整

- 所有 Free 小窗口共享固定“关闭”按钮，放在滚动正文之外；设置、外观、引导与帮助、调色、工具、项目、分辨率、导出及错误窗口都适用。点击背景空白或系统返回也可关闭；点击窗口正文不会误关。Free 无新增弹簧或转场动画。
- 基岩版保存对话框改用通用二进制 MIME，以保留 `.mcpack` 文件名，避免 Android DocumentsUI 为 ZIP MIME 补成 `.mcpack.zip`。Java 保留 `.zip` 和 ZIP MIME。分享使用相同格式判断。
- 基岩版输出仍是标准 ZIP 容器，根目录直接放 manifest.json 与资源，而非套一层 ZIP；`.mcpack` 是该容器的游戏导入扩展名。
- 删除外观页顶部的 Sun UI 演示卡片（Hello, sunshine!）；字体、文字颜色、自定义背景保留。
- 删除高对比度开关和提示。升级后忽略以前保存的高对比度值，恢复普通显示，避免隐藏入口后无法关闭旧状态。
- 按修改后的全部应用界面、多语言文案和素材名称重新裁剪字体，保留开源许可和系统字体回退。

模板仍在开始界面按所选 Java／基岩版本下载，准备后离线编辑。未增加编辑功能。3.0.8 的下载、权限、模板来源及 Free 范围说明见 README_3.0.8-Fr.md。

## 构建与验证

JDK 17、Android SDK 35 / build-tools 35.0.0、Gradle 8.11.1。最低 Android 8.0，GLES 3.0。

```sh
./gradlew :app:assembleFreeRelease :app:lintFreeRelease :app:testFreeDebugUnitTest
ANDROID_HOME=/your/android-sdk bash test-free-polish.sh
```

新增 Robolectric Compose 回归在 Android API 26 和 35 环境检查关闭按钮、长窗口、返回键、内外点击，以及生产导出文件选择 Intent、Android 文件名处理和实际基岩包内容。它们是主机上的 Android 模拟实现，不是真机或 Android Emulator。

正式签名从 `MCTS_SIGNING_KEY` / `MCTS_SIGNING_PASSWORD` 环境变量提供，别名 mcts。源码不含私钥、密码、本机 SDK 配置或下载的官方纹理；缺少正式密钥时 Gradle 使用本机调试签名，不能覆盖本次 APK。

详见 VALIDATION_3.0.8-1-Fr.md。仍需实机确认各厂商文件选择器、手势返回、键盘与横屏，以及 Minecraft 游戏内导入。
