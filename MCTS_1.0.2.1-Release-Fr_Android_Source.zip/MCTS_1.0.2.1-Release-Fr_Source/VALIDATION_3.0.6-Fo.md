# 3.0.6-Fo 验证

- `:app:assembleFreeRelease :app:lintFreeRelease --offline` 成功。Lint 无错误，32 项非阻断警告。
- 核心数据测试 83 项、模板污染负向检查 4 项通过。
- 编译后 Kotlin 项目实现使用 JVM 文件/图像适配器验证 167 项。覆盖十套版本配置、整块草方块的面绑定及名称、项目隔离、编辑颜色导出、Free 导出无 PBR 贴图和无基岩 PBR capability。
- 发布 APK 内十套模板、41,544 个 PNG 的 SHA256 与 ZIP CRC 校验通过，零 `.tmp` / `.part`。
- `zipalign -c -P 16 4` 和 `apksigner verify` 通过。包名 `com.axion.pompreview.studio3.free`，版本名 `3.0.6-Fo`，版本码 30600。
- 签名证书 SHA256：`e5fd9c926f8ccce3cd2697ac4819dc3ad7ffbbff30b3b02a6672f0a9006231d7`。
- 无 Android 真机或模拟器；安装、GPU 渲染、透明模式的实际可读性与手势体验尚未在设备上验证。
