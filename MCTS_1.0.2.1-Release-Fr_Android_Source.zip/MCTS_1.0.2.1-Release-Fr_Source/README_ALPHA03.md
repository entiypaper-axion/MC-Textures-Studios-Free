# 3.0.0-alpha03 — Sunlight

保留 alpha02 的工作区排版、项目和绘画功能，改为浅色双渐变、柔和高光、Haze 模糊与 Prismal 派生液态折射。按钮弹簧回弹、素材列表错峰入场、页面柔光扩散、短暂成功光效、流动进度条。减少动态效果和高对比度继续可用；声音默认关闭。

设置 → 外观 · 字体与背景：字体、文字颜色与 85%–140% 字号、三款预设背景、自选双色渐变、本地图片与柔光遮罩。修改自动保存，不改变纹理与导出。图片按需缩小并按 EXIF 转正，复制到本机后可离线使用。字体支持 TTF/OTF/TTC 导入；超限或无效文件不会替换当前外观。

内置系统基础/衬线/等宽、Monocraft 和 LXGW WenKai。Monocraft 是开源 Minecraft 风格字体，不是官方 Java 原版字体；文楷是开源手写体，不是原神字体。未附带原神专有字体，用户可导入有权使用的字体。OFL 许可与来源 SHA256 随 APK 附带。

模板生成使用 assets 以外的缓存目录，构建前核对十套白名单及 SHA256/CRC，构建后拒绝 tmp/part。工具 tools/verify_package.py 可检查 APK 中每套模板的哈希、CRC 和 PNG 数量。再生成模板前必须等待构建结束，不应同时运行。

包名 com.axion.pompreview.studio3，versionCode 30004。沿用 alpha02 签名，支持直接覆盖升级；不会清空项目。最低 Android 8.0。AGSL 在 Android 13+ 使用，旧系统保留兼容玻璃表现。

构建：JDK 17、Gradle 8.11.1、Android SDK 35 / build-tools 35.0.0。设置 MCTS_SIGNING_KEY 和 MCTS_SIGNING_PASSWORD（别名 mcts），运行 gradle :app:assembleRelease :app:lintRelease。签名密钥备份独立保存，不包含在源码包。

最终验证见 VALIDATION_ALPHA03.md。没有真机或模拟器测试，不声称所有设备 GPU 已兼容。
