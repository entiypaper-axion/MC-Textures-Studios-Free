# MCTS Free 3.0.6-Fo

本次发布的是 Free 版。版本名 `3.0.6-Fo`，版本码 30600，包名 `com.axion.pompreview.studio3.free`。独立安装，可与普通版共存，项目数据各自保存。Android 8.0 及以上，设备需支持 OpenGL ES 3.0。

保留颜色贴图编辑、调色盘、取色器、图层、撤销/重做、像素格、16–512 分辨率、实时立体预览、模板选择、多项目和 Java/Bedrock 颜色资源包导出。多面方块按整块浏览，点开后选择面贴图；预览组合各面的颜色贴图。

Free 版只开放颜色通道，不提供 MER、法线、高度等 PBR 编辑；导出时不生成这些贴图，基岩导出也不声明 PBR capability。实时预览只能查看、旋转和缩放，不能在模型上绘画。没有玻璃模糊、折射、动态壁纸、过渡动画、入场动画、弹性反馈或涟漪反馈。

透明模式默认关闭，可在设置中开启；开启后面板和边框隐藏，背景模糊保持为零，界面会提示文字可读性可能受影响。普通状态使用实色面板。静态图片和字体设置沿用现有实现。

构建：JDK 17、Gradle 8.11.1、Android SDK 35；执行 `gradle :app:assembleFreeRelease :app:lintFreeRelease`。源码同时保留 full/free 两个构建变体；本次交付对应 freeRelease。签名可通过 `MCTS_SIGNING_KEY`、`MCTS_SIGNING_PASSWORD` 环境变量配置，别名 `mcts`；密钥不包含在源码中。

自动验证见 `VALIDATION_3.0.6-Fo.md`。尚无 Android 真机或模拟器测试记录；复杂实体模型和动画不保证完全复现游戏画面。
