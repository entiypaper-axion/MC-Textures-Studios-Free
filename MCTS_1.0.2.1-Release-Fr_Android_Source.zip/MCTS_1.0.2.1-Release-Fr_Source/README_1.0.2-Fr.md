# MCTS Free 1.0.2-Release-Fr

Built on 1.0.1-Release-Fr, including the startup-crash fix. The version is now versionCode 31020 and versionName `1.0.2-Release` + `-Fr`. Package name and signing are unchanged, so 1.0.1 upgrades in place.

## What's new

### 1. Startup animation
- Every cold start plays the opening from the promo video:
  - The 5 × 5 squares drop in one by one. The squares forming the "M" land white, then cool to mint green.
  - The plate gains its sides and a glow, then slides into the lockup "MCTS · FREE · version".
- It is silent and lasts about 3 seconds. Tap anywhere to skip.
- Rotating the screen does not replay it.
- With reduce motion on, the finished logo shows for 0.7 s and fades.
- The first time the app is opened, the 1.0.1 five-step guide follows. Anyone who already saw it in 1.0.1 does not get it again.
- Code: `LogoIntro.kt`, called from `MainActivity`.

### 2. Templates for every version
- **Java editions: all 103 releases from 1.0 to 26.3**, including 1.2.1–1.2.5, 1.7.2–1.7.10, 1.8–1.8.9, 1.21.5–1.21.11 and 26.1–26.1.2.
  - Each one is Mojang's official client.jar, pinned by Mojang's SHA-1.
  - Download sources are tried in this order: piston-data, then launcher.mojang.com, then BMCLAPI. The mirror is also checked by SHA-1.
  - pack_format values come from each version's own `version.json`. Examples: 1.21.9 = 69, 26.1 = 84, 26.3 = 97.1.
- **Bedrock: 51 versions, each matched to the Java version of the same period.**
  - 1.19.40 to 26.50 come from Mojang/bedrock-samples, pinned by commit.
  - 1.16.20 to 1.19.30 come from the bedrock.dev archive of Mojang's vanilla samples.
  - Mojang has no public resource archive from before 1.16.20, so Java before 1.16.2 has no Bedrock counterpart.
- **1.0 – 1.5.2 old texture packs are fully supported** (`core/LegacyPack.java`):
  - **1.5.x:** single files are kept and their original paths are remembered.
  - **1.0 – 1.4.7:** `terrain.png` and `gui/items.png` are cut into single tiles for editing.
    - Tile names come from the 1.5.2 split textures: identical pixels get the same name. This requires one extra 5 MB download of the 1.5.2 jar.
    - Tiles with no match keep their index name, such as `terrain_037`.
  - **Export** stitches the tiles back into the atlas and writes a texture-pack zip with `pack.txt`.
    - If any tile is larger than 16 px, the whole atlas is scaled up to that size. Before 1.5 this needs OptiFine/MCPatcher, and the export report says so.
  - **Importing an old texture pack** splits it with the same names.
- **Version picker:**
  - Versions are grouped by line, newest first ("26.3", "26.2" … "1.0 – 1.4").
  - The group containing the selected version is open; the others fold to one row.
  - It has search, and shows the download size and downloaded state.
- The asset browser's Chinese names fall back to the bundled index of the nearest version in the same edition. Pre-1.13 names are still mapped through `LegacyNames`.

### 3. Motion: Apple-style light bounce
- All motion uses one spring family:
  - Response ≈ 0.32 s.
  - Small controls use damping 0.55: one slight undershoot of about 1.5 % after release.
  - Panels and pages use damping 0.78. (`Motion.kt`)
- **Buttons, chips and toggles:** pressing bulges the control like a drop of water, up to +12 % on icon-sized controls and less on long rows. Releasing springs back once.
- **Dialogs, menus and panels:** they spring in (scale 0.92 → 1, rising slightly) and leave quickly. `ProDialogs` waits for the exit animation before removing a dialog.
- **Page switch and lists:**
  - Start page ↔ editor ↔ custom layout cross-fade with a slight zoom.
  - Asset lists and project cards rise in one after another, 28 ms apart. Scrolling does not replay this.
- **Canvas, tools and panels:**
  - Pinching past the zoom limit stretches like a rubber band and springs back on release.
  - The selected tool "pops"; segmented controls slide with a small stretch.
  - Dragged layout panels settle with the spring.
- **When it turns off:** animations are on by default, Free included. They turn off with the accessibility "reduce motion" switch, or automatically when the system has "remove animations" on (animator duration scale = 0).

### 4. Liquid glass (Android 13+, off by default)
- Turn it on under Settings → Liquid glass, then import your own wallpaper. No wallpaper is bundled.
- It is modelled on iOS 26 Liquid Glass:
  - The backdrop is frosted.
  - A thick rounded bevel refracts what is behind it, with a slight colour split.
  - The rim has a specular highlight lit from the top left.
- **Small icons:**
  - Every top-bar, rail and tool icon sits under its own thick squircle of glass.
  - The glass is almost clear; only the refraction and the rim show its thickness.
  - Pressing makes it brighter.
- **Large surfaces:** the start page, panels, canvas area and dialogs get a heavy blur, about 20 dp. While a dialog is open, the workspace behind it blurs as well.
- **How it is drawn:**
  - The wallpaper is blurred once at ¼ resolution (`GlassBlur.kt`).
  - Each glass element is drawn by an AGSL shader (`LiquidGlass.kt`). Nothing is blurred per frame.
- **Older Android:** below Android 13 the switch is unavailable, a message explains why, and the 1.0.1 surfaces stay. If the shader ever fails on a device, glass switches itself off for that device.

### 5. Custom UI (Settings → Custom UI, also reachable from the "UI layout" dialog)
- The workspace has 9 blocks:
  - The three top-bar groups.
  - Assets/layers.
  - 3D preview.
  - Canvas.
  - Colour.
  - Tools.
  - Undo/zoom.
- In edit mode, each block can be dragged anywhere, resized from all four corners, stacked (bring to front / send to back) and hidden or shown.
- Blocks snap to an 8 dp grid and to the edges and centres of other blocks and the screen. Guide lines show while snapping, and blocks settle with a spring.
- Portrait and landscape each keep their own set of presets. Presets can be:
  - created;
  - named and renamed;
  - switched;
  - deleted;
  - reset to default;
  - exported and imported as `.mctslayout.json`, which can be shared with other devices.
- Positions are stored as fractions of the safe area, so a preset adapts to other screen sizes.
- The per-model compatibility table was dropped. The default layout now adapts to the screen:
  - **Phone portrait:** canvas plus bottom toolbar.
  - **Phone landscape:** tool rail plus large canvas, with a sidebar when the screen is at least 840 dp wide.
  - **Tablet:** sidebar / canvas / tool panel. Below 960 dp it switches to the narrow tool rail so the canvas keeps its room.
  - Notches, punch-holes and navigation bars are avoided using the safe area.

## Verification (this environment cannot build an APK)
- `bash test-core.sh`: CoreTest 83 + Core101Test 28 + **Core102Test 20** checks, all passing.
  - Core102Test covers texture-pack build, export, import and HD atlas stitching, the PNG decoder round trip, and both Bedrock archive layouts.
- The PNG decoder was compared pixel by pixel with ImageIO on 397 real PNGs, with no differences.
- The full `app` and `core` code type-checks against the offline API stubs (`stubs101/check.sh`) with 0 errors.
- New unit test `Free102Test`:
  - Version list matches sources.json.
  - Format and texture-pack flags are correct.
  - Version groups are in order.
  - Index fallback picks the right version.
  - Layout presets save, load, export and import, and every block stays on screen.
  - Motion and glass parameters are correct.
- The layout-preset and version logic was also run once on a JVM with real org.json.
