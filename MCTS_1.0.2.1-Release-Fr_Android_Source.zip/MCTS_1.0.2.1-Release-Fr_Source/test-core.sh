#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/core-test build/test-output
mapfile -t sources < <(find core/src -name '*.java' -print | sort)
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d build/core-test "${sources[@]}"
java -cp build/core-test com.mcts.core.CoreTest build/test-output
java -cp build/core-test com.mcts.core.Core101Test
java -cp build/core-test com.mcts.core.Core102Test build/test-output
java -cp build/core-test com.mcts.core.Core1021Test build/test-output
