# 验证记录 · 2026-09-12

## 已执行

`bash test-core.sh`：PASS，83 项断言，JDK 17。

- 16、32、64、128、256、512 分辨率角落像素可独立修改。
- 编辑不会改写之前的预览快照；返回数组不能反向污染文档。
- 一次笔划包含多个像素，整笔撤销与重做正确。
- 图层透明度/显示开关及撤销，项目序列化往返。
- 本地版本保留与恢复，路径穿越拒绝。
- LabPBR 发光 254 上限、通用金属、孔隙和次表面编码。
- 双端 ZIP 条目、兼容性报告、Bedrock normal/heightmap 互斥约束。
- PNG 数据块 CRC 与 alpha=0 下的 RGB 数据保真。
- 32 MiB 撤销记录预算，分支编辑清空 redo。

补充静态/文件检查通过：74 个界面文字键均有中/英/日三份文本，无缺失或重复键；
Android XML 语法有效；实际导出的 6 张测试 PNG 均可解码为 512×512；ZIP CRC 与
包内 JSON 可解析。此检查不代替 Compose 编译或屏幕布局验证。

## Android 构建与产物

已解决代理配置和构建环境缺失，使用 Gradle 8.11.1 / JDK 17 / SDK 35 / build-tools 35.0.0。
修复 Kotlin 控件回调与属性 setter 的 JVM 签名冲突后，Android/Compose 编译及 APK 打包完成。
`apksigner verify --verbose --print-certs` 通过，APK Signature Scheme v2、RSA 2048 调试签名。
`zipalign -c 4` 通过。包名 `com.axion.pompreview.next`，版本 `3.0.0-alpha01` / 30001，
最低 API 26、目标 API 35，支持 arm64-v8a、armeabi-v7a、x86、x86_64。

`:app:assembleDebug :app:lintDebug`：BUILD SUCCESSFUL。
Lint：0 错误、7 警告（备份配置、未设置应用图标、4 处 KTX 风格建议、预览视图点击无障碍）。
APK ZIP CRC 检查通过，文件大小 10,378,397 字节。
SHA-256：`b54728911b82600f660d16a8ea5cc160d24b1402f3e8440d02634cd458fc9435`。

**GPU/AGSL 运行和真机交互尚未验证。** 编译及核心 JVM 测试通过不等于实机验证通过。

## 待执行

- APK 安装、启动和项目恢复。
- 手机上的截图/交互测试、横竖屏/折叠状态切换、挖孔与导航避让。
- 中文/English/日本語溢出与字体放大检查，TalkBack 顺序。
- 512 高频绘制/拖动的帧时间、内存峰值、后台时动画暂停。
- 确认 Haze 采样坐标与 AGSL 实际可见变化、文字层清晰。
- 对两款实际游戏及支持 LabPBR 的着色器执行输出包导入验证。

验证清单严格区分：已测试的核心逻辑、已写源码的 UI、尚未实现的平台功能。
