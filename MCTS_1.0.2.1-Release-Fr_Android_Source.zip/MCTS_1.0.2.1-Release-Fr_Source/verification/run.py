"""Run Projects' real compiled Kotlin bytecode with JVM file/image adapters (not a device test)."""
import os,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[1]
cache=pathlib.Path(os.environ.get('GRADLE_USER_HOME',str(pathlib.Path.home()/'.gradle')))/'caches/modules-2'
stdlib=sorted(cache.rglob('kotlin-stdlib-*.jar'))
assert stdlib,'Build Android classes first'
output=root/'build/project-verification';output.mkdir(parents=True,exist_ok=True)
cp=os.pathsep.join([str(output),str(root/('app/build/tmp/kotlin-classes/'+(sys.argv[2]if len(sys.argv)>2 else 'freeRelease'))),str(root/'core/build/classes/java/main'),str(root/'verification/lib/json-20240303.jar'),*[str(p)for p in stdlib]])
sources=[str(p)for p in (root/'verification').rglob('*.java')]
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-encoding','UTF-8','-cp',cp,'-d',str(output),*sources],check=True)
if os.environ.get('MCTS_TEMPLATE_FIXTURES'):
 subprocess.run(['java','-cp',cp,'ProjectIntegration',str(root/'app/src/main/assets')],check=True)
else:
 print('SKIP: project integration needs MCTS_TEMPLATE_FIXTURES from 3.0.7 source')
subprocess.run(['java','-cp',cp,'DownloadLifecycleTest'],check=True)
