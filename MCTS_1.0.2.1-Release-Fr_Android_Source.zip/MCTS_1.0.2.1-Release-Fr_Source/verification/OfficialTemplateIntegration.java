import android.content.Context;
import com.mcts.studio.*;
import com.mcts.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.json.*;
/** Uses pinned source archives already fetched during verification. Does not package them. */
public class OfficialTemplateIntegration {
 public static void main(String[]args)throws Exception{
  Path root=Files.createTempDirectory("official-template-integration-");Context ctx=new Context(root.toFile(),new File(args[0]));TemplateStore store=new TemplateStore(ctx);
  Path cache=ctx.getFilesDir().toPath().resolve("templates-v1");Files.createDirectories(cache);int checks=0;
  for(GameProfile profile:ProjectsKt.getGameProfiles()){
   Path source=Path.of(args[1],profile.getId()+".zip");Files.createLink(cache.resolve(profile.getId()+".source.download"),source);
   store.download(profile,(a,b,c,d)->kotlin.Unit.INSTANCE);
   if(!store.available(profile))throw new AssertionError("Not ready: "+profile.getId());checks++;
   try(ZipFile fresh=new ZipFile(store.verifiedArchive(profile));ZipFile reference=new ZipFile(Path.of(args[2],profile.getId()+".zip").toFile())){
    int png=0;
    for(ZipEntry e:Collections.list(fresh.entries())){
     if(TemplateArchive.isPbr(e.getName()))throw new AssertionError("PBR bundled");checks++;
     ZipEntry old=reference.getEntry(e.getName());if(old==null)throw new AssertionError("Unexpected texture: "+e.getName());checks++;
     if(e.getName().endsWith(".png")){
      png++;java.awt.image.BufferedImage a=javax.imageio.ImageIO.read(fresh.getInputStream(e)),b=javax.imageio.ImageIO.read(reference.getInputStream(old));
      if(a==null||b==null||a.getWidth()!=b.getWidth()||a.getHeight()!=b.getHeight()||!Arrays.equals(a.getRGB(0,0,a.getWidth(),a.getHeight(),null,0,a.getWidth()),b.getRGB(0,0,b.getWidth(),b.getHeight(),null,0,b.getWidth())))throw new AssertionError("Pixels changed: "+profile.getId()+"/"+e.getName());checks++;
     }
    }
    Set<String> wanted=new HashSet<>();for(ZipEntry e:Collections.list(reference.entries()))if(!e.isDirectory()&&!TemplateArchive.isPbr(e.getName()))wanted.add(e.getName());
    if(!wanted.equals(new HashSet<>(fresh.stream().map(ZipEntry::getName).toList())))throw new AssertionError("Missing template texture "+profile.getId());checks++;
    System.out.println(profile.getId()+": "+png+" color images, exact pixel match, cache "+store.archive(profile).length()+" bytes");
   }
  }
  System.out.println("PASS: "+checks+" official source extraction/pixel/cache checks");
 }
}
