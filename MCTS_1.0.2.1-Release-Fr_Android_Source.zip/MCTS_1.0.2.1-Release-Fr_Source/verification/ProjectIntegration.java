import android.content.Context;
import com.mcts.studio.*;
import com.mcts.core.*;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import org.json.*;

/** Exercises the compiled Projects Kotlin class using JVM file/image adapters; not a UI or device test. */
public class ProjectIntegration {
 static int checks;static void check(boolean b,String why){if(!b)throw new AssertionError(why);checks++;}
 static String text(ZipFile z,String n)throws Exception{return new String(z.getInputStream(z.getEntry(n)).readAllBytes(),"UTF-8");}
 public static void main(String[] args)throws Exception {
  Path root=Files.createTempDirectory("mcts-integration-");Context ctx=new Context(root.toFile(),new File(args[0]));Projects engine=new Projects(ctx);
  Path fixtures=Path.of(System.getenv("MCTS_TEMPLATE_FIXTURES"));
  Path cache=ctx.getFilesDir().toPath().resolve("templates-v1");Files.createDirectories(cache);
  for(GameProfile profile:ProjectsKt.getGameProfiles()){
   Path next=cache.resolve(profile.getId()+".zip");
   try(ZipFile in=new ZipFile(fixtures.resolve(profile.getId()+".zip").toFile());ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(next))){
    for(ZipEntry e:Collections.list(in.entries()))if(!e.isDirectory()&&!TemplateArchive.isPbr(e.getName())){out.putNextEntry(new ZipEntry(e.getName()));in.getInputStream(e).transferTo(out);out.closeEntry();}
   }
   String sha=java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(next)));
   Files.writeString(cache.resolve(profile.getId()+".ready.json"),new JSONObject().put("schema",1).put("size",Files.size(next)).put("sha256",sha).toString());
  }
  PackProject legacy=engine.legacy();MaterialDocument original=new MaterialDocument("stone",MaterialDocument.Kind.BLOCK,16,16);original.fill(0,MaterialDocument.Channel.COLOR,0xff123456);String key=engine.store(legacy).save(original);
  for(GameProfile profile:ProjectsKt.getGameProfiles()) {
   PackProject p=engine.create("Test \"独立\" "+profile.getVersion(),profile,true);check(!p.getId().equals(legacy.getId()),"Project IDs collide");
   BlockCatalogue catalogue=engine.catalogue(p);
   BlockAsset grass=catalogue.getBlocks().stream().filter(b->b.getId().equals("grass_block")).findFirst().orElseThrow();
   check(grass.label(Language.ZH).contains("草方块"),"Localized block name");
   check(grass.getFaces().size()==6&&grass.getFaces().get(2).contains("dirt"),"Grass bottom binding");
   List<TemplateTexture> list=engine.textures(p);check(list.size()>100,"Missing bundled textures "+profile.getId());
   TemplateTexture first=list.stream().filter(t->t.getEditable()&&t.getPath().endsWith("/stone.png")).findFirst().orElseThrow();
   TemplateTexture other=list.stream().filter(t->t.getEditable()&&!t.getPath().equals(first.getPath())).findFirst().orElseThrow();
   MaterialDocument doc=engine.openTexture(p,first,first.getWidth());check(doc.width==first.getWidth()&&doc.height==first.getHeight(),"Template resized");
   ProjectStore store=engine.store(p);String docKey=ProjectStore.key(doc.kind,doc.name);doc.fill(0,MaterialDocument.Channel.COLOR,0xffef1294);store.save(doc);
   check(store.versions(docKey).size()==1,"Template history missing");
   File output=root.resolve(profile.getId()+".zip").toFile();engine.export(p,output);
   try(ZipFile z=new ZipFile(output);ZipFile base=new ZipFile(new File(engine.folder(p.getId()),"base.zip"))){
    check(z.getEntry(first.getPath())!=null,"Original path lost");
    java.awt.image.BufferedImage img=javax.imageio.ImageIO.read(z.getInputStream(z.getEntry(first.getPath())));check(img.getRGB(0,0)==0xffef1294,"Edited pixel not exported");
    check(Arrays.equals(z.getInputStream(z.getEntry(other.getPath())).readAllBytes(),base.getInputStream(base.getEntry(other.getPath())).readAllBytes()),"Unedited template changed");
    if(profile.getJava()) {JSONObject info=new JSONObject(text(z,"pack.mcmeta")).getJSONObject("pack");check(info.getString("description").equals(p.getName()),"Project name escaping");check(profile.getFormat()>=65?info.getJSONArray("min_format").getInt(0)==profile.getFormat():info.getInt("pack_format")==profile.getFormat(),"Pack version format");}
    else {JSONObject info=new JSONObject(text(z,"manifest.json"));check(info.getJSONObject("header").getString("uuid").equals(p.getHeader()),"UUID changed");check(info.has("capabilities")==profile.getVv(),"Unsupported VV capability");}
    String stem=first.getPath().substring(0,first.getPath().length()-4);check((z.getEntry(stem+(profile.getJava()?"_s.png":"_mers.png"))!=null)==(profile.getJava()||profile.getVv()),"PBR target gating");
   }
   MaterialDocument high=engine.openTexture(p,first,512);high.fill(0,MaterialDocument.Channel.COLOR,0xff9a45ab);store.save(high);
   MaterialDocument bound=engine.openBoundTexture(p,first);
   check(bound.width==512&&bound.composite(MaterialDocument.Channel.COLOR)[0]==0xff9a45ab,"Preview loading resized an edited face");
   check(engine.store(legacy).open(key).composite(MaterialDocument.Channel.COLOR)[0]==0xff123456,"Projects contaminated legacy");
   check(engine.read(p.getId()).getHeader().equals(p.getHeader()),"Metadata persistence");
   File basic=root.resolve(profile.getId()+"-free.zip").toFile();engine.export(p,basic,true);
   try(ZipFile z=new ZipFile(basic)){
    check(z.stream().noneMatch(e->TemplateArchive.isPbr(e.getName())),"Free PBR leakage");
    if(!profile.getJava())check(!new JSONObject(text(z,"manifest.json")).has("capabilities"),"Free advertises PBR");
    java.awt.image.BufferedImage img=javax.imageio.ImageIO.read(z.getInputStream(z.getEntry(first.getPath())));check(img.getWidth()==512&&img.getHeight()==512&&img.getRGB(0,0)==0xff9a45ab,"Free lost high-resolution color edit");
   }
  }
  check(engine.list().size()==11,"Project catalogue count");
  try{engine.folder("../escape");throw new AssertionError("Traversal allowed");}catch(IllegalArgumentException expected){checks++;}
  System.out.println("PASS: "+checks+" project/template export checks against compiled Kotlin (JVM adapters)");
 }
}
