import com.mcts.core.CanvasGeometry;
public final class CanvasGeometryTest {
 static int checks;static void check(boolean b){if(!b)throw new AssertionError("geometry #"+checks);checks++;}
 static void near(float a,float b){check(Math.abs(a-b)<.002f);}
 public static void main(String[]args){
  for(int size:new int[]{16,32,64,128,256,512})for(float zoom:new float[]{.5f,1f,4f,32f,256f}) {
   CanvasGeometry g=new CanvasGeometry(700,430,size,size,zoom,17,-31);
   near(g.left+g.unit*size/2,367);near(g.top+g.unit*size/2,184);
   for(int i:new int[]{0,size/2,size-1}){check(g.x(g.screenX(i)+g.unit*.5f)==i);check(g.y(g.screenY(i)+g.unit*.5f)==i);}
   check(g.x(g.left-1)==-1);check(g.y(g.top-1)==-1);check(g.x(g.screenX(size)+1)==-1);check(g.y(g.screenY(size)+1)==-1);
   check(g.firstX()>=0&&g.lastX(700)<size);check(g.firstY()>=0&&g.lastY(430)<size);
  }
  CanvasGeometry rectangle=new CanvasGeometry(800,600,128,64,1,0,0);near(rectangle.unit,6.25f);near(rectangle.left,0);near(rectangle.top,100);
  check(rectangle.y(99)==-1);check(rectangle.y(499)==63);check(rectangle.y(500)==-1);
  try{new CanvasGeometry(0,1,16,16,1,0,0);throw new AssertionError("bad viewport accepted");}catch(IllegalArgumentException ok){checks++;}
  System.out.println("PASS: "+checks+" canvas fit, pan, zoom, boundary and all-resolution checks");
 }
}
