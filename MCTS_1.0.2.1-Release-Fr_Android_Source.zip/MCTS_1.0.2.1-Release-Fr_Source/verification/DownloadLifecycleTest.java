import android.content.Context;
import com.mcts.studio.*;
import com.mcts.core.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;
import org.json.*;
import kotlin.Unit;

/** Real Kotlin downloader with recording HTTP connections, not an Android UI test. */
public class DownloadLifecycleTest {
 static int checks,calls;static boolean ranged;
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);checks++;}
 static byte[] source()throws Exception {
  ByteArrayOutputStream out=new ByteArrayOutputStream();try(ZipOutputStream z=new ZipOutputStream(out)){
   for(int i=0;i<110;i++){z.putNextEntry(new ZipEntry("root/resource_pack/textures/blocks/"+(i==0?"stone":"texture_"+i)+".png"));int[] p=new int[256];Arrays.fill(p,0xff00ff00|i);z.write(Png.rgba(16,16,p));z.closeEntry();}
  }return out.toByteArray();
 }
 static String hash(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
 static class HTTP extends HttpURLConnection {
  final byte[] bytes;HTTP(URL u,byte[] b){super(u);bytes=b;calls++;}
  int offset(){String r=getRequestProperty("Range");if(r==null)return 0;ranged=true;return Integer.parseInt(r.substring(6,r.length()-1));}
  public int getResponseCode(){return offset()>0?206:200;}
  public String getHeaderField(String name){return name.equals("Content-Range")?"bytes "+offset()+"-"+(bytes.length-1)+"/"+bytes.length:null;}
  public long getContentLengthLong(){return bytes.length-offset();}
  public InputStream getInputStream(){return new ByteArrayInputStream(bytes,offset(),bytes.length-offset()){@Override public synchronized int read(byte[] b,int off,int len){return super.read(b,off,Math.min(len,257));}};}
  public void connect(){}public boolean usingProxy(){return false;}public void disconnect(){}
 }
 public static void main(String[]args)throws Exception{
  byte[] source=source();Path root=Files.createTempDirectory("download-lifecycle-");Path assets=root.resolve("assets/templates");Files.createDirectories(assets);
  GameProfile p=ProjectsKt.getGameProfiles().stream().filter(x->x.getId().equals("bedrock_1200")).findFirst().orElseThrow();
  JSONObject row=new JSONObject().put("profile",p.getId()).put("url","https://unit.invalid/sample.zip").put("source_sha256",hash(source)).put("size_bytes",source.length);
  Files.writeString(assets.resolve("sources.json"),new JSONArray().put(row).toString());Context ctx=new Context(root.toFile(),root.resolve("assets").toFile());
  TemplateStore store=new TemplateStore(ctx,url->new HTTP(url,source));check(!store.available(p),"Missing source marked ready");
  boolean[] cancelled={false};
  try{store.download(p,(stage,fraction,bytes,total)->{if(!cancelled[0]&&bytes>0){cancelled[0]=true;store.cancel();}return Unit.INSTANCE;});throw new AssertionError("Cancel ignored");}catch(java.util.concurrent.CancellationException expected){checks++;}
  check(!store.available(p),"Cancelled download marked ready");
  store.download(p,(a,b,c,d)->Unit.INSTANCE);check(ranged,"Resume did not use HTTP Range");check(store.available(p),"Successful download not ready");
  int prior=calls;store.download(p,(a,b,c,d)->Unit.INSTANCE);check(calls==prior,"Ready cache re-downloaded");
  check(store.verifiedArchive(p).exists(),"Verified cache missing");
  Path dir=ctx.getFilesDir().toPath().resolve("templates-v1");
  try(var files=Files.list(dir)){check(files.noneMatch(f->f.toString().endsWith(".download")||f.toString().endsWith(".part")||f.toString().endsWith(".building")),"Download debris after success");}
  File cached=store.archive(p);byte[] data=Files.readAllBytes(cached.toPath());data[30]^=1;Files.write(cached.toPath(),data);
  try{store.verifiedArchive(p);throw new AssertionError("Corrupt cache accepted");}catch(Exception expected){check(expected instanceof IOException,"Wrong exception type");}
  check(!store.available(p),"Corrupt cache still ready");store.download(p,(a,b,c,d)->Unit.INSTANCE);check(store.available(p),"Cache repair failed");
  // Hash mismatch must not expose a partial/new archive as ready.
  Path badRoot=Files.createTempDirectory("download-wrong-hash-");Context badCtx=new Context(badRoot.toFile(),root.resolve("assets").toFile());
  byte[] wrong=source.clone();wrong[50]^=1;TemplateStore bad=new TemplateStore(badCtx,url->new HTTP(url,wrong));
  try{bad.download(p,(a,b,c,d)->Unit.INSTANCE);throw new AssertionError("Wrong hash accepted");}catch(Exception e){check(e.getMessage().equals("TEMPLATE_HASH"),"Wrong hash error");}
  check(!bad.available(p),"Wrong hash marked ready");
  // Reject insufficient storage before opening a connection.
  Path lowRoot=Files.createTempDirectory("download-low-space-");
  TemplateStore low=new TemplateStore(new Context(lowRoot.toFile(),root.resolve("assets").toFile()),url->new HTTP(url,source),()->0L);
  int beforeLow=calls;
  try{low.download(p,(a,b,c,d)->Unit.INSTANCE);throw new AssertionError("Low storage accepted");}catch(Exception e){check("TEMPLATE_SPACE".equals(e.getMessage()),"Wrong space error");}
  check(calls==beforeLow,"Download opened despite insufficient storage");
  // A broken stream must retry automatically with Range, without a user action.
  Path retryRoot=Files.createTempDirectory("download-auto-retry-");final int[] retries={0};ranged=false;
  TemplateStore retry=new TemplateStore(new Context(retryRoot.toFile(),root.resolve("assets").toFile()),url->{
   if(retries[0]++>0)return new HTTP(url,source);
   return new HTTP(url,source){public InputStream getInputStream(){return new InputStream(){int cursor;
    public int read()throws IOException{throw new IOException("broken stream");}
    public int read(byte[] b,int off,int len)throws IOException{if(cursor>0)throw new IOException("broken stream");int n=Math.min(257,source.length);System.arraycopy(source,0,b,off,n);cursor=n;return n;}
   };}};
  });
  retry.download(p,(a,b,c,d)->Unit.INSTANCE);check(retry.available(p)&&ranged&&retries[0]==2,"Automatic retry did not resume");
  check(retry.cacheBytes(p)>0,"Cache size not reported");retry.deleteCache(p);check(!retry.available(p)&&retry.cacheBytes(p)==0,"Cache cleanup left files");
  // All URLs share the same pinned SHA-256. A failed primary falls back.
  row.put("urls",new JSONArray().put("https://unit.invalid/primary.zip").put("https://unit.invalid/fallback.zip"));
  Files.writeString(assets.resolve("sources.json"),new JSONArray().put(row).toString());
  Path fallbackRoot=Files.createTempDirectory("download-fallback-");final boolean[] fallbackUsed={false};
  TemplateStore fallback=new TemplateStore(new Context(fallbackRoot.toFile(),root.resolve("assets").toFile()),url->{
    if(url.toString().contains("primary"))return new HTTP(url,source){public int getResponseCode(){return 404;}};
    fallbackUsed[0]=true;return new HTTP(url,source);
  });
  fallback.download(p,(a,b,c,d)->Unit.INSTANCE);check(fallback.available(p)&&fallbackUsed[0],"Backup URL not used");
  System.out.println("PASS: "+checks+" download lifecycle checks: cancellation, resume, atomic readiness, offline reuse, corruption repair, source hash");
 }
}
