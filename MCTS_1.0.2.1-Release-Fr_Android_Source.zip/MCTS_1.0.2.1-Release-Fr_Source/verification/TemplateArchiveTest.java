import com.mcts.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
public class TemplateArchiveTest {
 static int checks;static void check(boolean b,String message){if(!b)throw new AssertionError(message);checks++;}
 static final TemplateArchive.Control control=new TemplateArchive.Control(){public void check(){}public void progress(float f){}};
 static byte[] tga(int type,int flags,int bits)throws Exception{
  ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] h=new byte[18];h[2]=(byte)type;h[12]=2;h[14]=1;h[16]=(byte)bits;h[17]=(byte)flags;b.write(h);
  if(type==10)b.write(1);
  b.write(new byte[]{0,0,(byte)255});if(bits==32)b.write(63);
  b.write(new byte[]{0,(byte)255,0});if(bits==32)b.write(127);
  return b.toByteArray();
 }
 public static void main(String[]args)throws Exception{
  Path root=Files.createTempDirectory("template-archive-test-");File source=root.resolve("source.zip").toFile(),dest=root.resolve("cache.zip").toFile();
  byte[] pixel=Png.rgba(16,16,new int[256]);
  try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(source))){
   for(int i=0;i<100;i++){z.putNextEntry(new ZipEntry("sample/resource_pack/textures/blocks/"+(i==0?"stone":"p"+i)+".png"));z.write(pixel);z.closeEntry();}
   for(String n:List.of("stone_mers.png","stone_normal.png","stone_height.png","stone.texture_set.json")){z.putNextEntry(new ZipEntry("sample/resource_pack/textures/blocks/"+n));z.write(pixel);z.closeEntry();}
   z.putNextEntry(new ZipEntry("sample/resource_pack/textures/blocks/test.tga"));z.write(tga(10,40,32));z.closeEntry();
  }
  check(TemplateArchive.build(source,"bedrock_12120",dest,control)==101,"Wrong PNG count");TemplateArchive.validate(dest);
  try(ZipFile z=new ZipFile(dest)){check(z.stream().noneMatch(e->TemplateArchive.isPbr(e.getName())),"PBR leakage");check(z.getEntry("textures/blocks/test.png")!=null,"TGA not converted");}
  byte[] original=Files.readAllBytes(dest.toPath());
  try{TemplateArchive.build(source,"bedrock_12120",dest,new TemplateArchive.Control(){public void check()throws IOException{throw new IOException("cancel");}public void progress(float f){}});throw new AssertionError("Cancellation ignored");}catch(IOException e){checks++;}
  check(Arrays.equals(original,Files.readAllBytes(dest.toPath())),"Cancellation changed ready cache");check(!new File(dest+".building").exists(),"Staging not cleaned");
  for(int type:new int[]{2,10})for(int flags:new int[]{0,16,32,48})for(int bits:new int[]{24,32}){
   TgaDecoder.Image image=TgaDecoder.decode(new ByteArrayInputStream(tga(type,flags|(bits==32?8:0),bits)));
   int x=(flags&16)==0?0:1;
   check((image.argb[x]&0xffffff)==0xff0000,"TGA row/column orientation");
   check((image.argb[x]>>>24)==(bits==32?63:255),"TGA alpha changed");
  }
  byte[] bad=tga(10,32,24);bad[18]=(byte)0xff;
  try{TgaDecoder.decode(new ByteArrayInputStream(bad));throw new AssertionError("Bad RLE allowed");}catch(IOException e){checks++;}
  try{TemplateArchive.texturePath("root/resource_pack/textures/../escape.png","bedrock_1200");throw new AssertionError("Traversal allowed");}catch(IOException e){checks++;}
  check(TemplateArchive.texturePath("assets/minecraft/textures/block/stone.png","java_1165").startsWith("assets/"),"Java path");
  check(TemplateArchive.texturePath("root/stable/resource/textures/blocks/stone.png","bedrock_116200").equals("textures/blocks/stone.png"),"Legacy Bedrock path");
  check(!TemplateArchive.isPbr("textures/blocks/rail_normal.png"),"Vanilla rail color removed");
  check(!TemplateArchive.isPbr("assets/minecraft/textures/particle/sga_n.png"),"Vanilla particle letter removed");
  EditionPolicy free=new EditionPolicy(true),full=new EditionPolicy(false);
  for(EditionPolicy.Feature f:EditionPolicy.Feature.values()){check(!free.allows(f),"Free capability exposed");check(full.allows(f),"Full capability blocked");}
  for(MaterialDocument.Channel c:MaterialDocument.Channel.values())check(free.allowsChannel(c)==(c==MaterialDocument.Channel.COLOR),"Free PBR channel exposed");
  System.out.println("PASS: "+checks+" template transaction, TGA conversion, path and edition policy checks");
 }
}
