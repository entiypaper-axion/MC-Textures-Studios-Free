package android.content;
import java.io.File;
import android.content.res.AssetManager;
/** JVM file-operation test double. Not packaged in the Android app. */
public class Context {
 private final File root,assets;
 public Context(File root,File assets){this.root=root;this.assets=assets;root.mkdirs();}
 public File getFilesDir(){File f=new File(root,"files");f.mkdirs();return f;}
 public File getCacheDir(){File f=new File(root,"cache");f.mkdirs();return f;}
 public AssetManager getAssets(){return new AssetManager(assets);}
}
