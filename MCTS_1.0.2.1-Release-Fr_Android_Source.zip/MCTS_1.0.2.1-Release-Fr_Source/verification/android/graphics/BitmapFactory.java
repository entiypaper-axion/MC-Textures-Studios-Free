package android.graphics;
public class BitmapFactory {public static Bitmap decodeStream(java.io.InputStream in){try{java.awt.image.BufferedImage b=javax.imageio.ImageIO.read(in);return b==null?null:new Bitmap(b);}catch(java.io.IOException e){return null;}}}
