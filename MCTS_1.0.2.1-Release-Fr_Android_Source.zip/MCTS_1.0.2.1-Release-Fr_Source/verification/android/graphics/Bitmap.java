package android.graphics;
public class Bitmap {private final java.awt.image.BufferedImage image;public Bitmap(java.awt.image.BufferedImage image){this.image=image;}public void getPixels(int[] pixels,int offset,int stride,int x,int y,int width,int height){image.getRGB(x,y,width,height,pixels,offset,stride);}public void recycle(){}}
