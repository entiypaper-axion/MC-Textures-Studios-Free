import pathlib,sys,tempfile,shutil,json
root=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tools'))
from verify_package import verify
source=root/'app/src/main/assets/templates';checks=0
with tempfile.TemporaryDirectory()as td:
 d=pathlib.Path(td);shutil.copy(source/'sources.json',d/'sources.json')
 for suffix in ('.zip.tmp','.zip.part','.zip'):
  bad=d/('java_1165'+suffix);bad.write_bytes(b'partial')
  try:verify(d);raise AssertionError('Bundled/staging file accepted')
  except ValueError:checks+=1
  finally:bad.unlink()
 rows=json.loads((d/'sources.json').read_text());rows[0]['source_sha256']='bad';(d/'sources.json').write_text(json.dumps(rows))
 try:verify(d);raise AssertionError('Invalid hash accepted')
 except ValueError:checks+=1
print('PASS:',checks,'negative package metadata regressions')
