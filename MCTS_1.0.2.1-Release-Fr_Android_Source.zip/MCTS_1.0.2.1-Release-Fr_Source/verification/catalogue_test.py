"""Validate actual semantic bindings against each bundled template, not filename guesses."""
import pathlib,json,zipfile,os
root=pathlib.Path(__file__).resolve().parents[1];checks=0
for file in (root/'app/src/main/assets/catalogue').glob('*.json'):
 data=json.loads(file.read_text());groups={g['id']:g for g in data['groups']}
 assert len(groups)==len(data['groups']), 'Duplicate block id'
 with zipfile.ZipFile(pathlib.Path(os.environ['MCTS_TEMPLATE_FIXTURES'])/f'{file.stem}.zip')as z:
  available=set(z.namelist())
  for g in groups.values():
   assert set(g['faces'])=={'up','south','down','north','west','east'}
   assert all(p in available for p in g['paths'])
   assert all(p in g['paths'] for p in g['faces'].values())
   assert len(g['names'])==5;checks+=1
  grass=groups['grass_block'];assert 'dirt' in grass['faces']['down']
  assert len(set(grass['faces'].values()))>=3;checks+=1
  furnace=groups['furnace'];assert any('front' in p for p in furnace['faces'].values()) and len(set(furnace['faces'].values()))>=3;checks+=1
  log=groups['oak_log'];assert log['faces']['up']==log['faces']['down'] and log['faces']['up']!=log['faces']['east'];checks+=1
  assert grass['names'][1]=='草方块',grass['names'];checks+=1
  assert all(len(names)==5 and all(names) for names in data['labels'].values());checks+=1
 print(file.stem,len(groups),'blocks:',grass['names'][1])
print('PASS:',checks,'catalogue reference, localized label and grass/furnace/log assembly checks')
