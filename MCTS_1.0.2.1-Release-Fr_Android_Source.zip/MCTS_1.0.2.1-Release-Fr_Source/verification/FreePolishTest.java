import com.mcts.core.*;
import java.nio.file.*;
import java.io.*;
import java.util.*;

/** Document/gesture regression tests, independent of Android touch dispatch. */
public final class FreePolishTest {
    static int checks;
    static void check(boolean value,String why){if(!value)throw new AssertionError(why);checks++;}
    public static void main(String[] args)throws Exception {
        for(int size:new int[]{16,32,64,128,256,512}) {
            MaterialDocument doc=new MaterialDocument("polish",MaterialDocument.Kind.BLOCK,size,size);
            doc.fill(0,MaterialDocument.Channel.COLOR,0xff112233);doc.clearHistory();
            int[] initial=doc.composite(MaterialDocument.Channel.COLOR);
            for(int row=0;row<20;row++) {
                doc.beginStroke(0,MaterialDocument.Channel.COLOR);
                SurfaceStroke path=new SurfaceStroke();
                for(int[] pixel:path.segment(0,row%size,0))doc.paint(pixel[0],pixel[1],0xff990000+row);
                for(int[] pixel:path.segment(size-1,row%size,0))doc.paint(pixel[0],pixel[1],0xff990000+row);
                doc.endStroke();
                int[] result=doc.composite(MaterialDocument.Channel.COLOR);
                for(int x=0;x<size;x++)check(result[row%size*size+x]==0xff990000+row,"Gap in fast stroke");
            }
            int[] finalPixels=doc.composite(MaterialDocument.Channel.COLOR);
            for(int i=0;i<20;i++)doc.undo();
            check(Arrays.equals(initial,doc.composite(MaterialDocument.Channel.COLOR)),"20 strokes != 20 undo actions");
            check(!doc.canUndo(),"Unexpected history item");
            for(int i=0;i<20;i++)doc.redo();
            check(Arrays.equals(finalPixels,doc.composite(MaterialDocument.Channel.COLOR)),"Redo mismatch");
            // Converting a paint drag into a pinch must preserve both pixels and history.
            long bytes=doc.getHistoryBytes();
            doc.beginStroke(0,MaterialDocument.Channel.COLOR);doc.paint(0,0,0xffabcdef);doc.paint(size-1,size-1,0xffabcdef);doc.cancelStroke();
            check(Arrays.equals(finalPixels,doc.composite(MaterialDocument.Channel.COLOR)),"Pinch left stray paint");
            check(doc.getHistoryBytes()==bytes,"Pinch created an undo item");
            int[] leaked=doc.composite(MaterialDocument.Channel.COLOR);leaked[0]=0;
            check(doc.composite(MaterialDocument.Channel.COLOR)[0]==finalPixels[0],"Cached plane leaked writable storage");
            Path dir=Files.createTempDirectory("mcts-free-save-");ProjectStore store=new ProjectStore(dir);
            String key=store.save(doc);for(int i=0;i<20;i++)store.save(doc);
            check(store.versions(key).isEmpty(),"Unchanged save created junk history");
            check(Arrays.equals(finalPixels,store.open(key).composite(MaterialDocument.Channel.COLOR)),"Save/reopen mismatch");
            doc.beginStroke(0,MaterialDocument.Channel.COLOR);doc.paint(size-1,size-1,0xff567890);doc.endStroke();store.save(doc);
            check(store.versions(key).size()==1,"Real edit missing version");
            try(java.util.stream.Stream<Path> files=Files.list(dir)){check(files.noneMatch(f->f.toString().endsWith(".tmp")),"Save debris");}
            // Opaque -> intermediate live feedback -> final opacity is one reversible action.
            doc.clearHistory();doc.previewOpacity(0,.8f);doc.previewOpacity(0,.6f);doc.previewOpacity(0,.3f);doc.finishOpacity();
            check(doc.getLayers().get(0).getOpacity()==.3f,"Opacity feedback mismatch");doc.undo();
            check(doc.getLayers().get(0).getOpacity()==1f&&!doc.canUndo(),"Opacity slider created multiple history items");doc.redo();
            check(doc.getLayers().get(0).getOpacity()==.3f,"Opacity redo mismatch");
        }
        SurfaceStroke stroke=new SurfaceStroke();stroke.segment(0,0,0);stroke.segment(10,0,0);stroke.reset();
        check(stroke.segment(5,5,0).length==1,"Re-entering the canvas joined an outside path");
        System.out.println("PASS: "+checks+" Free polish checks: continuous strokes, undo/redo, pinch rollback, cache isolation, atomic save/reopen, opacity history.");
    }
}
