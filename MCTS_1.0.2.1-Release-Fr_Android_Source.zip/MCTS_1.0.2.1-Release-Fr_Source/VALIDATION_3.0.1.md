# MCTS 3.0.1 验证记录

- 发布构建 `:app:assembleRelease :app:lintRelease` 返回成功（退出码 0）。
- Lint：0 errors, 23 warnings；完整结果见 validation/lint-3.0.1.txt。
- 核心 JVM：83 项通过，覆盖图层、历史、16–512 分辨率、持久化和导出。
- 新画布几何：427 项通过，覆盖居中适配、缩放、平移、边界、矩形贴图及各分辨率绘画坐标。
- 发布版 Kotlin 项目/模板导出：122 项通过，使用 JVM 文件/图像适配器，并非 Android 真机测试。
- 模板残留/损坏反例：4 项通过（tmp、part、截断、字节修改）。
- APK 外层及全部内置模板 CRC/SHA256 校验通过；10 套、34,838 张 PNG；无 .tmp/.part。
- 内置字体及许可证：4 个文件 SHA256 与来源记录一致。
- apksigner 验证成功；v2/v3 签名，证书与 alpha02/03 一致：e5fd9c926f8ccce3cd2697ac4819dc3ad7ffbbff30b3b02a6672f0a9006231d7。
- zipalign `-c -P 16 4` 通过。
- AAPT：com.axion.pompreview.studio3；versionCode 30100；versionName 3.0.1；minSdk 26、targetSdk 35；不可调试。
- APK 字节数：110422230。
- APK SHA256：e30a8ca043e492ac9199b0daa07d332552dfe76f955462d42ebaa977047b4d38。

本次没有可用的 Android 设备或模拟器，未进行安装、GPU 画面或触控动效的实机验证。以上自动检查不能替代真机体验测试。Lint 警告完整保留，没有隐藏。

## 安装后建议检查

直接覆盖 alpha03，确认已有项目。普通模式检查左上参数、左下预览、右侧画板和底部栏；拖动中间分隔线。切换素材/编辑/图层、颜色/高度/金属度，观察底框移动和一次回弹。进入全屏绘画，检查左侧通道、中央画板、右侧调色/吸管/撤销，以及返回键退出。打开 16/256/512 分辨率，切换网格，移动/缩放后检查落笔位置；放大高度通道到单格可读，检查数值；修改后确认立体预览刷新，再保存、重新打开并导出。减少动态效果设置应跳过弹性转场。

## 复现

`bash test-core.sh`

`java -m jdk.compiler/com.sun.tools.javac.Main -cp build/core-test -d build/core-test verification/CanvasGeometryTest.java`

`java -cp build/core-test CanvasGeometryTest`

`python3 verification/test_template_gate.py`

`gradle :app:assembleRelease :app:lintRelease`

`python3 verification/run.py /path/to/json-20240303.jar release`

`python3 tools/verify_package.py /path/to/app-release.apk`
