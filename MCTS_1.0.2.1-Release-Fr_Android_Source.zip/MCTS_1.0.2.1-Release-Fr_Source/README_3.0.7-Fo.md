# MCTS Free 3.0.7-Fo

本次是 Free 版的编辑体验和可靠性打磨，版本码 30700。包名 `com.axion.pompreview.studio3.free`，与 Plus 的 `com.axion.pompreview.studio3`、Ultra 的 `com.axion.pompreview.studio3.ultra` 不同，数据各自保存，不会覆盖 Plus 或 Ultra。最低 Android 8.0，设备需支持 OpenGL ES 3.0。

## 本轮改进

- 画笔采用统一触摸处理并插补快速移动经过的像素；一整笔对应一次撤销。第二根手指进入时回滚本次未完成笔划，切换缩放，减少误画。取色器拖动和双指操作不会写入像素。
- 画布贴图、像素网格和触摸坐标共用几何计算，使用最近邻采样。透明棋盘格按屏幕可见尺度绘制，减少高清画布重复绘制。
- 多面方块预览保留已编辑各面的原始分辨率，避免切换面导致其他面重采样。批量填充后重新加载整块预览。GPU 只上传发生变化的面，不为每个画笔更新重建纹理存储；上下文重建后恢复贴图。
- 文档合成缓存和紧凑笔划记录降低重复分配；图层透明度拖动实时反馈，松手后形成一个可撤销操作。
- 文件先写临时文件、同步内容再替换；重复保存相同文档不再增加历史副本，真实修改继续保留历史。模板包和 APK 构建检查禁止 `.tmp`、`.part` 等残留。
- 小屏使用紧凑工具条和上下预览／画板，保留可调大小占比；全屏画板的工具仍可访问。弹窗适配安全区和软键盘。
- 调色盘显示当前选色标识，按钮明确显示禁用状态，交互目标至少 48dp；补充读屏语义、当前版本、五种语言的操作／错误提示。加载、成功和按下反馈均为 Free 静态样式。
- 预览初始化失败显示可重试提示，颜色编辑、保存和导出可继续使用。文件权限和空间不足显示具体操作建议。
- 使用现有 MCTS 标志作为 Free 启动图标。

## Free 范围

保留颜色编辑、调色盘、取色器、图层、撤销／重做、像素格、16–512 分辨率、模板、多项目、只读立体预览和 Java／基岩版颜色资源包导出。没有 PBR/MER 编辑、模型绘画、玻璃模糊或折射、动态壁纸和过渡动画。保留默认关闭的透明模式、静态背景和字体设置。

多面方块按整块浏览，展开后选择面贴图，预览组合各面颜色；复杂实体模型、动画或特殊方块不保证完全复现游戏画面。需要在 Minecraft 中验证导出结果。

## 安装与签名

本次找不到之前 3.0.6-Fo 的私有签名密钥，因此使用新的 Free 专用签名。APK 的签名验证和对齐验证通过，但无法直接覆盖旧签名的 3.0.6-Fo。已经安装旧 Free 的用户应先把项目素材导出并保留到应用之外，再卸载旧 Free、安装本版；卸载会删除应用私有数据。Plus、Ultra 不受此操作影响。

新密钥已单独保留，未来 Free 更新应继续使用同一密钥。私有密钥及密码不在本源码 ZIP 内，勿公开分发。

## 构建

需要 JDK 17、Android SDK platform 35/build-tools 35.0.0，Gradle Wrapper 为 8.11.1，依赖 Google Maven/Maven Central。

```sh
./gradlew :app:assembleFreeRelease :app:lintFreeRelease
ANDROID_HOME=/your/android-sdk bash test-free-polish.sh
```

Linux 上安装 Mesa EGL/GLES 库后，可设置 `MCTS_TEST_MESA=1` 运行主机着色器检查。源码保留 full/free 两个变体，本次只交付 freeRelease，full 并非本次发布的 Plus。

自行构建时可通过 `MCTS_SIGNING_KEY` 和 `MCTS_SIGNING_PASSWORD` 配置签名，别名为 `mcts`。未配置时使用本机 Android 调试密钥，无法覆盖本次官方签名包。输出位置为 `app/build/outputs/apk/free/release/app-free-release.apk`。

验证结果见 [VALIDATION_3.0.7-Fo.md](VALIDATION_3.0.7-Fo.md)。本次没有 Android 真机或模拟器实测，不将主机测试等同于安装、手势、读屏、GPU 兼容性或实际游戏验证。历史说明保留原版本内容，以本文件为本次范围依据。
