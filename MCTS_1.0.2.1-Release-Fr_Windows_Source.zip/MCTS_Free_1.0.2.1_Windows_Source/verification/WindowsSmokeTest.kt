// JVM smoke test of the Windows model/compat layer (run during development against API stubs; see README section 5).
// 1.0.2.1 checks need -Dfontjar=<client.jar or a zip with assets/minecraft/font + textures/font> and -Dmodelszip=<models side archive>.
import com.mcts.studio.*
import com.mcts.studio.compat.*
import com.mcts.core.*
import java.io.File
import java.util.zip.*
import javax.imageio.ImageIO
import java.awt.image.BufferedImage

var fails=0
fun check(name:String,ok:Boolean){println((if(ok)"PASS " else "FAIL ")+name);if(!ok)fails++}

fun main(){
    val tmp=File(System.getProperty("java.io.tmpdir"),"mcts-smoke-"+System.nanoTime()).apply{mkdirs()}
    val ctx=Application(File(tmp,"files"),File(tmp,"cache"))
    // prefs
    val p=ctx.getSharedPreferences("studio3",0)
    p.edit().putString("a","x").putBoolean("b",true).putInt("c",7).putFloat("d",.5f).apply()
    val p2=SharedPreferences::class.java.getDeclaredConstructor(File::class.java).also{it.isAccessible=true}.newInstance(File(File(ctx.filesDir,"prefs"),"studio3.properties"))
    check("prefs persist",p2.getString("a",null)=="x"&&p2.getBoolean("b",false)&&p2.getInt("c",0)==7&&p2.getFloat("d",0f)==.5f&&p2.getString("zz","def")=="def")
    p.edit().remove("a").apply();check("prefs remove",p.getString("a",null)==null)
    // assets
    val cat=ctx.assets.list("catalogue").toList()
    check("asset list catalogue (${cat.size})","java_1165.json" in cat&&cat.size==10)
    check("asset list root has templates",("templates" in ctx.assets.list("")))
    check("asset open sources.json",ctx.assets.open("templates/sources.json").use{it.readBytes().size>1000})
    // bitmaps
    val logo=ctx.assets.bytes("mcts_logo.png")
    val o=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeByteArray(logo,0,logo.size,o)
    check("png bounds ${o.outWidth}x${o.outHeight}",o.outWidth==512&&o.outHeight==512)
    val bmp=BitmapFactory.decodeByteArray(logo,0,logo.size)!!
    val ref=ImageIO.read(logo.inputStream())
    var same=true;for(y in 0 until 512 step 7)for(x in 0 until 512 step 5){val a=bmp.getPixel(x,y);val b=ref.getRGB(x,y);if((a ushr 24)!=(b ushr 24)||((a ushr 24)!=0&&a!=b))same=false}
    check("png pixels match ImageIO",same)
    val jpg=File(tmp,"a.jpg");val bi=BufferedImage(300,200,BufferedImage.TYPE_INT_RGB);bi.setRGB(10,10,0xff0000);ImageIO.write(bi,"jpg",jpg)
    val jo=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(jpg.path,jo)
    check("jpeg bounds",jo.outWidth==300&&jo.outHeight==200)
    val js=BitmapFactory.decodeFile(jpg.path,BitmapFactory.Options().apply{inSampleSize=2})!!
    check("jpeg sample 2",js.width==150&&js.height==100)
    val px=IntArray(150*100);js.getPixels(px,0,150,0,0,150,100);check("getPixels opaque",px.all{(it ushr 24)==255})
    val scaled=Bitmap.createScaledBitmap(bmp,64,64,false);check("scaled",scaled.width==64)
    // colours
    var hsvOk=true;val r=java.util.Random(1);repeat(2000){val c=0xff000000.toInt() or r.nextInt(0x1000000);val h=FloatArray(3);Colors.colorToHSV(c,h);val back=Colors.HSVToColor(h)
        for(sh in listOf(0,8,16))if(kotlin.math.abs((c ushr sh and 255)-(back ushr sh and 255))>1)hsvOk=false}
    check("hsv roundtrip",hsvOk)
    // content resolver
    val out=File(tmp,"out/x.bin");ctx.contentResolver.openOutputStream(Uri.fromFile(out),"wt")!!.use{it.write(byteArrayOf(1,2,3))}
    check("resolver write",out.readBytes().contentEquals(byteArrayOf(1,2,3))&&!File(tmp,"out/.x.bin.part").exists())
    check("resolver read",ctx.contentResolver.openInputStream(Uri.fromFile(out))!!.use{it.readBytes().size}==3)
    // LRU
    val lru=LruCache<String,Int>(2);lru.put("a",1);lru.put("b",2);lru.get("a");lru.put("c",3);check("lru evicts eldest",lru.get("b")==null&&lru.get("a")==1)
    // dialog filters
    check("filters",DialogHost.extensions(arrayOf("image/png","image/*")).contains("jpg")&&DialogHost.extensions(arrayOf("application/zip","application/octet-stream","*/*")).contains("mcpack"))
    // Projects / templates / catalogue with the compat Context
    val projects=Projects(ctx)
    val profile=profileById("java_12111")!!
    check("profiles ${gameProfiles.size}",gameProfiles.size==154)
    val pack=projects.create("Smoke",profile,false)
    check("project list",projects.list().any{it.id==pack.id})
    // fake template base.zip with one block texture
    val img=IntArray(16*16){i->if(i%2==0)0xff336699.toInt() else 0xffccaa22.toInt()}
    ZipOutputStream(File(projects.folder(pack.id),"base.zip").outputStream()).use{z->
        z.putNextEntry(ZipEntry("assets/minecraft/textures/block/stone.png"));z.write(Png.rgba(16,16,img));z.closeEntry()
        z.putNextEntry(ZipEntry("pack.mcmeta"));z.write("{\"pack\":{\"pack_format\":64,\"description\":\"x\"}}".toByteArray());z.closeEntry()}
    val tex=projects.textures(pack);check("textures ${tex.size}",tex.size==1&&tex[0].width==16)
    val thumb=projects.thumbnail(pack,tex[0].path);check("thumbnail",thumb!=null&&thumb.width==16)
    val doc=projects.openTexture(pack,tex[0],32);check("openTexture 32",doc.width==32&&doc.composite(MaterialDocument.Channel.COLOR)[0]==0xff336699.toInt())
    check("previewFaces",projects.previewFaces(pack,doc)?.shape=="minecraft:stone")
    doc.beginStroke(0,MaterialDocument.Channel.COLOR);doc.paint(0,0,0xffff0000.toInt());doc.endStroke();projects.store(pack).save(doc)
    val sum=projects.exportSummary(pack);check("export summary edited=${sum.edited}",sum.edited==1)
    val zip=File(tmp,"export.zip");projects.export(pack,zip,true,ExportMeta("Smoke pack","desc"))
    ZipFile(zip).use{z->val names=z.entries().asSequence().map{it.name}.toList()
        check("export has mcmeta+texture $names",names.contains("pack.mcmeta")&&names.any{it.endsWith("block/stone.png")})}
    val cat2=projects.catalogue(pack);check("catalogue label",cat2.label("assets/minecraft/textures/block/stone.png",Language.ZH).contains("石"))
    val reset=projects.resetTexture(pack,doc);check("reset texture",reset.composite(MaterialDocument.Channel.COLOR)[0]==0xff336699.toInt())
    check("template sources",projects.templates.available(profile)==false)
    // layout presets
    val store=LayoutStore(File(ctx.filesDir,"layouts.json"));store.put(true,seedLayout("A",1280f,800f));check("layout store",LayoutStore(File(ctx.filesDir,"layouts.json")).active(true)?.name=="A")
    // Windows integration fallback (no .minecraft): goes to Downloads
    System.setProperty("user.home",tmp.path);File(tmp,"Downloads").mkdirs()
    val (sent,file)=WindowsIntegration.sendToMinecraft(zip,"Smoke.zip",true)
    check("send fallback -> $sent",file.isFile&&file.parentFile.name=="Downloads")
    val (sent2,file2)=WindowsIntegration.sendToMinecraft(zip,"Smoke.zip",true);check("unique name ${file2.name}",file2.name=="Smoke (2).zip")
    // Diagnostics
    check("diagnostics",Diagnostics.report("1.0.2","31020".toInt(),"Windows 11","10.0 amd64","21","ZH","NONE").contains("Windows"))
    tmp.deleteRecursively()
    // ---- 1.0.2.1
    run{
        val fontJar=File(System.getProperty("fontjar"));val modelsZip=File(System.getProperty("modelszip"))
        val tmp=File(System.getProperty("java.io.tmpdir"),"mcts-smoke1021-"+System.nanoTime()).apply{mkdirs()}
        val ctx=Application(File(tmp,"files"),File(tmp,"cache"))
        val ttf=File(tmp,"mc.ttf")
        val n=com.mcts.core.MinecraftFont.build(fontJar,ttf){}
        check("minecraft font from jar ($n glyphs, ${ttf.length()/1024} KB)",n>50000&&ttf.length()>1_000_000)
        val awt=java.awt.Font.createFont(java.awt.Font.TRUETYPE_FONT,ttf)
        check("font loads in Java2D and has 中/A",awt.canDisplay('中')&&awt.canDisplay('A'))
        val stairs=OfficialModels.mesh(listOf(modelsZip),"minecraft:oak_stairs")
        check("official stairs model (${stairs?.quads?.size?.div(21)} quads)",stairs!=null&&stairs.quads.size/21>=10&&stairs.slots.contains("assets/minecraft/textures/block/oak_planks.png"))
        val door=OfficialModels.mesh(listOf(modelsZip),"minecraft:oak_door")
        check("door both halves",door!=null&&door.slots.size==2)
        val chest=com.axion.pompreview.PreviewGeometry.build("entity:entity/chest/normal")
        check("chest entity box UV (${chest.vertexCount()} vertices)",chest.vertexCount()==3*6*6&&chest.label.contains("箱子"))
        val q=com.axion.pompreview.PreviewGeometry.buildQuads(stairs!!.quads)
        check("quads mesh",q.vertexCount()==stairs.quads.size/21*6)
    }

    println(if(fails==0)"ALL PASSED" else "$fails FAILED");if(fails>0)System.exit(1)
}
