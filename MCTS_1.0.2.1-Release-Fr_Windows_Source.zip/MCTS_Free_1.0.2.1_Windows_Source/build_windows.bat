@echo off
chcp 65001 >nul
setlocal
title MCTS Free 1.0.2.1 - Windows build

rem ------------------------------------------------------------------
rem  Builds the MCTS Free 1.0.2.1 installer (.exe) on Windows 10/11.
rem  Needs: JDK 17 or newer (e.g. Eclipse Temurin 17/21) and internet
rem  for the first build (Gradle, Compose, WiX are downloaded once).
rem  Result: out\MCTS_Free_1.0.2.1_Windows_Setup.exe
rem ------------------------------------------------------------------

cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
  if defined JAVA_HOME (
    set "PATH=%JAVA_HOME%\bin;%PATH%"
  ) else (
    echo [MCTS] 没有找到 Java。请先安装 JDK 17 或更新版本（推荐 Eclipse Temurin 17）：
    echo        https://adoptium.net/zh-CN/temurin/releases/?os=windows^&package=jdk
    pause
    exit /b 1
  )
)

for /f "tokens=3" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do set JV=%%~v
echo [MCTS] Java %JV%
echo [MCTS] 正在构建安装包（第一次需要下载依赖，约 5-15 分钟）...

call gradlew.bat --no-daemon :desktop:packageExe
if errorlevel 1 (
  echo.
  echo [MCTS] 构建失败。请把上面的报错截图反馈。
  pause
  exit /b 1
)

if not exist out mkdir out
for %%f in ("desktop\build\compose\binaries\main\exe\*.exe") do copy /y "%%f" "out\MCTS_Free_1.0.2.1_Windows_Setup.exe" >nul

if exist "out\MCTS_Free_1.0.2.1_Windows_Setup.exe" (
  echo.
  echo [MCTS] 完成：out\MCTS_Free_1.0.2.1_Windows_Setup.exe
  explorer /select,"%~dp0out\MCTS_Free_1.0.2.1_Windows_Setup.exe"
) else (
  echo [MCTS] 没有找到生成的 exe，请检查 desktop\build\compose\binaries\main\exe
)
pause
