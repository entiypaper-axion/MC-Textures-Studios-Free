package com.mcts.core;
/** Reflections use pixel indices, including rectangular textures and odd centre cells.
 * All reflected pixels belong to the caller's single document stroke. */
public final class SymmetryBrush {
    private SymmetryBrush() {}
    public static void paint(MaterialDocument doc,int x,int y,int color,boolean mirrorX,boolean mirrorY) {
        if(x<0||y<0||x>=doc.width||y>=doc.height)return;
        int rx=doc.width-1-x,ry=doc.height-1-y;
        doc.paint(x,y,color);
        if(mirrorX&&rx!=x)doc.paint(rx,y,color);
        if(mirrorY&&ry!=y)doc.paint(x,ry,color);
        if(mirrorX&&mirrorY&&rx!=x&&ry!=y)doc.paint(rx,ry,color);
    }
}
