package com.mcts.core;
import java.io.*;

/** Decodes official Bedrock sample TGAs (indexed/truecolor/gray, raw or RLE). */
public final class TgaDecoder {
    public static final class Image { public final int width,height;public final int[] argb;Image(int w,int h,int[] p){width=w;height=h;argb=p;} }
    private static int u8(InputStream in)throws IOException{int v=in.read();if(v<0)throw new EOFException("TEMPLATE_INVALID");return v;}
    private static int u16(InputStream in)throws IOException{return u8(in)|(u8(in)<<8);}
    private static int color(InputStream in,int bits,boolean alpha)throws IOException{
        if(bits==15||bits==16){int v=u16(in);int r=(v>>10)&31,g=(v>>5)&31,b=v&31;return ((alpha&&(v&0x8000)==0?0:255)<<24)|((r*255/31)<<16)|((g*255/31)<<8)|(b*255/31);}
        if(bits==24||bits==32){int b=u8(in),g=u8(in),r=u8(in),a=bits==32?u8(in):255;return (a<<24)|(r<<16)|(g<<8)|b;}
        throw new IOException("TEMPLATE_INVALID");
    }
    public static Image decode(InputStream in)throws IOException{
        int id=u8(in),map=u8(in),type=u8(in),first=u16(in),count=u16(in),paletteBits=u8(in);
        u16(in);u16(in);int w=u16(in),h=u16(in),bits=u8(in),flags=u8(in);
        if(w<1||h<1||(long)w*h>16*1024*1024L||w>8192||h>8192||map>1||(flags&0xc0)!=0)throw new IOException("TEMPLATE_INVALID");
        boolean rle=type>=9;int kind=rle?type-8:type;
        if(kind<1||kind>3||(kind==1&&map!=1)||(kind==1&&bits!=8&&bits!=16)||(kind==3&&bits!=8&&bits!=16))throw new IOException("TEMPLATE_INVALID");
        for(int i=0;i<id;i++)u8(in);
        int[] palette=map==1?new int[first+count]:null;
        if(palette!=null){if(count==0)throw new IOException("TEMPLATE_INVALID");for(int i=first;i<first+count;i++)palette[i]=color(in,paletteBits,paletteBits==16);}
        int[] pixels=new int[w*h];int at=0;
        while(at<pixels.length){int header=rle?u8(in):0,n=rle?(header&127)+1:1;if(at+n>pixels.length)throw new IOException("TEMPLATE_INVALID");int repeated=0;
            for(int i=0;i<n;i++){
                int c;
                if(i>0&&rle&&(header&128)!=0)c=repeated;
                else if(kind==1){int index=bits==8?u8(in):u16(in);if(index<first||index>=first+count)throw new IOException("TEMPLATE_INVALID");c=palette[index];}
                else if(kind==3){int gray=u8(in),a=bits==16?u8(in):255;c=(a<<24)|(gray<<16)|(gray<<8)|gray;}
                else c=color(in,bits,(flags&15)>0);
                repeated=c;int x=at%w,y=at/w;if((flags&16)!=0)x=w-1-x;if((flags&32)==0)y=h-1-y;pixels[y*w+x]=c;at++;
            }
        }
        return new Image(w,h,pixels);
    }
}
