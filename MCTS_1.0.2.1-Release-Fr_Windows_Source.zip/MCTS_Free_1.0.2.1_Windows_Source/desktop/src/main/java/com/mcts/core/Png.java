package com.mcts.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.*;

/** Writes straight RGBA, preserving RGB even at alpha zero (essential for LabPBR). */
public final class Png {
    private Png() {}
    public static byte[] rgba(int width, int height, int[] argb) throws IOException {
        if (width <= 0 || height <= 0 || (long)width*height != argb.length || argb.length > 512*512)
            throw new IllegalArgumentException("PIXEL_COUNT");
        return encode(width,height,argb);
    }
    /** Bounded conversion for bundled sample images; document editing remains limited to 512. */
    public static byte[] templateRgba(int width,int height,int[] argb)throws IOException {
        if(width<=0||height<=0||(long)width*height!=argb.length||argb.length>16*1024*1024)throw new IllegalArgumentException("PIXEL_COUNT");
        return encode(width,height,argb);
    }
    private static byte[] encode(int width,int height,int[] argb)throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(); DataOutputStream out = new DataOutputStream(bytes);
        out.write(new byte[]{(byte)137,80,78,71,13,10,26,10});
        ByteArrayOutputStream header = new ByteArrayOutputStream(); DataOutputStream h = new DataOutputStream(header);
        h.writeInt(width); h.writeInt(height); h.write(new byte[]{8,6,0,0,0});
        chunk(out,"IHDR",header.toByteArray());
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        try (DeflaterOutputStream z = new DeflaterOutputStream(data)) {
            for (int y=0;y<height;y++) {
                z.write(0);
                for (int x=0;x<width;x++) {
                    int pixel = argb[y*width+x];
                    z.write(pixel>>>16); z.write(pixel>>>8); z.write(pixel); z.write(pixel>>>24);
                }
            }
        }
        chunk(out,"IDAT",data.toByteArray()); chunk(out,"IEND",new byte[0]); out.flush(); return bytes.toByteArray();
    }
    private static void chunk(DataOutputStream out,String name,byte[] data) throws IOException {
        byte[] type = name.getBytes(StandardCharsets.US_ASCII); CRC32 crc = new CRC32(); crc.update(type); crc.update(data);
        out.writeInt(data.length); out.write(type); out.write(data); out.writeInt((int)crc.getValue());
    }
}
