package com.mcts.core;
/** One policy used by UI and operation entry points; hidden controls are not a security boundary. */
public final class EditionPolicy {
    public enum Feature { PBR, MODEL_PAINT, MODEL_IMPORT, GLASS, VIDEO_WALLPAPER, SPRING_MOTION }
    private final boolean free;
    public EditionPolicy(boolean free){this.free=free;}
    public boolean allows(Feature feature){return !free;}
    public boolean allowsChannel(MaterialDocument.Channel channel){return !free||channel==MaterialDocument.Channel.COLOR;}
}
