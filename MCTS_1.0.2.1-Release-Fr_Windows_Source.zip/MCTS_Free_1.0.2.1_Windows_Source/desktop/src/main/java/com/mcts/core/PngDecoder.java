package com.mcts.core;

import java.io.*;
import java.util.zip.*;

/**
 * Pure-Java PNG reader (every colour type and bit depth, Adam7, tRNS) returning straight (non-premultiplied) ARGB.
 * The engine needs it where no platform decoder exists (template building, texture-pack atlases, desktop builds).
 */
public final class PngDecoder {
    private PngDecoder() {}
    public static final class Image {
        public final int width, height; public final int[] argb;
        public Image(int width, int height, int[] argb) { this.width = width; this.height = height; this.argb = argb; }
    }

    public static boolean isPng(byte[] b) { return PackImport.isPng(b); }

    public static Image decode(byte[] bytes) throws IOException { return decode(bytes, 64L * 1024 * 1024); }

    public static Image decode(byte[] bytes, long maxPixels) throws IOException {
        if (!isPng(bytes)) throw new IOException("PNG_INVALID");
        int width = 0, height = 0, depth = 0, type = 0, interlace = 0;
        int[] palette = null;
        int trnsGray = -1, trnsR = -1, trnsG = -1, trnsB = -1;
        ByteArrayOutputStream idat = new ByteArrayOutputStream(bytes.length);
        boolean header = false;
        int pos = 8;
        while (pos + 12 <= bytes.length) {
            int len = readInt(bytes, pos), name = readInt(bytes, pos + 4);
            int start = pos + 8;
            if (len < 0 || start + len + 4 > bytes.length) throw new IOException("PNG_INVALID");
            if (name == 0x49484452) {
                width = readInt(bytes, start); height = readInt(bytes, start + 4);
                depth = bytes[start + 8] & 255; type = bytes[start + 9] & 255; interlace = bytes[start + 12] & 255;
                if (width <= 0 || height <= 0 || (long) width * height > maxPixels) throw new IOException("PNG_SIZE");
                header = true;
            } else if (name == 0x504c5445) {
                int n = len / 3; palette = new int[n];
                for (int i = 0; i < n; i++) palette[i] = 0xff000000 | ((bytes[start + i * 3] & 255) << 16) | ((bytes[start + i * 3 + 1] & 255) << 8) | (bytes[start + i * 3 + 2] & 255);
            } else if (name == 0x74524e53) {
                if (type == 3 && palette != null) { for (int i = 0; i < Math.min(len, palette.length); i++) palette[i] = (palette[i] & 0xffffff) | ((bytes[start + i] & 255) << 24); }
                else if (type == 0 && len >= 2) trnsGray = u16(bytes, start);
                else if (type == 2 && len >= 6) { trnsR = u16(bytes, start); trnsG = u16(bytes, start + 2); trnsB = u16(bytes, start + 4); }
            } else if (name == 0x49444154) {
                idat.write(bytes, start, len);
            } else if (name == 0x49454e44) break;
            pos = start + len + 4;
        }
        if (!header) throw new IOException("PNG_INVALID");
        int channels;
        switch (type) { case 0: channels = 1; break; case 2: channels = 3; break; case 3: channels = 1; break; case 4: channels = 2; break; case 6: channels = 4; break; default: throw new IOException("PNG_INVALID"); }
        if (!(depth == 1 || depth == 2 || depth == 4 || depth == 8 || depth == 16) || (type != 0 && type != 3 && depth < 8) || (type == 3 && depth == 16)) throw new IOException("PNG_INVALID");
        if (type == 3 && palette == null) throw new IOException("PNG_INVALID");
        int bitsPerPixel = channels * depth, bpp = Math.max(1, bitsPerPixel / 8);
        int[][] passes = interlace == 1
            ? new int[][]{{0, 0, 8, 8}, {4, 0, 8, 8}, {0, 4, 4, 8}, {2, 0, 4, 4}, {0, 2, 2, 4}, {1, 0, 2, 2}, {0, 1, 1, 2}}
            : new int[][]{{0, 0, 1, 1}};
        long expected = 0;
        for (int[] p : passes) {
            int pw = (width - p[0] + p[2] - 1) / p[2], ph = (height - p[1] + p[3] - 1) / p[3];
            if (pw > 0 && ph > 0) expected += (long) ph * (1 + rowBytes(pw, bitsPerPixel));
        }
        if (expected > Integer.MAX_VALUE - 16) throw new IOException("PNG_SIZE");
        byte[] data = new byte[(int) expected];
        Inflater inflater = new Inflater();
        try {
            inflater.setInput(idat.toByteArray());
            int got = 0;
            while (got < data.length) {
                int n = inflater.inflate(data, got, data.length - got);
                if (n == 0) { if (inflater.finished() || inflater.needsInput() || inflater.needsDictionary()) break; }
                got += n;
            }
            if (got < data.length) throw new IOException("PNG_INVALID");
        } catch (DataFormatException e) { throw new IOException("PNG_INVALID", e); }
        finally { inflater.end(); }
        int[] out = new int[width * height];
        int p0 = 0;
        for (int[] p : passes) {
            int pw = (width - p[0] + p[2] - 1) / p[2], ph = (height - p[1] + p[3] - 1) / p[3];
            if (pw <= 0 || ph <= 0) continue;
            int rb = rowBytes(pw, bitsPerPixel);
            byte[] prev = new byte[rb], cur = new byte[rb];
            for (int y = 0; y < ph; y++) {
                int filter = data[p0++] & 255;
                System.arraycopy(data, p0, cur, 0, rb); p0 += rb;
                unfilter(filter, cur, prev, bpp);
                int py = p[1] + y * p[3];
                for (int x = 0; x < pw; x++) out[py * width + p[0] + x * p[2]] = pixel(cur, x, type, depth, palette, trnsGray, trnsR, trnsG, trnsB);
                byte[] t = prev; prev = cur; cur = t;
            }
        }
        return new Image(width, height, out);
    }

    /** Width/height from the IHDR only (no pixel decode). Returns null when not a PNG. */
    public static int[] size(byte[] head) {
        if (head.length < 24 || !isPng(head) || readInt(head, 12) != 0x49484452) return null;
        return new int[]{readInt(head, 16), readInt(head, 20)};
    }

    private static int rowBytes(int w, int bitsPerPixel) { return (int) (((long) w * bitsPerPixel + 7) / 8); }
    private static int readInt(byte[] b, int i) { return ((b[i] & 255) << 24) | ((b[i + 1] & 255) << 16) | ((b[i + 2] & 255) << 8) | (b[i + 3] & 255); }
    private static int u16(byte[] b, int i) { return ((b[i] & 255) << 8) | (b[i + 1] & 255); }

    private static void unfilter(int filter, byte[] cur, byte[] prev, int bpp) throws IOException {
        int n = cur.length;
        switch (filter) {
            case 0: break;
            case 1: for (int i = bpp; i < n; i++) cur[i] = (byte) (cur[i] + cur[i - bpp]); break;
            case 2: for (int i = 0; i < n; i++) cur[i] = (byte) (cur[i] + prev[i]); break;
            case 3: for (int i = 0; i < n; i++) { int a = i >= bpp ? cur[i - bpp] & 255 : 0; cur[i] = (byte) (cur[i] + ((a + (prev[i] & 255)) >>> 1)); } break;
            case 4: for (int i = 0; i < n; i++) {
                int a = i >= bpp ? cur[i - bpp] & 255 : 0, b = prev[i] & 255, c = i >= bpp ? prev[i - bpp] & 255 : 0;
                int pp = a + b - c, pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c);
                cur[i] = (byte) (cur[i] + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c));
            } break;
            default: throw new IOException("PNG_INVALID");
        }
    }

    private static int sample(byte[] row, int index, int depth) {
        if (depth == 8) return row[index] & 255;
        if (depth == 16) return ((row[index * 2] & 255) << 8) | (row[index * 2 + 1] & 255);
        int bit = index * depth, b = row[bit >>> 3] & 255;
        return (b >>> (8 - depth - (bit & 7))) & ((1 << depth) - 1);
    }

    private static int to8(int v, int depth) { return depth == 16 ? v >>> 8 : depth == 8 ? v : v * 255 / ((1 << depth) - 1); }

    private static int pixel(byte[] row, int x, int type, int depth, int[] pal, int tg, int tr, int tgG, int tb) {
        switch (type) {
            case 0: { int v = sample(row, x, depth), g = to8(v, depth), a = v == tg ? 0 : 255; return (a << 24) | (g << 16) | (g << 8) | g; }
            case 2: {
                int r = sample(row, x * 3, depth), g = sample(row, x * 3 + 1, depth), b = sample(row, x * 3 + 2, depth);
                int a = r == tr && g == tgG && b == tb ? 0 : 255;
                return (a << 24) | (to8(r, depth) << 16) | (to8(g, depth) << 8) | to8(b, depth);
            }
            case 3: { int i = sample(row, x, depth); return pal == null || i >= pal.length ? 0xff000000 : pal[i]; }
            case 4: { int g = to8(sample(row, x * 2, depth), depth), a = to8(sample(row, x * 2 + 1, depth), depth); return (a << 24) | (g << 16) | (g << 8) | g; }
            default: {
                int r = to8(sample(row, x * 4, depth), depth), g = to8(sample(row, x * 4 + 1, depth), depth), b = to8(sample(row, x * 4 + 2, depth), depth), a = to8(sample(row, x * 4 + 3, depth), depth);
                return (a << 24) | (r << 16) | (g << 8) | b;
            }
        }
    }
}
