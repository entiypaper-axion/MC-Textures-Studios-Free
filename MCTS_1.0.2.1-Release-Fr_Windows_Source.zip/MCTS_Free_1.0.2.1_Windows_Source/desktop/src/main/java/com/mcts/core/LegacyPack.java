package com.mcts.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/**
 * Java 1.0 – 1.5.2 texture packs.
 * <p>
 * Inside MCTS every texture lives at {@code assets/minecraft/textures/...} (the 1.6+ layout), so the editor, asset browser
 * and project store work unchanged. This class converts in both directions and remembers the original archive paths:
 * <ul>
 *   <li>1.5.x: files are already split ({@code textures/blocks/stone.png}); other folders ({@code mob/}, {@code gui/}, …) sit at the root.</li>
 *   <li>1.0 – 1.4.7: blocks and items are stitched into {@code terrain.png} and {@code gui/items.png} (16 × 16 tiles each).
 *       Tiles are cut out for editing and stitched back on export. Tile names come from the 1.5.2 split textures
 *       (same pixels → same name); tiles without a match are called {@code terrain_037} / {@code items_037}.</li>
 * </ul>
 * The mapping is stored inside the cache as {@code mcts_legacy/map.txt}; the original atlases as {@code mcts_legacy/<atlas>.png}.
 * Nothing under {@code mcts_legacy/} is shown in the asset browser.
 */
public final class LegacyPack {
    private LegacyPack() {}
    public static final String DIR = "mcts_legacy/", MAP = DIR + "map.txt", PREFIX = "assets/minecraft/textures/";
    private static final long MAX_ENTRY = 32L * 1024 * 1024, MAX_TOTAL = 512L * 1024 * 1024;

    /** atlas id → original archive path, folder for its tiles, and 1.5.2 folder used for naming. */
    static final String[][] ATLASES = {{"terrain", "terrain.png", "blocks", "textures/blocks/"}, {"items", "gui/items.png", "items", "textures/items/"}};

    /** Cache ↔ archive mapping. */
    public static final class Map {
        public final LinkedHashMap<String, String> files = new LinkedHashMap<>();          // cache path → archive path
        public final LinkedHashMap<String, int[]> tiles = new LinkedHashMap<>();           // cache path → {atlas, index}
        public String text() {
            StringBuilder b = new StringBuilder("# MCTS texture-pack map v1\n");
            for (java.util.Map.Entry<String, String> e : files.entrySet()) b.append("F\t").append(e.getKey()).append('\t').append(e.getValue()).append('\n');
            for (java.util.Map.Entry<String, int[]> e : tiles.entrySet()) b.append("T\t").append(e.getKey()).append('\t').append(ATLASES[e.getValue()[0]][0]).append('\t').append(e.getValue()[1]).append('\n');
            return b.toString();
        }
        public static Map parse(String text) throws IOException {
            Map m = new Map();
            for (String line : text.split("\n")) {
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] p = line.split("\t");
                if (p[0].equals("F") && p.length == 3) { safe(p[1]); safe(p[2]); m.files.put(p[1], p[2]); }
                else if (p[0].equals("T") && p.length == 4) { safe(p[1]); m.tiles.put(p[1], new int[]{atlasIndex(p[2]), Integer.parseInt(p[3])}); }
            }
            return m;
        }
        /** atlas index → cache path (first one wins). */
        public String tilePath(int atlas, int index) {
            for (java.util.Map.Entry<String, int[]> e : tiles.entrySet()) if (e.getValue()[0] == atlas && e.getValue()[1] == index) return e.getKey();
            return null;
        }
    }

    static int atlasIndex(String id) throws IOException {
        for (int i = 0; i < ATLASES.length; i++) if (ATLASES[i][0].equals(id)) return i;
        throw new IOException("PACK_INVALID");
    }

    static void safe(String n) throws IOException {
        if (n.startsWith("/") || n.contains(":") || n.contains("\\")) throw new IOException("PACK_INVALID");
        for (String part : n.split("/")) if (part.equals("..") || part.equals(".")) throw new IOException("PACK_INVALID");
    }

    /** Archive path → cache path (inverse of the default rule; explicit map entries win on export). */
    public static String cachePath(String archivePath) {
        return archivePath.startsWith("textures/") ? PREFIX + archivePath.substring("textures/".length()) : PREFIX + archivePath;
    }

    private static boolean wanted(String n) {
        if (!n.endsWith(".png") || n.startsWith("META-INF/") || n.contains("/.") || n.startsWith(".")) return false;
        return !n.startsWith("assets/") && !n.startsWith("net/") && !n.startsWith("com/");
    }

    // ------------------------------------------------------------------ reference names (1.5.2)

    /** Pixel key of a 16×16 version of the image's first square frame (transparent pixels normalised). */
    static long[] key(int[] argb, int w, int h) {
        int s = Math.min(w, h); if (s <= 0) return null;
        long[] k = new long[16 * 16 / 2 + 1];
        int[] px = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            int p = argb[(y * s / 16) * w + x * s / 16];
            px[y * 16 + x] = (p >>> 24) == 0 ? 0 : p;
        }
        for (int i = 0; i < 256; i += 2) k[i / 2] = ((long) px[i] << 32) | (px[i + 1] & 0xffffffffL);
        return k;
    }

    /** name candidates per atlas from the 1.5.2 jar: key → sorted names. */
    static List<java.util.Map<String, List<String>>> references(File jar) throws IOException {
        List<java.util.Map<String, List<String>>> out = new ArrayList<>();
        for (int i = 0; i < ATLASES.length; i++) out.add(new HashMap<>());
        if (jar == null || !jar.isFile()) return out;
        try (ZipFile zip = new ZipFile(jar)) {
            List<? extends ZipEntry> entries = Collections.list(zip.entries());
            entries.sort(Comparator.comparing(ZipEntry::getName));
            for (ZipEntry e : entries) {
                String n = e.getName();
                for (int a = 0; a < ATLASES.length; a++) {
                    String folder = ATLASES[a][3];
                    if (!n.startsWith(folder) || !n.endsWith(".png") || n.indexOf('/', folder.length()) >= 0) continue;
                    try {
                        PngDecoder.Image img = PngDecoder.decode(read(zip, e), 4L * 1024 * 1024);
                        long[] k = key(img.argb, img.width, img.height);
                        if (k != null) out.get(a).computeIfAbsent(Arrays.toString(k), x -> new ArrayList<>()).add(n.substring(folder.length(), n.length() - 4));
                    } catch (IOException ignored) {}
                }
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ template

    /**
     * Builds the editing cache from an official client.jar (1.0 – 1.5.2).
     * @param reference the 1.5.2 client.jar used to name atlas tiles (may be null: tiles then keep index names)
     */
    public static int buildTemplate(File jar, File reference, boolean atlas, File output, TemplateArchive.Control control) throws IOException {
        File part = new File(output.getPath() + ".building");
        try (ZipFile zip = new ZipFile(jar); FileOutputStream file = new FileOutputStream(part); ZipOutputStream out = new ZipOutputStream(file)) {
            List<java.util.Map<String, List<String>>> refs = atlas ? references(reference) : null;
            Map map = new Map(); Set<String> written = new HashSet<>(); long total = 0; int count = 0;
            List<? extends ZipEntry> entries = Collections.list(zip.entries());
            entries.sort(Comparator.comparing(ZipEntry::getName));
            int done = 0;
            for (ZipEntry e : entries) {
                control.check(); control.progress((float) ++done / Math.max(1, entries.size()));
                String n = e.getName().replace('\\', '/');
                if (e.isDirectory() || !wanted(n)) continue;
                safe(n);
                if (e.getSize() > MAX_ENTRY) throw new IOException("TEMPLATE_LARGE");
                byte[] bytes = read(zip, e);
                total += bytes.length; if (total > MAX_TOTAL) throw new IOException("TEMPLATE_LARGE");
                if (!PngDecoder.isPng(bytes)) continue;
                int a = atlas ? atlasOf(n) : -1;
                if (a >= 0) {
                    put(out, written, DIR + ATLASES[a][0] + ".png", bytes);
                    count += split(bytes, a, refs.get(a), null, map, out, written);
                    continue;
                }
                String target = cachePath(n);
                if (written.contains(target)) continue;
                put(out, written, target, bytes); map.files.put(target, n); count++;
            }
            if (count < 100) throw new IOException("TEMPLATE_INVALID");
            put(out, written, MAP, map.text().getBytes(StandardCharsets.UTF_8));
            out.finish(); out.flush(); file.getFD().sync();
        } catch (Exception e) { part.delete(); throw e; }
        try { TemplateArchive.validate(part); Files.move(part.toPath(), output.toPath(), StandardCopyOption.REPLACE_EXISTING); return 0; }
        finally { part.delete(); }
    }

    static int atlasOf(String archivePath) {
        for (int i = 0; i < ATLASES.length; i++) if (ATLASES[i][1].equals(archivePath)) return i;
        return -1;
    }

    /**
     * Cuts one atlas into tiles. Names: existing mapping for that index (when importing onto a template) → 1.5.2 match → index name.
     * @return number of tiles written
     */
    static int split(byte[] png, int atlas, java.util.Map<String, List<String>> refs, Map existing, Map map, ZipOutputStream out, Set<String> written) throws IOException {
        PngDecoder.Image img = PngDecoder.decode(png, 16L * 1024 * 1024);
        if (img.width < 16 || img.width != img.height || img.width % 16 != 0) throw new IOException("PACK_ATLAS");
        int t = img.width / 16, n = 0;
        Set<String> used = new HashSet<>(map.tiles.keySet());
        String folder = PREFIX + ATLASES[atlas][2] + "/";
        for (int index = 0; index < 256; index++) {
            int ox = index % 16 * t, oy = index / 16 * t;
            int[] tile = new int[t * t]; boolean visible = false;
            for (int y = 0; y < t; y++) for (int x = 0; x < t; x++) {
                int p = img.argb[(oy + y) * img.width + ox + x]; tile[y * t + x] = p; if ((p >>> 24) != 0) visible = true;
            }
            if (!visible) continue;
            String path = existing != null ? existing.tilePath(atlas, index) : null;
            if (path == null && refs != null) {
                List<String> names = refs.get(Arrays.toString(key(tile, t, t)));
                if (names != null) for (String name : names) { String p = folder + name + ".png"; if (!used.contains(p) && !written.contains(p)) { path = p; break; } }
            }
            if (path == null || used.contains(path) && !isTile(map, path, atlas, index)) path = folder + String.format(Locale.ROOT, "%s_%03d.png", ATLASES[atlas][0], index);
            used.add(path);
            map.tiles.put(path, new int[]{atlas, index});
            if (!written.contains(path)) { put(out, written, path, Png.templateRgba(t, t, tile)); n++; }
        }
        return n;
    }

    private static boolean isTile(Map map, String path, int atlas, int index) {
        int[] v = map.tiles.get(path); return v != null && v[0] == atlas && v[1] == index;
    }

    // ------------------------------------------------------------------ import (user texture pack → project base)

    /** Root folder of a pre-1.6 texture pack inside the archive ("" or "Folder/"), or null. */
    static String root(List<String> names) {
        String best = null;
        for (String n : names) {
            String r = null;
            if (n.endsWith("pack.txt")) r = n.substring(0, n.length() - "pack.txt".length());
            else if (n.endsWith("terrain.png") && !n.endsWith("/textures/terrain.png")) r = n.substring(0, n.length() - "terrain.png".length());
            else { int i = n.indexOf("textures/blocks/"); if (i >= 0 && !n.contains("assets/")) r = n.substring(0, i); }
            if (r != null && (best == null || r.length() < best.length())) best = r;
        }
        return best;
    }

    public static final class Imported { public final int imported; public final String description; Imported(int i, String d) { imported = i; description = d; } }

    /**
     * Converts a user's 1.0 – 1.5.2 texture pack into a project base archive. The cached template (optional) supplies
     * tile names, original atlases and untouched textures.
     */
    public static Imported importPack(File pack, boolean atlas, File template, File output) throws IOException {
        File part = new File(output.getPath() + ".part");
        try (ZipFile zip = new ZipFile(pack)) {
            List<? extends ZipEntry> entries = Collections.list(zip.entries());
            if (entries.size() > PackImport.MAX_ENTRIES) throw new IOException("PACK_LARGE");
            List<String> names = new ArrayList<>();
            for (ZipEntry e : entries) { String n = e.getName().replace('\\', '/'); PackImport.safe(n); names.add(n); }
            String root = root(names);
            if (root == null) throw new IOException(PackImport.root(names, true) != null || PackImport.root(names, false) != null ? "PACK_EDITION" : "PACK_EMPTY");
            Map base = null; ZipFile templateZip = template != null && template.isFile() ? new ZipFile(template) : null;
            try {
                if (templateZip != null) { ZipEntry m = templateZip.getEntry(MAP); if (m != null) base = Map.parse(new String(read(templateZip, m), StandardCharsets.UTF_8)); }
                Map map = new Map(); if (base != null) { map.files.putAll(base.files); map.tiles.putAll(base.tiles); }
                java.util.Map<String, String> reverse = new HashMap<>();
                for (java.util.Map.Entry<String, String> f : map.files.entrySet()) reverse.put(f.getValue(), f.getKey());
                String description = null; int imported = 0; long total = 0;
                try (FileOutputStream file = new FileOutputStream(part); ZipOutputStream out = new ZipOutputStream(file)) {
                    Set<String> written = new HashSet<>();
                    for (ZipEntry e : entries) {
                        String n = e.getName().replace('\\', '/');
                        if (e.isDirectory() || !n.startsWith(root)) continue;
                        String rel = n.substring(root.length());
                        if (e.getSize() > PackImport.MAX_ENTRY) throw new IOException("PACK_LARGE");
                        if (rel.equals("pack.txt")) { description = new String(read(zip, e), StandardCharsets.UTF_8).replaceAll("§.", "").trim(); if (description.length() > 240) description = description.substring(0, 240); continue; }
                        if (!wanted(rel)) continue;
                        byte[] bytes = read(zip, e);
                        total += bytes.length; if (total > PackImport.MAX_TOTAL) throw new IOException("PACK_LARGE");
                        if (!PngDecoder.isPng(bytes)) continue;
                        int a = atlas ? atlasOf(rel) : -1;
                        if (a >= 0) {
                            if (base == null) put(out, written, DIR + ATLASES[a][0] + ".png", bytes);
                            imported += split(bytes, a, null, base, map, out, written);
                            continue;
                        }
                        String target = reverse.getOrDefault(rel, cachePath(rel));
                        if (written.contains(target)) continue;
                        put(out, written, target, bytes); map.files.put(target, rel); imported++;
                    }
                    if (imported == 0) throw new IOException("PACK_EMPTY");
                    if (templateZip != null) for (ZipEntry e : Collections.list(templateZip.entries())) {
                        if (e.isDirectory() || written.contains(e.getName()) || e.getName().equals(MAP)) continue;
                        PackImport.safe(e.getName());
                        put(out, written, e.getName(), read(templateZip, e));
                    }
                    put(out, written, MAP, map.text().getBytes(StandardCharsets.UTF_8));
                    out.finish(); out.flush(); file.getFD().sync();
                }
                Files.move(part.toPath(), output.toPath(), StandardCopyOption.REPLACE_EXISTING);
                return new Imported(imported, description);
            } finally { if (templateZip != null) templateZip.close(); }
        } catch (ZipException e) { throw new IOException("PACK_INVALID", e); }
        finally { part.delete(); }
    }

    // ------------------------------------------------------------------ export (modern layout → texture pack)

    /**
     * Rewrites an export built in the 1.6+ layout into a texture pack: archive paths restored, atlases stitched,
     * pack.txt written. Tiles larger than the original atlas cell scale the whole atlas (HD needs OptiFine/MCPatcher before 1.5).
     */
    public static void toTexturePack(File modern, File base, String name, String description, File output) throws IOException {
        Map map;
        java.util.Map<Integer, PngDecoder.Image> originals = new HashMap<>();
        try (ZipFile b = new ZipFile(base)) {
            ZipEntry m = b.getEntry(MAP); if (m == null) throw new IOException("PACK_MAP");
            map = Map.parse(new String(read(b, m), StandardCharsets.UTF_8));
            for (int a = 0; a < ATLASES.length; a++) { ZipEntry e = b.getEntry(DIR + ATLASES[a][0] + ".png"); if (e != null) originals.put(a, PngDecoder.decode(read(b, e), 16L * 1024 * 1024)); }
        }
        java.util.Map<Integer, java.util.Map<Integer, PngDecoder.Image>> tiles = new HashMap<>();
        Set<String> names = new HashSet<>();
        try (ZipFile in = new ZipFile(modern); ZipOutputStream out = new ZipOutputStream(new FileOutputStream(output))) {
            String txt = (name == null ? "" : name.trim()) + "\n" + (description == null ? "" : description.trim());
            put(out, names, "pack.txt", txt.trim().getBytes(StandardCharsets.UTF_8));
            for (ZipEntry e : Collections.list(in.entries())) {
                String n = e.getName();
                if (e.isDirectory() || n.equals("pack.mcmeta") || n.equals("pack.txt") || n.startsWith(DIR)) continue;
                int[] tile = map.tiles.get(n);
                if (tile != null) { tiles.computeIfAbsent(tile[0], x -> new HashMap<>()).put(tile[1], PngDecoder.decode(read(in, e), 4L * 1024 * 1024)); continue; }
                String target = map.files.get(n);
                if (target == null) target = n.startsWith(PREFIX) ? n.substring(PREFIX.length()) : n;
                if (names.contains(target)) continue;
                safe(target);
                put(out, names, target, read(in, e));
            }
            for (int a = 0; a < ATLASES.length; a++) {
                PngDecoder.Image original = originals.get(a);
                java.util.Map<Integer, PngDecoder.Image> edited = tiles.getOrDefault(a, Collections.emptyMap());
                if (original == null && edited.isEmpty()) continue;
                int t = original != null ? original.width / 16 : 16;
                for (PngDecoder.Image i : edited.values()) t = Math.max(t, i.width);
                t = Math.min(t, 256);
                int size = t * 16; int[] atlas = new int[size * size];
                if (original != null) { int s = original.width; for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) atlas[y * size + x] = original.argb[(y * s / size) * s + x * s / size]; }
                for (java.util.Map.Entry<Integer, PngDecoder.Image> e : edited.entrySet()) {
                    PngDecoder.Image img = e.getValue(); int ox = e.getKey() % 16 * t, oy = e.getKey() / 16 * t;
                    int fw = img.width, fh = Math.min(img.height, img.width);
                    for (int y = 0; y < t; y++) for (int x = 0; x < t; x++) atlas[(oy + y) * size + ox + x] = img.argb[(y * fh / t) * fw + x * fw / t];
                }
                put(out, names, ATLASES[a][1], Png.templateRgba(size, size, atlas));
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    static byte[] read(ZipFile zip, ZipEntry e) throws IOException {
        try (InputStream in = zip.getInputStream(e)) {
            ByteArrayOutputStream data = new ByteArrayOutputStream(); byte[] buffer = new byte[65536]; int n;
            while ((n = in.read(buffer)) != -1) { data.write(buffer, 0, n); if (data.size() > MAX_ENTRY) throw new IOException("TEMPLATE_LARGE"); }
            return data.toByteArray();
        }
    }

    private static void put(ZipOutputStream out, Set<String> written, String name, byte[] bytes) throws IOException {
        if (!written.add(name)) return;
        out.putNextEntry(new ZipEntry(name)); out.write(bytes); out.closeEntry();
    }
}
