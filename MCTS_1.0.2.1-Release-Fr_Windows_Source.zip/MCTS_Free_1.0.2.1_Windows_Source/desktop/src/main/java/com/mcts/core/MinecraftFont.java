package com.mcts.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * 1.0.2.1: builds a TrueType font from the official Minecraft: Java Edition client.jar the user downloads
 * (nothing is bundled). It reads the game's own font definition (assets/minecraft/font/default.json and its
 * includes): the bitmap sheets (ascii.png, accented.png, nonlatin_european.png), the "space" advances and the
 * Unifont hex glyphs the game uses for Chinese, Japanese, Korean and every other script. Each pixel region becomes an
 * outline with square corners, so the UI text looks exactly like the game at any size.
 *
 * Metrics follow the game: one game pixel = 32 font units, em = 9 game pixels (ascent 7, descent 2);
 * bitmap glyphs advance by their inked width + 1 pixel; Unifont glyphs are drawn at half scale like in the game.
 */
public final class MinecraftFont {
    public interface Control { void check() throws IOException; }
    private MinecraftFont() { }

    static final int UNIT = 32;          // font units per game pixel
    static final int EM = 9 * UNIT;      // units per em
    static final int ASCENT = 7 * UNIT;
    static final int DESCENT = 2 * UNIT;

    /** One glyph: a bitmap with its pixel size and placement, in font units. */
    static final class Glyph {
        final int cp, w, h, pixel, left, top, advance; final boolean[] on;
        Glyph(int cp, int w, int h, boolean[] on, int pixel, int left, int top, int advance) {
            this.cp = cp; this.w = w; this.h = h; this.on = on; this.pixel = pixel; this.left = left; this.top = top; this.advance = advance;
        }
    }

    /** Builds [output] from [clientJar]; returns the number of characters. Output is written atomically. */
    public static int build(File clientJar, File output, Control control) throws IOException {
        TreeMap<Integer, Glyph> glyphs = new TreeMap<>();
        try (ZipFile zip = new ZipFile(clientJar)) {
            Reader reader = new Reader(zip, glyphs, control);
            reader.font("minecraft:default", 0);
        }
        if (!glyphs.containsKey((int) 'A') || glyphs.size() < 95) throw new IOException("FONT_SOURCE");
        // No-break space behaves like space.
        Glyph space = glyphs.get(32);
        if (space != null && !glyphs.containsKey(0xA0)) glyphs.put(0xA0, new Glyph(0xA0, 0, 0, new boolean[0], UNIT, 0, 0, space.advance));
        byte[] ttf = TrueType.write(new ArrayList<>(glyphs.values()), control);
        File parent = output.getAbsoluteFile().getParentFile();
        if (parent != null) parent.mkdirs();
        File part = new File(output.getPath() + ".part");
        try {
            try (FileOutputStream out = new FileOutputStream(part)) { out.write(ttf); out.getFD().sync(); }
            Files.move(part.toPath(), output.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } finally { part.delete(); }
        return glyphs.size();
    }

    // ------------------------------------------------------------------ font definition

    private static final class Reader {
        final ZipFile zip; final Map<Integer, Glyph> glyphs; final Control control;
        Reader(ZipFile zip, Map<Integer, Glyph> glyphs, Control control) { this.zip = zip; this.glyphs = glyphs; this.control = control; }

        byte[] bytes(String path, long limit) throws IOException {
            ZipEntry e = zip.getEntry(path);
            if (e == null) return null;
            if (e.getSize() > limit) throw new IOException("FONT_SOURCE");
            try (InputStream in = zip.getInputStream(e)) { return readAll(in, limit); }
        }
        static String path(String id, String folder, String ext) {
            String ns = id.contains(":") ? id.substring(0, id.indexOf(':')) : "minecraft";
            String p = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;
            if (p.contains("..")) return null;
            return "assets/" + ns + "/" + folder + p + ext;
        }

        void font(String id, int depth) throws IOException {
            if (depth > 6) return;
            byte[] data = bytes(path(id, "font/", ".json"), 4L << 20);
            if (data == null) return;
            Object root = Json.parse(new String(data, StandardCharsets.UTF_8));
            Object providers = root instanceof Map ? ((Map<?, ?>) root).get("providers") : null;
            if (!(providers instanceof List)) return;
            for (Object p : (List<?>) providers) {
                control.check();
                if (!(p instanceof Map)) continue;
                Map<?, ?> m = (Map<?, ?>) p;
                if (!defaultFilter(m.get("filter"))) continue;
                String type = String.valueOf(m.get("type"));
                switch (type) {
                    case "reference": font(String.valueOf(m.get("id")), depth + 1); break;
                    case "space": space(m); break;
                    case "bitmap": bitmap(m); break;
                    case "unihex": unihex(m); break;
                    default: break; // ttf / legacy_unicode: not used by current versions
                }
            }
        }

        /** Providers apply when every filter option matches the game's defaults (uniform off, jp off). */
        static boolean defaultFilter(Object filter) {
            if (!(filter instanceof Map)) return true;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) filter).entrySet()) if (Boolean.TRUE.equals(e.getValue())) return false;
            return true;
        }

        void space(Map<?, ?> m) {
            Object adv = m.get("advances");
            if (!(adv instanceof Map)) return;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) adv).entrySet()) {
                String k = String.valueOf(e.getKey());
                if (k.isEmpty() || !(e.getValue() instanceof Number)) continue;
                int cp = k.codePointAt(0);
                if (glyphs.containsKey(cp)) continue;
                int a = (int) Math.round(((Number) e.getValue()).doubleValue() * UNIT);
                glyphs.put(cp, new Glyph(cp, 0, 0, new boolean[0], UNIT, 0, 0, Math.max(0, a)));
            }
        }

        void bitmap(Map<?, ?> m) throws IOException {
            String file = String.valueOf(m.get("file"));
            byte[] png = bytes(path(file, "textures/", ""), 8L << 20);
            Object chars = m.get("chars");
            if (png == null || !(chars instanceof List) || ((List<?>) chars).isEmpty()) return;
            PngDecoder.Image img = PngDecoder.decode(png, 16L << 20);
            List<?> rows = (List<?>) chars;
            int[][] cps = new int[rows.size()][];
            int cols = 0;
            for (int r = 0; r < rows.size(); r++) { cps[r] = String.valueOf(rows.get(r)).codePoints().toArray(); cols = Math.max(cols, cps[r].length); }
            if (cols == 0) return;
            int cw = img.width / cols, ch = img.height / rows.size();
            if (cw < 1 || ch < 1) return;
            double height = m.get("height") instanceof Number ? ((Number) m.get("height")).doubleValue() : 8;
            double ascent = m.get("ascent") instanceof Number ? ((Number) m.get("ascent")).doubleValue() : 7;
            double scale = height / ch; // game pixels per sheet pixel
            int pixel = (int) Math.round(scale * UNIT);
            if (pixel < 1) return;
            for (int r = 0; r < cps.length; r++) for (int c = 0; c < cps[r].length; c++) {
                int cp = cps[r][c];
                if (cp == 0 || glyphs.containsKey(cp)) continue;
                boolean[] on = new boolean[cw * ch]; int right = -1;
                for (int y = 0; y < ch; y++) for (int x = 0; x < cw; x++) {
                    int a = img.argb[(r * ch + y) * img.width + c * cw + x] >>> 24;
                    if (a > 0) { on[y * cw + x] = true; right = Math.max(right, x); }
                }
                // The game: advance = inked width × scale + 1 pixel (space-like empty cells only get the 1 pixel).
                int advance = (int) Math.round(((right + 1) * scale + 1) * UNIT);
                glyphs.put(cp, new Glyph(cp, cw, ch, on, pixel, 0, (int) Math.round(ascent * UNIT), advance));
            }
        }

        void unihex(Map<?, ?> m) throws IOException {
            String id = String.valueOf(m.get("hex_file"));
            String path = id.contains(":") ? "assets/" + id.substring(0, id.indexOf(':')) + "/" + id.substring(id.indexOf(':') + 1) : "assets/minecraft/" + id;
            byte[] zipped = bytes(path, 64L << 20);
            if (zipped == null) return;
            List<int[]> overrides = new ArrayList<>();
            Object so = m.get("size_overrides");
            if (so instanceof List) for (Object o : (List<?>) so) if (o instanceof Map) {
                Map<?, ?> r = (Map<?, ?>) o;
                String from = String.valueOf(r.get("from")), to = String.valueOf(r.get("to"));
                if (from.isEmpty() || to.isEmpty() || !(r.get("left") instanceof Number) || !(r.get("right") instanceof Number)) continue;
                overrides.add(new int[]{from.codePointAt(0), to.codePointAt(0), ((Number) r.get("left")).intValue(), ((Number) r.get("right")).intValue()});
            }
            try (ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(zipped))) {
                ZipEntry e;
                while ((e = in.getNextEntry()) != null) {
                    if (!e.getName().endsWith(".hex")) continue;
                    BufferedReader lines = new BufferedReader(new InputStreamReader(in, StandardCharsets.US_ASCII));
                    String line; int n = 0;
                    while ((line = lines.readLine()) != null) {
                        if ((++n & 1023) == 0) control.check();
                        int colon = line.indexOf(':');
                        if (colon < 1) continue;
                        int cp = Integer.parseInt(line.substring(0, colon), 16);
                        // Basic Multilingual Plane only (cmap format 4); no surrogates / private use.
                        if (cp > 0xFFFF || (cp >= 0xD800 && cp <= 0xF8FF) || glyphs.containsKey(cp)) continue;
                        String hex = line.substring(colon + 1).trim();
                        int w = hex.length() / 4; // 32 digits = 8 wide, 64 = 16 wide (16 rows)
                        if (w != 8 && w != 16 && w != 24 && w != 32) continue;
                        boolean[] on = new boolean[w * 16];
                        int left = w, right = -1;
                        for (int y = 0; y < 16; y++) for (int x = 0; x < w; x++) {
                            int digit = Character.digit(hex.charAt(y * (w / 4) + x / 4), 16);
                            if (((digit >> (3 - (x & 3))) & 1) != 0) { on[y * w + x] = true; left = Math.min(left, x); right = Math.max(right, x); }
                        }
                        for (int[] o : overrides) if (cp >= o[0] && cp <= o[1]) { left = o[2]; right = o[3]; }
                        if (right < left) { left = 0; right = -1; }
                        int half = UNIT / 2;
                        // Half-size pixels; the glyph is shifted so its left edge starts at the pen; advance = width/2 + 1 pixel.
                        int advance = (right - left + 1) * half + UNIT;
                        glyphs.put(cp, new Glyph(cp, w, 16, on, half, -left * half, ASCENT, advance));
                    }
                }
            }
        }
    }

    static byte[] readAll(InputStream in, long limit) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] b = new byte[65536]; int n;
        while ((n = in.read(b)) >= 0) { out.write(b, 0, n); if (out.size() > limit) throw new IOException("FONT_SOURCE"); }
        return out.toByteArray();
    }

    // ------------------------------------------------------------------ outlines

    /** Pixel-region boundaries as closed polygons (outer clockwise, holes anticlockwise) in font units, y up. */
    static List<int[]> outline(Glyph g) {
        int w = g.w, h = g.h;
        // Directed edges on the pixel-corner grid (gx 0..w, gy 0..h, gy counted downwards), filled side on the right.
        Map<Long, List<long[]>> from = new HashMap<>();
        int count = 0;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            if (!g.on[y * w + x]) continue;
            boolean up = y > 0 && g.on[(y - 1) * w + x], down = y < h - 1 && g.on[(y + 1) * w + x];
            boolean left = x > 0 && g.on[y * w + x - 1], right = x < w - 1 && g.on[y * w + x + 1];
            // In y-up font space: top edge goes +x, right edge goes -y, bottom edge -x, left edge +y (clockwise).
            if (!up) count += edge(from, x, y, x + 1, y);
            if (!right) count += edge(from, x + 1, y, x + 1, y + 1);
            if (!down) count += edge(from, x + 1, y + 1, x, y + 1);
            if (!left) count += edge(from, x, y + 1, x, y);
        }
        List<int[]> contours = new ArrayList<>();
        while (!from.isEmpty()) {
            long startKey = from.keySet().iterator().next();
            List<long[]> list = from.get(startKey);
            long[] e = list.remove(list.size() - 1);
            if (list.isEmpty()) from.remove(startKey);
            List<int[]> pts = new ArrayList<>();
            int sx = (int) e[0], sy = (int) e[1];
            pts.add(new int[]{sx, sy});
            int px = (int) e[0], py = (int) e[1], cx = (int) e[2], cy = (int) e[3];
            int guard = 0;
            while (!(cx == sx && cy == sy) && guard++ < 100000) {
                pts.add(new int[]{cx, cy});
                long key = key(cx, cy);
                List<long[]> outs = from.get(key);
                if (outs == null || outs.isEmpty()) break;
                // At a corner shared by two diagonal pixels, turn right (keeps diagonal pixels separate).
                int dx = cx - px, dy = cy - py; long[] pick = outs.get(0);
                if (outs.size() > 1) for (long[] o : outs) {
                    int ox = (int) (o[2] - o[0]), oy = (int) (o[3] - o[1]);
                    // right turn in y-down grid = (dx,dy) -> (-dy,dx)
                    if (ox == -dy && oy == dx) { pick = o; break; }
                }
                outs.remove(pick); if (outs.isEmpty()) from.remove(key);
                px = cx; py = cy; cx = (int) pick[2]; cy = (int) pick[3];
            }
            // Drop collinear points.
            List<int[]> clean = new ArrayList<>();
            int n = pts.size();
            for (int i = 0; i < n; i++) {
                int[] a = pts.get((i + n - 1) % n), b = pts.get(i), c = pts.get((i + 1) % n);
                if ((b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]) != 0) clean.add(b);
            }
            if (clean.size() < 3) continue;
            int[] flat = new int[clean.size() * 2];
            for (int i = 0; i < clean.size(); i++) {
                flat[i * 2] = g.left + clean.get(i)[0] * g.pixel;
                flat[i * 2 + 1] = g.top - clean.get(i)[1] * g.pixel;
            }
            contours.add(flat);
        }
        return contours;
    }
    private static long key(int x, int y) { return ((long) x << 32) ^ (y & 0xffffffffL); }
    private static int edge(Map<Long, List<long[]>> from, int x0, int y0, int x1, int y1) {
        from.computeIfAbsent(key(x0, y0), k -> new ArrayList<>(2)).add(new long[]{x0, y0, x1, y1});
        return 1;
    }

    // ------------------------------------------------------------------ TrueType writer

    static final class TrueType {
        static byte[] write(List<Glyph> glyphs, Control control) throws IOException {
            int n = glyphs.size() + 1; // + .notdef
            if (n > 65535) throw new IOException("FONT_SOURCE");
            ByteArrayOutputStream glyf = new ByteArrayOutputStream();
            int[] loca = new int[n + 1];
            int[] adv = new int[n], lsb = new int[n];
            int xMin = 0, yMin = -DESCENT, xMax = 0, yMax = ASCENT, maxPoints = 0, maxContours = 0, advMax = 0, minLsb = 0, minRsb = 0, maxExtent = 0;
            // .notdef: empty, 4 pixels wide.
            adv[0] = 4 * UNIT; loca[0] = 0; loca[1] = 0;
            for (int i = 1; i < n; i++) {
                if ((i & 511) == 0) control.check();
                Glyph g = glyphs.get(i - 1);
                adv[i] = g.advance; advMax = Math.max(advMax, g.advance);
                List<int[]> contours = g.on.length == 0 ? Collections.<int[]>emptyList() : outline(g);
                if (!contours.isEmpty()) {
                    int gx0 = Integer.MAX_VALUE, gy0 = Integer.MAX_VALUE, gx1 = Integer.MIN_VALUE, gy1 = Integer.MIN_VALUE, points = 0;
                    for (int[] c : contours) for (int k = 0; k < c.length; k += 2) {
                        gx0 = Math.min(gx0, c[k]); gx1 = Math.max(gx1, c[k]); gy0 = Math.min(gy0, c[k + 1]); gy1 = Math.max(gy1, c[k + 1]); points++;
                    }
                    lsb[i] = gx0; minLsb = Math.min(minLsb, gx0); minRsb = Math.min(minRsb, g.advance - gx1); maxExtent = Math.max(maxExtent, gx1);
                    xMin = Math.min(xMin, gx0); xMax = Math.max(xMax, gx1); yMin = Math.min(yMin, gy0); yMax = Math.max(yMax, gy1);
                    maxPoints = Math.max(maxPoints, points); maxContours = Math.max(maxContours, contours.size());
                    DataOutputStream d = new DataOutputStream(glyf);
                    d.writeShort(contours.size()); d.writeShort(gx0); d.writeShort(gy0); d.writeShort(gx1); d.writeShort(gy1);
                    int end = -1; for (int[] c : contours) { end += c.length / 2; d.writeShort(end); }
                    d.writeShort(0); // no instructions
                    ByteArrayOutputStream flags = new ByteArrayOutputStream(), xs = new ByteArrayOutputStream(), ys = new ByteArrayOutputStream();
                    int lx = 0, ly = 0;
                    for (int[] c : contours) for (int k = 0; k < c.length; k += 2) {
                        int dx = c[k] - lx, dy = c[k + 1] - ly; lx = c[k]; ly = c[k + 1];
                        int f = 1;
                        if (dx == 0) f |= 0x10; else if (Math.abs(dx) < 256) { f |= 0x02 | (dx > 0 ? 0x10 : 0); xs.write(Math.abs(dx)); } else { xs.write((dx >> 8) & 255); xs.write(dx & 255); }
                        if (dy == 0) f |= 0x20; else if (Math.abs(dy) < 256) { f |= 0x04 | (dy > 0 ? 0x20 : 0); ys.write(Math.abs(dy)); } else { ys.write((dy >> 8) & 255); ys.write(dy & 255); }
                        flags.write(f);
                    }
                    flags.writeTo(glyf); xs.writeTo(glyf); ys.writeTo(glyf);
                    while (glyf.size() % 4 != 0) glyf.write(0);
                }
                loca[i + 1] = glyf.size();
            }
            Map<String, byte[]> t = new TreeMap<>();
            t.put("glyf", glyf.toByteArray());
            t.put("loca", table(d -> { for (int v : loca) d.writeInt(v); }));
            t.put("hmtx", table(d -> { for (int i = 0; i < n; i++) { d.writeShort(adv[i]); d.writeShort(lsb[i]); } }));
            t.put("cmap", cmap(glyphs));
            final int fxMin = xMin, fyMin = yMin, fxMax = xMax, fyMax = yMax, fPoints = maxPoints, fContours = maxContours, fAdv = advMax, fLsb = minLsb, fRsb = minRsb, fExt = maxExtent;
            t.put("head", table(d -> {
                d.writeInt(0x00010000); d.writeInt(0x00010000); d.writeInt(0); d.writeInt(0x5F0F3CF5);
                d.writeShort(0x000B); d.writeShort(EM); d.writeLong(3873657600L); d.writeLong(3873657600L); // 2026-10-01 (seconds since 1904)
                d.writeShort(fxMin); d.writeShort(fyMin); d.writeShort(fxMax); d.writeShort(fyMax);
                d.writeShort(0); d.writeShort(6); d.writeShort(2); d.writeShort(1); d.writeShort(0);
            }));
            t.put("hhea", table(d -> {
                d.writeInt(0x00010000); d.writeShort(ASCENT); d.writeShort(-DESCENT); d.writeShort(0);
                d.writeShort(fAdv); d.writeShort(fLsb); d.writeShort(fRsb); d.writeShort(fExt);
                d.writeShort(1); d.writeShort(0); d.writeShort(0); for (int i = 0; i < 4; i++) d.writeShort(0);
                d.writeShort(0); d.writeShort(n);
            }));
            t.put("maxp", table(d -> {
                d.writeInt(0x00010000); d.writeShort(n); d.writeShort(fPoints); d.writeShort(fContours);
                d.writeShort(0); d.writeShort(0); d.writeShort(2); for (int i = 0; i < 8; i++) d.writeShort(0);
            }));
            int first = glyphs.isEmpty() ? 32 : Math.min(0xFFFF, glyphs.get(0).cp), last = glyphs.isEmpty() ? 32 : Math.min(0xFFFF, glyphs.get(glyphs.size() - 1).cp);
            t.put("OS/2", table(d -> {
                d.writeShort(4); d.writeShort(6 * UNIT); d.writeShort(400); d.writeShort(5); d.writeShort(0);
                for (int i = 0; i < 4; i++) d.writeShort(EM / 2);           // subscript size / offset
                for (int i = 0; i < 4; i++) d.writeShort(EM / 2);           // superscript
                d.writeShort(UNIT); d.writeShort(3 * UNIT);                 // strikeout
                d.writeShort(0); d.write(new byte[10]);                     // family class, panose
                d.writeInt(0xFFFFFFFF); d.writeInt(0xFFFFFFFF); d.writeInt(0x0FFFFFFF); d.writeInt(0); // unicode ranges (broad)
                d.write("MCTS".getBytes(StandardCharsets.US_ASCII)); d.writeShort(0x40);
                d.writeShort(first); d.writeShort(last);
                d.writeShort(ASCENT); d.writeShort(-DESCENT); d.writeShort(0);
                d.writeShort(Math.max(ASCENT, fyMax)); d.writeShort(Math.max(DESCENT, -fyMin));
                d.writeInt(0x003E019F); d.writeInt(0);                      // code pages (Latin, CJK…)
                d.writeShort(5 * UNIT); d.writeShort(7 * UNIT); d.writeShort(0); d.writeShort(32); d.writeShort(1);
            }));
            t.put("name", name());
            t.put("post", table(d -> { d.writeInt(0x00030000); d.writeInt(0); d.writeShort(-UNIT); d.writeShort(UNIT); d.writeInt(0); d.writeInt(0); d.writeInt(0); d.writeInt(0); d.writeInt(0); }));
            return assemble(t);
        }

        interface Body { void write(DataOutputStream d) throws IOException; }
        static byte[] table(Body b) throws IOException { ByteArrayOutputStream o = new ByteArrayOutputStream(); DataOutputStream d = new DataOutputStream(o); b.write(d); d.flush(); return o.toByteArray(); }

        /** Format 4 (BMP) for Windows Unicode and Unicode platforms; runs of consecutive glyphs share a segment. */
        static byte[] cmap(List<Glyph> glyphs) throws IOException {
            List<int[]> segs = new ArrayList<>(); // start, end, glyph of start
            for (int i = 0; i < glyphs.size(); i++) {
                int cp = glyphs.get(i).cp, gid = i + 1;
                if (cp > 0xFFFE) continue;
                int[] last = segs.isEmpty() ? null : segs.get(segs.size() - 1);
                if (last != null && cp == last[1] + 1 && gid == last[2] + (cp - last[0])) last[1] = cp;
                else segs.add(new int[]{cp, cp, gid});
            }
            segs.add(new int[]{0xFFFF, 0xFFFF, 0});
            int segX2 = segs.size() * 2;
            int search = 2; int sel = 0; while (search * 2 <= segX2) { search *= 2; sel++; }
            final int fSearch = search, fSel = sel;
            byte[] sub = table(d -> {
                d.writeShort(4); d.writeShort(16 + segs.size() * 8); d.writeShort(0);
                d.writeShort(segX2); d.writeShort(fSearch); d.writeShort(fSel); d.writeShort(segX2 - fSearch);
                for (int[] s : segs) d.writeShort(s[1]);
                d.writeShort(0);
                for (int[] s : segs) d.writeShort(s[0]);
                for (int[] s : segs) d.writeShort(s[0] == 0xFFFF ? 1 : (s[2] - s[0]) & 0xFFFF);
                for (int i = 0; i < segs.size(); i++) d.writeShort(0);
            });
            if (sub.length > 65535) throw new IOException("FONT_SOURCE");
            return table(d -> {
                d.writeShort(0); d.writeShort(2);
                d.writeShort(0); d.writeShort(3); d.writeInt(4 + 16);
                d.writeShort(3); d.writeShort(1); d.writeInt(4 + 16);
                d.write(sub);
            });
        }

        static byte[] name() throws IOException {
            String[] values = {"", "Minecraft (MCTS)", "Regular", "MCTS: Minecraft Java font built from the user's own client.jar", "Minecraft (MCTS) Regular", "Version 1.0", "MinecraftMCTS-Regular"};
            List<byte[]> strings = new ArrayList<>();
            for (int i = 1; i <= 6; i++) strings.add(values[i].getBytes(StandardCharsets.UTF_16BE));
            return table(d -> {
                d.writeShort(0); d.writeShort(6); d.writeShort(6 + 6 * 12);
                int off = 0;
                for (int i = 0; i < 6; i++) { d.writeShort(3); d.writeShort(1); d.writeShort(0x409); d.writeShort(i + 1); d.writeShort(strings.get(i).length); d.writeShort(off); off += strings.get(i).length; }
                for (byte[] s : strings) d.write(s);
            });
        }

        static byte[] assemble(Map<String, byte[]> tables) throws IOException {
            int num = tables.size();
            int search = 1, sel = 0; while (search * 2 <= num) { search *= 2; sel++; }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            DataOutputStream d = new DataOutputStream(out);
            d.writeInt(0x00010000); d.writeShort(num); d.writeShort(search * 16); d.writeShort(sel); d.writeShort(num * 16 - search * 16);
            int offset = 12 + num * 16; int headOffset = -1;
            // Directory sorted by tag (TreeMap order; "OS/2" sorts before lowercase tags as required).
            for (Map.Entry<String, byte[]> e : tables.entrySet()) {
                byte[] b = e.getValue();
                d.write(e.getKey().getBytes(StandardCharsets.US_ASCII)); d.writeInt(checksum(b)); d.writeInt(offset); d.writeInt(b.length);
                if (e.getKey().equals("head")) headOffset = offset;
                offset += (b.length + 3) & ~3;
            }
            for (byte[] b : tables.values()) { d.write(b); for (int i = b.length; i % 4 != 0; i++) d.write(0); }
            d.flush();
            byte[] font = out.toByteArray();
            int adjust = (int) (0xB1B0AFBAL - (checksum(font) & 0xffffffffL));
            font[headOffset + 8] = (byte) (adjust >>> 24); font[headOffset + 9] = (byte) (adjust >>> 16);
            font[headOffset + 10] = (byte) (adjust >>> 8); font[headOffset + 11] = (byte) adjust;
            return font;
        }
        static int checksum(byte[] b) {
            long sum = 0;
            for (int i = 0; i < b.length; i += 4) {
                long v = 0; for (int k = 0; k < 4; k++) v = (v << 8) | (i + k < b.length ? b[i + k] & 255 : 0);
                sum = (sum + v) & 0xffffffffL;
            }
            return (int) sum;
        }
    }

    // ------------------------------------------------------------------ minimal JSON (font definitions only; lenient like the game: trailing commas)

    static final class Json {
        final String s; int i;
        private Json(String s) { this.s = s; }
        static Object parse(String text) throws IOException { Json j = new Json(text); j.ws(); Object v = j.value(); return v; }
        void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        Object value() throws IOException {
            ws(); if (i >= s.length()) throw new IOException("FONT_SOURCE");
            char c = s.charAt(i);
            if (c == '{') { i++; Map<String, Object> m = new LinkedHashMap<>(); ws(); if (peek('}')) { i++; return m; }
                while (true) { ws(); if (peek('}')) { i++; return m; } String k = string(); ws(); expect(':'); m.put(k, value()); ws(); if (peek(',')) { i++; continue; } expect('}'); return m; } }
            if (c == '[') { i++; List<Object> l = new ArrayList<>(); ws(); if (peek(']')) { i++; return l; }
                while (true) { ws(); if (peek(']')) { i++; return l; } l.add(value()); ws(); if (peek(',')) { i++; continue; } expect(']'); return l; } }
            if (c == '"') return string();
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            if (s.startsWith("null", i)) { i += 4; return null; }
            int st = i; while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            if (st == i) throw new IOException("FONT_SOURCE");
            return Double.parseDouble(s.substring(st, i));
        }
        boolean peek(char c) { return i < s.length() && s.charAt(i) == c; }
        void expect(char c) throws IOException { if (!peek(c)) throw new IOException("FONT_SOURCE"); i++; }
        String string() throws IOException {
            expect('"'); StringBuilder b = new StringBuilder();
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == '"') return b.toString();
                if (c != '\\') { b.append(c); continue; }
                char e = s.charAt(i++);
                switch (e) {
                    case 'u': b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; break;
                    case 'n': b.append('\n'); break; case 't': b.append('\t'); break; case 'r': b.append('\r'); break;
                    case 'b': b.append('\b'); break; case 'f': b.append('\f'); break;
                    default: b.append(e);
                }
            }
            throw new IOException("FONT_SOURCE");
        }
    }
}
