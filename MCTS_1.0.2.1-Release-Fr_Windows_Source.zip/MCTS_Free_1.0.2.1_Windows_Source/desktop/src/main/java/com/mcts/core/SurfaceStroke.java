package com.mcts.core;

/** Texture UVs are continuous only within the same physical quad. */
public final class SurfaceStroke {
    private int previousSurface=-1,previousX,previousY;
    public void reset(){previousSurface=-1;}
    public int[][] segment(int x,int y,int surface){
        if(surface<0||x<0||y<0){reset();return new int[0][];}
        if(previousSurface!=surface){previousSurface=surface;previousX=x;previousY=y;return new int[][]{{x,y}};}
        int steps=Math.max(Math.abs(x-previousX),Math.abs(y-previousY));
        if(steps==0)return new int[0][];
        int[][] points=new int[steps][2];
        for(int i=1;i<=steps;i++){points[i-1][0]=previousX+(x-previousX)*i/steps;points[i-1][1]=previousY+(y-previousY)*i/steps;}
        previousX=x;previousY=y;return points;
    }
}
