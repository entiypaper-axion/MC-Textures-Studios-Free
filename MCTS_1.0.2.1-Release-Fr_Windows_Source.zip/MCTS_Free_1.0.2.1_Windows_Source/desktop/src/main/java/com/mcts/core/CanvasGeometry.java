package com.mcts.core;

/** Shared drawing/hit-test geometry. Coordinates use canvas pixels, never dp. */
public final class CanvasGeometry {
    public final float unit,left,top;
    public final int width,height;
    public CanvasGeometry(float viewWidth,float viewHeight,int width,int height,float zoom,float panX,float panY) {
        if(viewWidth<=0 || viewHeight<=0 || width<=0 || height<=0 || !Float.isFinite(zoom) || zoom<=0) throw new IllegalArgumentException("INVALID_VIEWPORT");
        this.width=width;this.height=height;
        unit=Math.min(viewWidth/width,viewHeight/height)*zoom;
        left=(viewWidth-width*unit)/2+panX;top=(viewHeight-height*unit)/2+panY;
    }
    public int x(float screenX){int x=(int)Math.floor((screenX-left)/unit);return x>=0&&x<width?x:-1;}
    public int y(float screenY){int y=(int)Math.floor((screenY-top)/unit);return y>=0&&y<height?y:-1;}
    public float screenX(int x){return left+x*unit;}
    public float screenY(int y){return top+y*unit;}
    public int firstX(){return Math.max(0,Math.min(width,(int)Math.floor(-left/unit)));}
    public int firstY(){return Math.max(0,Math.min(height,(int)Math.floor(-top/unit)));}
    public int lastX(float viewWidth){return Math.max(-1,Math.min(width-1,(int)Math.floor((viewWidth-left)/unit)));}
    public int lastY(float viewHeight){return Math.max(-1,Math.min(height-1,(int)Math.floor((viewHeight-top)/unit)));}
}
