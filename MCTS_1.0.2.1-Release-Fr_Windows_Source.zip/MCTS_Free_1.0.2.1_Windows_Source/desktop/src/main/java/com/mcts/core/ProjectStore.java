package com.mcts.core;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Per-asset local versions. Only the opened asset is resident in memory. */
public final class ProjectStore {
    private static final int MAGIC = 0x4D435433;
    private final Path root;
    public ProjectStore(Path root) throws IOException { this.root = root.toAbsolutePath(); Files.createDirectories(this.root); }
    public List<String> list() throws IOException {
        List<String> result = new ArrayList<>();
        try (DirectoryStream<Path> files = Files.newDirectoryStream(root,"*.mctdoc")) {
            for(Path file:files) result.add(file.getFileName().toString().replace(".mctdoc",""));
        }
        Collections.sort(result); return result;
    }
    public String save(MaterialDocument doc) throws IOException {
        doc.endStroke(); String key = key(doc.kind, doc.name); Path target = path(key);
        Path temp = Files.createTempFile(root,"save-",".tmp");
        try {
            try(FileOutputStream out = new FileOutputStream(temp.toFile())) { write(doc,out); out.getFD().sync(); }
            if(Files.exists(target) && sameBytes(temp,target))return key;
            Path versions = root.resolve("history").resolve(key); Files.createDirectories(versions);
            if(Files.exists(target)) Files.copy(target, versions.resolve(UUID.randomUUID()+".mctdoc"));
            try { Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
            catch(AtomicMoveNotSupportedException e) { Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING); }
            return key;
        } finally { Files.deleteIfExists(temp); }
    }
    private static boolean sameBytes(Path a,Path b) throws IOException {
        if(Files.size(a)!=Files.size(b))return false;
        try(InputStream left=new BufferedInputStream(Files.newInputStream(a));InputStream right=new BufferedInputStream(Files.newInputStream(b))) {
            int x;while((x=left.read())!=-1)if(x!=right.read())return false;
            return right.read()==-1;
        }
    }
    public MaterialDocument open(String key) throws IOException {
        try(InputStream in=Files.newInputStream(path(key))) { return read(in); }
    }
    public List<String> versions(String key) throws IOException {
        path(key); Path folder=root.resolve("history").resolve(key); List<Path> items=new ArrayList<>();
        if(Files.exists(folder)) try(DirectoryStream<Path> files=Files.newDirectoryStream(folder,"*.mctdoc")) {
            for(Path file:files) items.add(file);
        }
        items.sort((a,b)->Long.compare(b.toFile().lastModified(),a.toFile().lastModified()));
        List<String> result=new ArrayList<>(); for(Path item:items) result.add(item.getFileName().toString()); return result;
    }
    public MaterialDocument openVersion(String key,String version) throws IOException {
        path(key); if(!version.matches("[a-f0-9-]{36}\\.mctdoc")) throw new IOException("INVALID_PATH");
        try(InputStream in=Files.newInputStream(root.resolve("history").resolve(key).resolve(version))) { return read(in); }
    }
    public static String key(MaterialDocument.Kind kind,String name) {
        // Hash suffix avoids collisions between folder separators and underscores.
        return kind.name().toLowerCase(Locale.ROOT)+"-"+UUID.nameUUIDFromBytes(name.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
    private Path path(String key) throws IOException {
        if(!key.matches("[a-z_]+-[a-f0-9-]{36}")) throw new IOException("INVALID_PATH");
        return root.resolve(key+".mctdoc");
    }

    public static void write(MaterialDocument doc,OutputStream output) throws IOException {
        doc.endStroke();
        DeflaterOutputStream zipped=new DeflaterOutputStream(output); DataOutputStream out=new DataOutputStream(zipped);
        out.writeInt(MAGIC); out.writeInt(1); out.writeUTF(doc.name); out.writeUTF(doc.kind.name());
        out.writeInt(doc.width); out.writeInt(doc.height); out.writeInt(doc.getLayers().size());
        for(MaterialDocument.Layer layer:doc.getLayers()) {
            out.writeUTF(layer.name); out.writeBoolean(layer.visible); out.writeFloat(layer.opacity); out.writeInt(layer.planes.size());
            for(Map.Entry<MaterialDocument.Channel,int[]> plane:layer.planes.entrySet()) {
                out.writeUTF(plane.getKey().name()); for(int pixel:plane.getValue()) out.writeInt(pixel);
            }
        }
        out.flush(); zipped.finish();
    }
    public static MaterialDocument read(InputStream input) throws IOException {
        try {
            DataInputStream in=new DataInputStream(new InflaterInputStream(input));
            if(in.readInt()!=MAGIC || in.readInt()!=1) throw new IOException("PROJECT_FORMAT");
            String name=in.readUTF(); MaterialDocument.Kind kind=MaterialDocument.Kind.valueOf(in.readUTF());
            MaterialDocument doc=new MaterialDocument(name,kind,in.readInt(),in.readInt());
            int count=in.readInt(); if(count<1 || count>MaterialDocument.MAX_LAYERS) throw new IOException("LAYER_LIMIT");
            doc.clearLayersForRestore(); long allocated=0;
            for(int i=0;i<count;i++) {
                String title=in.readUTF(); boolean visible=in.readBoolean(); float opacity=in.readFloat();
                if(!Float.isFinite(opacity)||opacity<0||opacity>1) throw new IOException("INVALID_OPACITY");
                int channels=in.readInt(); if(channels<0 || channels>MaterialDocument.Channel.values().length) throw new IOException("CHANNEL_COUNT");
                Map<MaterialDocument.Channel,int[]> planes=new EnumMap<>(MaterialDocument.Channel.class);
                for(int j=0;j<channels;j++) {
                    MaterialDocument.Channel channel=MaterialDocument.Channel.valueOf(in.readUTF());
                    if(planes.containsKey(channel)) throw new IOException("DUPLICATE_CHANNEL");
                    allocated+=(long)doc.width*doc.height*4;
                    if(allocated>128L*1024*1024) throw new IOException("PROJECT_TOO_LARGE");
                    int[] pixels=new int[doc.width*doc.height]; for(int p=0;p<pixels.length;p++) pixels[p]=in.readInt();
                    planes.put(channel,pixels);
                }
                doc.restoreLayer(title,visible,opacity,planes);
            }
            if(in.read()!=-1) throw new IOException("PROJECT_TRAILING_DATA");
            return doc;
        } catch(IllegalArgumentException e) { throw new IOException("PROJECT_FORMAT",e); }
    }
}
