package com.mcts.core;

import java.util.ArrayDeque;

/** Brush footprints, flood fill and pixel-perfect helpers. Pure functions, no Android types. */
public final class PixelTools {
    private PixelTools() {}
    public static final int MAX_BRUSH = 8;

    /** Offsets as {dx0,dy0,dx1,dy1,...}. Size 1..8; the painted pixel sits at the footprint centre. */
    public static int[] brushOffsets(int size, boolean round) {
        int n = Math.max(1, Math.min(MAX_BRUSH, size));
        int start = -(n - 1) / 2;
        float centre = (n - 1) / 2f, limit = (n / 2f) * (n / 2f) - .5f;
        int[] tmp = new int[n * n * 2]; int count = 0;
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++) {
            if (round && n > 2) {
                float dx = x - centre, dy = y - centre;
                if (dx * dx + dy * dy > limit) continue;
            }
            tmp[count++] = start + x; tmp[count++] = start + y;
        }
        int[] out = new int[count]; System.arraycopy(tmp, 0, out, 0, count); return out;
    }

    static boolean similar(int a, int b, int tolerance) {
        if (a == b) return true;
        int limit = Math.round(Math.max(0, Math.min(100, tolerance)) * 255f / 100f);
        // Fully transparent pixels match each other regardless of hidden RGB.
        if ((a >>> 24) == 0 && (b >>> 24) == 0) return true;
        for (int shift = 0; shift <= 24; shift += 8)
            if (Math.abs(((a >>> shift) & 255) - ((b >>> shift) & 255)) > limit) return false;
        return true;
    }

    /** Pixels to recolour. Contiguous = 4-neighbour region; otherwise every similar pixel. */
    public static boolean[] fillMask(int[] pixels, int width, int height, int x, int y, int tolerance, boolean contiguous) {
        if (width <= 0 || height <= 0 || pixels.length != width * height) throw new IllegalArgumentException("PIXEL_COUNT");
        boolean[] mask = new boolean[pixels.length];
        if (x < 0 || y < 0 || x >= width || y >= height) return mask;
        int seed = pixels[y * width + x];
        if (!contiguous) {
            for (int i = 0; i < pixels.length; i++) mask[i] = similar(seed, pixels[i], tolerance);
            return mask;
        }
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        int first = y * width + x; mask[first] = true; queue.add(first);
        while (!queue.isEmpty()) {
            int i = queue.poll(), px = i % width, py = i / width;
            int[] next = {px > 0 ? i - 1 : -1, px < width - 1 ? i + 1 : -1, py > 0 ? i - width : -1, py < height - 1 ? i + width : -1};
            for (int j : next) if (j >= 0 && !mask[j] && similar(seed, pixels[j], tolerance)) { mask[j] = true; queue.add(j); }
        }
        return mask;
    }

    /** True when b is the elbow of an L between a and c (a,c diagonal; both orthogonally touch b). */
    public static boolean isElbow(int ax, int ay, int bx, int by, int cx, int cy) {
        boolean ab = Math.abs(ax - bx) + Math.abs(ay - by) == 1;
        boolean bc = Math.abs(bx - cx) + Math.abs(by - cy) == 1;
        boolean diagonal = Math.abs(ax - cx) == 1 && Math.abs(ay - cy) == 1;
        return ab && bc && diagonal;
    }
}
