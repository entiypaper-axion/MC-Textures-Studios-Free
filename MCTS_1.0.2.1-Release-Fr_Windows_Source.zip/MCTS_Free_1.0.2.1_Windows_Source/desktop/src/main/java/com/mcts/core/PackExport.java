package com.mcts.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import static com.mcts.core.MaterialDocument.Channel.*;

/** A batch is streamed one document at a time. Never silently promises cross-edition model parity. */
public final class PackExport {
    public enum Target { BEDROCK_VV, JAVA_LABPBR }
    public interface Progress { void update(int complete, int total, String asset); }
    private PackExport() {}
    public static void export(ProjectStore project, List<String> keys, Target target,
                              int javaPackFormat, OutputStream output, Progress progress) throws IOException {
        export(project,keys,target,javaPackFormat,output,progress,false);
    }
    public static void export(ProjectStore project,List<String> keys,Target target,int javaPackFormat,OutputStream output,Progress progress,boolean colorOnly) throws IOException {
        if(keys.isEmpty()) throw new IOException("EMPTY_PROJECT");
        if(javaPackFormat<1 || javaPackFormat>1000) throw new IOException("PACK_FORMAT_REQUIRED");
        Set<String> entries=new HashSet<>();
        try(ZipOutputStream zip=new ZipOutputStream(output)) {
            if(target==Target.JAVA_LABPBR) {
                text(zip,entries,"pack.mcmeta","{\"pack\":{\"pack_format\":"+javaPackFormat+",\"description\":\"MC Textures Studios · LabPBR\"}}");
            } else {
                text(zip,entries,"manifest.json","{\"format_version\":2,\"header\":{\"name\":\"MC Textures Studios\",\"description\":\"Vibrant Visuals materials\",\"uuid\":\""+UUID.randomUUID()+"\",\"version\":[1,0,0],\"min_engine_version\":[1,21,90]},\"modules\":[{\"type\":\"resources\",\"uuid\":\""+UUID.randomUUID()+"\",\"version\":[1,0,0]}],\"capabilities\":[\"pbr\"]}");
            }
            int complete=0;
            StringBuilder report=new StringBuilder("MCTS 3.0 alpha01 export\n\nThis build exports texture images, not model/entity/attachable definitions.\nReview game-specific texture identifiers and paths before release.\n");
            if(target==Target.JAVA_LABPBR) report.append("LabPBR 1.3; requires a compatible shader pack. Partial metalness is approximated at threshold 128. Roughness is perceptual; specular red = 255 - roughness.\n");
            else report.append("Uses normal + MERS texture sets. Standard Vibrant Visuals ignores normal alpha: POM height is not bound by this export. Metalness and subsurface are mutually exclusive in Vibrant Visuals.\n");
            for(String key:keys) {
                if(Thread.currentThread().isInterrupted()) throw new InterruptedIOException("CANCELLED");
                MaterialDocument doc=project.open(key);
                String path=path(doc,target); int w=doc.width,h=doc.height;
                put(zip,entries,path+".png",Png.rgba(w,h,doc.composite(COLOR)));
                if(colorOnly || doc.kind==MaterialDocument.Kind.UI || doc.kind==MaterialDocument.Kind.PARTICLE) {
                    report.append(doc.name).append(": color image only; UI/particle PBR requires engine-specific support.\n");
                } else {
                    int[] normal=doc.composite(NORMAL), height=doc.composite(HEIGHT), ao=doc.composite(AO);
                    int[] metal=doc.composite(METALNESS), emission=doc.composite(EMISSIVE), rough=doc.composite(ROUGHNESS);
                    int[] subsurface=doc.composite(SUBSURFACE), f0=doc.composite(F0), porosity=doc.composite(POROSITY);
                    if(target==Target.JAVA_LABPBR) {
                        for(int p=0;p<normal.length;p++) {
                            normal[p]=(normal[p]&0x00ffff00)|(ao[p]&255)|((height[p]&255)<<24);
                            metal[p]=labSpecular(metal[p]&255,emission[p]&255,rough[p]&255,subsurface[p]&255,f0[p]&255,porosity[p]&255);
                        }
                        put(zip,entries,path+"_n.png",Png.rgba(w,h,normal));
                        put(zip,entries,path+"_s.png",Png.rgba(w,h,metal));
                    } else {
                        for(int p=0;p<normal.length;p++) {
                            normal[p]=(normal[p]&0x00ffffff)|0xff000000;
                            metal[p]=((subsurface[p]&255)<<24)|((metal[p]&255)<<16)|((emission[p]&255)<<8)|(rough[p]&255);
                        }
                        put(zip,entries,path+"_normal.png",Png.rgba(w,h,normal));
                        put(zip,entries,path+"_mers.png",Png.rgba(w,h,metal));
                        String file=path.substring(path.lastIndexOf('/')+1);
                        text(zip,entries,path+".texture_set.json","{\"format_version\":\"1.21.30\",\"minecraft:texture_set\":{\"color\":\""+file+"\",\"normal\":\""+file+"_normal\",\"metalness_emissive_roughness_subsurface\":\""+file+"_mers\"}}");
                    }
                }
                if(doc.kind==MaterialDocument.Kind.FLIPBOOK) report.append(doc.name).append(": single editable frame only; animation timing/strip assembly pending.\n");
                if(doc.kind==MaterialDocument.Kind.MODEL_TEXTURE || doc.kind==MaterialDocument.Kind.ATTACHABLE_TEXTURE || doc.kind==MaterialDocument.Kind.ENTITY)
                    report.append(doc.name).append(": texture exported; model bindings must be provided separately.\n");
                if(progress!=null) progress.update(++complete,keys.size(),doc.name);
            }
            text(zip,entries,"mcts_export_report.txt",report.toString());
        }
    }
    public static int labSpecular(int metal,int emission,int roughness,int subsurface,int f0,int porosity) {
        int green=metal>=128?255:Math.min(229,f0);
        int blue=subsurface>0?65+Math.round(subsurface*190f/255):Math.round(porosity*64f/255);
        int alpha=Math.round(emission*254f/255); // 255 means disabled in LabPBR.
        return(alpha<<24)|((255-roughness)<<16)|(green<<8)|blue;
    }
    public static String path(MaterialDocument doc,Target target) {
        String folder;
        switch(doc.kind) {
            case BLOCK: case FLIPBOOK: folder=target==Target.JAVA_LABPBR?"block":"blocks"; break;
            case ITEM: folder=target==Target.JAVA_LABPBR?"item":"items"; break;
            case PARTICLE: folder="particle"; break;
            case UI: folder=target==Target.JAVA_LABPBR?"gui":"ui"; break;
            default: folder="entity";
        }
        return(target==Target.JAVA_LABPBR?"assets/minecraft/textures/":"textures/")+folder+"/"+doc.name;
    }
    private static void text(ZipOutputStream zip,Set<String> entries,String path,String value) throws IOException {
        put(zip,entries,path,value.getBytes(StandardCharsets.UTF_8));
    }
    private static void put(ZipOutputStream zip,Set<String> entries,String path,byte[] bytes) throws IOException {
        if(!entries.add(path)) throw new IOException("EXPORT_PATH_COLLISION: "+path);
        zip.putNextEntry(new ZipEntry(path)); zip.write(bytes); zip.closeEntry();
    }
}
