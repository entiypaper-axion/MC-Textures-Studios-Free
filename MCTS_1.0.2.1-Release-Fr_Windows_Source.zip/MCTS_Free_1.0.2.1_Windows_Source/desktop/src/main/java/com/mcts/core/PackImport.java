package com.mcts.core;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/**
 * Turns a user's resource pack (.zip / .mcpack) into a project base archive.
 * Only colour textures are taken; models, scripts, shaders, sounds and PBR maps are ignored.
 * A cached official template (optional) is copied first so untouched textures stay available.
 */
public final class PackImport {
    private PackImport() {}
    public static final long MAX_ENTRY = 16L * 1024 * 1024, MAX_TOTAL = 512L * 1024 * 1024;
    public static final int MAX_ENTRIES = 40000;

    public static final class Result {
        public final int imported; public final boolean java; public final String name, description;
        Result(int imported, boolean java, String name, String description) { this.imported = imported; this.java = java; this.name = name; this.description = description; }
    }
    /** For importers outside this class (texture packs). */
    public static Result result(int imported, boolean java, String name, String description) { return new Result(imported, java, name, description); }

    /** Detects edition from the archive layout. Returns null when nothing usable is found. */
    static String root(List<String> names, boolean java) {
        if (java) {
            String best = null;
            for (String n : names) { int i = n.indexOf("assets/minecraft/textures/"); if (i >= 0) { String r = n.substring(0, i); if (best == null || r.length() < best.length()) best = r; } }
            return best;
        }
        String best = null;
        for (String n : names) if (n.endsWith("manifest.json")) { String r = n.substring(0, n.length() - "manifest.json".length()); if (best == null || r.length() < best.length()) best = r; }
        if (best == null) return null;
        for (String n : names) if (n.startsWith(best + "textures/")) return best;
        return null;
    }

    static void safe(String name) throws IOException {
        String n = name.replace('\\', '/');
        if (n.startsWith("/") || n.contains(":")) throw new IOException("PACK_INVALID");
        for (String part : n.split("/")) if (part.equals("..")) throw new IOException("PACK_INVALID");
    }

    public static Result build(File pack, boolean javaProject, File template, File output) throws IOException {
        File part = new File(output.getPath() + ".part");
        int imported = 0; long total = 0; String name = null, description = null;
        try (ZipFile zip = new ZipFile(pack)) {
            List<? extends ZipEntry> entries = Collections.list(zip.entries());
            if (entries.size() > MAX_ENTRIES) throw new IOException("PACK_LARGE");
            List<String> names = new ArrayList<>();
            for (ZipEntry e : entries) { safe(e.getName()); names.add(e.getName().replace('\\', '/')); }
            String javaRoot = root(names, true), bedrockRoot = root(names, false);
            if (javaProject && javaRoot == null) throw new IOException(bedrockRoot != null ? "PACK_EDITION" : "PACK_EMPTY");
            if (!javaProject && bedrockRoot == null) throw new IOException(javaRoot != null ? "PACK_EDITION" : "PACK_EMPTY");
            String root = javaProject ? javaRoot : bedrockRoot;
            Map<String, byte[]> textures = new LinkedHashMap<>();
            for (ZipEntry e : entries) {
                String n = e.getName().replace('\\', '/');
                if (e.isDirectory() || !n.startsWith(root)) continue;
                String rel = n.substring(root.length());
                boolean meta = javaProject ? rel.equals("pack.mcmeta") : rel.equals("manifest.json");
                String target;
                if (javaProject) target = rel.startsWith("assets/minecraft/textures/") ? rel : null;
                else target = rel.startsWith("textures/") ? rel : null;
                if (!meta && (target == null || !target.matches(".*\\.(png|tga)$") || TemplateArchive.isPbr(target))) continue;
                if (e.getSize() > MAX_ENTRY) throw new IOException("PACK_LARGE");
                byte[] bytes = read(zip, e);
                total += bytes.length; if (total > MAX_TOTAL) throw new IOException("PACK_LARGE");
                if (meta) {
                    String text = new String(bytes, java.nio.charset.StandardCharsets.UTF_8);
                    description = field(text, "description"); if (!javaProject) name = field(text, "name");
                    continue;
                }
                if (target.endsWith(".tga")) {
                    TgaDecoder.Image image = TgaDecoder.decode(new ByteArrayInputStream(bytes));
                    bytes = Png.templateRgba(image.width, image.height, image.argb);
                    target = target.substring(0, target.length() - 4) + ".png";
                } else if (!isPng(bytes)) continue;
                textures.put(target, bytes);
            }
            if (textures.isEmpty()) throw new IOException("PACK_EMPTY");
            try (FileOutputStream file = new FileOutputStream(part); ZipOutputStream out = new ZipOutputStream(file)) {
                Set<String> written = new HashSet<>();
                for (Map.Entry<String, byte[]> t : textures.entrySet()) {
                    out.putNextEntry(new ZipEntry(t.getKey())); out.write(t.getValue()); out.closeEntry();
                    written.add(t.getKey()); imported++;
                }
                if (template != null && template.isFile()) try (ZipFile base = new ZipFile(template)) {
                    for (ZipEntry e : Collections.list(base.entries())) {
                        if (e.isDirectory() || written.contains(e.getName())) continue;
                        safe(e.getName());
                        out.putNextEntry(new ZipEntry(e.getName()));
                        try (InputStream in = base.getInputStream(e)) { byte[] buffer = new byte[65536]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n); }
                        out.closeEntry(); written.add(e.getName());
                    }
                }
                out.finish(); out.flush(); file.getFD().sync();
            }
            Files.move(part.toPath(), output.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return new Result(imported, javaProject, name, description);
        } catch (ZipException e) {
            throw new IOException("PACK_INVALID", e);
        } finally { part.delete(); }
    }

    private static byte[] read(ZipFile zip, ZipEntry e) throws IOException {
        try (InputStream in = zip.getInputStream(e)) {
            ByteArrayOutputStream data = new ByteArrayOutputStream(); byte[] buffer = new byte[65536]; int n; CRC32 crc = new CRC32();
            while ((n = in.read(buffer)) != -1) { data.write(buffer, 0, n); crc.update(buffer, 0, n); if (data.size() > MAX_ENTRY) throw new IOException("PACK_LARGE"); }
            if (e.getCrc() != -1 && crc.getValue() != e.getCrc()) throw new IOException("PACK_INVALID");
            return data.toByteArray();
        }
    }
    static boolean isPng(byte[] b) {
        if (b.length < 24) return false;
        long magic = 0; for (int i = 0; i < 8; i++) magic = (magic << 8) | (b[i] & 255);
        return magic == 0x89504e470d0a1a0aL;
    }
    /** Minimal JSON string lookup for display only (name/description); never trusted for paths. */
    static String field(String json, String key) {
        int i = json.indexOf("\"" + key + "\""); if (i < 0) return null;
        int colon = json.indexOf(':', i); if (colon < 0) return null;
        int q = json.indexOf('"', colon + 1); if (q < 0) return null;
        StringBuilder out = new StringBuilder();
        for (int j = q + 1; j < json.length() && out.length() < 120; j++) {
            char c = json.charAt(j);
            if (c == '\\' && j + 1 < json.length()) { out.append(json.charAt(++j)); continue; }
            if (c == '"') return out.toString().replaceAll("§.", "").trim();
            out.append(c);
        }
        return null;
    }
}
