package com.mcts.studio

import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * CPU blur for the liquid-glass backdrop. The wallpaper is blurred once (at ¼ resolution) whenever it or the window size
 * changes; the glass shader then samples it with bilinear filtering, so nothing is blurred per frame.
 * Three box passes ≈ Gaussian. Pure Kotlin (shared with the desktop build).
 */
internal object GlassBlur {
    /** Box radius for one of three passes that together approximate a Gaussian of [sigma] texels. */
    fun boxRadius(sigma:Float):Int{
        if(sigma<=.3f)return 0
        val perPass=sigma/sqrt(3f)
        return ((sqrt(12f*perPass*perPass+1f)-1f)/2f).roundToInt().coerceAtLeast(1)
    }

    /** Blurs opaque ARGB pixels in place (alpha forced to 255). */
    fun blur(pixels:IntArray,w:Int,h:Int,sigma:Float){
        val r=boxRadius(sigma);if(r==0||w<2||h<2)return
        val tmp=IntArray(pixels.size)
        repeat(3){horizontal(pixels,tmp,w,h,r);vertical(tmp,pixels,w,h,r)}
    }

    private fun horizontal(src:IntArray,dst:IntArray,w:Int,h:Int,r:Int){
        val div=2*r+1
        for(y in 0 until h){
            val row=y*w;var sr=0;var sg=0;var sb=0
            for(i in -r..r){val p=src[row+i.coerceIn(0,w-1)];sr+=p shr 16 and 255;sg+=p shr 8 and 255;sb+=p and 255}
            for(x in 0 until w){
                dst[row+x]=(0xff shl 24) or ((sr/div) shl 16) or ((sg/div) shl 8) or (sb/div)
                val out=src[row+(x-r).coerceIn(0,w-1)];val inn=src[row+(x+r+1).coerceIn(0,w-1)]
                sr+=(inn shr 16 and 255)-(out shr 16 and 255);sg+=(inn shr 8 and 255)-(out shr 8 and 255);sb+=(inn and 255)-(out and 255)
            }
        }
    }

    private fun vertical(src:IntArray,dst:IntArray,w:Int,h:Int,r:Int){
        val div=2*r+1
        for(x in 0 until w){
            var sr=0;var sg=0;var sb=0
            for(i in -r..r){val p=src[i.coerceIn(0,h-1)*w+x];sr+=p shr 16 and 255;sg+=p shr 8 and 255;sb+=p and 255}
            for(y in 0 until h){
                dst[y*w+x]=(0xff shl 24) or ((sr/div) shl 16) or ((sg/div) shl 8) or (sb/div)
                val out=src[(y-r).coerceIn(0,h-1)*w+x];val inn=src[(y+r+1).coerceIn(0,h-1)*w+x]
                sr+=(inn shr 16 and 255)-(out shr 16 and 255);sg+=(inn shr 8 and 255)-(out shr 8 and 255);sb+=(inn and 255)-(out and 255)
            }
        }
    }

    /**
     * Centre-crops [src] (w×h) to the aspect of [outW]×[outH] and resamples (box filter when shrinking) — used to fit the
     * user's wallpaper to the window before blurring.
     */
    fun cover(src:IntArray,w:Int,h:Int,outW:Int,outH:Int):IntArray{
        val scale=maxOf(outW.toFloat()/w,outH.toFloat()/h)
        val cw=outW/scale;val ch=outH/scale;val x0=(w-cw)/2f;val y0=(h-ch)/2f
        val out=IntArray(outW*outH)
        val step=1f/scale
        val taps=step.toInt().coerceIn(1,4)
        for(y in 0 until outH)for(x in 0 until outW){
            var r=0;var g=0;var b=0;var n=0
            for(j in 0 until taps)for(i in 0 until taps){
                val sx=(x0+(x+(i+.5f)/taps)*step).toInt().coerceIn(0,w-1);val sy=(y0+(y+(j+.5f)/taps)*step).toInt().coerceIn(0,h-1)
                val p=src[sy*w+sx];r+=p shr 16 and 255;g+=p shr 8 and 255;b+=p and 255;n++
            }
            out[y*outW+x]=(0xff shl 24) or ((r/n) shl 16) or ((g/n) shl 8) or (b/n)
        }
        return out
    }
}
