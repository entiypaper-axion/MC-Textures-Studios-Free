package com.mcts.studio

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.mcts.core.MaterialDocument

/** Tools shown in the tool panel, in order. Eraser (white) and Erase (transparent) are deliberately separate. */
internal val proTools=listOf(StudioModel.Tool.PENCIL to "pencil",StudioModel.Tool.ERASER to "eraser",StudioModel.Tool.ERASE to "erase_alpha",
    StudioModel.Tool.FILL to "fill",StudioModel.Tool.PICKER to "picker",StudioModel.Tool.MOVE to "move")

/** Unique colours of the current texture (most frequent first), for the swatch row. */
@Composable internal fun textureColors(model:StudioModel,limit:Int=7):List<Int>{
    val doc=model.document;val revision=model.revision
    return remember(doc,revision/8){
        val counts=HashMap<Int,Int>()
        for(p in doc.composite(MaterialDocument.Channel.COLOR))if((p ushr 24)!=0)counts[p or 0xff000000.toInt()]=(counts[p or 0xff000000.toInt()]?:0)+1
        counts.entries.sortedByDescending{it.value}.take(limit).map{it.key}
    }
}

@Composable internal fun ProColorBlock(model:StudioModel){
    val c=LocalPro.current
    val color=0xff000000.toInt() or (model.rgb.toIntOrNull(16)?:0)
    val hsv=remember(model.rgb){FloatArray(3).also{com.mcts.studio.compat.Colors.colorToHSV(color,it)}}
    var hue by remember{mutableFloatStateOf(hsv[0])}
    LaunchedEffect(model.rgb){if(hsv[1]>.02f)hue=hsv[0]}
    var hex by remember(model.rgb){mutableStateOf(model.rgb.uppercase())}
    fun hsvColor(h:Float,s:Float,v:Float)=com.mcts.studio.compat.Colors.HSVToColor(floatArrayOf(h,s.coerceIn(0f,1f),v.coerceIn(0f,1f)))
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()){
        ProLabel(model.p("color"))
        ProIconButton("picker",model.p("tool_picker"),{model.selectTool(StudioModel.Tool.PICKER)},selected=model.tool==StudioModel.Tool.PICKER,size=28.dp)
    }
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
        Box(Modifier.size(52.dp,46.dp).clickable(role=androidx.compose.ui.semantics.Role.Button,onClickLabel=model.p("swap_colors")){model.swapColors()}
            .semantics{contentDescription=model.p("swap_colors")}){
            Box(Modifier.align(Alignment.BottomEnd).size(28.dp).clip(RoundedCornerShape(7.dp)).background(Color(0xff000000.toInt() or (model.secondaryRgb.toIntOrNull(16)?:0xffffff))).border(1.dp,Color.Black.copy(alpha=.2f),RoundedCornerShape(7.dp)))
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).checker(4.dp).background(Color(color).copy(alpha=model.brushAlpha/255f)).border(2.dp,c.group,RoundedCornerShape(8.dp)))
        }
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)){
            ProField(hex,{v->hex=v.filter{it in "0123456789abcdefABCDEF"}.take(6).uppercase();if(hex.length==6)model.chooseColor(0xff000000.toInt() or hex.toInt(16))},
                mono=true,placeholder="RRGGBB",description="HEX",keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Ascii))
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(4.dp)){
                ProIcon("swap",c.tx3,13.dp);Text(model.p("primary_secondary"),style=MaterialTheme.typography.labelSmall,color=c.tx3)
                Spacer(Modifier.weight(1f));Text("${model.brushAlpha*100/255}%",style=MaterialTheme.typography.labelSmall.copy(fontFamily=ProMono),color=c.tx3)
            }
        }
    }
    // Saturation / value field
    var area by remember{mutableStateOf(IntSize(1,1))}
    fun pick(p:Offset){model.chooseColor(hsvColor(hue,p.x/area.width.coerceAtLeast(1),1-p.y/area.height.coerceAtLeast(1)))}
    Canvas(Modifier.fillMaxWidth().height(104.dp).clip(RoundedCornerShape(9.dp)).onSizeChanged{area=it}
        .pointerInput(model.busy){if(!model.busy)detectTapGestures{pick(it)}}
        .pointerInput(model.busy){if(!model.busy)detectDragGestures(onDragStart={pick(it)}){ch,_->ch.consume();pick(ch.position)}}
        .semantics{contentDescription=model.p("color_field")}){
        drawRect(Color.hsv(hue,1f,1f));drawRect(Brush.horizontalGradient(listOf(Color.White,Color.Transparent)));drawRect(Brush.verticalGradient(listOf(Color.Transparent,Color.Black)))
        val at=Offset(hsv[1]*size.width,(1-hsv[2])*size.height)
        drawCircle(Color.Black.copy(alpha=.5f),8.dp.toPx(),at,style=Stroke(3.5.dp.toPx()));drawCircle(Color.White,8.dp.toPx(),at,style=Stroke(2.dp.toPx()))
    }
    // Hue strip
    var hueWidth by remember{mutableIntStateOf(1)}
    fun pickHue(x:Float){hue=(x/hueWidth.coerceAtLeast(1)*359.99f).coerceIn(0f,359.99f);model.chooseColor(hsvColor(hue,hsv[1].coerceAtLeast(.05f),hsv[2].coerceAtLeast(.05f)))}
    Canvas(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).onSizeChanged{hueWidth=it.width}
        .pointerInput(model.busy){if(!model.busy)detectTapGestures{pickHue(it.x)}}
        .pointerInput(model.busy){if(!model.busy)detectDragGestures(onDragStart={pickHue(it.x)}){ch,_->ch.consume();pickHue(ch.position.x)}}
        .semantics{contentDescription=model.p("hue")}){
        drawRect(Brush.horizontalGradient((0..6).map{Color.hsv((it*60f).coerceAtMost(359.99f),1f,1f)}))
        val x=hue/360f*size.width;drawRect(Color.White,Offset(x-3.dp.toPx(),0f),androidx.compose.ui.geometry.Size(6.dp.toPx(),size.height),style=Stroke(2.dp.toPx()))
    }
    // Alpha strip (checkerboard = transparent)
    var alphaWidth by remember{mutableIntStateOf(1)}
    fun pickAlpha(x:Float){model.changeBrushAlpha((x/alphaWidth.coerceAtLeast(1)*255).toInt())}
    Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).checker(3.5.dp).onSizeChanged{alphaWidth=it.width}
        .pointerInput(Unit){detectTapGestures{pickAlpha(it.x)}}
        .pointerInput(Unit){detectDragGestures(onDragStart={pickAlpha(it.x)}){ch,_->ch.consume();pickAlpha(ch.position.x)}}
        .semantics{contentDescription=model.p("opacity")+" ${model.brushAlpha*100/255}%"}){
        Canvas(Modifier.matchParentSize()){
            drawRect(Brush.horizontalGradient(listOf(Color(color).copy(alpha=0f),Color(color))))
            val x=model.brushAlpha/255f*size.width;drawRect(Color.White,Offset(x-3.dp.toPx(),0f),androidx.compose.ui.geometry.Size(6.dp.toPx(),size.height),style=Stroke(2.dp.toPx()))
        }
    }
    // Swatches: transparent, colours used by this texture, recent colours.
    val used=textureColors(model)
    val swatches:List<Int?> = (listOf<Int?>(null)+used+model.recentColors().filter{it !in used}).take(16)
    val columns=8
    Column(verticalArrangement=Arrangement.spacedBy(5.dp)){
        swatches.chunked(columns).forEach{row->
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                row.forEach{sw->
                    val selected=if(sw==null)model.tool==StudioModel.Tool.ERASE else (sw and 0xffffff)==(color and 0xffffff)&&model.tool!=StudioModel.Tool.ERASE
                    ProSwatch(sw,selected,{if(sw==null)model.selectTool(StudioModel.Tool.ERASE)else{model.chooseColor(sw);if(model.tool!=StudioModel.Tool.PENCIL&&model.tool!=StudioModel.Tool.FILL)model.selectTool(StudioModel.Tool.PENCIL)}},model)
                }
                repeat(columns-row.size){Spacer(Modifier.size(22.dp))}
            }
        }
    }
}

@Composable private fun ToolCell(model:StudioModel,tool:StudioModel.Tool,icon:String,modifier:Modifier){
    val c=LocalPro.current;val on=model.tool==tool;val tick=rememberTick()
    val name=model.p("tool_"+tool.name.lowercase())
    val (press,pressMod)=rememberPress(!model.busy)
    val lift=remember(press){derivedStateOf{if(press.pressed.value).05f else 0f}}
    val glass=smallGlassOn
    val bg by androidx.compose.animation.animateColorAsState(if(on)c.accSoft else c.raised,if(LocalQuiet.current)androidx.compose.animation.core.snap() else ProMotion.settle(),label="tool")
    Column(modifier.then(pressMod).height(54.dp)
        .glass(GlassKind.CHIP,10.dp,if(on)c.acc else null,lift,id=icon,fallback=Modifier.clip(RoundedCornerShape(10.dp)).background(bg).border(1.dp,if(on)c.acc else Color.Transparent,RoundedCornerShape(10.dp)))
        .clickable(interactionSource=press.source,indication=androidx.compose.foundation.LocalIndication.current,enabled=!model.busy,role=androidx.compose.ui.semantics.Role.RadioButton){tick();model.selectTool(tool)}
        .semantics{contentDescription=name+" · "+model.p("tool_hint_"+tool.name.lowercase());selected=on},
        horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
        ProIcon(icon,if(on)c.acc else if(glass)c.tx else c.tx2,20.dp,Modifier.popOn(on).then(if(glass)Modifier.underGlass() else Modifier))
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(3.dp)){
            Text(model.p("tool_short_"+tool.name.lowercase()),style=MaterialTheme.typography.labelSmall,color=if(on)c.tx else c.tx2,maxLines=1)
            // Visual reminder of the difference: white square vs checkerboard.
            if(tool==StudioModel.Tool.ERASER)Box(Modifier.size(8.dp).background(Color.White).border(1.dp,Color.Black.copy(alpha=.35f)))
            if(tool==StudioModel.Tool.ERASE)Box(Modifier.size(8.dp).checker(2.dp).border(1.dp,Color.Black.copy(alpha=.35f)))
        }
    }
}

@Composable private fun Pill(icon:String,text:String,on:Boolean,enabled:Boolean,onClick:()->Unit,modifier:Modifier){
    val c=LocalPro.current;val tick=rememberTick()
    val (press,pressMod)=rememberPress(enabled)
    Row(modifier.then(pressMod).height(34.dp).clip(RoundedCornerShape(9.dp)).background(if(on)c.accSoft else Color.Transparent).border(1.dp,if(on)c.acc else c.line,RoundedCornerShape(9.dp))
        .clickable(interactionSource=press.source,indication=androidx.compose.foundation.LocalIndication.current,enabled=enabled,role=androidx.compose.ui.semantics.Role.Button){tick();onClick()}.semantics{if(on)selected=true},
        horizontalArrangement=Arrangement.spacedBy(6.dp,Alignment.CenterHorizontally),verticalAlignment=Alignment.CenterVertically){
        val tint=when{!enabled->c.tx3.copy(alpha=.5f);on->c.acc;else->c.tx2}
        ProIcon(icon,tint,17.dp);Text(text,style=MaterialTheme.typography.labelMedium,color=tint,maxLines=1)
    }
}

@Composable internal fun ProZoomRow(model:StudioModel,view:PaintViewport){
    val c=LocalPro.current
    Row(Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(9.dp)).background(c.raised).padding(horizontal=2.dp),verticalAlignment=Alignment.CenterVertically){
        ProIconButton("zoom_out",model.p("zoom_out"),{view.scale(view.zoom/1.25f)},size=30.dp)
        Text("${(view.zoom*100).toInt()}%",Modifier.weight(1f),style=MaterialTheme.typography.labelMedium.copy(fontFamily=ProMono),color=c.tx,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
        ProIconButton("zoom_in",model.p("zoom_in"),{view.scale(view.zoom*1.25f)},size=30.dp)
        Box(Modifier.width(1.dp).height(18.dp).background(c.line))
        ProIconButton("fit",model.p("fit"),{view.fit()},size=30.dp)
    }
}

/** Tools header + 3×2 tool grid + brush size + mirror/grid (also a custom-UI block on its own). */
@Composable internal fun ProToolsSection(model:StudioModel,onDialog:(String)->Unit){
    val c=LocalPro.current
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()){
        ProLabel(model.p("tools"))
        ProIconButton("brush_settings",model.p("brush_settings"),{onDialog("brush")},size=28.dp)
    }
    proTools.chunked(3).forEach{row->
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){row.forEach{(tool,icon)->ToolCell(model,tool,icon,Modifier.weight(1f))}}
    }
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
        Text(model.p("brush"),style=MaterialTheme.typography.labelMedium,color=c.tx2)
        val sizes=listOf(1,2,3,4,6,8)
        ProSegmented(sizes.map{"$it"},sizes.indexOf(model.brushSize),{model.changeBrushSize(sizes[it])},Modifier.weight(1f),mono=true)
        Text("px",style=MaterialTheme.typography.labelSmall.copy(fontFamily=ProMono),color=c.tx3)
    }
    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
        Pill("mirror",model.p("mirror"),model.mirrorX||model.mirrorY,!model.busy,{if(model.mirrorX||model.mirrorY)model.setMirror(false,false)else model.setMirror(true,false)},Modifier.weight(1f))
        Pill("grid",model.p("grid"),model.pixelGrid,true,{model.setGrid(!model.pixelGrid)},Modifier.weight(1f))
    }
}

/** Undo/redo + current tool hint + zoom (also a custom-UI block on its own). */
@Composable internal fun ProHistorySection(model:StudioModel,view:PaintViewport){
    val c=LocalPro.current;val revision=model.revision
    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
        Pill("undo",model.p("undo"),false,!model.busy&&model.undoEnabled,model::undo,Modifier.weight(1f))
        Pill("redo",model.p("redo"),false,!model.busy&&model.redoEnabled,model::redo,Modifier.weight(1f))
    }
    val tool=model.tool.name.lowercase()
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(c.raised).padding(10.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
        ProIcon(proTools.first{it.first==model.tool}.second,c.acc,16.dp,Modifier.padding(top=1.dp))
        Column{
            Text(model.p("tool_"+tool),style=MaterialTheme.typography.labelLarge,color=c.tx)
            Text(model.p("tool_hint_"+tool),style=MaterialTheme.typography.bodySmall,color=c.tx2)
        }
    }
    ProZoomRow(model,view)
}

/** Wide tool panel: colour block on top, tools and options below (1.0.1 design). */
@Composable internal fun ProToolPanel(model:StudioModel,view:PaintViewport,onDialog:(String)->Unit,modifier:Modifier=Modifier){
    val revision=model.revision
    ProPanel(modifier){
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            ProColorBlock(model)
            ProDivider()
            ProToolsSection(model,onDialog)
            ProHistorySection(model,view)
        }
    }
}

/** Compact tool panel (UI layout → toolbar: compact): icons only. */
@Composable internal fun ProToolRail(model:StudioModel,view:PaintViewport,onDialog:(String)->Unit,modifier:Modifier=Modifier){
    val c=LocalPro.current;val revision=model.revision
    ProPanel(modifier){
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(2.dp)){
            val color=0xff000000.toInt() or (model.rgb.toIntOrNull(16)?:0)
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(Color(color)).border(1.dp,c.line,RoundedCornerShape(8.dp))
                .clickable(role=androidx.compose.ui.semantics.Role.Button){onDialog("color")}.semantics{contentDescription=model.p("color")+" #"+model.rgb.uppercase()})
            Spacer(Modifier.height(6.dp))
            proTools.forEach{(tool,icon)->ProIconButton(icon,model.p("tool_"+tool.name.lowercase()),{model.selectTool(tool)},Modifier.popOn(model.tool==tool),selected=model.tool==tool,enabled=!model.busy,tile=true)}
            Box(Modifier.width(32.dp).height(1.dp).background(c.line))
            ProIconButton("mirror",model.p("mirror"),{model.setMirror(!(model.mirrorX||model.mirrorY),false)},selected=model.mirrorX||model.mirrorY)
            ProIconButton("grid",model.p("grid"),{model.setGrid(!model.pixelGrid)},selected=model.pixelGrid)
            ProIconButton("brush_settings",model.p("brush_settings"),{onDialog("brush")})
            Box(Modifier.width(32.dp).height(1.dp).background(c.line))
            ProIconButton("undo",model.p("undo"),model::undo,enabled=!model.busy&&model.undoEnabled)
            ProIconButton("redo",model.p("redo"),model::redo,enabled=!model.busy&&model.redoEnabled)
            Box(Modifier.width(32.dp).height(1.dp).background(c.line))
            ProIconButton("zoom_in",model.p("zoom_in"),{view.scale(view.zoom*1.25f)})
            ProIconButton("zoom_out",model.p("zoom_out"),{view.scale(view.zoom/1.25f)})
            ProIconButton("fit",model.p("fit"),{view.fit()})
        }
    }
}
