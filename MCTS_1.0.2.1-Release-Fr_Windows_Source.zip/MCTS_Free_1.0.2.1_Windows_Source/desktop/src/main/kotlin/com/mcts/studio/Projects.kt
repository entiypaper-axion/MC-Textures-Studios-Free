package com.mcts.studio

import com.mcts.studio.compat.Context
import com.mcts.studio.compat.Uri
import com.mcts.studio.compat.BitmapFactory
import com.mcts.core.*
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.Properties
import java.util.zip.*

/**
 * pair = the content-era counterpart on the other edition (null when none exists: Bedrock resource packs and the archived
 * vanilla samples start at 1.16.20, so Java before 1.16.2 has no Bedrock pair).
 * format = Java pack_format (0 = pre-1.6 texture pack: no pack.mcmeta, pack.txt instead).
 * legacy = kept so existing projects still open, but not offered for new projects.
 */
data class GameProfile(val id:String,val java:Boolean,val version:String,val format:Int,val pair:String?,val vv:Boolean=false,val legacy:Boolean=false,val formatMinor:Int=0) {
    val label get()=(if(java)"Java " else "Bedrock ")+version
    /** Pre-1.13 Java uses textures/blocks + textures/items and old texture names. */
    val flattened get()=!java||format>=4
    /** 1.0–1.5.2: texture pack (pack.txt, files at the archive root). 1.0–1.4.7 also stitch blocks/items into terrain.png / gui/items.png. */
    val texturePack get()=java&&format==0
    val atlas get()=texturePack&&!version.startsWith("1.5")
    /** Numeric version for sorting and grouping ("1.21.11" → [1,21,11]; "26.1.2" → [26,1,2]). */
    val parts get()=version.split('.').map{it.toIntOrNull()?:0}
    /** Group shown in the version picker: "1.21", "26.1", "1.0 – 1.4" … */
    val line get()=if(java&&format==0&&atlas)"1.0 – 1.4" else parts.take(2).joinToString(".")
}
/** Every Java release 1.0 – 26.3 (official client.jar, pinned by Mojang's SHA-1) and the matching Bedrock vanilla samples. */
val gameProfiles=listOf(
    GameProfile("java_1_0",true,"1.0",0,null),
    GameProfile("java_1_1",true,"1.1",0,null),
    GameProfile("java_1_2_1",true,"1.2.1",0,null),
    GameProfile("java_1_2_2",true,"1.2.2",0,null),
    GameProfile("java_1_2_3",true,"1.2.3",0,null),
    GameProfile("java_1_2_4",true,"1.2.4",0,null),
    GameProfile("java_1_2_5",true,"1.2.5",0,null),
    GameProfile("java_1_3_1",true,"1.3.1",0,null),
    GameProfile("java_1_3_2",true,"1.3.2",0,null),
    GameProfile("java_1_4_2",true,"1.4.2",0,null),
    GameProfile("java_1_4_4",true,"1.4.4",0,null),
    GameProfile("java_1_4_5",true,"1.4.5",0,null),
    GameProfile("java_1_4_6",true,"1.4.6",0,null),
    GameProfile("java_1_4_7",true,"1.4.7",0,null),
    GameProfile("java_1_5",true,"1.5",0,null),
    GameProfile("java_1_5_1",true,"1.5.1",0,null),
    GameProfile("java_1_5_2",true,"1.5.2",0,null),
    GameProfile("java_1_6_1",true,"1.6.1",1,null),
    GameProfile("java_1_6_2",true,"1.6.2",1,null),
    GameProfile("java_164",true,"1.6.4",1,null),
    GameProfile("java_1_7_2",true,"1.7.2",1,null),
    GameProfile("java_1_7_4",true,"1.7.4",1,null),
    GameProfile("java_1_7_5",true,"1.7.5",1,null),
    GameProfile("java_1_7_6",true,"1.7.6",1,null),
    GameProfile("java_1_7_7",true,"1.7.7",1,null),
    GameProfile("java_1_7_8",true,"1.7.8",1,null),
    GameProfile("java_1_7_9",true,"1.7.9",1,null),
    GameProfile("java_1710",true,"1.7.10",1,null),
    GameProfile("java_1_8",true,"1.8",1,null),
    GameProfile("java_1_8_1",true,"1.8.1",1,null),
    GameProfile("java_1_8_2",true,"1.8.2",1,null),
    GameProfile("java_1_8_3",true,"1.8.3",1,null),
    GameProfile("java_1_8_4",true,"1.8.4",1,null),
    GameProfile("java_1_8_5",true,"1.8.5",1,null),
    GameProfile("java_1_8_6",true,"1.8.6",1,null),
    GameProfile("java_1_8_7",true,"1.8.7",1,null),
    GameProfile("java_1_8_8",true,"1.8.8",1,null),
    GameProfile("java_189",true,"1.8.9",1,null),
    GameProfile("java_1_9",true,"1.9",2,null),
    GameProfile("java_1_9_1",true,"1.9.1",2,null),
    GameProfile("java_1_9_2",true,"1.9.2",2,null),
    GameProfile("java_1_9_3",true,"1.9.3",2,null),
    GameProfile("java_1_9_4",true,"1.9.4",2,null),
    GameProfile("java_1_10",true,"1.10",2,null),
    GameProfile("java_1_10_1",true,"1.10.1",2,null),
    GameProfile("java_1_10_2",true,"1.10.2",2,null),
    GameProfile("java_1_11",true,"1.11",3,null),
    GameProfile("java_1_11_1",true,"1.11.1",3,null),
    GameProfile("java_1_11_2",true,"1.11.2",3,null),
    GameProfile("java_1_12",true,"1.12",3,null),
    GameProfile("java_1_12_1",true,"1.12.1",3,null),
    GameProfile("java_1122",true,"1.12.2",3,null),
    GameProfile("java_1_13",true,"1.13",4,null),
    GameProfile("java_1_13_1",true,"1.13.1",4,null),
    GameProfile("java_1_13_2",true,"1.13.2",4,null),
    GameProfile("java_1_14",true,"1.14",4,null),
    GameProfile("java_1_14_1",true,"1.14.1",4,null),
    GameProfile("java_1_14_2",true,"1.14.2",4,null),
    GameProfile("java_1_14_3",true,"1.14.3",4,null),
    GameProfile("java_1_14_4",true,"1.14.4",4,null),
    GameProfile("java_1_15",true,"1.15",5,null),
    GameProfile("java_1_15_1",true,"1.15.1",5,null),
    GameProfile("java_1_15_2",true,"1.15.2",5,null),
    GameProfile("java_1_16",true,"1.16",5,null),
    GameProfile("java_1_16_1",true,"1.16.1",5,null),
    GameProfile("java_1_16_2",true,"1.16.2",6,"1.16.20"),
    GameProfile("java_1_16_3",true,"1.16.3",6,"1.16.20"),
    GameProfile("java_1_16_4",true,"1.16.4",6,"1.16.100"),
    GameProfile("java_1165",true,"1.16.5",6,"1.16.200"),
    GameProfile("java_1_17",true,"1.17",7,"1.17.0"),
    GameProfile("java_1_17_1",true,"1.17.1",7,"1.17.10"),
    GameProfile("java_1_18",true,"1.18",8,"1.18.0"),
    GameProfile("java_1_18_1",true,"1.18.1",8,"1.18.1"),
    GameProfile("java_1_18_2",true,"1.18.2",8,"1.18.10"),
    GameProfile("java_1_19",true,"1.19",9,"1.19.0"),
    GameProfile("java_1_19_1",true,"1.19.1",9,"1.19.20"),
    GameProfile("java_1_19_2",true,"1.19.2",9,"1.19.20"),
    GameProfile("java_1_19_3",true,"1.19.3",12,"1.19.50"),
    GameProfile("java_1_19_4",true,"1.19.4",13,"1.19.70"),
    GameProfile("java_1_20",true,"1.20",15,"1.20.0"),
    GameProfile("java_1201",true,"1.20.1",15,"1.20.0"),
    GameProfile("java_1_20_2",true,"1.20.2",18,"1.20.30"),
    GameProfile("java_1_20_3",true,"1.20.3",22,"1.20.50"),
    GameProfile("java_1_20_4",true,"1.20.4",22,"1.20.50"),
    GameProfile("java_1_20_5",true,"1.20.5",32,"1.20.80"),
    GameProfile("java_1206",true,"1.20.6",32,"1.20.80"),
    GameProfile("java_121",true,"1.21",34,"1.21.0"),
    GameProfile("java_1211",true,"1.21.1",34,"1.21.20"),
    GameProfile("java_1_21_2",true,"1.21.2",42,"1.21.40"),
    GameProfile("java_1_21_3",true,"1.21.3",42,"1.21.40"),
    GameProfile("java_1214",true,"1.21.4",46,"1.21.50"),
    GameProfile("java_1_21_5",true,"1.21.5",55,"1.21.70"),
    GameProfile("java_1_21_6",true,"1.21.6",63,"1.21.90"),
    GameProfile("java_1_21_7",true,"1.21.7",64,"1.21.90"),
    GameProfile("java_1_21_8",true,"1.21.8",64,"1.21.100"),
    GameProfile("java_1_21_9",true,"1.21.9",69,"1.21.110"),
    GameProfile("java_1_21_10",true,"1.21.10",69,"1.21.110"),
    GameProfile("java_12111",true,"1.21.11",75,"1.21.130"),
    GameProfile("java_26_1",true,"26.1",84,"26.10"),
    GameProfile("java_26_1_1",true,"26.1.1",84,"26.10"),
    GameProfile("java_26_1_2",true,"26.1.2",84,"26.10"),
    GameProfile("java_262",true,"26.2",88,"26.30"),
    GameProfile("java_263",true,"26.3",97,"26.50",formatMinor=1),
    GameProfile("bedrock_1_16_20",false,"1.16.20",6,"1.16.2"),
    GameProfile("bedrock_1_16_100",false,"1.16.100",6,"1.16.4"),
    GameProfile("bedrock_116200",false,"1.16.200",6,"1.16.5"),
    GameProfile("bedrock_1_16_210",false,"1.16.210",6,"1.16.5"),
    GameProfile("bedrock_1_16_220",false,"1.16.220",7,"1.17"),
    GameProfile("bedrock_1_17_0",false,"1.17.0",7,"1.17"),
    GameProfile("bedrock_1_17_10",false,"1.17.10",7,"1.17.1"),
    GameProfile("bedrock_1_17_30",false,"1.17.30",8,"1.18"),
    GameProfile("bedrock_1_17_40",false,"1.17.40",8,"1.18"),
    GameProfile("bedrock_1_18_0",false,"1.18.0",8,"1.18"),
    GameProfile("bedrock_1_18_1",false,"1.18.1",8,"1.18.1"),
    GameProfile("bedrock_1_18_10",false,"1.18.10",8,"1.18.2"),
    GameProfile("bedrock_1_18_30",false,"1.18.30",9,"1.19"),
    GameProfile("bedrock_1_18_31",false,"1.18.31",9,"1.19"),
    GameProfile("bedrock_1_19_0",false,"1.19.0",9,"1.19"),
    GameProfile("bedrock_1_19_2",false,"1.19.2",9,"1.19"),
    GameProfile("bedrock_1_19_10",false,"1.19.10",9,"1.19.1"),
    GameProfile("bedrock_1_19_20",false,"1.19.20",9,"1.19.2"),
    GameProfile("bedrock_1_19_30",false,"1.19.30",9,"1.19.2"),
    GameProfile("bedrock_1_19_40",false,"1.19.40",12,"1.19.3"),
    GameProfile("bedrock_1_19_50",false,"1.19.50",12,"1.19.3"),
    GameProfile("bedrock_1_19_60",false,"1.19.60",13,"1.19.4"),
    GameProfile("bedrock_1_19_70",false,"1.19.70",13,"1.19.4"),
    GameProfile("bedrock_1_19_80",false,"1.19.80",15,"1.20"),
    GameProfile("bedrock_1200",false,"1.20.0",15,"1.20.1"),
    GameProfile("bedrock_1_20_10",false,"1.20.10",15,"1.20.1"),
    GameProfile("bedrock_1_20_30",false,"1.20.30",18,"1.20.2"),
    GameProfile("bedrock_1_20_40",false,"1.20.40",18,"1.20.2"),
    GameProfile("bedrock_1_20_50",false,"1.20.50",22,"1.20.3"),
    GameProfile("bedrock_1_20_60",false,"1.20.60",22,"1.20.4"),
    GameProfile("bedrock_1_20_70",false,"1.20.70",32,"1.20.5"),
    GameProfile("bedrock_12080",false,"1.20.80",32,"1.20.6"),
    GameProfile("bedrock_1210",false,"1.21.0",34,"1.21"),
    GameProfile("bedrock_12120",false,"1.21.20",34,"1.21.1"),
    GameProfile("bedrock_1_21_30",false,"1.21.30",42,"1.21.2"),
    GameProfile("bedrock_1_21_40",false,"1.21.40",42,"1.21.2"),
    GameProfile("bedrock_12150",false,"1.21.50",46,"1.21.4"),
    GameProfile("bedrock_1_21_60",false,"1.21.60",55,"1.21.5"),
    GameProfile("bedrock_1_21_70",false,"1.21.70",55,"1.21.5"),
    GameProfile("bedrock_1_21_80",false,"1.21.80",55,"1.21.5"),
    GameProfile("bedrock_1_21_90",false,"1.21.90",63,"1.21.6",true),
    GameProfile("bedrock_1_21_100",false,"1.21.100",64,"1.21.8",true),
    GameProfile("bedrock_1_21_110",false,"1.21.110",69,"1.21.9",true),
    GameProfile("bedrock_1_21_120",false,"1.21.120",69,"1.21.10",true),
    GameProfile("bedrock_121130",false,"1.21.130",75,"1.21.11",true),
    GameProfile("bedrock_26_0",false,"26.0",84,"26.1",true),
    GameProfile("bedrock_26_10",false,"26.10",84,"26.1",true),
    GameProfile("bedrock_26_20",false,"26.20",84,"26.1.2",true),
    GameProfile("bedrock_2630",false,"26.30",88,"26.2",true),
    GameProfile("bedrock_26_40",false,"26.40",97,"26.3",true),
    GameProfile("bedrock_2650",false,"26.50",97,"26.3",true))
/** Profiles offered for new projects (legacy ones still open). */
val offeredProfiles get()=gameProfiles.filter{!it.legacy}
fun profileById(id:String)=gameProfiles.firstOrNull{it.id==id}
/** The other edition's counterpart, or null when that era has none. */
fun GameProfile.counterpart()=pair?.let{v->gameProfiles.firstOrNull{it.java!=java&&it.version==v&&!it.legacy}}
data class PackProject(val id:String,val name:String,val profile:GameProfile,val header:String,val module:String)
data class TemplateTexture(val path:String,val width:Int,val height:Int) {
    val editable get()=width in 16..512&&height in 16..512&&(width and (width-1))==0&&(height and (height-1))==0
    val category get()=TemplateCategory.of(path)
    val pbr get()=TemplateArchive.isPbr(path)
    fun sizes()=listOf(16,32,64,128,256,512).filter{width>0&&it*height%width==0}.filter{n->val h=n*height/width;h in 16..512&&(h and(h-1))==0}
}
data class FaceMaps(val top:IntArray,val side:IntArray,val bottom:IntArray,val role:Int,val shape:String)
data class ExportSummary(val edited:Int,val unchanged:Int) { val total get()=edited+unchanged }
data class TrashedProject(val project:PackProject,val token:String)
/** Export-dialog options; blank strings fall back to the project name. icon = PNG bytes for pack.png / pack_icon.png. */
data class ExportMeta(val name:String="",val description:String="",val icon:ByteArray?=null)
/** Pre-export review: nothing blocks export, these are warnings the user may ignore. */
data class ExportCheck(val edited:Int,val unchanged:Int,val mixedSize:List<String>,val newTransparency:List<String>){val clean get()=edited>0&&mixedSize.isEmpty()&&newTransparency.isEmpty()}
data class ProjectInfo(val profile:GameProfile,val edited:Int,val documents:Int,val templateTextures:Int,val bytes:Long)
fun bedrockEngine(version:String):List<Int> {
    val parts=version.split('.').mapNotNull{it.toIntOrNull()}
    return if(parts.firstOrNull()==1)parts.take(3).let{it+List(3-it.size){0}} else listOf(1)+parts.take(2).let{it+List(2-it.size){0}}
}
class Projects(private val context:Context) {
    val templates=TemplateStore(context)
    private val textureIndex=java.util.concurrent.ConcurrentHashMap<String,List<TemplateTexture>>()
    private val catalogues=mutableMapOf<String,BlockCatalogue>()
    fun catalogue(p:PackProject)=synchronized(catalogues){catalogues.getOrPut(p.id+"/"+p.profile.id){BlockCatalogue(context.assets,p.profile.id,textures(p).map{it.path}.toSet())}}

    private val root=File(context.filesDir,"projects").apply{mkdirs()}
    fun folder(id:String):File {require(id=="local"||id.matches(Regex("[a-f0-9-]{36}")));return File(root,id)}
    fun store(p:PackProject)=ProjectStore(folder(p.id).toPath())
    fun models(p:PackProject)=File(folder(p.id),"model-data.zip")
    fun importModels(p:PackProject,uri:Uri){
        val dir=folder(p.id);val staging=File(dir,"model-data.part")
        try{
            context.contentResolver.openInputStream(uri)?.use{input->staging.outputStream().use{out->
                val buffer=ByteArray(64*1024);var total=0L
                while(true){val n=input.read(buffer);if(n<0)break;total+=n;if(total>250L*1024*1024)throw IOException("MODEL_LARGE");out.write(buffer,0,n)}
            }}?:throw IOException("MODEL_INVALID")
            ZipFile(staging).use{zip->if(zip.entries().asSequence().none{it.name.endsWith(".geo.json")||it.name.contains("assets/minecraft/models/block/")})throw IOException("MODEL_INVALID")}
            java.nio.file.Files.move(staging.toPath(),models(p).toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        }finally{staging.delete()}
    }
    fun read(id:String):PackProject {
        val j=JSONObject(File(folder(id),"project.json").readText())
        return PackProject(id,j.getString("name"),profileById(j.getString("profile"))?:throw IOException("PROJECT_PROFILE"),j.getString("header"),j.getString("module"))
    }
    private fun write(p:PackProject) {
        val dir=folder(p.id).apply{mkdirs()};val tmp=File(dir,"project.tmp")
        tmp.writeText(JSONObject().put("name",p.name).put("profile",p.profile.id).put("header",p.header).put("module",p.module).toString())
        java.nio.file.Files.move(tmp.toPath(),File(dir,"project.json").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
    }
    fun legacy():PackProject {
        if(File(folder("local"),"project.json").exists())return read("local")
        return PackProject("local","My textures",profileById("bedrock_121130")!!,UUID.randomUUID().toString(),UUID.randomUUID().toString()).also{write(it)}
    }
    fun list()=root.listFiles()?.filter{it.isDirectory&&File(it,"project.json").exists()}?.mapNotNull{runCatching{read(it.name)}.getOrNull()}?.sortedBy{it.name}?:emptyList()
    fun create(name:String,profile:GameProfile,template:Boolean):PackProject {
        require(name.trim().isNotEmpty()&&name.length<=80)
        val p=PackProject(UUID.randomUUID().toString(),name.trim(),profile,UUID.randomUUID().toString(),UUID.randomUUID().toString())
        val dir=folder(p.id).apply{mkdirs()}
        try {
            if(template){
                val cache=templates.verifiedArchive(profile)
                val staging=File(dir,"base.part")
                cache.inputStream().use{input->java.io.FileOutputStream(staging).use{output->input.copyTo(output);output.fd.sync()}}
                java.nio.file.Files.move(staging.toPath(),File(dir,"base.zip").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
            }
            write(p);return p
        }catch(e:Exception){dir.deleteRecursively();throw e}
    }
    fun rename(p:PackProject,name:String):PackProject {
        require(name.trim().isNotEmpty()&&name.length<=80)
        return p.copy(name=name.trim()).also{write(it)}
    }
    /** Copy local documents and the prepared template. Never change the source pack UUIDs. */
    fun duplicate(p:PackProject,name:String):PackProject {
        require(name.trim().isNotEmpty()&&name.length<=80)
        val copy=p.copy(id=UUID.randomUUID().toString(),name=name.trim(),header=UUID.randomUUID().toString(),module=UUID.randomUUID().toString())
        val staging=File(root,"copy-${copy.id}")
        try{
            folder(p.id).copyRecursively(staging,overwrite=false)
            File(staging,"project.json").writeText(JSONObject().put("name",copy.name).put("profile",copy.profile.id).put("header",copy.header).put("module",copy.module).toString())
            java.nio.file.Files.move(staging.toPath(),folder(copy.id).toPath())
            return copy
        }finally{staging.deleteRecursively()}
    }
    private val trash=File(context.filesDir,"project-trash").apply{mkdirs();listFiles()?.filter{System.currentTimeMillis()-it.lastModified()>24*60*60*1000L}?.forEach{it.deleteRecursively()}}
    fun trash(p:PackProject):TrashedProject {
        closeThumbnails(p.id)
        val token=UUID.randomUUID().toString()
        java.nio.file.Files.move(folder(p.id).toPath(),File(trash,token).toPath())
        File(trash,token).setLastModified(System.currentTimeMillis())
        textureIndex.remove(p.id)
        return TrashedProject(p,token)
    }
    fun restore(deleted:TrashedProject):PackProject {
        require(deleted.token.matches(Regex("[a-f0-9-]{36}")))
        java.nio.file.Files.move(File(trash,deleted.token).toPath(),folder(deleted.project.id).toPath())
        textureIndex.remove(deleted.project.id)
        return read(deleted.project.id)
    }
    fun purge(deleted:TrashedProject){
        require(deleted.token.matches(Regex("[a-f0-9-]{36}")))
        if(!File(trash,deleted.token).deleteRecursively())throw IOException("PROJECT_DELETE")
    }
    /** A stored template can be opened without having any changed pixels. Count actual edits. */
    fun exportSummary(p:PackProject):ExportSummary {
        val bindings=paths(p);val s=store(p)
        val file=File(folder(p.id),"base.zip")
        val base=if(file.exists())ZipFile(file)else null
        try{
            val originals=base?.entries()?.asSequence()?.filter{!it.isDirectory&&it.name.endsWith(".png")&&editableTemplatePath(it.name)&&!TemplateArchive.isPbr(it.name)}?.map{it.name}?.toSet()?:emptySet()
            val edited=mutableSetOf<String>()
            for(key in s.list()){
                val doc=s.open(key);val path=bindings.getProperty(key)?:PackExport.path(doc,if(p.profile.java)PackExport.Target.JAVA_LABPBR else PackExport.Target.BEDROCK_VV)+".png"
                val entry=base?.getEntry(path)
                var different=true
                if(entry!=null){
                    val bitmap=base.getInputStream(entry).use{BitmapFactory.decodeStream(it)}
                    if(bitmap!=null)try{
                        if(bitmap.width==doc.width&&bitmap.height==doc.height){
                            val pixels=IntArray(doc.width*doc.height);bitmap.getPixels(pixels,0,doc.width,0,0,doc.width,doc.height)
                            different=!pixels.contentEquals(doc.composite(MaterialDocument.Channel.COLOR))
                        }
                    }finally{bitmap.recycle()}
                }
                if(different)edited.add(path)
            }
            return ExportSummary(edited.size,(originals-edited).size)
        }finally{base?.close()}
    }
    fun textures(p:PackProject):List<TemplateTexture> {
        textureIndex[p.id]?.let{return it}
        val file=File(folder(p.id),"base.zip");if(!file.exists())return emptyList()
        val result=mutableListOf<TemplateTexture>()
        ZipFile(file).use{zip->zip.entries().asSequence().filter{it.name.endsWith(".png")&&editableTemplatePath(it.name)}.forEach{entry->
            zip.getInputStream(entry).use{input->
                val b=java.io.DataInputStream(input)
                if(entry.size>=24&&b.readLong()==0x89504e470d0a1a0aUL.toLong()&&b.readInt()==13&&b.readInt()==0x49484452)
                    result.add(TemplateTexture(entry.name,b.readInt(),b.readInt()))
            }
        }};return result.sortedBy{it.path}.also{textureIndex[p.id]=it}
    }
    private val thumbs=com.mcts.studio.compat.LruCache<String,com.mcts.studio.compat.Bitmap>(800)
    private var thumbZip:Pair<String,ZipFile>?=null
    /** Small preview of a template texture (≤64 px, nearest). Cached; the base archive stays open per project. */
    @Synchronized fun thumbnail(p:PackProject,path:String):com.mcts.studio.compat.Bitmap?{
        val key=p.id+"|"+path
        thumbs.get(key)?.let{return it}
        val file=File(folder(p.id),"base.zip");if(!file.isFile)return null
        val zip=thumbZip?.takeIf{it.first==p.id}?.second?:ZipFile(file).also{thumbZip?.second?.close();thumbZip=p.id to it}
        val entry=zip.getEntry(path)?:return null
        val decoded=zip.getInputStream(entry).use{BitmapFactory.decodeStream(it)}?:return null
        val bitmap=if(decoded.width>64||decoded.height>64){
            val scale=64f/maxOf(decoded.width,decoded.height)
            com.mcts.studio.compat.Bitmap.createScaledBitmap(decoded,(decoded.width*scale).toInt().coerceAtLeast(1),(decoded.height*scale).toInt().coerceAtLeast(1),false).also{if(it!==decoded)decoded.recycle()}
        }else decoded
        thumbs.put(key,bitmap);return bitmap
    }
    @Synchronized fun closeThumbnails(id:String){if(thumbZip?.first==id){thumbZip?.second?.close();thumbZip=null}}
    fun paths(p:PackProject)=Properties().also{v->File(folder(p.id),"paths.properties").takeIf{it.exists()}?.inputStream()?.use{v.load(it)}}
    /** Preview loading must not resize or overwrite another edited face. */
    fun openBoundTexture(p:PackProject,t:TemplateTexture):MaterialDocument {
        val key=paths(p).entries.firstOrNull{it.value==t.path}?.key?.toString()
        if(key!=null && key in store(p).list())return store(p).open(key)
        return openTexture(p,t)
    }
    fun openTexture(p:PackProject,t:TemplateTexture,targetSize:Int=t.width):MaterialDocument {
        require(t.editable&&targetSize in t.sizes())
        val targetHeight=targetSize*t.height/t.width
        val raw=t.path.substringAfter("textures/").removeSuffix(".png")
        val name=if(raw.matches(Regex("[a-z0-9_][a-z0-9_/-]{0,95}")))raw else "template_"+UUID.nameUUIDFromBytes(t.path.toByteArray()).toString()
        val kind=when(raw.substringBefore('/')){"block","blocks"->MaterialDocument.Kind.BLOCK;"item","items"->MaterialDocument.Kind.ITEM;"gui","ui"->MaterialDocument.Kind.UI;"particle"->MaterialDocument.Kind.PARTICLE;else->MaterialDocument.Kind.ENTITY}
        val s=store(p);val key=ProjectStore.key(kind,name)
        if(key in s.list()){
            val existing=s.open(key)
            if(existing.width==targetSize&&existing.height==targetHeight)return existing
            val resized=existing.resized(targetSize,targetHeight);s.save(resized);return resized
        }
        val doc=MaterialDocument(name,kind,targetSize,targetHeight)
        ZipFile(File(folder(p.id),"base.zip")).use{zip->
            val bitmap=zip.getInputStream(zip.getEntry(t.path)).use{BitmapFactory.decodeStream(it)}?:error("PNG_SIZE")
            try{val source=IntArray(t.width*t.height);bitmap.getPixels(source,0,t.width,0,0,t.width,t.height)
                val pixels=IntArray(targetSize*targetHeight){i->source[(i/targetSize*t.height/targetHeight)*t.width+(i%targetSize*t.width/targetSize)]}
                doc.replacePlane(0,MaterialDocument.Channel.COLOR,pixels);doc.clearHistory()}
            finally{bitmap.recycle()}
        }
        val paths=paths(p).apply{setProperty(key,t.path)};val tmp=File(folder(p.id),"paths.tmp")
        tmp.outputStream().use{paths.store(it,"Original texture paths")}
        java.nio.file.Files.move(tmp.toPath(),File(folder(p.id),"paths.properties").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        s.save(doc);return doc
    }
    fun previewFaces(p:PackProject,doc:MaterialDocument):FaceMaps?{
        val base=File(folder(p.id),"base.zip");if(!base.isFile)return null
        val path=paths(p).getProperty(ProjectStore.key(doc.kind,doc.name))?:return null
        val prefix=path.substringBeforeLast('/')+'/';val file=path.substringAfterLast('/').removeSuffix(".png")
        val stripped=file.replace(Regex("(_top|_bottom|_side|_front|_back|_north|_south|_east|_west)(_overlay)?$"),"")
        val role=when{file.endsWith("_top")->1;file.endsWith("_bottom")->3;file.contains("_side")->2;else->0}
        val shape=when(doc.kind){
            MaterialDocument.Kind.BLOCK->"minecraft:"+if(stripped=="grass")"grass_block" else stripped
            MaterialDocument.Kind.ITEM->"item:$stripped"
            MaterialDocument.Kind.UI->"ui:$stripped"
            MaterialDocument.Kind.PARTICLE->"particle:$stripped"
            else->"entity:$stripped"
        }
        val empty=IntArray(doc.width*doc.height)
        ZipFile(base).use{zip->
            fun read(vararg names:String):IntArray?{
                val entry=names.firstNotNullOfOrNull{n->zip.getEntry(prefix+n+".png")}
                    ?:return null
                val bitmap=zip.getInputStream(entry).use{BitmapFactory.decodeStream(it)}?:return null
                try{
                    val raw=IntArray(bitmap.width*bitmap.height);bitmap.getPixels(raw,0,bitmap.width,0,0,bitmap.width,bitmap.height)
                    return IntArray(doc.width*doc.height){i->raw[(i/doc.width*bitmap.height/doc.height)*bitmap.width+(i%doc.width*bitmap.width/doc.width)]}
                }finally{bitmap.recycle()}
            }
            val selected=doc.composite(MaterialDocument.Channel.COLOR)
            val top=read(stripped+"_top",file)?:selected
            val side=read(stripped+"_side",stripped+"_side_carried",file)?:selected
            val bottom=read(stripped+"_bottom",if(stripped=="grass"||stripped=="grass_block")"dirt" else file)?:selected
            return FaceMaps(top,side,bottom,role,shape)
        }
    }
    /** User pack (.zip/.mcpack) → new project. A cached template, when present, fills in untouched textures. */
    fun importPack(source:File,name:String,profile:GameProfile):Pair<PackProject,PackImport.Result> {
        require(name.trim().isNotEmpty()&&name.length<=80)
        val p=PackProject(UUID.randomUUID().toString(),name.trim(),profile,UUID.randomUUID().toString(),UUID.randomUUID().toString())
        val dir=folder(p.id).apply{mkdirs()}
        try{
            val template=if(templates.available(profile))runCatching{templates.verifiedArchive(profile)}.getOrNull()else null
            val result=if(profile.texturePack)LegacyPack.importPack(source,profile.atlas,template,File(dir,"base.zip")).let{PackImport.result(it.imported,true,null,it.description)}
                else PackImport.build(source,profile.java,template,File(dir,"base.zip"))
            write(p);return p to result
        }catch(e:Exception){dir.deleteRecursively();throw e}
    }
    /** Replace the current texture with the template original (same editing size). The old version stays in history. */
    fun resetTexture(p:PackProject,doc:MaterialDocument):MaterialDocument {
        val key=ProjectStore.key(doc.kind,doc.name)
        val path=paths(p).getProperty(key)?:throw IOException("NO_TEMPLATE_PATH")
        val fresh=MaterialDocument(doc.name,doc.kind,doc.width,doc.height)
        ZipFile(File(folder(p.id),"base.zip")).use{zip->
            val entry=zip.getEntry(path)?:throw IOException("NO_TEMPLATE_PATH")
            val bitmap=zip.getInputStream(entry).use{BitmapFactory.decodeStream(it)}?:throw IOException("PNG_SIZE")
            try{val w=bitmap.width;val h=bitmap.height;val source=IntArray(w*h);bitmap.getPixels(source,0,w,0,0,w,h)
                fresh.replacePlane(0,MaterialDocument.Channel.COLOR,IntArray(doc.width*doc.height){i->source[(i/doc.width*h/doc.height)*w+(i%doc.width*w/doc.width)]})
                fresh.clearHistory()
            }finally{bitmap.recycle()}
        }
        store(p).save(fresh);return fresh
    }
    fun info(p:PackProject):ProjectInfo {
        val summary=exportSummary(p)
        val bytes=folder(p.id).walkTopDown().filter{it.isFile}.sumOf{it.length()}
        return ProjectInfo(p.profile,summary.edited,store(p).list().size,textures(p).size,bytes)
    }
    fun exportCheck(p:PackProject):ExportCheck {
        val summary=exportSummary(p);val bindings=paths(p);val s=store(p)
        val file=File(folder(p.id),"base.zip");val mixed=mutableListOf<String>();val clear=mutableListOf<String>()
        if(file.exists())ZipFile(file).use{base->
            for(key in s.list()){
                val path=bindings.getProperty(key)?:continue
                val entry=base.getEntry(path)?:continue
                val doc=s.open(key);val pixels=doc.composite(MaterialDocument.Channel.COLOR)
                val bitmap=base.getInputStream(entry).use{BitmapFactory.decodeStream(it)}?:continue
                try{
                    val same=bitmap.width==doc.width&&bitmap.height==doc.height
                    if(!same)mixed.add(path.substringAfterLast('/'))
                    if(doc.kind==MaterialDocument.Kind.BLOCK&&pixels.any{(it ushr 24)<255}){
                        // Only flag pixels that were opaque in the original: real see-through blocks stay quiet.
                        val raw=IntArray(bitmap.width*bitmap.height);bitmap.getPixels(raw,0,bitmap.width,0,0,bitmap.width,bitmap.height)
                        if(raw.all{(it ushr 24)==255})clear.add(path.substringAfterLast('/'))
                    }
                }finally{bitmap.recycle()}
            }
        }
        return ExportCheck(summary.edited,summary.unchanged,mixed,clear)
    }
    @JvmOverloads fun export(p:PackProject,output:File,colorOnly:Boolean=false,meta:ExportMeta=ExportMeta()) {
        val s=store(p);val keys=s.list();val bindings=paths(p)
        val target=if(p.profile.java)PackExport.Target.JAVA_LABPBR else PackExport.Target.BEDROCK_VV
        val edited=File.createTempFile("edited-",".zip",context.cacheDir)
        try {
            PackExport.export(s,keys,target,maxOf(1,p.profile.format),edited.outputStream(),null,colorOnly)
            val remap=mutableMapOf<String,String>()
            for(key in keys){val original=bindings.getProperty(key)?:continue;val doc=s.open(key);val old=PackExport.path(doc,target);val path=original.removeSuffix(".png")
                for(suffix in listOf(".png","_n.png","_s.png","_normal.png","_mers.png",".texture_set.json"))remap[old+suffix]=path+suffix
            }
            val legacy=p.profile.texturePack
            val built=if(legacy)File.createTempFile("modern-",".zip",context.cacheDir) else output
            ZipOutputStream(built.outputStream()).use{out->
                val names=mutableSetOf<String>()
                fun put(name:String,bytes:ByteArray){check(names.add(name));out.putNextEntry(ZipEntry(name));out.write(bytes);out.closeEntry()}
                val packName=meta.name.trim().ifEmpty{p.name}.take(80);val packDescription=meta.description.trim().ifEmpty{if(p.profile.java)packName else "MCTS resource pack"}.take(240)
                val info=if(p.profile.java){val fmt=JSONObject().put("description",packDescription)
                    if(p.profile.format>=65){fmt.put("min_format",JSONArray(listOf(p.profile.format,0)));fmt.put("max_format",JSONArray(listOf(p.profile.format,p.profile.formatMinor)))}else fmt.put("pack_format",p.profile.format)
                    "pack.mcmeta" to JSONObject().put("pack",fmt)
                }else {
                    val engine=bedrockEngine(p.profile.version)
                    val header=JSONObject().put("name",packName).put("description",packDescription).put("uuid",p.header).put("version",JSONArray(listOf(1,0,0))).put("min_engine_version",JSONArray(engine))
                    val module=JSONObject().put("type","resources").put("uuid",p.module).put("version",JSONArray(listOf(1,0,0)))
                    val manifest=JSONObject().put("format_version",2).put("header",header).put("modules",JSONArray().put(module))
                    if(p.profile.vv&&!colorOnly)manifest.put("capabilities",JSONArray(listOf("pbr")))
                    "manifest.json" to manifest
                };if(!legacy)put(info.first,info.second.toString(2).toByteArray())
                meta.icon?.let{icon->put(if(p.profile.java)"pack.png" else "pack_icon.png",icon)}
                ZipFile(edited).use{zip->zip.entries().asSequence().forEach{entry->
                    if(entry.name in listOf("manifest.json","pack.mcmeta","mcts_export_report.txt"))return@forEach
                    if(!p.profile.java&&!p.profile.vv&&!entry.name.endsWith(".png"))return@forEach
                    if(!p.profile.java&&!p.profile.vv&&(entry.name.endsWith("_mers.png")||entry.name.endsWith("_normal.png")))return@forEach
                    val name=remap[entry.name]?:entry.name
                    var bytes=zip.getInputStream(entry).use{it.readBytes()}
                    if(name.endsWith(".texture_set.json")){
                        val stem=name.substringAfterLast('/').removeSuffix(".texture_set.json")
                        bytes=JSONObject().put("format_version","1.21.30").put("minecraft:texture_set",JSONObject().put("color",stem).put("normal",stem+"_normal").put("metalness_emissive_roughness_subsurface",stem+"_mers")).toString().toByteArray()
                    };put(name,bytes)
                }}
                val base=File(folder(p.id),"base.zip")
                if(base.exists())ZipFile(base).use{zip->zip.entries().asSequence().filter{!it.isDirectory&&it.name !in names&&(!colorOnly||!TemplateArchive.isPbr(it.name))&&!(meta.icon!=null&&it.name in setOf("pack.png","pack_icon.png"))}.forEach{entry->
                    names.add(entry.name);out.putNextEntry(ZipEntry(entry.name));zip.getInputStream(entry).use{it.copyTo(out)};out.closeEntry()
                }}
                put("mcts_export_report.txt",("MCTS ${BuildConfig.VERSION_NAME} · ${p.profile.label}\nAll edits and untouched template textures. Original model/animation behavior is supplied by the game.\n"+
                    if(legacy)"Texture pack for Java ${p.profile.version} (pack.txt). Tiles larger than 16 px need OptiFine/MCPatcher before 1.5.\n" else if(colorOnly)"Color-only resource pack. No normal, height, MER or LabPBR maps generated." else if(!p.profile.java&&!p.profile.vv)"Historical Bedrock: color resources only. PBR remains in the local project. No RenderDragon shader binaries generated." else "Material preview is not an in-game compatibility test. No shader binary compilation.").toByteArray())
            }
            if(legacy)try{LegacyPack.toTexturePack(built,File(folder(p.id),"base.zip"),meta.name.trim().ifEmpty{p.name}.take(80),meta.description.trim().take(240),output)}finally{built.delete()}
        }finally{edited.delete()}
    }
}
/** Template entries shown in the asset browser (internal texture-pack bookkeeping under mcts_legacy/ stays hidden). */
internal fun editableTemplatePath(path:String)=path.startsWith("assets/")||path.startsWith("textures/")
