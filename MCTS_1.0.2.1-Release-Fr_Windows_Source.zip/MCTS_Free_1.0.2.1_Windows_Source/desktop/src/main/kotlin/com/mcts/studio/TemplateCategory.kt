package com.mcts.studio

enum class TemplateCategory(val zh:String,val en:String,val ja:String,val fr:String,val es:String){
    SINGLE_BLOCK("单面方块","Single-face block","単一面ブロック","Bloc à texture unique","Bloque de textura única"),
    MULTI_BLOCK("多面方块","Multi-face block","複数面ブロック","Bloc à plusieurs faces","Bloque de varias caras"),
    PARTIAL_BLOCK("不完整方块","Partial block","部分ブロック","Bloc partiel","Bloque parcial"),
    PLANT("植物","Plant","植物","Plante","Planta"),
    ENTITY("实体","Entity","エンティティ","Entité","Entidad"),
    ITEM_MODEL("物品模型","Item model","アイテムモデル","Modèle d’objet","Modelo de objeto"),
    PARTICLE("粒子效果","Particle","パーティクル","Particule","Partícula"),
    UI("UI","UI","UI","Interface","Interfaz"),
    TEXTURE("贴图","Texture","テクスチャ","Texture","Textura");
    fun label(language:Language)=when(language){Language.ZH->zh;Language.EN->en;Language.JA->ja;Language.FR->fr;Language.ES->es}
    companion object{
        private val partial=Regex("(slab|stairs|fence|wall|door|trapdoor|button|torch|lantern|pane|rail|carpet|sign|banner|bed|chest|shulker|hopper|pot|cauldron|anvil|campfire|candle|chain|rod)")
        private val plant=Regex("(flower|sapling|grass|fern|leaves|crop|wheat|carrot|potato|beetroot|vine|cactus|kelp|mushroom|fungus|coral|bamboo|seagrass|bush|roots)")
        private val sides=Regex("(_top|_bottom|_side|_front|_back|_up|_down|_north|_south|_east|_west)(_[0-9]+)?$")
        fun of(path:String):TemplateCategory{
            val raw=path.substringAfter("textures/");val first=raw.substringBefore('/');val name=raw.substringAfterLast('/').substringBeforeLast('.')
            return when(first){
                "block","blocks"->when{partial.containsMatchIn(name)->PARTIAL_BLOCK;plant.containsMatchIn(name)&&!name.contains("grass_block")&& !name.contains("coral_block")->PLANT;sides.containsMatchIn(name)->MULTI_BLOCK;else->SINGLE_BLOCK}
                "entity"->ENTITY;"item","items"->ITEM_MODEL;"particle"->PARTICLE;"gui","ui"->UI;else->TEXTURE
            }
        }
    }
}
