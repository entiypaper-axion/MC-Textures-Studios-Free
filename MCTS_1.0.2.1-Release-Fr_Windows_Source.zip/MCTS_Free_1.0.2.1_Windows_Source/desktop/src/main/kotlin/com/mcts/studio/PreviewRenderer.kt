package com.mcts.studio

import com.axion.pompreview.PreviewGeometry

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * CPU renderer for the Free "basic" 3D preview. Same camera, mesh, culling, texture orientation and lighting as the
 * Android GL renderer in basic mode: albedo × (0.5 + 0.5·max(N·L, 0)), alpha < 0.1 discarded, nearest sampling with repeat,
 * optional pixel grid; perspective-correct UVs with a depth buffer.
 */
internal object PreviewRenderer {
    private const val STRIDE = PreviewGeometry.FLOATS_PER_VERTEX
    private val LIGHT = floatArrayOf(0.43f, 0.78f, 0.46f).let { val l = sqrt(it[0] * it[0] + it[1] * it[1] + it[2] * it[2]); floatArrayOf(it[0] / l, it[1] / l, it[2] / l) }
    private const val CLEAR = (0xff shl 24) or (6 shl 16) or (8 shl 8) or 12 // (0.025, 0.032, 0.047)
    private val TAN_HALF_FOV = tan(22.0 * kotlin.math.PI / 180.0)

    class Camera(var yaw: Float = 38f, var pitch: Float = 24f, var distance: Float = 4.25f) {
        fun orbit(dYaw: Float, dPitch: Float) { yaw += dYaw; pitch = (pitch + dPitch).coerceIn(-78f, 78f) }
        fun zoom(factor: Float) { distance = (distance * factor).coerceIn(2.55f, 8f) }
    }

    /** Renders into a new ARGB array of [w]×[h]. faces[0..5] are size×size colour maps (top, south, bottom, north, west, east). */
    fun render(mesh: PreviewGeometry.Result, faces: Array<IntArray>, size: Int, w: Int, h: Int, cam: Camera, grid: Boolean): IntArray {
        val out = IntArray(w * h) { CLEAR }
        if (w <= 0 || h <= 0 || size < 1) return out
        val depthBuf = FloatArray(w * h) { Float.POSITIVE_INFINITY }
        val yaw = cam.yaw * kotlin.math.PI / 180.0; val pitch = cam.pitch * kotlin.math.PI / 180.0
        val cy = cos(yaw); val sy = sin(yaw); val cp = cos(pitch); val sp = sin(pitch); val d = cam.distance.toDouble()
        val aspect = w.toDouble() / h
        val v = mesh.vertices
        val sx = DoubleArray(3); val syA = DoubleArray(3); val dz = DoubleArray(3); val tu = DoubleArray(3); val tv = DoubleArray(3)
        var base = 0
        while (base + STRIDE * 3 <= v.size) {
            var valid = true
            for (i in 0 until 3) {
                val off = base + i * STRIDE
                val x = v[off].toDouble(); val y = v[off + 1].toDouble(); val z = v[off + 2].toDouble()
                val depth = d - (x * cp * sy + y * sp + z * cp * cy)
                if (depth <= .1) { valid = false; break }
                val horizontal = x * cy - z * sy
                val vertical = y * cp - (x * sy + z * cy) * sp
                sx[i] = w * (.5 + horizontal / (depth * TAN_HALF_FOV * aspect) * .5)
                syA[i] = h * (.5 - vertical / (depth * TAN_HALF_FOV) * .5)
                dz[i] = depth; tu[i] = v[off + 6].toDouble(); tv[i] = v[off + 7].toDouble()
            }
            if (valid) {
                // Back-face culling (GL default: counter-clockwise front faces; screen y points down).
                val area = (sx[1] - sx[0]) * (syA[2] - syA[0]) - (sx[2] - sx[0]) * (syA[1] - syA[0])
                if (area < 0) {
                    val faceIndex = (v[base + 14].toInt() - 1).coerceIn(0, 5)
                    val nx = v[base + 3]; val ny = v[base + 4]; val nz = v[base + 5]
                    val shade = .5f + .5f * max(nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2], 0f)
                    triangle(out, depthBuf, w, h, sx, syA, dz, tu, tv, faces[faceIndex], size, shade, grid)
                }
            }
            base += STRIDE * 3
        }
        return out
    }

    private fun triangle(out: IntArray, depthBuf: FloatArray, w: Int, h: Int, x: DoubleArray, y: DoubleArray, z: DoubleArray,
                         u: DoubleArray, v: DoubleArray, tex: IntArray, n: Int, shade: Float, grid: Boolean) {
        val minX = max(0, floor(min(x[0], min(x[1], x[2]))).toInt()); val maxX = min(w - 1, ceil(max(x[0], max(x[1], x[2]))).toInt())
        val minY = max(0, floor(min(y[0], min(y[1], y[2]))).toInt()); val maxY = min(h - 1, ceil(max(y[0], max(y[1], y[2]))).toInt())
        if (minX > maxX || minY > maxY) return
        val denom = (y[1] - y[2]) * (x[0] - x[2]) + (x[2] - x[1]) * (y[0] - y[2])
        if (abs(denom) < 1e-9) return
        val iz0 = 1 / z[0]; val iz1 = 1 / z[1]; val iz2 = 1 / z[2]
        val uz0 = u[0] * iz0; val uz1 = u[1] * iz1; val uz2 = u[2] * iz2
        val vz0 = v[0] * iz0; val vz1 = v[1] * iz1; val vz2 = v[2] * iz2
        // Texels per screen pixel (affine approximation, used for the grid line width / fade like fwidth()).
        var gridWidth = 0.0
        if (grid) {
            val dudx = ((u[1] - u[0]) * (y[2] - y[0]) - (u[2] - u[0]) * (y[1] - y[0])) / denom
            val dudy = ((u[2] - u[0]) * (x[1] - x[0]) - (u[1] - u[0]) * (x[2] - x[0])) / denom
            val dvdx = ((v[1] - v[0]) * (y[2] - y[0]) - (v[2] - v[0]) * (y[1] - y[0])) / denom
            val dvdy = ((v[2] - v[0]) * (x[1] - x[0]) - (v[1] - v[0]) * (x[2] - x[0])) / denom
            gridWidth = max(abs(dudx) + abs(dudy), abs(dvdx) + abs(dvdy)) * n
        }
        val lineEdge = max(gridWidth * 0.6, 0.002)
        val fade = 1.0 - smooth(0.25, 1.0, gridWidth)
        for (py in minY..maxY) {
            val cyp = py + .5
            for (px in minX..maxX) {
                val cxp = px + .5
                val a = ((y[1] - y[2]) * (cxp - x[2]) + (x[2] - x[1]) * (cyp - y[2])) / denom
                val b = ((y[2] - y[0]) * (cxp - x[2]) + (x[0] - x[2]) * (cyp - y[2])) / denom
                val c = 1 - a - b
                if (a < 0 || b < 0 || c < 0) continue
                val iz = a * iz0 + b * iz1 + c * iz2
                val depth = (1 / iz).toFloat()
                val idx = py * w + px
                if (depth > depthBuf[idx]) continue
                val uu = (a * uz0 + b * uz1 + c * uz2) / iz
                val vv = (a * vz0 + b * vz1 + c * vz2) / iz
                val fu = uu - floor(uu); val fv = vv - floor(vv)
                val tx = min(n - 1, (fu * n).toInt()); val tyRow = n - 1 - min(n - 1, (fv * n).toInt())
                val p = tex[tyRow * n + tx]
                if ((p ushr 24) < 26) continue // alpha < 0.10 → discard
                depthBuf[idx] = depth
                var r = ((p ushr 16) and 255) * shade; var g = ((p ushr 8) and 255) * shade; var bl = (p and 255) * shade
                if (grid) {
                    val cu = fu * n - floor(fu * n); val cv = fv * n - floor(fv * n)
                    val edge = min(min(cu, 1 - cu), min(cv, 1 - cv))
                    val line = 1 - smooth(0.0, lineEdge, edge)
                    val k = (line * fade * 0.45).toFloat()
                    if (k > 0f) { r += (0.07f * 255 - r) * k; g += (0.20f * 255 - g) * k; bl += (0.24f * 255 - bl) * k }
                }
                out[idx] = (0xff shl 24) or (r.toInt().coerceIn(0, 255) shl 16) or (g.toInt().coerceIn(0, 255) shl 8) or bl.toInt().coerceIn(0, 255)
            }
        }
    }

    private fun smooth(e0: Double, e1: Double, x: Double): Double { val t = ((x - e0) / (e1 - e0)).coerceIn(0.0, 1.0); return t * t * (3 - 2 * t) }
}
