package com.mcts.studio

import com.mcts.studio.compat.Bitmap
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mcts.core.MaterialDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Pixel-exact thumbnail of a template texture (loaded off the main thread, cached in Projects). */
@Composable internal fun TemplateThumb(model:StudioModel,path:String?,size:Dp=36.dp){
    val c=LocalPro.current
    val image by produceState<ImageBitmap?>(null,model.pack.id,path){
        value=if(path==null)null else withContext(Dispatchers.IO){runCatching{model.projectFiles.thumbnail(model.pack,path)?.asImageBitmap()}.getOrNull()}
    }
    Box(Modifier.size(size).clip(RoundedCornerShape(6.dp)).checker(size/6).border(1.dp,c.line,RoundedCornerShape(6.dp)),contentAlignment=Alignment.Center){
        val img=image
        if(img!=null)Image(img,null,Modifier.fillMaxSize(),filterQuality=FilterQuality.None)
        else ProIcon("image",c.tx3,size*.45f)
    }
}

/** Live thumbnail of the open document (header). */
@Composable internal fun DocumentThumb(model:StudioModel,size:Dp){
    val doc=model.document;val revision=model.revision
    val image=remember(doc,revision/4){Bitmap.createBitmap(doc.composite(MaterialDocument.Channel.COLOR),doc.width,doc.height,Bitmap.Config.ARGB_8888).asImageBitmap()}
    Box(Modifier.size(size).clip(RoundedCornerShape(8.dp)).checker(size/6)){Image(image,null,Modifier.fillMaxSize(),filterQuality=FilterQuality.None)}
}

@Composable internal fun ProProjectHeader(model:StudioModel,onProjects:()->Unit){
    val c=LocalPro.current
    Row(Modifier.fillMaxWidth().clickable(enabled=!model.busy,role=androidx.compose.ui.semantics.Role.Button,onClickLabel=model.p("projects")){onProjects()}.padding(start=14.dp,end=8.dp,top=12.dp,bottom=10.dp),
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
        DocumentThumb(model,34.dp)
        Column(Modifier.weight(1f)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Text(model.pack.name,style=MaterialTheme.typography.titleMedium,color=c.tx,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f,fill=false))
                ProIcon("chev_down",c.tx3,14.dp)
            }
            val state=if(model.busy&&!model.quietBusy)model.p("working") else if(model.quietBusy)model.p("saving") else model.p("ready")
            Text("${model.pack.profile.label} · $state",style=MaterialTheme.typography.bodySmall,color=c.tx3,maxLines=1)
        }
    }
}

@Composable internal fun ProPreviewCard(model:StudioModel,height:Dp?,modifier:Modifier=Modifier){
    val c=LocalPro.current
    Column(modifier.fillMaxWidth().then(if(height!=null)Modifier.height(height) else Modifier.fillMaxHeight()).proSurface(GlassKind.PREVIEW,12.dp,c.previewBg)){
        Row(Modifier.fillMaxWidth().padding(start=12.dp,end=4.dp,top=4.dp),verticalAlignment=Alignment.CenterVertically){
            ProIcon("cube",Color(0xffa3aab4),14.dp);Spacer(Modifier.width(6.dp))
            Text(model.p("preview_3d"),style=MaterialTheme.typography.labelMedium,color=Color(0xffa3aab4),modifier=Modifier.weight(1f))
            ProIconButton("rotate",model.p("preview_reload"),model::retryPreview,size=28.dp)
        }
        val missing=remember(model.pack.id,model.cacheRevision,model.modelMesh,model.chooseBlock){model.chooseBlock&&model.templateModelsMissing}
        if(missing)ModelDataHint(model)
        Preview(model,Modifier.fillMaxWidth().weight(1f))
    }
}

/** 1.0.2.1: templates downloaded by 1.0.2 have no model data, so partial blocks use approximate built-in shapes. */
@Composable private fun ModelDataHint(model:StudioModel){
    var confirm by remember{mutableStateOf(false)}
    Row(Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=2.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)){
        Text(model.p("models_missing"),style=MaterialTheme.typography.labelSmall,color=Color(0xffa3aab4),modifier=Modifier.weight(1f),maxLines=2)
        ProButton(model.p("models_get"),{if(model.meteredConfirm&&model.isMetered())confirm=true else model.downloadTemplateModels()},kind=ProKind.GHOST,enabled=!model.busy)
    }
    if(confirm)ProDialog(model,model.p("models_get"),{confirm=false},icon="download"){
        Text(model.t("metered_notice"),style=MaterialTheme.typography.bodyMedium,color=LocalPro.current.tx)
        ProButton(model.p("models_get"),{confirm=false;model.downloadTemplateModels()},kind=ProKind.PRIMARY)
    }
}

/** Sidebar = project header + 素材/图层 tabs + 3D preview (1.0.1 sketch). */
@Composable internal fun ProSidebar(model:StudioModel,onTemplate:(TemplateTexture)->Unit,onDialog:(String)->Unit,onImportLayer:()->Unit,modifier:Modifier=Modifier,showPreview:Boolean=true){
    var tab by rememberSaveable{mutableIntStateOf(0)}
    ProPanel(modifier){
        ProProjectHeader(model){onDialog("projects")}
        ProSegmented(listOf(model.p("tab_assets"),model.p("tab_layers")),tab,{tab=it},Modifier.padding(horizontal=12.dp).fillMaxWidth())
        Box(Modifier.fillMaxWidth().weight(1f).padding(top=10.dp)){
            if(tab==0)ProAssets(model,onTemplate) else ProLayers(model,onImportLayer)
        }
        if(!showPreview)Spacer(Modifier.height(12.dp)) else when(model.previewSize){
            StudioModel.PreviewSize.HIDDEN->Spacer(Modifier.height(12.dp))
            StudioModel.PreviewSize.NORMAL->ProPreviewCard(model,196.dp,Modifier.padding(12.dp))
            StudioModel.PreviewSize.LARGE->ProPreviewCard(model,300.dp,Modifier.padding(12.dp))
        }
    }
}

@Composable private fun AssetRow(model:StudioModel,title:String,subtitle:String,thumb:String?,selected:Boolean,enabled:Boolean,onClick:()->Unit,mark:Boolean=false,enter:Modifier=Modifier){
    val c=LocalPro.current
    val (press,pressMod)=rememberPress(enabled)
    Row(enter.then(pressMod).fillMaxWidth().clip(RoundedCornerShape(9.dp)).background(if(selected)c.accSoft else Color.Transparent)
        .clickable(interactionSource=press.source,indication=androidx.compose.foundation.LocalIndication.current,enabled=enabled,role=androidx.compose.ui.semantics.Role.Button){onClick()}.semantics(mergeDescendants=true){if(selected)this.selected=true}
        .padding(horizontal=8.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
        TemplateThumb(model,thumb)
        Column(Modifier.weight(1f)){
            Text(title,style=MaterialTheme.typography.bodyMedium.copy(fontFamily=ProMono),color=if(enabled)c.tx else c.tx3,maxLines=1,overflow=TextOverflow.Ellipsis)
            Text(subtitle,style=MaterialTheme.typography.bodySmall,color=c.tx3,maxLines=1,overflow=TextOverflow.Ellipsis)
        }
        if(mark)Box(Modifier.size(7.dp).clip(RoundedCornerShape(50)).background(c.acc))
    }
}

/** 1.0.1 asset browser: same data as 1.0.0 (template library / project assets / block groups), denser rows with thumbnails. */
@Composable internal fun ProAssets(model:StudioModel,onTemplate:(TemplateTexture)->Unit){
    val c=LocalPro.current
    var query by remember(model.pack.id){mutableStateOf("")}
    var templates by remember(model.pack.id){mutableStateOf(true)}
    var category by remember{mutableStateOf<TemplateCategory?>(null)}
    var expanded by remember(model.pack.id){mutableStateOf<BlockAsset?>(null)}
    // paths.properties is read once per change, not per row / per recomposition.
    val bindings=remember(model.assets,model.document,model.pack.id){model.projectFiles.paths(model.pack)}
    val currentPath=bindings.getProperty(com.mcts.core.ProjectStore.key(model.document.kind,model.document.name))
    val edited=remember(bindings){model.assets.mapNotNull{bindings.getProperty(it.key)}.toSet()}
    val epoch=rememberListEpoch(model.pack.id,templates,category,expanded)
    Column(Modifier.fillMaxSize().padding(horizontal=12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        ProField(query,{query=it},Modifier.fillMaxWidth(),placeholder=model.p("search_textures"),leading="search")
        ProSegmented(listOf(model.p("project_assets"),model.p("template_library")),if(templates)1 else 0,{templates=it==1;expanded=null},Modifier.fillMaxWidth())
        if(templates){
            val group=expanded.takeIf{model.chooseBlock}
            if(group!=null){
                Row(verticalAlignment=Alignment.CenterVertically){
                    ProIconButton("chev_down",model.p("back"),{expanded=null},Modifier.semantics{},size=28.dp)
                    Text(group.label(model.language),style=MaterialTheme.typography.titleSmall,color=c.tx,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                val textures=group.paths.mapNotNull{path->model.templateTextures.firstOrNull{it.path==path}}
                LazyColumn(Modifier.fillMaxSize()){itemsIndexed(textures,key={_,t->t.path}){i,t->
                    val faces=group.faces.mapIndexedNotNull{face,path->if(path==t.path)model.t("face${face+1}")else null}
                    AssetRow(model,model.assetName(t.path),faces.joinToString(" · ")+" · ${t.width}×${t.height}",t.path,t.path==currentPath,!model.busy&&t.editable&&t.sizes().isNotEmpty(),{onTemplate(t)},mark=t.path in edited,enter=Modifier.enterStagger(i,epoch))
                }}
                return@Column
            }
            val choices=listOf<TemplateCategory?>(null)+TemplateCategory.entries
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                choices.forEach{ch->ProChip(ch?.label(model.language)?:model.p("all"),ch==category,{category=ch})}
            }
            val catalogue=remember(model.pack.id,model.templateTextures){model.blocks()}
            val blocks=if(model.chooseBlock)catalogue.filter{g->(category==null||g.category==category)&&(g.label(model.language).contains(query,true)||g.paths.any{it.contains(query,true)})}else emptyList()
            val used=remember(catalogue,model.chooseBlock){if(model.chooseBlock)catalogue.flatMap{it.paths}.toSet()else emptySet()}
            val textures=model.templateTextures.filter{it.path !in used&&(category==null||it.category==category)&&(query.isBlank()||it.path.contains(query,true)||model.assetName(it.path).contains(query,true))}
            Row{
                Text("${category?.label(model.language)?:model.p("all")} · ${blocks.size+textures.size}",style=MaterialTheme.typography.labelSmall,color=c.tx3,modifier=Modifier.weight(1f))
                Text(model.p("total_count").format(model.templateTextures.size),style=MaterialTheme.typography.labelSmall,color=c.tx3)
            }
            if(model.templateTextures.isEmpty())ProNote(model.p("no_template_textures"))
            LazyColumn(Modifier.fillMaxSize()){
                itemsIndexed(blocks,key={_,g->"block:"+g.id}){i,g->
                    AssetRow(model,g.id,g.label(model.language).substringAfter(" · ")+" · ${g.category.label(model.language)} · "+model.p("faces_count").format(g.paths.size),g.paths.firstOrNull(),g.paths.contains(currentPath),!model.busy,{expanded=g;model.openBlock(g)},mark=g.paths.any{it in edited},enter=Modifier.enterStagger(i,epoch))
                }
                itemsIndexed(textures,key={_,t->t.path}){i,t->
                    val name=model.assetName(t.path)
                    AssetRow(model,name.substringBefore(" · "),name.substringAfter(" · ",name)+" · ${t.category.label(model.language)} · ${t.width}×${t.height}",t.path,t.path==currentPath,!model.busy&&t.editable&&t.sizes().isNotEmpty(),{onTemplate(t)},mark=t.path in edited,enter=Modifier.enterStagger(blocks.size+i,epoch))
                }
            }
        }else{
            val list=model.assets.filter{query.isBlank()||it.name.contains(query,true)}
            if(list.isEmpty())ProNote(model.p("no_project_assets"))
            LazyColumn(Modifier.fillMaxSize()){itemsIndexed(list,key={_,a->a.key}){i,asset->
                val path=bindings.getProperty(asset.key)
                AssetRow(model,if(path!=null)model.assetName(path).substringBefore(" · ") else asset.name,"${model.t(asset.kind.name)} · ${asset.size}",path,
                    asset.name==model.document.name&&asset.kind==model.document.kind,!model.busy,{model.open(asset.key)},mark=true,enter=Modifier.enterStagger(i,epoch))
            }}
        }
    }
}

/** Layers tab: visibility, selection, opacity, add / import, editing resolution. */
@Composable internal fun ProLayers(model:StudioModel,onImportLayer:()->Unit){
    val c=LocalPro.current;val revision=model.revision
    val layers=model.document.layers
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        ProLabel(model.p("layers_count").format(layers.size))
        // Top layer first, as in every editor.
        layers.indices.reversed().forEach{i->
            val layer=layers[i];val on=i==model.activeLayer
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if(on)c.accSoft else c.raised).border(1.dp,if(on)c.acc else Color.Transparent,RoundedCornerShape(10.dp))
                .clickable(enabled=!model.busy,role=androidx.compose.ui.semantics.Role.RadioButton){model.selectLayer(i)}.semantics{selected=on}.padding(horizontal=6.dp,vertical=6.dp),
                verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
                ProIconButton(if(layer.isVisible)"eye" else "eye_off",(if(layer.isVisible)model.p("hide") else model.p("show"))+" "+layer.name,{model.visibility(i,!layer.isVisible)},enabled=!model.busy,size=32.dp)
                Text(layer.name,style=MaterialTheme.typography.bodyMedium,color=if(layer.isVisible)c.tx else c.tx3,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis)
                Text("${(layer.opacity*100).toInt()}%",style=MaterialTheme.typography.labelMedium.copy(fontFamily=ProMono),color=c.tx2)
            }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            ProButton(model.p("add_layer"),model::addLayer,Modifier.weight(1f),icon="plus",enabled=!model.busy&&layers.size<MaterialDocument.MAX_LAYERS)
            ProButton(model.p("import_png_short"),onImportLayer,Modifier.weight(1f),icon="image",enabled=!model.busy&&layers.size<MaterialDocument.MAX_LAYERS)
        }
        ProDivider()
        val active=layers.getOrNull(model.activeLayer)
        if(active!=null){
            Row{ProLabel(model.p("opacity"),Modifier.weight(1f));Text("${(active.opacity*100).toInt()}%",style=MaterialTheme.typography.labelMedium.copy(fontFamily=ProMono),color=c.tx)}
            ProSlider(active.opacity,model::opacity,0f..1f,onValueChangeFinished=model::finishOpacity,description=model.p("opacity")+" "+active.name,enabled=!model.busy)
        }
        val texture=remember(model.document,model.templateTextures){model.currentTemplateTexture()}
        if(texture!=null){
            val sizes=texture.sizes()
            ProLabel(model.p("edit_resolution"))
            ProSegmented(sizes.map{"$it×"},sizes.indexOf(model.document.width),{model.openTemplate(texture,sizes[it])},Modifier.fillMaxWidth(),enabled=!model.busy,mono=true)
            Text(model.p("resolution_hint"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
        }
        Spacer(Modifier.height(8.dp))
    }
}
