package com.mcts.studio

/**
 * Windows wording (zh, en, ja, fr, es). Looked up before every other table by both t() and p(), so texts that talk
 * about fingers, phones, Android or the share sheet read correctly on a PC. Keys that do not mention the platform
 * are not repeated here.
 */
internal object WordsWin {
    private fun w(zh: String, en: String, ja: String, fr: String, es: String) = listOf(zh, en, ja, fr, es)
    fun text(key: String, language: Language): String? = values[key]?.get(language.ordinal)
    val values: Map<String, List<String>> = mapOf(
        // Input
        "gesture_hint" to w("左键画画 · 滚轮缩放 · 中键或按住空格拖动画布 · 右键吸色",
            "Left button paints · wheel zooms · middle button or Space+drag moves · right button picks a colour",
            "左ボタンで描画・ホイールで拡大・中ボタンかSpace+ドラッグで移動・右ボタンでスポイト",
            "Clic gauche peint · molette zoome · clic milieu ou Espace+glisser déplace · clic droit prélève",
            "Clic izquierdo pinta · rueda amplía · botón central o Espacio+arrastrar mueve · clic derecho toma color"),
        "tool_hint_pencil" to w("用主色画像素；右键点画布可临时吸色。","Paints with the main colour; right-click the canvas to pick a colour.","メイン色で描画。右クリックでスポイト。","Peint avec la couleur principale ; clic droit pour prélever.","Pinta con el color principal; clic derecho para tomar color."),
        "tool_hint_move" to w("拖动画布，滚轮缩放（任何工具下按住空格或中键也能拖动）。","Drag to move the canvas, wheel to zoom (Space or the middle button pans with any tool).","ドラッグで移動、ホイールで拡大（Spaceか中ボタンでも移動）。","Glisser pour déplacer, molette pour zoomer (Espace ou clic milieu avec tout outil).","Arrastra para mover, rueda para ampliar (Espacio o botón central con cualquier herramienta)."),
        "tool_hint_picker" to w("点画布取色为主色，取完自动回到画笔。","Click the canvas to pick the main colour, then returns to the pencil.","クリックで色を取り、ペンに戻ります。","Cliquez pour prélever, puis retour au crayon.","Haz clic para tomar el color; luego vuelve al lápiz."),
        "bar_theme_dark" to w("深色模式（单击切换浅色，右键更多）","Dark mode (click for light, right-click for more)","ダーク（クリックでライト、右クリックで詳細）","Mode sombre (clic : clair, clic droit : options)","Modo oscuro (clic: claro, clic derecho: opciones)"),
        "bar_theme_light" to w("浅色模式（单击切换深色，右键更多）","Light mode (click for dark, right-click for more)","ライト（クリックでダーク、右クリックで詳細）","Mode clair (clic : sombre, clic droit : options)","Modo claro (clic: oscuro, clic derecho: opciones)"),
        "theme_hint" to w("顶栏的模式按钮：单击在浅色和深色之间切换，右键（或长按）打开这里。","Top-bar mode button: click toggles light/dark, right-click (or hold) opens this.","上部のボタン：クリックで切替、右クリック（長押し）でここを開きます。","Bouton du haut : clic bascule, clic droit (ou maintien) ouvre ce menu.","Botón superior: clic cambia, clic derecho (o mantener) abre esto."),
        "onboard_4" to w("左键画画，滚轮缩放，中键或空格+拖动移动画布，右键吸色。快捷键可在顶栏「键鼠设置」里改；触屏电脑也支持双指缩放。",
            "Left button paints, the wheel zooms, middle button or Space+drag pans, right button picks a colour. Shortcuts are editable under Keyboard & mouse in the top bar; touch screens can pinch.",
            "左で描画、ホイールで拡大、中ボタンかSpace+ドラッグで移動、右でスポイト。ショートカットは上部バーのキー設定で変更できます。",
            "Clic gauche peint, molette zoome, clic milieu ou Espace+glisser déplace, clic droit prélève. Raccourcis modifiables via Clavier et souris (barre du haut).",
            "Clic izquierdo pinta, rueda amplía, botón central o Espacio+arrastrar mueve, clic derecho toma color. Atajos editables en Teclado y ratón (barra superior)."),
        "long_press_picker_hint" to w("只对触摸屏手指生效；鼠标用右键吸色。","Touch screens only; with a mouse, right-click picks a colour.","タッチ画面のみ。マウスは右クリック。","Écrans tactiles uniquement ; à la souris, clic droit.","Solo pantallas táctiles; con ratón, clic derecho."),
        "stylus_only_hint" to w("防手掌误触：触摸只用来移动和缩放，鼠标和手写笔照常画画。","Palm rejection: touch only moves and zooms; mouse and pen still paint.","タッチは移動と拡大のみ。マウスとペンで描画。","Le toucher ne fait que déplacer/zoomer ; souris et stylet peignent.","El toque solo mueve y amplía; ratón y lápiz pintan."),
        // Saving, sharing, files
        "autosave_hint" to w("按间隔保存，窗口切走或关闭时也会保存。","Saves on an interval, when the window loses focus and when it closes.","一定間隔と、ウィンドウの切替・終了時に保存します。","Enregistre à intervalle, quand la fenêtre perd le focus et à la fermeture.","Guarda a intervalos, al cambiar de ventana y al cerrar."),
        "export_share" to w("导出到 Minecraft","Export to Minecraft","Minecraft へ書き出し","Exporter vers Minecraft","Exportar a Minecraft"),
        "share" to w("导出到 Minecraft","Export to Minecraft","Minecraft へ書き出し","Exporter vers Minecraft","Exportar a Minecraft"),
        "export" to w("导出","Export","書き出し","Exporter","Exportar"),
        "save_to_file" to w("另存为…","Save as…","名前を付けて保存…","Enregistrer sous…","Guardar como…"),
        "win_sent_java" to w("已放进 .minecraft\\resourcepacks，在游戏「选项 → 资源包」里启用即可。","Copied into .minecraft\\resourcepacks. Enable it in Options → Resource Packs.","resourcepacks に入れました。設定→リソースパックで有効にしてください。","Copié dans .minecraft\\resourcepacks. Activez-le dans Options → Packs de ressources.","Copiado en .minecraft\\resourcepacks. Actívalo en Opciones → Paquetes de recursos."),
        "win_sent_bedrock" to w("已交给 Minecraft 导入（文件也保存在“下载”）。导入后在世界设置 → 资源包里启用。","Handed to Minecraft for import (a copy is in Downloads). Then enable it in World Settings → Resource Packs.","Minecraft に読み込みを依頼しました（ダウンロードにも保存）。","Transmis à Minecraft pour import (copie dans Téléchargements).","Enviado a Minecraft para importar (copia en Descargas)."),
        "win_saved_downloads" to w("已保存到“下载”文件夹，资源管理器已打开。","Saved to your Downloads folder and shown in Explorer.","ダウンロードフォルダーに保存し、エクスプローラーで表示しました。","Enregistré dans Téléchargements et affiché dans l’Explorateur.","Guardado en Descargas y mostrado en el Explorador."),
        "win_send_failed" to w("没能复制导出的文件。请改用「另存为…」。","Could not copy the exported file. Use “Save as…” instead.","コピーできませんでした。「名前を付けて保存」をお使いください。","Copie impossible. Utilisez « Enregistrer sous… ».","No se pudo copiar. Usa «Guardar como…»."),
        "export_bedrock_steps" to w("1. 点「导出到 Minecraft」会直接用 Minecraft 打开 .mcpack 并导入；用「另存为…」时，双击保存的 .mcpack 也一样。\n2. 在世界设置 → 资源包中启用。\n如果双击没反应，请确认已安装 Windows 版基岩版。",
            "1. “Export to Minecraft” opens the .mcpack with Minecraft, which imports it; after “Save as…”, double-click the file.\n2. Enable it under World Settings → Resource Packs.\nIf nothing happens, check that Minecraft for Windows (Bedrock) is installed.",
            "1.「Minecraft へ書き出し」で .mcpack を開いて読み込みます。保存した場合はダブルクリック。\n2. ワールド設定→リソースパックで有効にします。",
            "1. « Exporter vers Minecraft » ouvre le .mcpack avec Minecraft ; sinon double-cliquez le fichier.\n2. Activez-le dans Paramètres du monde → Packs de ressources.",
            "1. «Exportar a Minecraft» abre el .mcpack con Minecraft; si no, haz doble clic en el archivo.\n2. Actívalo en Ajustes del mundo → Paquetes de recursos."),
        "export_java_steps" to w("1. 「导出到 Minecraft」会把 ZIP 原样放进 %APPDATA%\\.minecraft\\resourcepacks；用其他启动器时，把 ZIP 放进它的 resourcepacks 文件夹，无需解压。\n2. 打开 Minecraft → 选项 → 资源包并启用。\n3. 确认游戏版本与项目目标一致。",
            "1. “Export to Minecraft” puts the ZIP into %APPDATA%\\.minecraft\\resourcepacks. For other launchers, put the ZIP (not extracted) in their resourcepacks folder.\n2. In Minecraft, open Options → Resource Packs and enable it.\n3. Match the project’s target game version.",
            "1.「Minecraft へ書き出し」で %APPDATA%\\.minecraft\\resourcepacks に入ります。他のランチャーはその resourcepacks へ。\n2. 設定→リソースパックで有効にします。\n3. 対象版を合わせます。",
            "1. « Exporter vers Minecraft » place le ZIP dans %APPDATA%\\.minecraft\\resourcepacks ; pour un autre lanceur, utilisez son dossier resourcepacks.\n2. Options → Packs de ressources.\n3. Utilisez la version ciblée.",
            "1. «Exportar a Minecraft» coloca el ZIP en %APPDATA%\\.minecraft\\resourcepacks; con otro lanzador, usa su carpeta resourcepacks.\n2. Opciones → Paquetes de recursos.\n3. Usa la versión elegida."),
        "export_next" to w("下一步：用「另存为…」换一个文件夹（如“下载”），检查磁盘剩余空间，再试一次。","Next: use “Save as…” with another folder (such as Downloads), check free disk space, then retry.","別のフォルダー（ダウンロード等）に保存し直し、空き容量を確認してください。","Utilisez « Enregistrer sous… » vers un autre dossier et vérifiez l’espace disque.","Usa «Guardar como…» en otra carpeta y comprueba el espacio en disco."),
        "import_clipboard_hint" to w("截图工具或浏览器“复制图片”后的图片，或复制的 PNG 文件。","An image copied from the Snipping Tool or a browser, or a copied PNG file.","切り取りツールやブラウザーでコピーした画像、またはコピーした PNG ファイル。","Une image copiée (Outil Capture, navigateur) ou un fichier PNG copié.","Una imagen copiada (Recortes, navegador) o un archivo PNG copiado."),
        "drop_busy" to w("正在处理，请稍后再拖入文件。","Busy — drop the file again in a moment.","処理中です。少し待ってからもう一度。","Occupé — redéposez le fichier dans un instant.","Ocupado: vuelve a soltar el archivo en un momento."),
        "drop_open_project" to w("先打开一个项目，再把图片拖进来作为新图层。","Open a project first, then drop the image to add it as a layer.","プロジェクトを開いてから画像をドロップしてください。","Ouvrez d’abord un projet, puis déposez l’image.","Abre primero un proyecto y luego suelta la imagen."),
        "drop_unknown" to w("支持拖入 .zip / .mcpack 资源包、PNG/JPG 图片和 .mctslayout.json 布局。","Drop a .zip / .mcpack pack, a PNG/JPG image or a .mctslayout.json layout.",".zip / .mcpack、PNG/JPG、.mctslayout.json をドロップできます。","Déposez un pack .zip / .mcpack, une image PNG/JPG ou un .mctslayout.json.","Suelta un paquete .zip / .mcpack, una imagen PNG/JPG o un .mctslayout.json."),
        // Feedback, diagnostics
        "feedback_hint" to w("反馈时请附上 Windows 版本、操作步骤和截图。","Please include your Windows version, steps and a screenshot.","Windows のバージョン、手順、スクリーンショットを添えてください。","Indiquez la version de Windows, les étapes et une capture.","Incluye la versión de Windows, los pasos y una captura."),
        "feedback_screenshot" to w("截取窗口用于反馈","Screenshot for feedback","フィードバック用スクリーンショット","Capture pour un retour","Captura para comentarios"),
        "feedback_screenshot_hint" to w("截取 MCTS 窗口存到“下载”，诊断信息同时复制到剪贴板（不含项目文件）。","Saves a picture of the MCTS window to Downloads and copies diagnostics to the clipboard (no project files).","ウィンドウをダウンロードに保存し、診断情報をコピーします。","Enregistre la fenêtre dans Téléchargements et copie le diagnostic.","Guarda la ventana en Descargas y copia el diagnóstico."),
        "win_screenshot_saved" to w("截图已存到“下载”，诊断信息已复制，可直接粘贴到反馈里。","Screenshot saved to Downloads; diagnostics copied — paste them into your report.","ダウンロードに保存し、診断情報をコピーしました。","Capture enregistrée ; diagnostic copié.","Captura guardada; diagnóstico copiado."),
        "diagnostics_hint" to w("仅含应用版本、Windows 版本、Java 运行时、语言和最近错误码；不含任何项目内容、账号或文件路径。复制后可自行粘贴反馈，不会自动上传。","Includes app version, Windows version, Java runtime, language and last error code only. No project content, accounts or paths. Nothing is uploaded automatically.","アプリ・Windows・Java の版、言語、最新エラーコードのみ。自動送信しません。","Version de l’app, de Windows, du runtime Java, langue et dernier code d’erreur uniquement. Aucun envoi automatique.","Solo versión de app, Windows y Java, idioma y último código de error. Nada se sube automáticamente."),
        "error_preview" to w("立体预览未能启动。请重试；若仍失败，请重启应用并反馈。平面绘画与保存仍可使用。","3D preview could not start. Retry, or restart the app and report it. You can still paint and save on the flat canvas.","3D表示を開始できません。再試行か再起動をお試しください。","Impossible de démarrer l’aperçu 3D. Réessayez ou redémarrez.","No se pudo iniciar la vista 3D. Reintenta o reinicia."),
        // Templates, downloads
        "template_reason" to w("官方素材由你的电脑从标注的 Mojang 下载源获取，旧基岩版使用样例归档；我们不托管官方纹理。仅需下载一次，准备好后即可离线创作。","Your PC downloads assets from the listed Mojang sources; older Bedrock uses an archived sample. We do not host official textures. Download once, then create offline.","PC が表示された Mojang 配布元から取得します。一度取得すればオフラインで制作できます。","Votre PC télécharge depuis les sources Mojang indiquées. Un téléchargement suffit pour créer hors ligne.","Tu PC descarga desde las fuentes Mojang indicadas. Descarga una vez y crea sin conexión."),
        "download_tls" to w("无法建立安全连接。请检查电脑日期时间、代理和网络后重试。","Could not establish a secure connection. Check the PC’s date and time, proxy and network, then retry.","安全な接続を確立できません。日付・プロキシ・ネットワークを確認してください。","Connexion sécurisée impossible. Vérifiez la date, le proxy et le réseau.","No se pudo establecer una conexión segura. Comprueba fecha, proxy y red."),
        "background_hint" to w("下载时可以最小化窗口；关闭窗口会取消下载。","You can minimise the window while downloading; closing it cancels the download.","ダウンロード中は最小化できます。閉じると中止します。","Vous pouvez réduire la fenêtre ; la fermer annule le téléchargement.","Puedes minimizar la ventana; cerrarla cancela la descarga."),
        "metered_confirm" to w("按流量计费的网络下载前确认","Ask before downloading on a metered connection","従量制課金接続では確認","Confirmer sur une connexion limitée","Confirmar en conexión de uso medido"),
        // Liquid glass
        "glass_unsupported" to w("显卡驱动无法运行液态玻璃着色器，已改用 1.0.1 的界面。更新显卡驱动后可再试。","The graphics driver could not run the liquid-glass shader, so the 1.0.1 look is used. Update the driver and try again.","グラフィックドライバーがシェーダーを実行できないため 1.0.1 の外観を使います。","Le pilote graphique ne peut pas exécuter le shader : apparence 1.0.1.","El controlador gráfico no puede ejecutar el sombreador: se usa el aspecto 1.0.1."),
        "glass_hint" to w("面板、图标和控件变成可折射的厚玻璃，透出下面实时的界面和画布。显卡占用略高，默认关闭。",
            "Panels, icons and controls become thick refracting glass that shows the live interface and canvas beneath. Uses a little more GPU; off by default.",
            "パネル・アイコン・操作部が屈折する厚いガラスになり、下のライブ画面とキャンバスが透けます。既定はオフ。",
            "Panneaux, icônes et commandes en verre épais qui laisse voir l’interface et le canevas en direct. Désactivé par défaut.",
            "Paneles, iconos y controles de vidrio grueso que dejan ver la interfaz y el lienzo en vivo. Desactivado por defecto."),
        // Layout
        "custom_ui_hint" to w("每个板块和按钮组都能拖到任意位置、拖角缩放、叠放。窗口横宽和竖长各存一套，可存多套预设并导出分享。","Every panel and button group can be moved anywhere, resized from its corners and stacked. Wide and tall windows keep separate presets you can share.","すべてのパネルとボタン群を自由に移動・拡大縮小・重ねられます。横長・縦長のウィンドウで別々に保存します。","Chaque panneau se déplace, se redimensionne et s’empile. Préréglages séparés fenêtre large / haute.","Cada panel se mueve, redimensiona y apila. Ajustes separados para ventana ancha / alta."),
        "orientation_landscape" to w("横宽窗口","wide window","横長ウィンドウ","fenêtre large","ventana ancha"),
        "orientation_portrait" to w("竖长窗口","tall window","縦長ウィンドウ","fenêtre haute","ventana alta"),
        "hand_hint_101" to w("窄窗口布局下，底部工具栏会靠向所选的手（适合触屏电脑）。","In the narrow-window layout the bottom toolbar moves toward the chosen hand (for touch PCs).","狭いウィンドウでは下部ツールが選んだ手側に寄ります。","En fenêtre étroite, la barre du bas suit la main choisie.","En ventana estrecha, la barra inferior se acerca a la mano elegida."),
        "phone" to w("窄窗口","Narrow","狭い","Étroite","Estrecha"),
        "tablet" to w("宽窗口","Wide","広い","Large","Ancha"),
        "a11y_haptics_hint" to w("按下按钮和切换工具时的轻微震动；大多数电脑没有震动硬件，此时不起作用。","A light tick on buttons and tool changes; most PCs have no vibration hardware.","ボタンとツール切替で軽く振動（多くのPCでは無効）。","Légère vibration (sans effet sur la plupart des PC).","Vibración leve (sin efecto en la mayoría de PC)."),
        "a11y_motion_hint" to w("关闭非必要动效。Windows「设置 → 辅助功能 → 视觉效果 → 动画效果」关闭时也会自动关闭。","Turns off non-essential motion. Also off automatically when Windows Animation effects are off.","不要な動きを止めます。Windows のアニメーション効果がオフの時も自動でオフ。","Désactive les animations non essentielles, aussi quand les effets d’animation de Windows sont désactivés.","Desactiva movimientos no esenciales; también si los efectos de animación de Windows están desactivados."),
        "layout_device" to w("窗口布局","Window layout","ウィンドウレイアウト","Disposition de la fenêtre","Diseño de la ventana"),
    )
}
