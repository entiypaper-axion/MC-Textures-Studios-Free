package com.mcts.studio

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private fun mb(bytes:Long)="%.1f MB".format(bytes/1048576f)

/** New-project form (start screen sidebar, per the 1.0.1 sketch). */
@Composable private fun NewProjectForm(model:StudioModel,launchers:ProLaunchers,onDialog:(String)->Unit,modifier:Modifier,scroll:Boolean=true){
    val c=LocalPro.current
    var profileId by rememberSaveable{mutableStateOf(model.templateProfileId.takeIf{id->offeredProfiles.any{it.id==id}}?:"java_12111")}
    LaunchedEffect(profileId){model.rememberTemplateChoice(profileId)}
    val profile=profileById(profileId)?:offeredProfiles.first()
    var name by rememberSaveable{mutableStateOf("My resource pack")}
    var confirmMetered by remember{mutableStateOf(false)}
    val ready=profile.id in model.availableTemplates
    fun download(){if(model.meteredConfirm&&model.isMetered())confirmMetered=true else model.prepareTemplate(profile)}
    ProPanel(modifier){
        Column(Modifier.fillMaxWidth().then(if(scroll)Modifier.fillMaxSize().verticalScroll(rememberScrollState())else Modifier).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Text(model.p("new_project"),style=MaterialTheme.typography.headlineSmall,color=c.tx,modifier=Modifier.semantics{heading()})
            ProLabel(model.p("game_version"))
            ProSegmented(listOf(model.p("java_edition"),model.p("bedrock_edition")),if(profile.java)0 else 1,{i->
                val wantJava=i==0
                if(wantJava!=profile.java)profileId=(profile.counterpart()?:offeredProfiles.last{it.java==wantJava}).id
            },Modifier.fillMaxWidth(),enabled=!model.busy)
            ProVersionPicker(model,profile,{profileId=it.id},enabled=!model.busy){p->
                val size=model.projectFiles.templates.expectedSize(p)
                when{p.id in model.availableTemplates->"✓ "+model.p("downloaded");size>0->mb(size);else->model.p("not_downloaded")}
            }
            ProVersionNotes(model,profile)
            ProNote(model.t("template_notice")+" "+model.p("source_note"))
            if(model.downloading){
                Text(model.t(model.downloadStage),style=MaterialTheme.typography.bodyMedium,color=c.tx,modifier=Modifier.semantics{liveRegion=LiveRegionMode.Polite})
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(c.raised)){
                    Box(Modifier.fillMaxHeight().fillMaxWidth(model.progress.coerceIn(.02f,1f)).background(c.acc))
                }
                if(model.downloadBytes>0)Text(mb(model.downloadBytes)+if(model.downloadTotal>0)" / "+mb(model.downloadTotal) else "",style=MaterialTheme.typography.labelMedium.copy(fontFamily=ProMono),color=c.tx3)
                Text(model.t("background_hint"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
                ProButton(model.t("cancel"),model::cancelDownload,kind=ProKind.GHOST)
            }else if(!ready){
                val partial=model.projectFiles.templates.partialBytes(profile)
                if(partial>0)Text(model.t("resume_download")+": "+mb(partial),style=MaterialTheme.typography.bodySmall,color=c.tx3)
                ProButton(model.t("template_download"),{download()},Modifier.fillMaxWidth(),icon="download",kind=ProKind.PRIMARY,enabled=!model.busy)
            }
            model.downloadError?.let{key->
                Text(model.t(key),style=MaterialTheme.typography.bodySmall,color=c.danger,modifier=Modifier.clip(RoundedCornerShape(10.dp)).background(c.danger.copy(alpha=.1f)).padding(10.dp).semantics{liveRegion=LiveRegionMode.Assertive})
                if(!ready&&!model.downloading)ProButton(model.t("retry"),{download()},kind=ProKind.GHOST,icon="rotate")
            }
            ProLabel(model.p("project_name"))
            ProField(name,{name=it.take(80)},Modifier.fillMaxWidth(),placeholder=model.t("project_name"),enabled=!model.busy)
            Spacer(Modifier.height(4.dp))
            ProButton(model.t("start_create"),{model.createPack(name,profile,true)},Modifier.fillMaxWidth(),icon="plus",kind=ProKind.PRIMARY,enabled=!model.busy&&ready&&name.isNotBlank())
            ProButton(model.t("start_resume"),model::continueEditing,Modifier.fillMaxWidth(),enabled=!model.busy)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                ProButton(model.t("cache_manage"),{onDialog("cache")},Modifier.weight(1f),kind=ProKind.GHOST)
                ProButton(model.t("about_notice"),{onDialog("about")},Modifier.weight(1f),kind=ProKind.GHOST)
            }
            Text(model.t("free_export_color"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
        }
    }
    if(confirmMetered)ProDialog(model,model.t("template_download"),{confirmMetered=false},width=420.dp,icon="download"){
        Text(model.t("metered_notice"),style=MaterialTheme.typography.bodyMedium,color=c.tx)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            ProButton(model.t("template_download"),{confirmMetered=false;model.prepareTemplate(profile)},kind=ProKind.PRIMARY)
            ProButton(model.t("cancel"),{confirmMetered=false},kind=ProKind.GHOST)
        }
    }
}

private val stonePaths=listOf("assets/minecraft/textures/block/stone.png","assets/minecraft/textures/blocks/stone.png","textures/blocks/stone.png")

@Composable private fun ProjectCard(model:StudioModel,project:PackProject,onActions:()->Unit,modifier:Modifier){
    val c=LocalPro.current
    val (press,pressMod)=rememberPress(!model.busy)
    Column(modifier.then(pressMod).proSurface(GlassKind.PANEL,14.dp,c.group)
        .clickable(interactionSource=press.source,indication=LocalIndication.current,enabled=!model.busy,role=Role.Button,onClickLabel=model.p("open")){model.openPack(project)}){
        Box(Modifier.fillMaxWidth().height(120.dp).background(if(glassOn)Color.Black.copy(alpha=.28f) else c.previewBg),contentAlignment=Alignment.Center){
            // Thumbnail: the project's own stone texture (falls back to an icon for blank projects).
            ProjectThumb(model,project)
        }
        Row(Modifier.fillMaxWidth().padding(start=12.dp,end=4.dp,top=8.dp,bottom=8.dp),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){
                Text(project.name,style=MaterialTheme.typography.titleSmall,color=c.tx,maxLines=1,overflow=TextOverflow.Ellipsis)
                Text(project.profile.label,style=MaterialTheme.typography.bodySmall,color=c.tx3)
            }
            ProIconButton("more",model.p("project_actions"),onActions,size=32.dp)
        }
    }
}

@Composable private fun ProjectThumb(model:StudioModel,project:PackProject){
    val image by produceState<ImageBitmap?>(null,project.id){
        value=withContext(Dispatchers.IO){runCatching{stonePaths.firstNotNullOfOrNull{path->model.projectFiles.thumbnail(project,path)}?.asImageBitmap()}.getOrNull()}
    }
    val img=image
    if(img!=null)Image(img,null,Modifier.size(72.dp).clip(RoundedCornerShape(8.dp)),filterQuality=FilterQuality.None)
    else ProIcon("cube",Color(0xffa3aab4),40.dp)
}

/** Start screen = new-project form (left panel) + recent projects (right area). */
@Composable internal fun ProStart(model:StudioModel,onDialog:(String)->Unit,launchers:ProLaunchers,phone:Boolean,modifier:Modifier){
    val c=LocalPro.current
    var query by rememberSaveable{mutableStateOf("")}
    var actions by remember{mutableStateOf<PackProject?>(null)}
    val projects=model.packs.filter{query.isBlank()||it.name.contains(query,true)}
    @Composable fun Recent(mod:Modifier){
        Column(mod.proSurface(GlassKind.WORK,14.dp,c.work).padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(14.dp)){
                McTsLogo(Modifier.size(48.dp))
                Column(Modifier.weight(1f)){
                    Text("MCTS Free",style=MaterialTheme.typography.headlineSmall,color=c.tx)
                    Text(BuildConfig.VERSION_NAME,style=MaterialTheme.typography.labelMedium.copy(fontFamily=ProMono),color=c.tx3)
                }
                if(!phone)ProField(query,{query=it},Modifier.width(240.dp),placeholder=model.p("search_projects"),leading="search")
            }
            if(phone)ProField(query,{query=it},Modifier.fillMaxWidth(),placeholder=model.p("search_projects"),leading="search")
            Row(verticalAlignment=Alignment.Bottom,horizontalArrangement=Arrangement.spacedBy(10.dp)){
                Text(model.p("recent_projects"),style=MaterialTheme.typography.titleMedium,color=c.tx)
                Text(model.p("projects_count").format(projects.size),style=MaterialTheme.typography.bodySmall,color=c.tx3)
            }
            val columns=if(phone)2 else 3
            val epoch=rememberListEpoch(query)
            (projects.map<PackProject,PackProject?>{it}+listOf(null)).chunked(columns).forEachIndexed{r,row->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(14.dp)){
                    row.forEachIndexed{i,p->
                        if(p!=null)ProjectCard(model,p,{actions=p},Modifier.weight(1f).enterStagger(r*columns+i,epoch))
                        else Column(Modifier.weight(1f).height(170.dp).clip(RoundedCornerShape(14.dp)).border(1.5.dp,c.line,RoundedCornerShape(14.dp))
                            .clickable(enabled=!model.busy,role=Role.Button){launchers.importPack()},horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp,Alignment.CenterVertically)){
                            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(c.raised),contentAlignment=Alignment.Center){ProIcon("import",c.tx2,22.dp)}
                            Text(model.p("import_pack"),style=MaterialTheme.typography.labelLarge,color=c.tx2)
                            Text(".zip / .mcpack",style=MaterialTheme.typography.bodySmall,color=c.tx3)
                        }
                    }
                    repeat(columns-row.size){Spacer(Modifier.weight(1f))}
                }
            }
        }
    }
    if(phone)Column(modifier.verticalScroll(rememberScrollState()).padding(8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        NewProjectForm(model,launchers,onDialog,Modifier.fillMaxWidth(),scroll=false)
        Recent(Modifier.fillMaxWidth())
    }else Row(modifier.padding(start=12.dp,end=12.dp,bottom=12.dp,top=7.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
        NewProjectForm(model,launchers,onDialog,Modifier.width(328.dp).fillMaxHeight())
        Box(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())){Recent(Modifier.fillMaxWidth())}
    }
    actions?.let{project->
        var mode by remember(project.id){mutableStateOf("")}
        var name by remember(project.id){mutableStateOf(project.name)}
        ProDialog(model,project.name,{actions=null},width=440.dp,icon="project"){
            ProButton(model.p("open"),{actions=null;model.openPack(project)},Modifier.fillMaxWidth(),kind=ProKind.PRIMARY,enabled=!model.busy)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                ProButton(model.t("project_rename"),{mode="rename";name=project.name},Modifier.weight(1f),enabled=!model.busy)
                ProButton(model.t("project_copy"),{mode="copy";name=project.name.take(72)+" (copy)"},Modifier.weight(1f),enabled=!model.busy)
                ProButton(model.t("project_delete"),{mode="delete"},Modifier.weight(1f),kind=ProKind.DANGER,enabled=!model.busy)
            }
            if(mode=="rename"||mode=="copy"){
                ProField(name,{name=it.take(80)},Modifier.fillMaxWidth(),placeholder=model.t("project_name"))
                ProButton(model.t(if(mode=="rename")"project_rename" else "project_copy"),{if(mode=="rename")model.renamePack(project,name)else model.duplicatePack(project,name);actions=null},
                    kind=ProKind.PRIMARY,enabled=!model.busy&&name.isNotBlank())
            }
            if(mode=="delete"){
                Text(model.t("project_delete_confirm"),style=MaterialTheme.typography.bodyMedium,color=c.danger)
                ProButton(model.t("project_delete"),{model.deletePack(project);actions=null},kind=ProKind.DANGER,enabled=!model.busy)
            }
        }
    }
}
