package com.mcts.studio

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/** 24-dp line icons (1.75 stroke, round caps) shared with the 1.0.1 design files. Generated from the icon set; edit the SVGs, not this table. */
internal object ProIcons {
    /** kind: S = stroke, F = fill, FS = fill + stroke. */
    private class Part(val kind:String,val d:String,val alpha:Float,val width:Float)
    private val table:Map<String,List<Part>> = mapOf(
        "project" to listOf(Part("S","M3 7.5A1.5 1.5 0 0 1 4.5 6H9l2 2h8.5A1.5 1.5 0 0 1 21 9.5v8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5z",1.0f,1.75f)),
        "import" to listOf(Part("S","M12 3.5v10.5",1.0f,1.75f),Part("S","M7.5 9.5 12 14l4.5-4.5",1.0f,1.75f),Part("S","M4 14v4.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V14",1.0f,1.75f)),
        "export" to listOf(Part("S","M12 14.5V4",1.0f,1.75f),Part("S","M7.5 8.5 12 4l4.5 4.5",1.0f,1.75f),Part("S","M4 14v4.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V14",1.0f,1.75f)),
        "brush_settings" to listOf(Part("S","M12.2 11.8 19 5a1.45 1.45 0 0 1 2.05 2.05L14.2 13.8",1.0f,1.75f),Part("S","M10.6 13c-2.2 0-4 1.6-4 3.6 0 1.4-1 2.4-2.6 2.4 1.2 1.3 2.8 2 4.6 2 2.5 0 4.5-2 4.5-4.5 0-1.9-1.1-3.5-2.5-3.5z",1.0f,1.75f),Part("S","M3 5h6.5",1.0f,1.75f),Part("S","M3 9.5h6.5",1.0f,1.75f),Part("FS","M5.4 5a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0z",1.0f,1.75f),Part("FS","M3.2 9.5a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0z",1.0f,1.75f)),
        "new" to listOf(Part("S","M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z",1.0f,1.75f),Part("S","M14 3v5h5",1.0f,1.75f),Part("S","M12 11.5v6",1.0f,1.75f),Part("S","M9 14.5h6",1.0f,1.75f)),
        "delete" to listOf(Part("S","M4 7h16",1.0f,1.75f),Part("S","M9.5 7V4.8c0-.45.35-.8.8-.8h3.4c.45 0 .8.35.8.8V7",1.0f,1.75f),Part("S","M6.5 7l.8 12.2A2 2 0 0 0 9.3 21h5.4a2 2 0 0 0 2-1.8L17.5 7",1.0f,1.75f),Part("S","M10.2 11v6",1.0f,1.75f),Part("S","M13.8 11v6",1.0f,1.75f)),
        "ui_layout" to listOf(Part("S","M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2z",1.0f,1.75f),Part("S","M3 9h18",1.0f,1.75f),Part("S","M9 9v11",1.0f,1.75f)),
        "canvas_left" to listOf(Part("S","M4 3v18",1.0f,1.75f),Part("S","M9 7h7a1.5 1.5 0 0 1 1.5 1.5v7a1.5 1.5 0 0 1 -1.5 1.5h-7a1.5 1.5 0 0 1 -1.5 -1.5v-7a1.5 1.5 0 0 1 1.5 -1.5z",1.0f,1.75f)),
        "canvas_center" to listOf(Part("S","M12 3v4",1.0f,1.75f),Part("S","M12 17v4",1.0f,1.75f),Part("S","M8.5 7h7a1.5 1.5 0 0 1 1.5 1.5v7a1.5 1.5 0 0 1 -1.5 1.5h-7a1.5 1.5 0 0 1 -1.5 -1.5v-7a1.5 1.5 0 0 1 1.5 -1.5z",1.0f,1.75f)),
        "canvas_right" to listOf(Part("S","M20 3v18",1.0f,1.75f),Part("S","M8 7h7a1.5 1.5 0 0 1 1.5 1.5v7a1.5 1.5 0 0 1 -1.5 1.5h-7a1.5 1.5 0 0 1 -1.5 -1.5v-7a1.5 1.5 0 0 1 1.5 -1.5z",1.0f,1.75f)),
        "keyboard_mouse" to listOf(Part("S","M3.5 8h10a1.5 1.5 0 0 1 1.5 1.5v6a1.5 1.5 0 0 1 -1.5 1.5h-10a1.5 1.5 0 0 1 -1.5 -1.5v-6a1.5 1.5 0 0 1 1.5 -1.5z",1.0f,1.75f),Part("S","M5 11h.01M8.5 11h.01M12 11h.01",1.0f,2.5f),Part("S","M5.5 14h6",1.0f,1.75f),Part("S","M19.5 6.5h0a2.5 2.5 0 0 1 2.5 2.5v6a2.5 2.5 0 0 1 -2.5 2.5h0a2.5 2.5 0 0 1 -2.5 -2.5v-6a2.5 2.5 0 0 1 2.5 -2.5z",1.0f,1.75f),Part("S","M19.5 9v2",1.0f,1.75f)),
        "accessibility" to listOf(Part("S","M2.75 12a9.25 9.25 0 1 0 18.5 0a9.25 9.25 0 1 0 -18.5 0z",1.0f,1.75f),Part("S","M12 7.3h.01",1.0f,2.6f),Part("S","M7.5 10l4.5 1 4.5-1",1.0f,1.75f),Part("S","M12 11v3.5",1.0f,1.75f),Part("S","M12 14.5 9.6 18.3M12 14.5l2.4 3.8",1.0f,1.75f)),
        "label_toggle" to listOf(Part("S","M3.5 4.5h8M7.5 4.5v8",1.0f,1.75f),Part("S","M14.5 13h4.5a1.5 1.5 0 0 1 1.5 1.5v4.5a1.5 1.5 0 0 1 -1.5 1.5h-4.5a1.5 1.5 0 0 1 -1.5 -1.5v-4.5a1.5 1.5 0 0 1 1.5 -1.5z",1.0f,1.75f),Part("S","M14.5 5.5h2a2.5 2.5 0 0 1 2.5 2.5v1.5",1.0f,1.75f),Part("S","M17.3 7.8 19 9.5l1.7-1.7",1.0f,1.75f),Part("S","M10 18.5H7.5A2.5 2.5 0 0 1 5 16v-1",1.0f,1.75f),Part("S","M6.7 16.2 5 14.5l-1.7 1.7",1.0f,1.75f)),
        "guide" to listOf(Part("S","M2.75 12a9.25 9.25 0 1 0 18.5 0a9.25 9.25 0 1 0 -18.5 0z",1.0f,1.75f),Part("S","M9.6 9.4a2.5 2.5 0 0 1 4.85.85c0 1.7-2.45 2.15-2.45 3.6",1.0f,1.75f),Part("S","M12 17h.01",1.0f,2.5f)),
        "theme_light" to listOf(Part("S","M8.2 12a3.8 3.8 0 1 0 7.6 0a3.8 3.8 0 1 0 -7.6 0z",1.0f,1.75f),Part("S","M18.30 12.00L20.60 12.00",1.0f,1.75f),Part("S","M16.45 16.45L18.08 18.08",1.0f,1.75f),Part("S","M12.00 18.30L12.00 20.60",1.0f,1.75f),Part("S","M7.55 16.45L5.92 18.08",1.0f,1.75f),Part("S","M5.70 12.00L3.40 12.00",1.0f,1.75f),Part("S","M7.55 7.55L5.92 5.92",1.0f,1.75f),Part("S","M12.00 5.70L12.00 3.40",1.0f,1.75f),Part("S","M16.45 7.55L18.08 5.92",1.0f,1.75f)),
        "theme_dark" to listOf(Part("S","M20 14.6A8.2 8.2 0 1 1 9.4 4a6.4 6.4 0 0 0 10.6 10.6z",1.0f,1.75f)),
        "language" to listOf(Part("S","M2.75 12a9.25 9.25 0 1 0 18.5 0a9.25 9.25 0 1 0 -18.5 0z",1.0f,1.75f),Part("S","M2.75 12h18.5",1.0f,1.75f),Part("S","M12 2.75c2.5 2.6 3.8 5.7 3.8 9.25s-1.3 6.65-3.8 9.25C9.5 18.65 8.2 15.55 8.2 12S9.5 5.35 12 2.75z",1.0f,1.75f)),
        "home" to listOf(Part("S","M3.5 10.5 12 3.5l8.5 7",1.0f,1.75f),Part("S","M5.5 9v10a1.5 1.5 0 0 0 1.5 1.5h3.5v-6h3v6H17a1.5 1.5 0 0 0 1.5-1.5V9",1.0f,1.75f)),
        "feedback" to listOf(Part("S","M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v10a1.5 1.5 0 0 1-1.5 1.5H9l-4.2 3.4A.5.5 0 0 1 4 20z",1.0f,1.75f),Part("S","M12 7.5v4",1.0f,1.75f),Part("S","M12 14h.01",1.0f,2.5f)),
        "settings" to listOf(Part("S","M21.35 11.08L21.35 12.92L18.70 14.03L18.17 15.30L19.27 17.96L17.96 19.27L15.30 18.17L14.03 18.70L12.92 21.35L11.08 21.35L9.97 18.70L8.70 18.17L6.04 19.27L4.73 17.96L5.83 15.30L5.30 14.03L2.65 12.92L2.65 11.08L5.30 9.97L5.83 8.70L4.73 6.04L6.04 4.73L8.70 5.83L9.97 5.30L11.08 2.65L12.92 2.65L14.03 5.30L15.30 5.83L17.96 4.73L19.27 6.04L18.17 8.70L18.70 9.97Z",1.0f,1.75f),Part("S","M9 12a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z",1.0f,1.75f)),
        "erase_alpha" to listOf(Part("S","M6 4h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2z",1.0f,1.75f),Part("F","M4 4h8v8H4zM12 12h8v8h-8z",0.35f,1.75f),Part("S","M8 16 16 8",1.0f,1.75f)),
        "swap" to listOf(Part("S","M7 4 4 7l3 3",1.0f,1.75f),Part("S","M4 7h11a4 4 0 0 1 4 4v1",1.0f,1.75f),Part("S","M17 20l3-3-3-3",1.0f,1.75f),Part("S","M20 17H9a4 4 0 0 1-4-4v-1",1.0f,1.75f)),
        "pencil" to listOf(Part("S","M4 20l1-4L15.5 5.5a2.12 2.12 0 0 1 3 3L8 19z",1.0f,1.75f),Part("S","M13.5 7.5l3 3",1.0f,1.75f)),
        "eraser" to listOf(Part("S","M9 20h11",1.0f,1.75f),Part("S","M5.2 15.8 14.6 6.4a2 2 0 0 1 2.8 0l2.2 2.2a2 2 0 0 1 0 2.8L11 20H8.5l-3.3-3.3a.64.64 0 0 1 0-.9z",1.0f,1.75f),Part("S","M9.6 11.4l5 5",1.0f,1.75f)),
        "fill" to listOf(Part("S","M5.1 11.4 11.5 5l7 7-6.4 6.4a1.5 1.5 0 0 1-2.1 0l-4.9-4.9a1.5 1.5 0 0 1 0-2.1z",1.0f,1.75f),Part("S","M5 12.2h13.4",1.0f,1.75f),Part("S","M8.5 2.5 11.5 5",1.0f,1.75f),Part("S","M20.3 15.6s1.6 1.9 1.6 3.1a1.6 1.6 0 0 1-3.2 0c0-1.2 1.6-3.1 1.6-3.1z",1.0f,1.75f)),
        "picker" to listOf(Part("S","M13.6 8.4 6.5 15.5v2h2l7.1-7.1",1.0f,1.75f),Part("S","M14.6 5.6l3.8 3.8",1.0f,1.75f),Part("S","M16.9 4.3a2.1 2.1 0 0 1 3 3l-1.5 1.5-3-3z",1.0f,1.75f),Part("S","M4 20.2h.01",1.0f,2.6f)),
        "move" to listOf(Part("S","M12 3v18M3 12h18",1.0f,1.75f),Part("S","M9.5 5.5 12 3l2.5 2.5M9.5 18.5 12 21l2.5-2.5M5.5 9.5 3 12l2.5 2.5M18.5 9.5 21 12l-2.5 2.5",1.0f,1.75f)),
        "mirror" to listOf(Part("S","M12 3v2.5M12 9v2.5M12 15v2.5M12 20.5V21",1.0f,1.75f),Part("S","M9 6.5 4 18h5z",1.0f,1.75f),Part("S","M15 6.5 20 18h-5z",1.0f,1.75f)),
        "undo" to listOf(Part("S","M9 14 4 9l5-5",1.0f,1.75f),Part("S","M4 9h10.5a5.5 5.5 0 0 1 0 11H11",1.0f,1.75f)),
        "redo" to listOf(Part("S","M15 14l5-5-5-5",1.0f,1.75f),Part("S","M20 9H9.5a5.5 5.5 0 0 0 0 11H13",1.0f,1.75f)),
        "grid" to listOf(Part("S","M5.5 4h13a1.5 1.5 0 0 1 1.5 1.5v13a1.5 1.5 0 0 1 -1.5 1.5h-13a1.5 1.5 0 0 1 -1.5 -1.5v-13a1.5 1.5 0 0 1 1.5 -1.5z",1.0f,1.75f),Part("S","M9.33 4v16M14.67 4v16M4 9.33h16M4 14.67h16",1.0f,1.75f)),
        "zoom_in" to listOf(Part("S","M4 11a7 7 0 1 0 14 0a7 7 0 1 0 -14 0z",1.0f,1.75f),Part("S","M20 20l-4-4",1.0f,1.75f),Part("S","M11 8v6M8 11h6",1.0f,1.75f)),
        "zoom_out" to listOf(Part("S","M4 11a7 7 0 1 0 14 0a7 7 0 1 0 -14 0z",1.0f,1.75f),Part("S","M20 20l-4-4",1.0f,1.75f),Part("S","M8 11h6",1.0f,1.75f)),
        "fit" to listOf(Part("S","M4 9V5.5A1.5 1.5 0 0 1 5.5 4H9M15 4h3.5A1.5 1.5 0 0 1 20 5.5V9M20 15v3.5a1.5 1.5 0 0 1-1.5 1.5H15M9 20H5.5A1.5 1.5 0 0 1 4 18.5V15",1.0f,1.75f)),
        "search" to listOf(Part("S","M4.5 11a6.5 6.5 0 1 0 13 0a6.5 6.5 0 1 0 -13 0z",1.0f,1.75f),Part("S","M20 20l-4.2-4.2",1.0f,1.75f)),
        "eye" to listOf(Part("S","M2.5 12s3.5-6.5 9.5-6.5 9.5 6.5 9.5 6.5-3.5 6.5-9.5 6.5S2.5 12 2.5 12z",1.0f,1.75f),Part("S","M9.2 12a2.8 2.8 0 1 0 5.6 0a2.8 2.8 0 1 0 -5.6 0z",1.0f,1.75f)),
        "eye_off" to listOf(Part("S","M4 4l16 16",1.0f,1.75f),Part("S","M10 5.7c.6-.1 1.3-.2 2-.2 6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-2.6 3.4M6.6 6.9C4 8.6 2.5 12 2.5 12s3.5 6.5 9.5 6.5c1.6 0 3-.4 4.2-1",1.0f,1.75f)),
        "plus" to listOf(Part("S","M12 5v14M5 12h14",1.0f,1.75f)),
        "more" to listOf(Part("S","M12 5.5h.01M12 12h.01M12 18.5h.01",1.0f,2.5f)),
        "chev_down" to listOf(Part("S","M6 9l6 6 6-6",1.0f,1.75f)),
        "chev_right" to listOf(Part("S","M9 6l6 6-6 6",1.0f,1.75f)),
        "check" to listOf(Part("S","M5 12.5l4.5 4.5L19 7.5",1.0f,1.75f)),
        "download" to listOf(Part("S","M12 4v11",1.0f,1.75f),Part("S","M7.5 10.5 12 15l4.5-4.5",1.0f,1.75f),Part("S","M5 20h14",1.0f,1.75f)),
        "close" to listOf(Part("S","M6 6l12 12M18 6 6 18",1.0f,1.75f)),
        "cube" to listOf(Part("S","M12 3l8 4.5v9L12 21l-8-4.5v-9z",1.0f,1.75f),Part("S","M4 7.5l8 4.5 8-4.5",1.0f,1.75f),Part("S","M12 12v9",1.0f,1.75f)),
        "layers" to listOf(Part("S","M12 4 3 8.5l9 4.5 9-4.5z",1.0f,1.75f),Part("S","M3 12.5l9 4.5 9-4.5",1.0f,1.75f),Part("S","M3 16.5l9 4.5 9-4.5",1.0f,1.75f)),
        "palette" to listOf(Part("S","M12 3a9 9 0 0 0 0 18c1.1 0 1.8-.8 1.8-1.8 0-.5-.2-.9-.5-1.2-.3-.3-.5-.7-.5-1.2 0-1 .8-1.8 1.8-1.8h2.2A5.2 5.2 0 0 0 22 9.8C22 6 17.5 3 12 3z",1.0f,1.75f),Part("S","M7.5 11.5h.01M9.5 7.5h.01M14.5 7h.01M17.2 10.5h.01",1.0f,2.5f)),
        "image" to listOf(Part("S","M5.5 4.5h13a2 2 0 0 1 2 2v11a2 2 0 0 1 -2 2h-13a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2z",1.0f,1.75f),Part("S","M7.4 10a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0z",1.0f,1.75f),Part("S","M20.5 16l-5-5-8.5 8.5",1.0f,1.75f)),
        "share" to listOf(Part("S","M15.5 5.5a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0 -5 0z",1.0f,1.75f),Part("S","M3.5 12a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0 -5 0z",1.0f,1.75f),Part("S","M15.5 18.5a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0 -5 0z",1.0f,1.75f),Part("S","M8.2 10.8l7.6-4.1M8.2 13.2l7.6 4.1",1.0f,1.75f)),
        "save" to listOf(Part("S","M5 4h11l3 3v11.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 18.5z",1.0f,1.75f),Part("S","M8 4v5h7V4",1.0f,1.75f),Part("S","M8 13h8v7h-8z",1.0f,1.75f)),
        "pointer" to listOf(Part("S","M9 11V5.5a1.5 1.5 0 0 1 3 0V10",1.0f,1.75f),Part("S","M12 10V8.5a1.5 1.5 0 0 1 3 0V11",1.0f,1.75f),Part("S","M15 10.5a1.5 1.5 0 0 1 3 0V15a6 6 0 0 1-6 6h-.8a6 6 0 0 1-4.9-2.6L4.2 15a1.5 1.5 0 0 1 2.4-1.7L9 15.5",1.0f,1.75f)),
        "rotate" to listOf(Part("S","M20 11a8 8 0 1 0-2.3 5.7",1.0f,1.75f),Part("S","M20 5v6h-6",1.0f,1.75f)),
        "info" to listOf(Part("S","M2.75 12a9.25 9.25 0 1 0 18.5 0a9.25 9.25 0 1 0 -18.5 0z",1.0f,1.75f),Part("S","M12 11v5.5",1.0f,1.75f),Part("S","M12 7.8h.01",1.0f,2.5f)),
        "clock" to listOf(Part("S","M2.75 12a9.25 9.25 0 1 0 18.5 0a9.25 9.25 0 1 0 -18.5 0z",1.0f,1.75f),Part("S","M12 7v5l3.2 2",1.0f,1.75f)),
        "copy" to listOf(Part("S","M10 8h8a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-8a2 2 0 0 1 -2 -2v-8a2 2 0 0 1 2 -2z",1.0f,1.75f),Part("S","M16 8V5.5A1.5 1.5 0 0 0 14.5 4h-9A1.5 1.5 0 0 0 4 5.5v9A1.5 1.5 0 0 0 5.5 16H8",1.0f,1.75f))
    )
    private val cache=HashMap<String,ImageVector>()
    val names:Set<String> get()=table.keys
    fun get(name:String):ImageVector=synchronized(cache){cache.getOrPut(name){build(name)}}
    private fun build(name:String):ImageVector{
        val parts=table[name]?:table.getValue("info")
        val builder=ImageVector.Builder(name=name,defaultWidth=24.dp,defaultHeight=24.dp,viewportWidth=24f,viewportHeight=24f)
        for(p in parts){
            val nodes=PathParser().parsePathString(p.d).toNodes()
            val filled=p.kind!="S";val stroked=p.kind!="F"
            builder.addPath(pathData=nodes,fill=if(filled)SolidColor(Color.Black)else null,fillAlpha=p.alpha,stroke=if(stroked)SolidColor(Color.Black)else null,strokeAlpha=p.alpha,
                strokeLineWidth=p.width,strokeLineCap=StrokeCap.Round,strokeLineJoin=StrokeJoin.Round)
        }
        return builder.build()
    }
}
