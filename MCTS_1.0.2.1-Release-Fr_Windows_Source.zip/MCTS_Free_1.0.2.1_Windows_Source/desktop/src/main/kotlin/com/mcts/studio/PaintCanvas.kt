package com.mcts.studio

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.*
import com.mcts.core.CanvasGeometry
import com.mcts.core.MaterialDocument
import kotlin.math.*

internal class PaintViewport {
    var zoom by mutableFloatStateOf(1f)
    var pan by mutableStateOf(Offset.Zero)
    /** Windows: texture pixel under the mouse (shown in the status bar while hovering). */
    var hover by mutableStateOf<Pair<Int,Int>?>(null)
    fun fit(){zoom=1f;pan=Offset.Zero}
    fun scale(v:Float){zoom=v.coerceIn(MIN,MAX)}
    /** 1.0.2 rubber band: past the limits a pinch keeps stretching with strong resistance… */
    fun stretch(v:Float){zoom=when{v>MAX->MAX*(v/MAX).pow(.3f);v<MIN->MIN*(v/MIN).pow(.3f);else->v}}
    /** …and springs back (light bounce, ~0.3 s) when the fingers lift. Zooms about the canvas centre so the picture stays put. */
    suspend fun settle(quiet:Boolean){
        val target=zoom.coerceIn(MIN,MAX);if(target==zoom)return
        val start=zoom;val startPan=pan
        if(quiet){zoom=target;pan=startPan*(target/start);return}
        androidx.compose.animation.core.Animatable(start).animateTo(target,ProMotion.bounce()){zoom=value;pan=startPan*(value/start)}
    }
    companion object{const val MIN=.5f;const val MAX=256f}
}
