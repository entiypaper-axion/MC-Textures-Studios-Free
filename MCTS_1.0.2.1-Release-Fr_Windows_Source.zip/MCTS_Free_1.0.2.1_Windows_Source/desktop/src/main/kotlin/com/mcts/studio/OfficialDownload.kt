package com.mcts.studio

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipFile

/** Downloads official archives only into a user's private project after an explicit tap. */
internal object OfficialDownload {
    private fun connection(url:String):HttpURLConnection{
        val parsed=URL(url)
        if(parsed.protocol!="https"||parsed.host !in setOf("piston-meta.mojang.com","piston-data.mojang.com","launcher.mojang.com","api.github.com","github.com"))throw IOException("MODEL_SOURCE")
        return (parsed.openConnection() as HttpURLConnection).apply{connectTimeout=20_000;readTimeout=45_000;setRequestProperty("User-Agent","MCTS-3.0.5");instanceFollowRedirects=true}
    }
    private fun json(url:String):String{
        val http=connection(url)
        try{
            if(http.responseCode !in 200..299)throw IOException("MODEL_DOWNLOAD")
            http.inputStream.use{input->val output=java.io.ByteArrayOutputStream();val buffer=ByteArray(16*1024)
                while(true){val n=input.read(buffer);if(n<0)break;if(output.size()+n>8*1024*1024)throw IOException("MODEL_LARGE");output.write(buffer,0,n)}
                return output.toString("UTF-8")}
        }finally{http.disconnect()}
    }
    fun fetch(profile:GameProfile,destination:File){
        val url:String;val expected:String?;val digestName:String
        if(profile.java){
            val versions=JSONObject(json("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")).getJSONArray("versions")
            val release=(0 until versions.length()).asSequence().map{versions.getJSONObject(it)}.firstOrNull{it.optString("id")==profile.version}?:throw IOException("MODEL_VERSION")
            val client=JSONObject(json(release.getString("url"))).getJSONObject("downloads").getJSONObject("client")
            url=client.getString("url");expected=client.getString("sha1");digestName="SHA-1"
        }else{
            val releases=JSONArray(json("https://api.github.com/repos/Mojang/bedrock-samples/releases?per_page=100"))
            val tag="1."+profile.version.removePrefix("1.")
            val release=(0 until releases.length()).asSequence().map{releases.getJSONObject(it)}.firstOrNull{it.optString("tag_name").contains(tag)}?:throw IOException("MODEL_VERSION")
            val assets=release.getJSONArray("assets")
            val minimal=(0 until assets.length()).asSequence().map{assets.getJSONObject(it)}.firstOrNull{it.optString("name").contains("min",true)&&it.optString("name").endsWith(".zip")}?:throw IOException("MODEL_VERSION")
            url=minimal.getString("browser_download_url");expected=minimal.optString("digest").removePrefix("sha256:").takeIf{it.length==64};digestName="SHA-256"
        }
        val tmp=File(destination.parentFile,"official-models.part");val md=MessageDigest.getInstance(digestName)
        try{
            val http=connection(url)
            try{
                if(http.responseCode !in 200..299)throw IOException("MODEL_DOWNLOAD")
                http.inputStream.use{input->tmp.outputStream().use{output->
                    val buffer=ByteArray(64*1024);var total=0L
                    while(true){val n=input.read(buffer);if(n<0)break;total+=n;if(total>250L*1024*1024)throw IOException("MODEL_LARGE");md.update(buffer,0,n);output.write(buffer,0,n)}
                }}
            }finally{http.disconnect()}
            if(expected!=null&&md.digest().joinToString(""){"%02x".format(it)}!=expected)throw IOException("MODEL_HASH")
            ZipFile(tmp).use{zip->if(zip.entries().asSequence().none{it.name.endsWith(".geo.json")||it.name.contains("assets/minecraft/models/block/")})throw IOException("MODEL_INVALID")}
            java.nio.file.Files.move(tmp.toPath(),destination.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        }finally{tmp.delete()}
    }
}
