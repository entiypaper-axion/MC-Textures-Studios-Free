package com.mcts.studio

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.mcts.studio.compat.DesktopDirs
import com.mcts.studio.compat.DesktopPlatform
import java.awt.Toolkit
import java.awt.datatransfer.DataFlavor
import java.awt.image.BufferedImage
import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import javax.imageio.ImageIO

/** Window state shared with the Compose tree (focus for autosave, files dropped on the window). */
internal object DesktopWindow {
    var focused by mutableStateOf(true)
    var dropped by mutableStateOf<File?>(null)
}

/** Windows equivalents of the Android share sheet / clipboard features. */
internal object WindowsIntegration {
    /** An image on the clipboard (screenshot, copied picture or a copied .png file) saved as a temporary PNG. */
    fun clipboardImage(): File? = runCatching {
        val clip = Toolkit.getDefaultToolkit().systemClipboard
        val target = File(DesktopDirs.context.cacheDir, "clipboard-${System.nanoTime()}.png")
        when {
            clip.isDataFlavorAvailable(DataFlavor.javaFileListFlavor) -> {
                @Suppress("UNCHECKED_CAST")
                val files = clip.getData(DataFlavor.javaFileListFlavor) as List<File>
                files.firstOrNull { it.isFile && it.name.lowercase().let { n -> n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".bmp") || n.endsWith(".gif") } }
            }
            clip.isDataFlavorAvailable(DataFlavor.imageFlavor) -> {
                val image = clip.getData(DataFlavor.imageFlavor) as java.awt.Image
                val w = image.getWidth(null); val h = image.getHeight(null)
                if (w <= 0 || h <= 0) null else {
                    val argb = BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB)
                    val g = argb.createGraphics(); g.drawImage(image, 0, 0, null); g.dispose()
                    ImageIO.write(argb, "png", target); target
                }
            }
            else -> null
        }
    }.getOrNull()

    private val downloads: File get() {
        val home = File(System.getProperty("user.home"))
        return listOf(File(home, "Downloads"), File(home, "下载"), home).first { it.isDirectory }
    }

    private fun unique(dir: File, name: String): File {
        var f = File(dir, name); var i = 2
        val stem = name.substringBeforeLast('.'); val ext = name.substringAfterLast('.', "")
        while (f.exists()) { f = File(dir, if (ext.isEmpty()) "$stem ($i)" else "$stem ($i).$ext"); i++ }
        return f
    }

    enum class Sent { JAVA_RESOURCEPACKS, BEDROCK_OPENED, DOWNLOADS }

    /**
     * "Export & send to Minecraft" on Windows:
     * Java → copied into %APPDATA%\.minecraft\resourcepacks (replacing an older export of the same name) and shown in Explorer;
     * Bedrock → the .mcpack is saved to Downloads and opened, which makes Minecraft for Windows import it.
     * Anything that cannot be found falls back to Downloads + Explorer.
     */
    fun sendToMinecraft(exported: File, fileName: String, isJava: Boolean): Pair<Sent, File> {
        if (isJava) {
            val appData = System.getenv("APPDATA")?.let(::File)
            val mc = appData?.let { File(it, ".minecraft") }
            if (mc != null && mc.isDirectory) {
                val packs = File(mc, "resourcepacks").apply { mkdirs() }
                val target = File(packs, fileName)
                Files.copy(exported.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
                DesktopPlatform.reveal(target)
                return Sent.JAVA_RESOURCEPACKS to target
            }
        }
        val target = unique(downloads, fileName)
        Files.copy(exported.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        if (!isJava && DesktopPlatform.isWindows && runCatching { java.awt.Desktop.getDesktop().open(target) }.isSuccess) return Sent.BEDROCK_OPENED to target
        DesktopPlatform.reveal(target)
        return Sent.DOWNLOADS to target
    }

    /** Feedback screenshot: saved to Downloads, diagnostics on the clipboard, Explorer shows the picture. */
    fun feedbackScreenshot(diagnostics: String): File? {
        val target = unique(downloads, "MCTS-feedback.png")
        if (!DesktopPlatform.screenshotPng(target)) return null
        DesktopPlatform.copyText(diagnostics)
        DesktopPlatform.reveal(target)
        return target
    }
}
