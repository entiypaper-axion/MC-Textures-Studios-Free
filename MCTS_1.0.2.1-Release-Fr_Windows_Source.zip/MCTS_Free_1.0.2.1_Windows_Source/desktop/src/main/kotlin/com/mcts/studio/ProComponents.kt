package com.mcts.studio

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.unit.DpOffset

@Composable internal fun ProIcon(name:String,tint:Color,size:Dp=20.dp,modifier:Modifier=Modifier){
    Icon(ProIcons.get(name),contentDescription=null,modifier=modifier.size(size),tint=tint)
}

/** Light haptic tick when the accessibility "haptics" option is on. */
@Composable internal fun rememberTick():()->Unit{
    val haptic=LocalHapticFeedback.current;val model=LocalProModel.current
    return remember(haptic,model?.haptics){{if(model?.haptics==true)haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)}}
}

/** Top-bar / tool button. In label mode (文字显示) the text replaces the icon. */
@OptIn(ExperimentalFoundationApi::class)
@Composable internal fun ProIconButton(icon:String,label:String,onClick:()->Unit,modifier:Modifier=Modifier,selected:Boolean=false,enabled:Boolean=true,
                                       showLabel:Boolean=false,onLongClick:(()->Unit)?=null,size:Dp=40.dp,tile:Boolean=false){
    // Windows: hovering shows the name (icons have no visible label); right-click does what a long press does.
    if(showLabel)ProIconButtonBody(icon,label,onClick,modifier,selected,enabled,true,onLongClick,size,tile)
    else TooltipArea(tooltip={ProTooltip(label)},modifier=modifier,delayMillis=550,tooltipPlacement=TooltipPlacement.CursorPoint(offset=DpOffset(0.dp,18.dp))){
        ProIconButtonBody(icon,label,onClick,Modifier,selected,enabled,false,onLongClick,size,tile)
    }
}

@Composable internal fun ProTooltip(text:String){
    val c=LocalPro.current
    Text(text,style=MaterialTheme.typography.labelMedium,color=c.tx,modifier=Modifier.shadowedTooltip(c.group,c.line).padding(horizontal=9.dp,vertical=5.dp))
}
private fun Modifier.shadowedTooltip(bg:Color,line:Color)=this.clip(RoundedCornerShape(7.dp)).background(bg).border(1.dp,line,RoundedCornerShape(7.dp))

/** Right mouse button → [action] (the desktop counterpart of a long press). */
internal fun Modifier.onSecondaryClick(enabled:Boolean,action:(()->Unit)?):Modifier=if(action==null||!enabled)this else this.pointerInput(action){
    awaitPointerEventScope{while(true){val e=awaitPointerEvent(PointerEventPass.Initial)
        if(e.type==PointerEventType.Press&&e.buttons.isSecondaryPressed){e.changes.forEach{it.consume()};action()}}}
}

@OptIn(ExperimentalFoundationApi::class)
@Composable private fun ProIconButtonBody(icon:String,label:String,onClick:()->Unit,modifier:Modifier,selected:Boolean,enabled:Boolean,
                                          showLabel:Boolean,onLongClick:(()->Unit)?,size:Dp,tile:Boolean){
    val c=LocalPro.current;val tick=rememberTick()
    val (press,pressMod)=rememberPress(enabled)
    // 1.0.2 liquid glass: icons sit under their own thick, nearly clear squircle (1.0.2.1: every icon button, switchable one by one).
    val asTile=glassOn
    val lift=remember(press){derivedStateOf{if(press.pressed.value).05f else 0f}}
    val tint=when{!enabled->c.tx3.copy(alpha=.45f);selected->c.acc;asTile->c.tx;else->c.tx2}
    Box(modifier.then(pressMod).height(size).then(if(showLabel)Modifier.widthIn(min=size+4.dp)else Modifier.width(size+4.dp))
        .then(if(asTile)Modifier.glass(GlassKind.ICON,size*.32f,if(selected)c.acc else null,lift,id=icon,fallback=Modifier.clip(RoundedCornerShape(9.dp)).background(if(selected)c.raised else Color.Transparent)) else Modifier.clip(RoundedCornerShape(9.dp)).background(if(selected)c.raised else Color.Transparent))
        .onSecondaryClick(enabled,onLongClick)
        .combinedClickable(interactionSource=press.source,indication=LocalIndication.current,enabled=enabled,role=Role.Button,onClickLabel=label,onLongClick=onLongClick,onClick={tick();onClick()})
        .semantics{contentDescription=label;this.selected=selected}
        .padding(horizontal=if(showLabel)10.dp else 0.dp),contentAlignment=Alignment.Center){
        if(showLabel)Text(label,style=MaterialTheme.typography.labelLarge,color=if(selected)c.acc else if(enabled)c.tx else c.tx3,maxLines=1)
        else ProIcon(icon,tint,21.dp,if(asTile&&smallGlassOn)Modifier.underGlass() else Modifier)
    }
}

/** The icon under a glass tile: very slightly enlarged and softened, as if seen through the glass. */
@Composable internal fun Modifier.underGlass():Modifier=this.graphicsLayer{scaleX=1.04f;scaleY=1.04f}.blur(.6.dp,BlurredEdgeTreatment.Unbounded)

@Composable internal fun ProGroup(modifier:Modifier=Modifier,content:@Composable RowScope.()->Unit){
    val c=LocalPro.current
    // With liquid glass every icon is its own tile, so the group itself has no plate (1.0.2 design).
    if(smallGlassOn)Row(modifier.padding(4.dp),horizontalArrangement=Arrangement.spacedBy(7.dp),verticalAlignment=Alignment.CenterVertically,content=content)
    else Row(modifier.clip(RoundedCornerShape(12.dp)).background(c.group).border(1.dp,c.line,RoundedCornerShape(12.dp)).padding(4.dp),
        horizontalArrangement=Arrangement.spacedBy(2.dp),verticalAlignment=Alignment.CenterVertically,content=content)
}

@Composable internal fun ProPanel(modifier:Modifier=Modifier,kind:GlassKind=GlassKind.PANEL,content:@Composable ColumnScope.()->Unit){
    val c=LocalPro.current
    Column(modifier.proSurface(kind,14.dp,c.group),content=content)
}

internal enum class ProKind { PRIMARY, SECONDARY, GHOST, DANGER }
@Composable internal fun ProButton(text:String,onClick:()->Unit,modifier:Modifier=Modifier,icon:String?=null,kind:ProKind=ProKind.SECONDARY,enabled:Boolean=true){
    val c=LocalPro.current;val tick=rememberTick()
    val (press,pressMod)=rememberPress(enabled)
    val bg=when(kind){ProKind.PRIMARY->c.acc;ProKind.DANGER->c.danger.copy(alpha=.14f);else->Color.Transparent}
    val fg=when{!enabled->c.tx3;kind==ProKind.PRIMARY->c.accTx;kind==ProKind.DANGER->c.danger;else->c.tx}
    val lift=remember(press){derivedStateOf{if(press.pressed.value).05f else 0f}}
    val plain=Modifier.clip(RoundedCornerShape(10.dp)).background(if(enabled)bg else c.raised)
        .then(if(kind==ProKind.SECONDARY)Modifier.border(1.dp,c.line,RoundedCornerShape(10.dp))else Modifier)
    // 1.0.2.1: text buttons are glass controls (accent / danger tinted); ghost buttons stay plain text.
    val glassy=kind!=ProKind.GHOST&&glassOn
    Row(modifier.then(pressMod).heightIn(min=40.dp)
        .then(if(glassy)Modifier.glass(GlassKind.CONTROL,10.dp,when(kind){ProKind.PRIMARY->c.acc;ProKind.DANGER->c.danger;else->null},lift,id=icon?:text,fallback=plain) else plain)
        .clickable(interactionSource=press.source,indication=LocalIndication.current,enabled=enabled,role=Role.Button){tick();onClick()}.padding(horizontal=14.dp,vertical=8.dp),
        horizontalArrangement=Arrangement.spacedBy(7.dp,Alignment.CenterHorizontally),verticalAlignment=Alignment.CenterVertically){
        if(icon!=null)ProIcon(icon,fg,17.dp)
        Text(text,style=MaterialTheme.typography.labelLarge.copy(fontWeight=if(kind==ProKind.PRIMARY)FontWeight.Bold else FontWeight.Medium),color=fg)
    }
}

@Composable internal fun ProLabel(text:String,modifier:Modifier=Modifier){
    Text(text,modifier,style=MaterialTheme.typography.labelSmall.copy(fontWeight=FontWeight.SemiBold,letterSpacing=MaterialTheme.typography.labelSmall.fontSize*.06f),color=LocalPro.current.tx3)
}

@Composable internal fun ProSegmented(options:List<String>,selected:Int,onSelect:(Int)->Unit,modifier:Modifier=Modifier,enabled:Boolean=true,mono:Boolean=false){
    val c=LocalPro.current;val tick=rememberTick();val quiet=LocalQuiet.current
    // 1.0.2: the selected pill slides between options with the bounce spring (stretching a little on the way).
    val position by animateFloatAsState(selected.coerceAtLeast(0).toFloat(),if(quiet)snap() else ProMotion.bounce(),label="segment")
    val plain=Modifier.clip(RoundedCornerShape(10.dp)).background(c.raised)
    val glass=glassOn
    Box(modifier.then(if(glass)Modifier.glass(GlassKind.CONTROL,10.dp,id="seg:"+options.size,fallback=plain) else plain).padding(3.dp)){
        if(selected>=0&&options.isNotEmpty())BoxWithConstraints(Modifier.matchParentSize()){
            val gap=2.dp;val cell=(maxWidth-gap*(options.size-1))/options.size
            val stretch=1f+kotlin.math.abs(position-selected)*.25f
            Box(Modifier.offset(x=(cell+gap)*position).width(cell).fillMaxHeight().graphicsLayer{scaleX=stretch}
                .clip(RoundedCornerShape(8.dp)).background(if(glass)c.bar.copy(alpha=.62f) else c.bar))
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(2.dp)){
            options.forEachIndexed{i,label->
                val on=i==selected
                Box(Modifier.weight(1f).heightIn(min=32.dp).clip(RoundedCornerShape(8.dp))
                    .selectableTab(on,enabled){tick();onSelect(i)}.padding(horizontal=6.dp,vertical=6.dp),contentAlignment=Alignment.Center){
                    Text(label,style=MaterialTheme.typography.labelLarge.copy(fontFamily=if(mono)ProMono else MaterialTheme.typography.labelLarge.fontFamily),
                        color=if(on)c.tx else c.tx3,maxLines=1)
                }
            }
        }
    }
}
private fun Modifier.selectableTab(selected:Boolean,enabled:Boolean,onClick:()->Unit)=this.then(
    Modifier.clickable(enabled=enabled,role=Role.Tab,onClick=onClick).semantics{this.selected=selected})

@Composable internal fun ProChip(text:String,selected:Boolean,onClick:()->Unit,modifier:Modifier=Modifier,enabled:Boolean=true){
    val c=LocalPro.current;val tick=rememberTick()
    val (press,pressMod)=rememberPress(enabled)
    val lift=remember(press){derivedStateOf{if(press.pressed.value).05f else 0f}}
    val plain=Modifier.clip(RoundedCornerShape(8.dp)).background(if(selected)c.accSoft else c.raised)
        .then(if(selected)Modifier.border(1.dp,c.acc,RoundedCornerShape(8.dp))else Modifier)
    Box(modifier.then(pressMod).heightIn(min=30.dp)
        .then(if(glassOn)Modifier.glass(GlassKind.CHIP,8.dp,if(selected)c.acc else null,lift,id=text,fallback=plain) else plain)
        .clickable(interactionSource=press.source,indication=LocalIndication.current,enabled=enabled,role=Role.Tab){tick();onClick()}.semantics{this.selected=selected}
        .padding(horizontal=10.dp,vertical=5.dp),contentAlignment=Alignment.Center){
        Text(text,style=MaterialTheme.typography.labelMedium,color=if(selected)c.acc else if(enabled)c.tx2 else c.tx3,maxLines=1)
    }
}

@Composable internal fun ProSwitchRow(title:String,checked:Boolean,onChange:(Boolean)->Unit,hint:String?=null,enabled:Boolean=true){
    val c=LocalPro.current;val tick=rememberTick()
    val (press,pressMod)=rememberPress(enabled)
    Row(Modifier.fillMaxWidth().then(pressMod).clip(RoundedCornerShape(10.dp)).clickable(interactionSource=press.source,indication=LocalIndication.current,enabled=enabled,role=Role.Switch){tick();onChange(!checked)}
        .semantics{toggleableState=if(checked)androidx.compose.ui.state.ToggleableState.On else androidx.compose.ui.state.ToggleableState.Off}.padding(vertical=6.dp),verticalAlignment=Alignment.CenterVertically){
        Column(Modifier.weight(1f)){
            Text(title,style=MaterialTheme.typography.bodyMedium,color=if(enabled)c.tx else c.tx3)
            if(hint!=null)Text(hint,style=MaterialTheme.typography.bodySmall,color=c.tx3)
        }
        Spacer(Modifier.width(12.dp))
        if(glassOn)GlassSwitch(checked,enabled,title)
        else Switch(checked=checked,onCheckedChange=null,enabled=enabled,colors=SwitchDefaults.colors(checkedThumbColor=c.accTx,checkedTrackColor=c.acc,uncheckedThumbColor=c.tx3,uncheckedTrackColor=c.raised,uncheckedBorderColor=c.line))
    }
}

@Composable internal fun ProSlider(value:Float,onValueChange:(Float)->Unit,valueRange:ClosedFloatingPointRange<Float>,modifier:Modifier=Modifier,steps:Int=0,
                                   onValueChangeFinished:(()->Unit)?=null,description:String="",enabled:Boolean=true){
    val c=LocalPro.current
    if(glassOn){
        // 1.0.2.1: a glass capsule behind the track; the Material track itself is see-through.
        Box(modifier,contentAlignment=Alignment.Center){
            Box(Modifier.fillMaxWidth().height(14.dp).padding(horizontal=2.dp)
                .glass(GlassKind.CONTROL,7.dp,id="slider:"+description,fallback=Modifier.clip(RoundedCornerShape(7.dp)).background(c.raised)))
            Slider(value=value,onValueChange=onValueChange,modifier=Modifier.fillMaxWidth().semantics{contentDescription=description},enabled=enabled,valueRange=valueRange,steps=steps,
                onValueChangeFinished=onValueChangeFinished,colors=SliderDefaults.colors(thumbColor=c.acc,activeTrackColor=c.acc.copy(alpha=.85f),inactiveTrackColor=Color.Transparent,activeTickColor=c.accTx,inactiveTickColor=c.tx3))
        }
        return
    }
    Slider(value=value,onValueChange=onValueChange,modifier=modifier.semantics{contentDescription=description},enabled=enabled,valueRange=valueRange,steps=steps,
        onValueChangeFinished=onValueChangeFinished,colors=SliderDefaults.colors(thumbColor=c.acc,activeTrackColor=c.acc,inactiveTrackColor=c.raised,activeTickColor=c.accTx,inactiveTickColor=c.tx3))
}

/** 1.0.2.1: switch with a glass capsule (accent tinted when on) and a white thumb that slides with the bounce spring. */
@Composable private fun GlassSwitch(checked:Boolean,enabled:Boolean,id:String){
    val c=LocalPro.current;val quiet=LocalQuiet.current
    val x by animateFloatAsState(if(checked)1f else 0f,if(quiet)snap() else ProMotion.bounce(),label="switch")
    val plain=Modifier.clip(RoundedCornerShape(14.dp)).background(if(checked)c.acc else c.raised).border(1.dp,c.line,RoundedCornerShape(14.dp))
    Box(Modifier.size(48.dp,28.dp).graphicsLayer{alpha=if(enabled)1f else .45f}
        .glass(GlassKind.CONTROL,14.dp,if(checked)c.acc else null,id="switch:"+id,fallback=plain)){
        Box(Modifier.padding(3.dp).offset(x=20.dp*x).size(22.dp).shadow(2.dp,CircleShape).clip(CircleShape).background(Color.White))
    }
}

@Composable internal fun ProField(value:String,onValueChange:(String)->Unit,modifier:Modifier=Modifier,placeholder:String="",leading:String?=null,mono:Boolean=false,
                                  enabled:Boolean=true,keyboardOptions:KeyboardOptions=KeyboardOptions.Default,description:String=placeholder){
    val c=LocalPro.current
    val style=MaterialTheme.typography.bodyMedium.copy(color=c.tx,fontFamily=if(mono)ProMono else MaterialTheme.typography.bodyMedium.fontFamily)
    val glass=glassOn
    BasicTextField(value=value,onValueChange=onValueChange,enabled=enabled,singleLine=true,textStyle=style,cursorBrush=SolidColor(c.acc),keyboardOptions=keyboardOptions,
        modifier=modifier.semantics{contentDescription=description},
        decorationBox={inner->
            val plain=Modifier.clip(RoundedCornerShape(9.dp)).background(c.field).border(1.dp,c.line,RoundedCornerShape(9.dp))
            Row(Modifier.heightIn(min=38.dp).then(if(glass)Modifier.glass(GlassKind.CONTROL,9.dp,id="field:"+description,fallback=plain) else plain).padding(horizontal=10.dp),
                verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
                if(leading!=null)ProIcon(leading,c.tx3,16.dp)
                Box(Modifier.weight(1f)){if(value.isEmpty())Text(placeholder,style=style.copy(color=c.tx3),maxLines=1);inner()}
            }
        })
}

/** Checkerboard behind transparent colours (swatches, alpha slider, "erase" chip). */
internal fun Modifier.checker(cell:Dp=5.dp):Modifier=this.drawBehind{
    val s=cell.toPx();val light=Color(0xffffffff);val dark=Color(0xffc9cdd2)
    drawRect(light)
    var y=0f;var row=0
    while(y<size.height){var x=if(row%2==0)0f else s;while(x<size.width){drawRect(dark,Offset(x,y),Size(minOf(s,size.width-x),minOf(s,size.height-y)));x+=2*s};y+=s;row++}
}

/** A colour swatch. color==null is "transparent". */
@Composable internal fun ProSwatch(color:Int?,selected:Boolean,onClick:()->Unit,model:StudioModel,size:Dp=22.dp){
    val c=LocalPro.current
    val label=if(color==null)model.p("transparent") else "#"+Integer.toHexString(color).takeLast(6).uppercase()+if(model.colorNames)" · "+colorName(color,model.language) else ""
    Column(horizontalAlignment=Alignment.CenterHorizontally){
        Box(Modifier.size(size).clip(RoundedCornerShape(5.dp)).then(if(color==null)Modifier.checker(size/4)else Modifier.background(Color(color or 0xff000000.toInt())))
            .border(if(selected)2.dp else 1.dp,if(selected)c.acc else Color.Black.copy(alpha=.18f),RoundedCornerShape(5.dp))
            .clickable(role=Role.RadioButton,onClick=onClick).semantics{contentDescription=label;this.selected=selected})
        if(model.colorNames)Text(if(color==null)"α0" else Integer.toHexString(color).takeLast(6).uppercase(),style=MaterialTheme.typography.labelSmall.copy(fontFamily=ProMono),color=c.tx3,maxLines=1)
    }
}

/** Approximate colour name for the colour-name accessibility option. */
internal fun colorName(argb:Int,language:Language):String{
    val hsv=FloatArray(3);com.mcts.studio.compat.Colors.colorToHSV(argb or 0xff000000.toInt(),hsv)
    val (h,s,v)=Triple(hsv[0],hsv[1],hsv[2])
    val key=when{
        v<.15f->"black";s<.12f&&v>.88f->"white";s<.15f->"gray"
        (h<20||h>=345)&&v<.55f->"brown";h<20||h>=345->"red";h<45&&v<.65f->"brown";h<45->"orange";h<70->"yellow";h<160->"green";h<200->"cyan";h<255->"blue";h<290->"purple";else->"pink"
    }
    val names=mapOf("black" to listOf("黑","black","黒","noir","negro"),"white" to listOf("白","white","白","blanc","blanco"),"gray" to listOf("灰","grey","灰","gris","gris"),
        "brown" to listOf("棕","brown","茶","brun","marrón"),"red" to listOf("红","red","赤","rouge","rojo"),"orange" to listOf("橙","orange","橙","orange","naranja"),
        "yellow" to listOf("黄","yellow","黄","jaune","amarillo"),"green" to listOf("绿","green","緑","vert","verde"),"cyan" to listOf("青","cyan","シアン","cyan","cian"),
        "blue" to listOf("蓝","blue","青","bleu","azul"),"purple" to listOf("紫","purple","紫","violet","morado"),"pink" to listOf("粉","pink","ピンク","rose","rosa"))
    return names.getValue(key)[language.ordinal]
}

/** Lets [ProDialogs] animate a dialog out before removing it (close() → closing=true → card leaves → finish()). */
internal class DialogExit(val closing:State<Boolean>,val finish:()->Unit)
internal val LocalDialogExit=staticCompositionLocalOf<DialogExit?>{null}

/**
 * Centred card dialog with a scrim; Back and outside taps close it. Content scrolls.
 * 1.0.2: the card springs in (scale .92 → 1, light bounce) and leaves quickly; with liquid glass the card is thick glass,
 * the scrim is lighter and the workspace behind is blurred (see ProWorkspace).
 */
@Composable internal fun ProDialog(model:StudioModel,title:String,onDismiss:()->Unit,width:Dp=560.dp,icon:String?=null,content:@Composable ColumnScope.()->Unit){
    val c=LocalPro.current;val quiet=LocalQuiet.current;val glass=glassOn
    val exit=LocalDialogExit.current
    val dismissNow by rememberUpdatedState(onDismiss)
    val progress=remember{Animatable(if(quiet)1f else 0f)}
    var leaving by remember{mutableStateOf(false)}
    val externalClosing=exit?.closing?.value==true
    LaunchedEffect(Unit){if(!quiet)progress.animateTo(1f,ProMotion.settle())}
    LaunchedEffect(leaving,externalClosing){
        if(!leaving&&!externalClosing)return@LaunchedEffect
        if(!quiet)progress.animateTo(0f,tween(140,easing=FastOutLinearInEasing))
        if(leaving&&!externalClosing)dismissNow() else exit?.finish?.invoke()
    }
    val requestClose:()->Unit={if(quiet)dismissNow() else leaving=true}
    DisposableEffect(Unit){model.dialogsOpen++;onDispose{model.dialogsOpen--}}
    // Windows: Esc = Back. The dialog is drawn in the main window; our own scrim replaces the platform one.
    @OptIn(ExperimentalComposeUiApi::class)
    val properties=DialogProperties(dismissOnBackPress=true,dismissOnClickOutside=true,usePlatformDefaultWidth=false,scrimColor=Color.Transparent)
    Dialog(onDismissRequest=requestClose,properties=properties){
      CompositionLocalProvider(LocalGlassWindow provides true){
        BoxWithConstraints(Modifier.fillMaxSize().graphicsLayer{alpha=progress.value.coerceIn(0f,1f)}.background(Color.Black.copy(alpha=if(glass).22f else .55f))
            .pointerInput(Unit){detectTapGestures{requestClose()}}.safeDrawingPadding().imePadding().padding(16.dp),contentAlignment=Alignment.Center){
            val maxH=maxHeight
            Column(Modifier.widthIn(max=width).fillMaxWidth().heightIn(max=maxH)
                .graphicsLayer{val p=progress.value;scaleX=.92f+.08f*p;scaleY=.92f+.08f*p;translationY=(1f-p)*16.dp.toPx()}
                .proSurface(GlassKind.DIALOG,16.dp,c.group)
                .pointerInput(Unit){detectTapGestures{}}){
                Row(Modifier.fillMaxWidth().padding(start=20.dp,end=8.dp,top=10.dp,bottom=4.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
                    if(icon!=null)ProIcon(icon,c.acc,20.dp)
                    Text(title,style=MaterialTheme.typography.titleLarge,color=c.tx,modifier=Modifier.weight(1f).semantics{heading()})
                    ProIconButton("close",model.p("close"),requestClose)
                }
                Column(Modifier.fillMaxWidth().weight(1f,fill=false).verticalScroll(rememberScrollState()).padding(start=20.dp,end=20.dp,bottom=20.dp,top=4.dp),
                    verticalArrangement=Arrangement.spacedBy(10.dp),content=content)
            }
        }
      }
    }
}

@Composable internal fun ProNote(text:String,icon:String="info"){
    val c=LocalPro.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(c.raised).padding(10.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
        ProIcon(icon,c.tx3,16.dp,Modifier.padding(top=1.dp))
        Text(text,style=MaterialTheme.typography.bodySmall,color=c.tx2)
    }
}

@Composable internal fun ProDivider(){HorizontalDivider(color=LocalPro.current.line,thickness=1.dp)}

@Composable internal fun ProSection(title:String,content:@Composable ColumnScope.()->Unit){
    Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text(title,style=MaterialTheme.typography.titleMedium,color=LocalPro.current.tx,modifier=Modifier.padding(top=6.dp).semantics{heading()})
        content()
    }
}

@Composable internal fun ProRadioRow(title:String,selected:Boolean,onClick:()->Unit,trailing:String?=null,enabled:Boolean=true){
    val c=LocalPro.current;val tick=rememberTick()
    val (press,pressMod)=rememberPress(enabled)
    val selectedBg by animateColorAsState(if(selected)c.accSoft else Color.Transparent,if(LocalQuiet.current)snap() else ProMotion.settle(),label="radio")
    Row(Modifier.fillMaxWidth().then(pressMod).heightIn(min=40.dp).clip(RoundedCornerShape(9.dp)).background(selectedBg)
        .border(1.dp,if(selected)c.acc else Color.Transparent,RoundedCornerShape(9.dp))
        .clickable(interactionSource=press.source,indication=LocalIndication.current,enabled=enabled,role=Role.RadioButton){tick();onClick()}.semantics{this.selected=selected}.padding(horizontal=10.dp),
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
        Box(Modifier.size(16.dp).popOn(selected).clip(CircleShape).border(if(selected)5.dp else 1.5.dp,if(selected)c.acc else c.tx3,CircleShape))
        Text(title,style=MaterialTheme.typography.bodyMedium,color=if(enabled)c.tx else c.tx3,modifier=Modifier.weight(1f))
        if(trailing!=null)Text(trailing,style=MaterialTheme.typography.labelMedium,color=c.tx3)
    }
}

internal val ProTitleStyle:TextStyle @Composable get()=MaterialTheme.typography.titleMedium
