package com.mcts.studio

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * A preview mesh built from official model JSON: [quads] in PreviewGeometry's QUAD_FLOATS layout (block pixels, y up,
 * u/v top-down 0..1, texture slot 1..6), the texture path shown in each slot, whether it is tinted (grass, leaves) and the
 * overlay painted over it (grass block sides).
 */
class ModelMesh(val quads:FloatArray,val slots:List<String>,val tints:BooleanArray,val overlays:List<String?>){
    /** Slot (1..6) for a texture path, or 0. */
    fun slotOf(path:String)=slots.indexOf(path)+1
}

/**
 * Reads models for the 3D preview: the project's own model archive (Ultra) and, since 1.0.2.1, the official models kept
 * next to the template download. 1.0.2 only read element boxes (from/to) and guessed the UVs from the box, so faces
 * with their own uv, rotated elements (plants), doors (two halves) and entity atlases showed the wrong part of the texture.
 */
internal object OfficialModels {
    private const val Q=21
    private const val MAX_QUADS=8192

    fun mesh(archives:List<File>,shape:String):ModelMesh?{
        for(archive in archives){
            if(!archive.isFile)continue
            val result=runCatching{ZipFile(archive).use{zip->Reader(zip).build(shape)}}.getOrNull()
            if(result!=null)return result
        }
        return null
    }

    private class Reader(val zip:ZipFile){
        /** Entry names by their path from "assets/" or "resource_pack/" on (imported archives may have a root folder). */
        private val index:Map<String,String> by lazy {
            val map=HashMap<String,String>()
            for(e in zip.entries()){
                if(e.isDirectory)continue
                val n=e.name.replace('\\','/')
                val at=listOf("assets/","resource_pack/").map{n.indexOf(it)}.filter{it>=0}.minOrNull()?:continue
                map.putIfAbsent(n.substring(at),e.name)
            }
            map
        }
        private val cache=HashMap<String,JSONObject?>()
        fun json(path:String):JSONObject?=cache.getOrPut(path){
            val name=index[path]?:return@getOrPut null
            val entry=zip.getEntry(name)?:return@getOrPut null
            if(entry.size !in 1..1_048_576)return@getOrPut null
            runCatching{JSONObject(zip.getInputStream(entry).bufferedReader().use{it.readText()})}.getOrNull()
        }

        fun build(shape:String):ModelMesh?{
            val clean=shape.substringBefore('#')
            val path=clean.substringAfter(':')
            val name=path.substringAfterLast('/')
            return if(clean.startsWith("entity:")){
                val parent=path.substringBeforeLast('/',"").substringAfterLast('/')
                bedrock(name)?:parent.takeIf{it.isNotBlank()}?.let{bedrock(it)}
            }else if(clean.startsWith("minecraft:"))javaBlock(name)?:bedrock(name) else null
        }

        // ---------------------------------------------------------------- Java block models

        private class Part(val model:String,val x:Int,val y:Int,val dy:Float)

        private fun javaBlock(id:String):ModelMesh?{
            val state=json("assets/minecraft/blockstates/$id.json")
            val parts=ArrayList<Part>()
            val variants=state?.optJSONObject("variants")
            val multipart=state?.optJSONArray("multipart")
            if(variants!=null&&variants.length()>0){
                val keys=variants.keys().asSequence().toList()
                fun props(k:String)=k.split(',').filter{'=' in it}.associate{it.substringBefore('=') to it.substringAfter('=')}
                fun score(k:String):Int{
                    val p=props(k);var s=0
                    val wanted=if(id.endsWith("_stairs"))"north" else "south"
                    if(p["facing"]==wanted)s+=4
                    if(p["half"]=="bottom"||p["half"]=="lower")s+=3
                    if(p["type"]=="bottom")s+=3
                    if(p["shape"]=="straight")s+=2
                    if(p["face"]=="floor")s+=2
                    if(p["axis"]=="y")s+=1
                    for(f in listOf("open","powered","lit","waterlogged","triggered","occupied","extended","hanging","attached"))if(p[f]=="false")s+=1
                    if(p["hinge"]=="left")s+=1
                    return s
                }
                val best=keys.maxByOrNull{score(it)}?:keys.first()
                variantModel(variants.opt(best))?.let{parts+=Part(it.first,it.second,it.third,0f)}
                // Doors, tall flowers, tall grass: draw both halves.
                val bp=props(best)
                if(bp["half"]=="lower"){
                    val upper=keys.firstOrNull{k->val p=props(k);p["half"]=="upper"&&p.keys==bp.keys&&p.all{(key,v)->key=="half"||bp[key]==v}}
                    upper?.let{u->variantModel(variants.opt(u))?.let{parts+=Part(it.first,it.second,it.third,16f)}}
                }
            }else if(multipart!=null){
                for(i in 0 until multipart.length()){
                    val part=multipart.optJSONObject(i)?:continue
                    if(!multipartWanted(part.optJSONObject("when")))continue
                    variantModel(part.opt("apply"))?.let{parts+=Part(it.first,it.second,it.third,0f)}
                }
            }
            if(parts.isEmpty())parts+=Part("block/$id",0,0,0f)
            val builder=MeshBuilder()
            for(part in parts){
                val model=resolveModel(part.model.substringAfter(':'))?:continue
                builder.addJava(model.first,model.second,part.x,part.y,part.dy)
            }
            return builder.result()
        }

        /** Multipart preview: the parts that are always there plus a straight north–south run (fences, walls, panes, bars). */
        private fun multipartWanted(whenObj:JSONObject?):Boolean{
            if(whenObj==null)return true
            if(whenObj.has("OR")||whenObj.has("AND"))return false
            val keys=whenObj.keys().asSequence().toList()
            return keys.isNotEmpty()&&keys.all{k->
                val v=whenObj.optString(k)
                k in setOf("north","south","up")&&v!="false"&&v!="none"&&v!="tall"&&!v.contains('|')
            }
        }

        private fun variantModel(v:Any?):Triple<String,Int,Int>?{
            val o=when(v){is JSONArray->v.optJSONObject(0);is JSONObject->v;else->null}?:return null
            val m=o.optString("model").takeIf{it.isNotBlank()}?:return null
            return Triple(m,o.optInt("x",0),o.optInt("y",0))
        }

        /** Elements of the model (from itself or the nearest parent) and the merged texture variables (child wins). */
        private fun resolveModel(model:String):Pair<JSONArray,Map<String,String>>?{
            val textures=HashMap<String,String>()
            var elements:JSONArray?=null
            var current:String?=model
            var depth=0
            while(current!=null&&depth<12){
                if(!current.matches(Regex("[a-z0-9_./-]+")))return null
                val obj=json("assets/minecraft/models/$current.json")?:break
                obj.optJSONObject("textures")?.let{t->t.keys().forEach{k->textures.putIfAbsent(k,t.optString(k))}}
                if(elements==null)elements=obj.optJSONArray("elements")
                current=obj.optString("parent").takeIf{it.isNotBlank()}?.substringAfter(':')
                if(current!=null&&current.startsWith("builtin/"))break
                depth++
            }
            return elements?.let{it to textures}
        }

        // ---------------------------------------------------------------- Bedrock entity geometry

        private fun bedrock(id:String):ModelMesh?{
            val obj=json("resource_pack/models/entity/$id.geo.json")?:json("resource_pack/models/entity/$id.json")?:return null
            val builder=MeshBuilder()
            val geometries=obj.optJSONArray("minecraft:geometry")
            if(geometries!=null){
                val g=geometries.optJSONObject(0)?:return null
                val d=g.optJSONObject("description")
                builder.addBedrock(g.optJSONArray("bones")?:return null,d?.optDouble("texture_width",64.0)?.toFloat()?:64f,d?.optDouble("texture_height",64.0)?.toFloat()?:64f)
            }else{
                val key=obj.keys().asSequence().firstOrNull{it.startsWith("geometry.")}?:return null
                val g=obj.optJSONObject(key)?:return null
                builder.addBedrock(g.optJSONArray("bones")?:return null,g.optDouble("texturewidth",64.0).toFloat(),g.optDouble("textureheight",32.0).toFloat())
            }
            return builder.result()
        }
    }

    private class Corner(var x:Float,var y:Float,var z:Float,val u:Float,val v:Float)

    /** Face directions: index 0 down, 1 up, 2 north, 3 south, 4 west, 5 east. */
    private val directions=listOf("down","up","north","south","west","east")
    private val directionVectors=arrayOf(floatArrayOf(0f,-1f,0f),floatArrayOf(0f,1f,0f),floatArrayOf(0f,0f,-1f),floatArrayOf(0f,0f,1f),floatArrayOf(-1f,0f,0f),floatArrayOf(1f,0f,0f))

    private class MeshBuilder{
        val out=ArrayList<Float>()
        val slots=ArrayList<String>()
        val tints=BooleanArray(6)
        val overlays=arrayOfNulls<String>(6)
        var quads=0
        private val seenBoxes=HashMap<String,Map<Int,Int>>()

        fun slotFor(texture:String):Int{
            val i=slots.indexOf(texture)
            if(i>=0)return i+1
            if(slots.size<6){slots+=texture;return slots.size}
            return 0
        }

        fun emit(c:List<Corner>,slot:Int){
            if(quads>=MAX_QUADS)return
            for(k in c){out+=k.x;out+=k.y;out+=k.z;out+=k.u;out+=k.v}
            out+=slot.toFloat();quads++
        }

        fun result():ModelMesh?=if(quads==0)null else ModelMesh(out.toFloatArray(),slots.toList(),tints.copyOf(),overlays.toList())

        /** Box corners (viewer's bottom-left, bottom-right, top-right, top-left; CCW from outside) for each direction. */
        fun corners(d:Int,f:FloatArray,t:FloatArray):Array<FloatArray>{
            val (x0,y0,z0)=Triple(f[0],f[1],f[2]);val (x1,y1,z1)=Triple(t[0],t[1],t[2])
            return when(d){
                0->arrayOf(floatArrayOf(x0,y0,z0),floatArrayOf(x1,y0,z0),floatArrayOf(x1,y0,z1),floatArrayOf(x0,y0,z1))
                1->arrayOf(floatArrayOf(x0,y1,z1),floatArrayOf(x1,y1,z1),floatArrayOf(x1,y1,z0),floatArrayOf(x0,y1,z0))
                2->arrayOf(floatArrayOf(x1,y0,z0),floatArrayOf(x0,y0,z0),floatArrayOf(x0,y1,z0),floatArrayOf(x1,y1,z0))
                3->arrayOf(floatArrayOf(x0,y0,z1),floatArrayOf(x1,y0,z1),floatArrayOf(x1,y1,z1),floatArrayOf(x0,y1,z1))
                4->arrayOf(floatArrayOf(x0,y0,z0),floatArrayOf(x0,y0,z1),floatArrayOf(x0,y1,z1),floatArrayOf(x0,y1,z0))
                else->arrayOf(floatArrayOf(x1,y0,z1),floatArrayOf(x1,y0,z0),floatArrayOf(x1,y1,z0),floatArrayOf(x1,y1,z1))
            }
        }

        /** Minecraft's default UV of a face when "uv" is missing (pixels, top-down). */
        fun defaultUv(d:Int,f:FloatArray,t:FloatArray):FloatArray=when(d){
            0->floatArrayOf(f[0],16-t[2],t[0],16-f[2])
            1->floatArrayOf(f[0],f[2],t[0],t[2])
            2->floatArrayOf(16-t[0],16-t[1],16-f[0],16-f[1])
            3->floatArrayOf(f[0],16-t[1],t[0],16-f[1])
            4->floatArrayOf(f[2],16-t[1],t[2],16-f[1])
            else->floatArrayOf(16-t[2],16-t[1],16-f[2],16-f[1])
        }

        fun addJava(elements:JSONArray,textures:Map<String,String>,rx:Int,ry:Int,dy:Float){
            fun resolve(ref:String):String?{
                var r=ref;var guard=0
                while(r.startsWith("#")&&guard++<8)r=textures[r.substring(1)]?:return null
                if(r.isBlank()||r.startsWith("#"))return null
                val ns=if(':' in r)r.substringBefore(':') else "minecraft"
                return "assets/$ns/textures/${r.substringAfter(':')}.png"
            }
            for(i in 0 until minOf(elements.length(),1024)){
                val e=elements.optJSONObject(i)?:continue
                val f=vec(e.optJSONArray("from"))?:continue;val t=vec(e.optJSONArray("to"))?:continue
                val faces=e.optJSONObject("faces")?:continue
                val rotation=e.optJSONObject("rotation")
                // A second element on exactly the same box (grass block side overlay): composited into the face texture.
                val boxKey=f.joinToString(",")+"|"+t.joinToString(",")+"|"+(rotation?.toString()?:"")+"|$rx,$ry,$dy"
                val base=seenBoxes[boxKey]
                if(base!=null){
                    for(d in 0..5){val face=faces.optJSONObject(directions[d])?:continue
                        val slot=base[d]?:continue;val tex=resolve(face.optString("texture"))?:continue
                        if(slot in 1..6&&overlays[slot-1]==null)overlays[slot-1]=tex
                    }
                    continue
                }
                val used=HashMap<Int,Int>()
                for(d in 0..5){
                    val face=faces.optJSONObject(directions[d])?:continue
                    val texture=resolve(face.optString("texture"))?:continue
                    val uv=face.optJSONArray("uv")?.let{a->if(a.length()==4)FloatArray(4){a.optDouble(it).toFloat()} else null}?:defaultUv(d,f,t)
                    val corners=corners(d,f,t)
                    val uvCorners=arrayOf(floatArrayOf(uv[0],uv[3]),floatArrayOf(uv[2],uv[3]),floatArrayOf(uv[2],uv[1]),floatArrayOf(uv[0],uv[1]))
                    val turn=((face.optInt("rotation",0)/90)%4+4)%4
                    val c=(0..3).map{k->val p=corners[k];val q=uvCorners[(k+turn)%4];Corner(p[0],p[1],p[2],q[0]/16f,q[1]/16f)}
                    if(rotation!=null)rotateElement(c,rotation)
                    for(k in c)turnBlock(k,rx,ry)
                    if(dy!=0f)c.forEach{it.y+=dy}
                    val slot=slotFor(texture)
                    if(slot>0&&face.optInt("tintindex",-1)>=0)tints[slot-1]=true
                    // Texture slot by the face's direction after the blockstate rotation when the model ran out of slots.
                    val visible=turnDirection(d,rx,ry)
                    emit(c,if(slot>0)slot else listOf(3,1,4,2,5,6)[visible])
                    used[d]=slot
                }
                seenBoxes[boxKey]=used
            }
        }

        private fun vec(a:JSONArray?):FloatArray?=if(a==null||a.length()!=3)null else FloatArray(3){a.optDouble(it).toFloat()}

        /** Element rotation (one axis, ±45° max) around its origin, with optional rescale like the game. */
        private fun rotateElement(c:List<Corner>,r:JSONObject){
            val o=vec(r.optJSONArray("origin"))?:floatArrayOf(8f,8f,8f)
            val angle=Math.toRadians(r.optDouble("angle",0.0)).toFloat()
            if(angle==0f)return
            val axis=r.optString("axis","y")
            val cs=cos(angle);val sn=sin(angle)
            val scale=if(r.optBoolean("rescale",false))1f/maxOf(abs(cs),1e-3f) else 1f
            for(k in c){
                val x=k.x-o[0];val y=k.y-o[1];val z=k.z-o[2]
                when(axis){
                    "x"->{k.y=(y*cs-z*sn)*scale+o[1];k.z=(y*sn+z*cs)*scale+o[2];k.x=x+o[0]}
                    "z"->{k.x=(x*cs-y*sn)*scale+o[0];k.y=(x*sn+y*cs)*scale+o[1];k.z=z+o[2]}
                    else->{k.x=(x*cs+z*sn)*scale+o[0];k.z=(-x*sn+z*cs)*scale+o[2];k.y=y+o[1]}
                }
            }
        }

        /** Blockstate rotation in 90° steps: x first (up → north for x=90), then y (north → east for y=90). */
        private fun turnBlock(k:Corner,rx:Int,ry:Int){
            repeat(((rx/90)%4+4)%4){val y=k.y;val z=k.z;k.y=z;k.z=16-y}
            repeat(((ry/90)%4+4)%4){val x=k.x;val z=k.z;k.x=16-z;k.z=x}
        }
        private fun turnDirection(d:Int,rx:Int,ry:Int):Int{
            val v=directionVectors[d].copyOf()
            repeat(((rx/90)%4+4)%4){val y=v[1];val z=v[2];v[1]=z;v[2]=-y}
            repeat(((ry/90)%4+4)%4){val x=v[0];val z=v[2];v[0]=-z;v[2]=x}
            return directionVectors.indexOfFirst{it[0]==v[0]&&it[1]==v[1]&&it[2]==v[2]}.coerceAtLeast(0)
        }

        /**
         * Bedrock geometry → Java-style space (x mirrored, like Blockbench), front turned towards the camera.
         * Box UV and per-face UV are both supported; cube rotations are applied around their pivot.
         */
        fun addBedrock(bones:JSONArray,tw:Float,th:Float){
            val texW=if(tw>0)tw else 64f;val texH=if(th>0)th else 64f
            for(i in 0 until bones.length()){
                val bone=bones.optJSONObject(i)?:continue
                val cubes=bone.optJSONArray("cubes")?:continue
                val bonePivot=vec(bone.optJSONArray("pivot"))
                val boneRot=vec(bone.optJSONArray("rotation"))
                for(j in 0 until cubes.length()){
                    val cube=cubes.optJSONObject(j)?:continue
                    val origin=vec(cube.optJSONArray("origin"))?:continue;val size=vec(cube.optJSONArray("size"))?:continue
                    val inflate=cube.optDouble("inflate",0.0).toFloat()
                    val f=floatArrayOf(-(origin[0]+size[0])-inflate,origin[1]-inflate,origin[2]-inflate)
                    val t=floatArrayOf(-origin[0]+inflate,origin[1]+size[1]+inflate,origin[2]+size[2]+inflate)
                    val w=size[0];val h=size[1];val d=size[2]
                    val mirror=cube.optBoolean("mirror",bone.optBoolean("mirror",false))
                    val uvAny=cube.opt("uv")
                    val faceUv=arrayOfNulls<FloatArray>(6)
                    if(uvAny is JSONArray&&uvAny.length()==2){
                        val u=uvAny.optDouble(0).toFloat();val v=uvAny.optDouble(1).toFloat()
                        faceUv[2]=floatArrayOf(u+d,v+d,u+d+w,v+d+h)            // north
                        faceUv[5]=floatArrayOf(u,v+d,u+d,v+d+h)                // east
                        faceUv[3]=floatArrayOf(u+d+w+d,v+d,u+2*d+2*w,v+d+h)    // south
                        faceUv[4]=floatArrayOf(u+d+w,v+d,u+d+w+d,v+d+h)        // west
                        faceUv[1]=floatArrayOf(u+d,v,u+d+w,v+d)                // up
                        faceUv[0]=floatArrayOf(u+d+w,v+d,u+d+2*w,v)            // down (flipped)
                        if(mirror){
                            val e=faceUv[5];faceUv[5]=faceUv[4];faceUv[4]=e
                            for(k in 0..5)faceUv[k]?.let{a->val s=a[0];a[0]=a[2];a[2]=s}
                        }
                    }else if(uvAny is JSONObject){
                        for(k in 0..5){val fo=uvAny.optJSONObject(directions[k])?:continue
                            val uv=fo.optJSONArray("uv")?:continue;val us=fo.optJSONArray("uv_size")
                            val u=uv.optDouble(0).toFloat();val v=uv.optDouble(1).toFloat()
                            val sw=us?.optDouble(0)?.toFloat()?:0f;val sh=us?.optDouble(1)?.toFloat()?:0f
                            faceUv[k]=floatArrayOf(u,v,u+sw,v+sh)
                        }
                    }else continue
                    val pivot=vec(cube.optJSONArray("pivot"));val rot=vec(cube.optJSONArray("rotation"))
                    for(k in 0..5){
                        val uv=faceUv[k]?:continue
                        val corners=corners(k,f,t)
                        val uvCorners=arrayOf(floatArrayOf(uv[0],uv[3]),floatArrayOf(uv[2],uv[3]),floatArrayOf(uv[2],uv[1]),floatArrayOf(uv[0],uv[1]))
                        val c=(0..3).map{n->Corner(corners[n][0],corners[n][1],corners[n][2],uvCorners[n][0]/texW,uvCorners[n][1]/texH)}
                        if(rot!=null&&pivot!=null)rotateEuler(c,rot,pivot)
                        if(boneRot!=null&&bonePivot!=null)rotateEuler(c,boneRot,bonePivot)
                        // Centre the entity on the block and turn its front (north) towards the camera.
                        for(p in c){p.x=8f-p.x;p.z=8f-p.z}
                        emit(c,0)
                    }
                }
            }
        }

        /** Bedrock Euler rotation (degrees, converted to the mirrored space) around a pivot: X, then Y, then Z. */
        private fun rotateEuler(c:List<Corner>,r:FloatArray,pivot:FloatArray){
            if(r[0]==0f&&r[1]==0f&&r[2]==0f)return
            val px=-pivot[0];val py=pivot[1];val pz=pivot[2]
            val ax=Math.toRadians(-r[0].toDouble());val ay=Math.toRadians(-r[1].toDouble());val az=Math.toRadians(r[2].toDouble())
            for(k in c){
                var x=(k.x-px).toDouble();var y=(k.y-py).toDouble();var z=(k.z-pz).toDouble()
                run{val ny=y*cos(ax)-z*sin(ax);val nz=y*sin(ax)+z*cos(ax);y=ny;z=nz}
                run{val nx=x*cos(ay)+z*sin(ay);val nz=-x*sin(ay)+z*cos(ay);x=nx;z=nz}
                run{val nx=x*cos(az)-y*sin(az);val ny=x*sin(az)+y*cos(az);x=nx;y=ny}
                k.x=(x+px).toFloat();k.y=(y+py).toFloat();k.z=(z+pz).toFloat()
            }
        }
    }
}
