package com.mcts.studio
/** The explicit field list excludes project names, filenames, account IDs and content. */
internal object Diagnostics {
    fun report(version:String,code:Int,os:String,osVersion:String,java:String,language:String,error:String):String =
        "MCTS Free diagnostics (Windows)\nApp: $version ($code)\nSystem: $os $osVersion\nJava runtime: $java\nLanguage: $language\nLast error code: $error\nNo project content or file paths included."
}
