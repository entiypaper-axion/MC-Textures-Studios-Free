package com.mcts.studio

import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.launch

/**
 * 1.0.2 motion: Apple-style light bounce.
 * One spring family everywhere — response ≈ 0.32 s, damping 0.55 for small controls (≈1.5 % undershoot after release),
 * 0.78 for panels and pages (≈2 % overshoot). Pressing makes a control bulge like a drop of water (up to +12 % for
 * icon-sized controls, less for wide rows). Everything is skipped when [LocalQuiet] is set (app switch or system "remove animations").
 */
internal object ProMotion {
    /** stiffness for a 0.32 s response: (2π / 0.32)² ≈ 385. */
    const val STIFF=385f
    fun <T> bounce()=spring<T>(dampingRatio=.55f,stiffness=STIFF)
    fun <T> settle()=spring<T>(dampingRatio=.78f,stiffness=STIFF)
    fun <T> quick()=spring<T>(dampingRatio=1f,stiffness=1400f)
    /** Press-in: fast ease-out to the bulge (0 → 90 ms). */
    val pressIn:AnimationSpec<Float> = tween(90,easing=FastOutSlowInEasing)
    /** Bulge for a control of [minSidePx]: +12 % at 44 dp and below, tapering to +3 % for long rows. */
    fun bulge(minSideDp:Float)=(0.12f*44f/minSideDp.coerceAtLeast(1f)).coerceIn(.03f,.12f)
}

/** State for one pressable control: share [source] with clickable(), apply [modifier] first in the chain so the whole control scales. */
internal class PressState(val source:MutableInteractionSource,val scale:Animatable<Float,AnimationVector1D>,val pressed:State<Boolean>){
    val modifier:Modifier get()=Modifier.graphicsLayer{scaleX=scale.value;scaleY=scale.value}
}

/** Drop-of-water press: bulges while held, springs back with one small undershoot on release. */
@Composable internal fun rememberPress(enabled:Boolean=true):Pair<PressState,Modifier>{
    val source=remember{MutableInteractionSource()}
    val scale=remember{Animatable(1f)}
    val pressed=remember{mutableStateOf(false)}
    val quiet=LocalQuiet.current
    var size by remember{mutableStateOf(IntSize.Zero)}
    val density=LocalDensity.current.density
    LaunchedEffect(source,quiet,enabled){
        source.interactions.collect{i->
            when(i){
                is PressInteraction.Press->{pressed.value=true;if(!quiet&&enabled)launch{scale.animateTo(1f+ProMotion.bulge(minOf(size.width,size.height)/density),ProMotion.pressIn)}}
                is PressInteraction.Release,is PressInteraction.Cancel->{pressed.value=false;if(!quiet)launch{scale.animateTo(1f,ProMotion.bounce())} else scale.snapTo(1f)}
            }
        }
    }
    val state=remember(source){PressState(source,scale,pressed)}
    return state to state.modifier.onSizeChanged{size=it}
}

/** One-shot "pop" when [key] becomes true (tool switched, item selected): 1 → 1.12 → 1 with the bounce spring. */
@Composable internal fun Modifier.popOn(key:Boolean):Modifier{
    val quiet=LocalQuiet.current
    val scale=remember{Animatable(1f)}
    LaunchedEffect(key){if(key&&!quiet){scale.snapTo(.86f);scale.animateTo(1f,ProMotion.bounce())}}
    return this.graphicsLayer{scaleX=scale.value;scaleY=scale.value}
}

/**
 * Staggered entrance for list items: rises 12 dp and fades in with the settle spring, 28 ms apart (first 10 items).
 * Only animates within [windowMs] of the list's first frame ([epoch]) so scrolling never replays it.
 */
@Composable internal fun Modifier.enterStagger(index:Int,epoch:Long,windowMs:Long=700):Modifier{
    val quiet=LocalQuiet.current
    val animate=remember{!quiet&&(System.nanoTime()-epoch)/1_000_000L<windowMs}
    val progress=remember{Animatable(if(animate)0f else 1f)}
    val lift=with(LocalDensity.current){12f*density}
    LaunchedEffect(Unit){if(animate){kotlinx.coroutines.delay(28L*index.coerceAtMost(10));progress.animateTo(1f,ProMotion.settle())}}
    return this.graphicsLayer{alpha=progress.value.coerceIn(0f,1f);translationY=(1f-progress.value)*lift}
}

/** Remember the moment a list first composed (for [enterStagger]). */
@Composable internal fun rememberListEpoch(vararg keys:Any?):Long=remember(*keys){System.nanoTime()}
