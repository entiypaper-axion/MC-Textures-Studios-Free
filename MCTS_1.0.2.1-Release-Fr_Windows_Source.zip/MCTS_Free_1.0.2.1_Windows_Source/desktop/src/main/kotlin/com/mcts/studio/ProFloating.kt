package com.mcts.studio

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** A snap guide line in dp: vertical (x = pos) or horizontal (y = pos). */
private data class Guide(val vertical:Boolean,val pos:Float)

/** Live (dp) rectangle of a block while it is dragged. */
private data class DpRect(val x:Float,val y:Float,val w:Float,val h:Float){val r get()=x+w;val b get()=y+h;val cx get()=x+w/2;val cy get()=y+h/2}

/**
 * Custom-UI workspace: every [Block] floats at its preset position. With [editing] the blocks become draggable/resizable
 * (four corner handles), snap to an 8 dp grid and to the edges/centres of the other blocks and the screen, and settle with the
 * panel spring. Content stays visible but does not take input while editing.
 */
@Composable internal fun FloatingWorkspace(model:StudioModel,spec:LayoutSpec,editing:Boolean,onChange:(LayoutSpec)->Unit,modifier:Modifier=Modifier,
                                           content:@Composable (Block)->Unit){
    BoxWithConstraints(modifier.fillMaxSize()){
        val w=maxWidth.value;val h=maxHeight.value
        var selected by remember{mutableStateOf<Block?>(null)}
        var guides by remember{mutableStateOf(emptyList<Guide>())}
        var grid by remember{mutableStateOf(true)}
        val current by rememberUpdatedState(spec)
        spec.order.forEachIndexed{z,block->
            val r=spec.rect(block)
            if(r.hidden&&!editing)return@forEachIndexed
            if(r.hidden)return@forEachIndexed
            key(block){
                FloatingBlock(model,block,r,w,h,z.toFloat(),editing,selected==block,grid,
                    others={current.order.filter{it!=block&&!current.rect(it).hidden}.map{o->current.rect(o).let{DpRect(it.x*w,it.y*h,it.w*w,it.h*h)}}},
                    onSelect={selected=block},
                    onGuides={guides=it},
                    onCommit={d->onChange(current.with(block,BlockRect(d.x/w,d.y/h,d.w/w,d.h/h)))}){CompositionLocalProvider(LocalFloatingBlock provides true){content(block)}}
            }
        }
        if(editing){
            val c=LocalPro.current
            Canvas(Modifier.fillMaxSize().zIndex(500f)){
                val dash=PathEffect.dashPathEffect(floatArrayOf(10f,8f))
                guides.forEach{g->val p=g.pos*density
                    if(g.vertical)drawLine(c.acc,Offset(p,0f),Offset(p,size.height),2f,pathEffect=dash) else drawLine(c.acc,Offset(0f,p),Offset(size.width,p),2f,pathEffect=dash)}
            }
            LayoutEditorBar(model,spec,selected,grid,{grid=it},onChange,{selected=it},Modifier.align(Alignment.BottomCenter).zIndex(1000f))
        }
    }
}

@Composable private fun FloatingBlock(model:StudioModel,block:Block,target:BlockRect,w:Float,h:Float,z:Float,editing:Boolean,selected:Boolean,grid:Boolean,
                                      others:()->List<DpRect>,onSelect:()->Unit,onGuides:(List<Guide>)->Unit,onCommit:(DpRect)->Unit,content:@Composable ()->Unit){
    val c=LocalPro.current;val quiet=LocalQuiet.current
    fun clampRect(d:DpRect):DpRect{
        val ww=d.w.coerceIn(minOf(block.minW,w),w);val hh=d.h.coerceIn(minOf(block.minH,h),h)
        return DpRect(d.x.coerceIn(0f,(w-ww).coerceAtLeast(0f)),d.y.coerceIn(0f,(h-hh).coerceAtLeast(0f)),ww,hh)
    }
    val goal=clampRect(DpRect(target.x*w,target.y*h,target.w*w,target.h*h))
    val ax=remember{Animatable(goal.x)};val ay=remember{Animatable(goal.y)};val aw=remember{Animatable(goal.w)};val ah=remember{Animatable(goal.h)}
    var dragging by remember{mutableStateOf(false)}
    val scope=rememberCoroutineScope()
    LaunchedEffect(goal){
        if(dragging)return@LaunchedEffect
        if(quiet){ax.snapTo(goal.x);ay.snapTo(goal.y);aw.snapTo(goal.w);ah.snapTo(goal.h);return@LaunchedEffect}
        launch{ax.animateTo(goal.x,ProMotion.settle())};launch{ay.animateTo(goal.y,ProMotion.settle())}
        launch{aw.animateTo(goal.w,ProMotion.settle())};launch{ah.animateTo(goal.h,ProMotion.settle())}
    }
    /** Snap a live rect: grid first, then edges/centres of the screen and other blocks within 8 dp. */
    fun snap(d:DpRect,resizing:Boolean):Pair<DpRect,List<Guide>>{
        var r=d
        if(grid)r=if(resizing)r.copy(w=(r.w/8f).roundToInt()*8f,h=(r.h/8f).roundToInt()*8f) else r.copy(x=(r.x/8f).roundToInt()*8f,y=(r.y/8f).roundToInt()*8f)
        val xs=mutableListOf(0f,w/2,w);val ys=mutableListOf(0f,h/2,h)
        others().forEach{o->xs+=listOf(o.x,o.r,o.cx,o.x-8f,o.r+8f);ys+=listOf(o.y,o.b,o.cy,o.y-8f,o.b+8f)}
        val found=mutableListOf<Guide>()
        fun near(v:Float,list:List<Float>)=list.minByOrNull{abs(it-v)}?.takeIf{abs(it-v)<8f}
        if(resizing){
            near(r.r,xs)?.let{r=r.copy(w=it-r.x);found+=Guide(true,it)}
            near(r.b,ys)?.let{r=r.copy(h=it-r.y);found+=Guide(false,it)}
        }else{
            val dx=listOf(r.x to 0f,r.cx to r.w/2,r.r to r.w).mapNotNull{(v,off)->near(v,xs)?.let{it to off}}.minByOrNull{abs(it.first-it.second-r.x)}
            dx?.let{(line,off)->r=r.copy(x=line-off);found+=Guide(true,line)}
            val dy=listOf(r.y to 0f,r.cy to r.h/2,r.b to r.h).mapNotNull{(v,off)->near(v,ys)?.let{it to off}}.minByOrNull{abs(it.first-it.second-r.y)}
            dy?.let{(line,off)->r=r.copy(y=line-off);found+=Guide(false,line)}
        }
        return clampRect(r) to found
    }
    val density=LocalDensity.current.density
    Box(Modifier.zIndex(z).offset(ax.value.dp,ay.value.dp).size(aw.value.dp,ah.value.dp)){
        content()
        if(editing){
            Box(Modifier.matchParentSize().clip(RoundedCornerShape(12.dp)).background(c.acc.copy(alpha=if(selected).14f else .06f))
                .border(if(selected)2.dp else 1.dp,c.acc.copy(alpha=if(selected)1f else .6f),RoundedCornerShape(12.dp))
                .semantics{contentDescription=block.label(model.language)}
                .pointerInput(block){detectTapGestures{onSelect()}}
                .pointerInput(block,grid,w,h){
                    var live=DpRect(0f,0f,0f,0f)
                    detectDragGestures(
                        onDragStart={onSelect();dragging=true;live=DpRect(ax.value,ay.value,aw.value,ah.value)},
                        onDragEnd={dragging=false;val (s,_)=snap(live,false);onGuides(emptyList());onCommit(s)
                            scope.launch{launch{ax.animateTo(s.x,ProMotion.settle())};launch{ay.animateTo(s.y,ProMotion.settle())}}},
                        onDragCancel={dragging=false;onGuides(emptyList())}){change,drag->
                        change.consume();live=live.copy(x=live.x+drag.x/density,y=live.y+drag.y/density)
                        val clamped=clampRect(live);onGuides(snap(live,false).second)
                        scope.launch{ax.snapTo(clamped.x);ay.snapTo(clamped.y)}
                    }
                }){
                Text(block.label(model.language),style=MaterialTheme.typography.labelMedium,color=c.accTx,
                    modifier=Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(6.dp)).background(c.acc).padding(horizontal=6.dp,vertical=2.dp))
            }
            if(selected){
                // corner handles: (sx,sy) = which edges move
                listOf(Triple(Alignment.TopStart,-1,-1),Triple(Alignment.TopEnd,1,-1),Triple(Alignment.BottomStart,-1,1),Triple(Alignment.BottomEnd,1,1)).forEach{(align,sx,sy)->
                    Box(Modifier.align(align).offset(if(sx<0)(-10).dp else 10.dp,if(sy<0)(-10).dp else 10.dp).size(28.dp)
                        .pointerInput(block,grid,w,h){
                            var live=DpRect(0f,0f,0f,0f)
                            detectDragGestures(
                                onDragStart={dragging=true;live=DpRect(ax.value,ay.value,aw.value,ah.value)},
                                onDragEnd={dragging=false;val (s,_)=snap(live,true);onGuides(emptyList());onCommit(s)
                                    scope.launch{launch{ax.animateTo(s.x,ProMotion.settle())};launch{ay.animateTo(s.y,ProMotion.settle())};launch{aw.animateTo(s.w,ProMotion.settle())};launch{ah.animateTo(s.h,ProMotion.settle())}}},
                                onDragCancel={dragging=false;onGuides(emptyList())}){change,drag->
                                change.consume()
                                val dx=drag.x/density;val dy=drag.y/density
                                var n=live
                                if(sx<0)n=n.copy(x=n.x+dx,w=n.w-dx) else n=n.copy(w=n.w+dx)
                                if(sy<0)n=n.copy(y=n.y+dy,h=n.h-dy) else n=n.copy(h=n.h+dy)
                                if(n.w<block.minW){if(sx<0)n=n.copy(x=n.r-block.minW);n=n.copy(w=block.minW)}
                                if(n.h<block.minH){if(sy<0)n=n.copy(y=n.b-block.minH);n=n.copy(h=block.minH)}
                                live=n
                                val clamped=clampRect(n);onGuides(snap(n,true).second)
                                scope.launch{ax.snapTo(clamped.x);ay.snapTo(clamped.y);aw.snapTo(clamped.w);ah.snapTo(clamped.h)}
                            }
                        },contentAlignment=Alignment.Center){
                        Box(Modifier.size(16.dp).clip(CircleShape).background(Color.White).border(3.dp,c.acc,CircleShape))
                    }
                }
            }
        }
    }
}

/** Floating toolbar while editing: z-order, hide/show, grid snapping, reset to the 1.0.1 arrangement, done. */
@Composable private fun LayoutEditorBar(model:StudioModel,spec:LayoutSpec,selected:Block?,grid:Boolean,onGrid:(Boolean)->Unit,onChange:(LayoutSpec)->Unit,onSelect:(Block?)->Unit,modifier:Modifier){
    val c=LocalPro.current
    var top by remember{mutableStateOf(false)}
    BoxWithConstraints(Modifier.fillMaxSize()){
        val maxW=maxWidth
        Column(Modifier.align(if(top)Alignment.TopCenter else Alignment.BottomCenter).padding(12.dp).widthIn(max=minOf(maxW-24.dp,760.dp))
            .proSurface(GlassKind.DIALOG,16.dp,c.group).padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
                ProIcon("ui_layout",c.acc,18.dp)
                Text(model.p("layout_editing").format(spec.name,model.p(if(model.layoutEditLandscape)"orientation_landscape" else "orientation_portrait")),
                    style=MaterialTheme.typography.labelLarge,color=c.tx,maxLines=1,modifier=Modifier.weight(1f))
                ProIconButton(if(top)"chev_down" else "chev_right",model.p(if(top)"layout_bar_bottom" else "layout_bar_top"),{top=!top},size=32.dp)
                ProButton(model.t("cancel"),model::cancelLayoutEdit,kind=ProKind.GHOST)
                ProButton(model.p("layout_done"),model::finishLayoutEdit,kind=ProKind.PRIMARY,icon="check")
            }
            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically){
                ProChip(model.p("layout_snap"),grid,{onGrid(!grid)})
                if(glassOn)ProChip(model.p("glass_pick"),model.glassPicking,{model.glassPicking=!model.glassPicking})
                if(selected!=null){
                    ProChip(model.p("layout_front"),false,{onChange(spec.toTop(selected))})
                    ProChip(model.p("layout_back"),false,{onChange(spec.toBottom(selected))})
                    if(selected!=Block.CANVAS)ProChip(model.p("layout_hide"),false,{onChange(spec.with(selected,spec.rect(selected).copy(hidden=true)));onSelect(null)})
                }
                spec.order.filter{spec.rect(it).hidden}.forEach{b->
                    ProChip("+ "+b.label(model.language),false,{onChange(spec.with(b,spec.rect(b).copy(hidden=false)).toTop(b));onSelect(b)})
                }
                ProChip(model.p("layout_seed"),false,{model.reseedLayoutEdit()})
            }
            if(model.glassPicking&&glassOn)Text(model.p("glass_pick_hint"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
            else if(selected==null)Text(model.p("layout_edit_hint"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
        }
    }
}

/** Settings section: presets for the current orientation. */
@Composable internal fun ProLayoutSettings(model:StudioModel,landscape:Boolean,onEdit:()->Unit,onExport:()->Unit,onImport:()->Unit){
    val c=LocalPro.current
    val revision=model.layoutRevision
    val names=remember(revision,landscape){model.layouts.names(landscape)}
    val active=remember(revision,landscape){model.layouts.slot(landscape).active}
    var renaming by remember{mutableStateOf<String?>(null)}
    var newName by remember{mutableStateOf("")}
    Text(model.p("custom_ui_hint"),style=MaterialTheme.typography.bodySmall,color=c.tx2)
    Text(model.p("orientation_now").format(model.p(if(landscape)"orientation_landscape" else "orientation_portrait")),style=MaterialTheme.typography.labelMedium,color=c.tx3)
    ProRadioRow(model.p("layout_default"),active==null,{model.selectLayout(landscape,null)},trailing=model.p("layout_responsive"))
    names.forEach{name->
        if(renaming==name){
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)){
                ProField(newName,{newName=it.take(40)},Modifier.weight(1f))
                ProButton(model.p("ok"),{if(model.renameLayout(landscape,name,newName))renaming=null},kind=ProKind.PRIMARY)
            }
        }else ProRadioRow(name,active==name,{model.selectLayout(landscape,name)})
    }
    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
        ProButton(model.p("layout_edit"),onEdit,icon="ui_layout",kind=ProKind.PRIMARY)
        ProButton(model.p("layout_new"),{model.newLayoutPreset(landscape);onEdit()},icon="plus")
        if(active!=null){
            ProButton(model.p("layout_rename"),{renaming=active;newName=active},kind=ProKind.GHOST)
            ProButton(model.p("layout_export"),onExport,icon="share",kind=ProKind.GHOST)
            ProButton(model.p("layout_delete"),{model.deleteLayout(landscape,active)},icon="delete",kind=ProKind.DANGER)
        }
        ProButton(model.p("layout_import"),onImport,icon="import",kind=ProKind.GHOST)
    }
    if(active!=null)ProButton(model.p("layout_reset"),{model.selectLayout(landscape,null);model.message="layout_reset_done"},Modifier.fillMaxWidth(),icon="rotate",kind=ProKind.GHOST)
}

/** dp helper for block minimums. */
internal val Block.minSize:Pair<Dp,Dp> get()=minW.dp to minH.dp
