package com.mcts.studio.compat

import java.awt.Desktop
import java.awt.Rectangle
import java.awt.Robot
import java.awt.Toolkit
import java.awt.datatransfer.StringSelection
import java.io.File
import java.net.URI
import javax.imageio.ImageIO

/** Where MCTS Free keeps its data on Windows: %LOCALAPPDATA%\MCTS Free\{files,cache} (templates are large, so not Roaming). */
object DesktopDirs {
    val base: File by lazy {
        val local = System.getenv("LOCALAPPDATA")?.takeIf { it.isNotBlank() }
        (if (local != null) File(local, "MCTS Free") else File(System.getProperty("user.home"), ".mcts-free")).also { it.mkdirs() }
    }
    val context: Application by lazy { Application(File(base, "files"), File(base, "cache")) }
}

object DesktopPlatform {
    val isWindows = System.getProperty("os.name").orEmpty().startsWith("Windows", ignoreCase = true)
    val osName: String get() = System.getProperty("os.name").orEmpty()
    val osVersion: String get() = System.getProperty("os.version").orEmpty()
    val osArch: String get() = System.getProperty("os.arch").orEmpty()
    val javaVersion: String get() = System.getProperty("java.runtime.version") ?: System.getProperty("java.version").orEmpty()

    fun openUrl(url: String): Boolean = runCatching {
        if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) { Desktop.getDesktop().browse(URI(url)); true }
        else if (isWindows) { ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", url).start(); true } else false
    }.getOrDefault(false)

    /** Opens Explorer with [file] selected (or the folder itself). */
    fun reveal(file: File): Boolean = runCatching {
        if (isWindows && file.exists()) { ProcessBuilder("explorer.exe", "/select,", file.absolutePath).start(); true }
        else { Desktop.getDesktop().open(if (file.isDirectory) file else file.absoluteFile.parentFile); true }
    }.getOrDefault(false)

    fun copyText(text: String) { runCatching { Toolkit.getDefaultToolkit().systemClipboard.setContents(StringSelection(text), null) } }

    /** Screenshot of the app window (feedback). */
    fun screenshotPng(target: File): Boolean = runCatching {
        val frame = DialogHost.frame ?: return false
        val p = frame.locationOnScreen
        val image = Robot().createScreenCapture(Rectangle(p.x, p.y, frame.width.coerceAtLeast(1), frame.height.coerceAtLeast(1)))
        ImageIO.write(image, "png", target)
    }.getOrDefault(false)

    /**
     * Windows "metered connection" (Settings → Network → Properties → Metered connection), read through the WinRT
     * NetworkInformation API in PowerShell on a background thread. Cached; refreshed when the window is focused.
     */
    @Volatile var metered = false; private set
    @Volatile private var checking = false
    fun refreshMetered() {
        if (!isWindows || checking) return
        checking = true
        Thread({
            try {
                val script = "[void][Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime];" +
                    "\$p=[Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile();if(\$p){\$p.GetConnectionCost().NetworkCostType}"
                val proc = ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script).redirectErrorStream(true).start()
                if (proc.waitFor(6, java.util.concurrent.TimeUnit.SECONDS)) {
                    val out = proc.inputStream.bufferedReader().readText().trim()
                    metered = out.contains("Fixed", true) || out.contains("Variable", true)
                } else proc.destroyForcibly()
            } catch (_: Exception) {} finally { checking = false }
        }, "mcts-metered").apply { isDaemon = true }.start()
    }

    /**
     * Windows "Animation effects" (Settings → Accessibility → Visual effects) = SPI_GETCLIENTAREAANIMATION.
     * Off there → the app's animations turn off too, like Android's "remove animations".
     */
    fun systemAnimationsOff(): Boolean {
        if (!isWindows) return false
        return runCatching {
            val user32 = com.sun.jna.Native.load("user32", User32::class.java)
            val value = IntArray(1) { 1 }
            user32.SystemParametersInfoW(0x1042, 0, value, 0) && value[0] == 0
        }.getOrDefault(false)
    }

    @Suppress("FunctionName")
    interface User32 : com.sun.jna.Library {
        fun SystemParametersInfoW(uiAction: Int, uiParam: Int, pvParam: IntArray, fWinIni: Int): Boolean
    }
}

/** Windows 10 (1809+) / 11: dark or light title bar to match the app theme (DWMWA_USE_IMMERSIVE_DARK_MODE). */
object DesktopTitleBar {
    @Volatile var window: java.awt.Window? = null
    private var applied: Boolean? = null
    private var wanted: Boolean? = null
    @Suppress("FunctionName")
    interface Dwm : com.sun.jna.Library {
        fun DwmSetWindowAttribute(hwnd: com.sun.jna.Pointer, attribute: Int, value: IntArray, size: Int): Int
    }
    private val dwm: Dwm? by lazy { if (DesktopPlatform.isWindows) runCatching { com.sun.jna.Native.load("dwmapi", Dwm::class.java) }.getOrNull() else null }
    /** Re-applies the last theme (the native window may not exist yet on the first call). */
    fun refresh() { wanted?.let { applied = null; apply(it) } }
    fun apply(dark: Boolean) {
        wanted = dark
        if (applied == dark) return
        val w = window ?: return
        val api = dwm ?: return
        runCatching {
            val hwnd = com.sun.jna.Native.getWindowPointer(w) ?: return
            val v = intArrayOf(if (dark) 1 else 0)
            // 20 = Windows 11 / 10 20H1+, 19 = Windows 10 1809–1909.
            if (api.DwmSetWindowAttribute(hwnd, 20, v, 4) != 0) api.DwmSetWindowAttribute(hwnd, 19, v, 4)
            applied = dark
        }
    }
}
