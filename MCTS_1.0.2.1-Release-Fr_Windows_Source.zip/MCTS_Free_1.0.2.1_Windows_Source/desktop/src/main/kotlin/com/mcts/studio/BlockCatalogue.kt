package com.mcts.studio

import com.mcts.studio.compat.AssetManager
import org.json.JSONObject

internal fun Language.catalogueIndex()=when(this){Language.EN->0;Language.ZH->1;Language.JA->2;Language.FR->3;Language.ES->4}

/** Compact semantic index: texture paths and labels, never game executables/models. */
data class BlockAsset(val id:String,val names:List<String>,val faces:List<String>,val paths:List<String>,val overlays:List<String?>,val tints:List<Boolean>) {
    fun label(language:Language)= "$id · ${names.getOrElse(language.catalogueIndex()){names.first()}}"
    val category get()=TemplateCategory.of("textures/block/$id.png").let { category->
        if(category==TemplateCategory.SINGLE_BLOCK&&faces.distinct().size>1)TemplateCategory.MULTI_BLOCK else category
    }
}
/** Versions without a bundled index borrow the nearest one of the same edition (names only, filtered to textures that exist). */
internal val catalogueFallback=mapOf(
    "java_164" to "java_1165","java_1710" to "java_1165","java_189" to "java_1165","java_1122" to "java_1165",
    "java_1206" to "java_1211","java_121" to "java_1211","java_1214" to "java_1211","java_263" to "java_262",
    "bedrock_12080" to "bedrock_12120","bedrock_1210" to "bedrock_12120","bedrock_12150" to "bedrock_12120","bedrock_2650" to "bedrock_2630")
private val bundledCatalogues=listOf("java_1165","java_1201","java_1211","java_12111","java_262","bedrock_116200","bedrock_1200","bedrock_12120","bedrock_121130","bedrock_2630")
private fun versionDistance(a:List<Int>,b:List<Int>):Long{
    fun n(v:List<Int>)=v.getOrElse(0){0}*1_000_000L+v.getOrElse(1){0}*1_000L+v.getOrElse(2){0}
    return kotlin.math.abs(n(a)-n(b))
}
/** Nearest bundled index for any profile (explicit table first). */
internal fun catalogueFor(profile:String):String{
    catalogueFallback[profile]?.let{return it}
    val p=profileById(profile)?:return profile
    fun norm(g:GameProfile)=if(g.parts.first()>=26)listOf(1)+g.parts else g.parts
    return bundledCatalogues.mapNotNull{profileById(it)}.filter{it.java==p.java}.minByOrNull{versionDistance(norm(p),norm(it))}?.id?:profile
}
/** Pre-1.13 Java names (blocks/stone, items/apple …) are mapped to the modern index through [LegacyNames]. */
internal fun isLegacyJava(profile:String)=profileById(profile)?.let{it.java&&it.format<4}?:false
class BlockCatalogue(assets:AssetManager,profile:String,available:Set<String>?=null){
    private val own=assets.list("catalogue")?.contains("$profile.json")==true
    private val source=if(own)profile else catalogueFor(profile)
    private val legacy=isLegacyJava(profile)
    private val json=runCatching{assets.open("catalogue/$source.json").bufferedReader().use{JSONObject(it.readText())}}.getOrElse{JSONObject().put("groups",org.json.JSONArray()).put("labels",JSONObject())}
    val blocks:List<BlockAsset>
    private val labels=json.getJSONObject("labels")
    init {
        val array=json.getJSONArray("groups")
        val directions=listOf("up","south","down","north","west","east")
        blocks=(0 until array.length()).map{index->val o=array.getJSONObject(index)
            val names=o.getJSONArray("names");val paths=o.getJSONArray("paths");val faces=o.getJSONObject("faces")
            val overlays=o.optJSONObject("overlays");val tints=o.optJSONObject("tints")
            BlockAsset(o.getString("id"),(0 until names.length()).map{names.getString(it)},directions.map{faces.getString(it)},(0 until paths.length()).map{paths.getString(it)},directions.map{overlays?.optString(it)?.takeIf{p->p.isNotBlank()}},directions.map{tints?.optBoolean(it,false)?:false})
        }.filter{group->!legacy&&(available==null||(own&&available.isEmpty())||group.paths.all{it in available})}
    }
    fun find(path:String):BlockAsset?{
        val raw=path.substringAfterLast('/').removeSuffix(".png")
        val stem=raw.replace(Regex("_(top|bottom|side|front|back|overlay)$"),"")
        val aliases=mapOf("grass" to "grass_block","log_oak" to "oak_log","log_spruce" to "spruce_log","log_birch" to "birch_log","planks_oak" to "oak_planks")
        val id=aliases[stem]?:stem
        return blocks.firstOrNull{it.id==raw&&path in it.paths}?:blocks.firstOrNull{it.id==id&&path in it.paths}?:blocks.filter{path in it.paths}.minByOrNull{if(it.category==TemplateCategory.PARTIAL_BLOCK)10+it.paths.size else it.paths.size}
    }
    fun label(path:String,language:Language):String{
        val original=path.substringAfterLast('/').removeSuffix(".png")
        val names=labels.optJSONArray(path)?:if(legacy)labels.optJSONArray(LegacyNames.modern(path))else null
        val name=names?.optString(language.catalogueIndex())?.takeIf{it.isNotBlank()}?:original.replace('_',' ')
        return "$original · $name"
    }
}
