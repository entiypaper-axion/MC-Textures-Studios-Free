package com.mcts.studio

/**
 * Java 1.6.4–1.12.2 use textures/blocks + textures/items and pre-1.13 names.
 * This maps a legacy path to its 1.13+ equivalent ONLY to look up display names in a modern catalogue.
 * Files are never renamed: exports keep the original legacy paths.
 */
internal object LegacyNames {
    private val colors=listOf("white","orange","magenta","light_blue","yellow","lime","pink","gray","silver","cyan","purple","blue","brown","green","red","black")
    private fun modernColor(c:String)=if(c=="silver")"light_gray" else c
    private val woods=mapOf("oak" to "oak","spruce" to "spruce","birch" to "birch","jungle" to "jungle","acacia" to "acacia","big_oak" to "dark_oak")
    private val blocks:Map<String,String> = buildMap {
        woods.forEach{(old,new)->put("planks_$old","${new}_planks");put("log_$old","${new}_log");put("log_${old}_top","${new}_log_top");put("leaves_$old","${new}_leaves")}
        listOf("oak","spruce","birch","jungle","acacia").forEach{put("sapling_$it","${it}_sapling")};put("sapling_roofed_oak","dark_oak_sapling")
        colors.forEach{c->val m=modernColor(c)
            put("wool_colored_$c","${m}_wool");put("hardened_clay_stained_$c","${m}_terracotta");put("glass_$c","${m}_stained_glass")
            put("glass_pane_top_$c","${m}_stained_glass_pane_top");put("concrete_$c","${m}_concrete");put("concrete_powder_$c","${m}_concrete_powder")
            put("glazed_terracotta_$c","${m}_glazed_terracotta");put("shulker_top_$c","${m}_shulker_box")}
        listOf("rose" to "rose_bush","syringa" to "lilac","grass" to "tall_grass","fern" to "large_fern","paeonia" to "peony","sunflower" to "sunflower").forEach{(old,new)->
            put("double_plant_${old}_bottom","${new}_bottom");put("double_plant_${old}_top","${new}_top")}
        putAll(mapOf(
            "stonebrick" to "stone_bricks","stonebrick_mossy" to "mossy_stone_bricks","stonebrick_cracked" to "cracked_stone_bricks","stonebrick_carved" to "chiseled_stone_bricks",
            "cobblestone_mossy" to "mossy_cobblestone","brick" to "bricks","nether_brick" to "nether_bricks","red_nether_brick" to "red_nether_bricks","end_bricks" to "end_stone_bricks",
            "grass_side" to "grass_block_side","grass_top" to "grass_block_top","grass_side_overlay" to "grass_block_side_overlay","grass_side_snowed" to "grass_block_snow",
            "dirt_podzol_side" to "podzol_side","dirt_podzol_top" to "podzol_top","farmland_dry" to "farmland","farmland_wet" to "farmland_moist",
            "stone_granite" to "granite","stone_granite_smooth" to "polished_granite","stone_diorite" to "diorite","stone_diorite_smooth" to "polished_diorite",
            "stone_andesite" to "andesite","stone_andesite_smooth" to "polished_andesite","sandstone_normal" to "sandstone","sandstone_carved" to "chiseled_sandstone",
            "sandstone_smooth" to "cut_sandstone","red_sandstone_normal" to "red_sandstone","red_sandstone_carved" to "chiseled_red_sandstone","red_sandstone_smooth" to "cut_red_sandstone",
            "quartz_block_chiseled" to "chiseled_quartz_block","quartz_block_lines" to "quartz_pillar","quartz_ore" to "nether_quartz_ore","hardened_clay" to "terracotta",
            "flower_rose" to "poppy","flower_dandelion" to "dandelion","flower_blue_orchid" to "blue_orchid","flower_allium" to "allium","flower_houstonia" to "azure_bluet",
            "flower_tulip_red" to "red_tulip","flower_tulip_orange" to "orange_tulip","flower_tulip_white" to "white_tulip","flower_tulip_pink" to "pink_tulip","flower_oxeye_daisy" to "oxeye_daisy",
            "tallgrass" to "grass","deadbush" to "dead_bush","mushroom_red" to "red_mushroom","mushroom_brown" to "brown_mushroom",
            "mushroom_block_skin_red" to "red_mushroom_block","mushroom_block_skin_brown" to "brown_mushroom_block","mushroom_block_skin_stem" to "mushroom_stem",
            "noteblock" to "note_block","furnace_front_off" to "furnace_front","pumpkin_face_off" to "carved_pumpkin","pumpkin_face_on" to "jack_o_lantern",
            "redstone_lamp_off" to "redstone_lamp","redstone_torch_on" to "redstone_torch","torch_on" to "torch",
            "rail_normal" to "rail","rail_normal_turned" to "rail_corner","rail_golden" to "powered_rail","rail_golden_powered" to "powered_rail_on",
            "rail_activator" to "activator_rail","rail_activator_powered" to "activator_rail_on","rail_detector" to "detector_rail","rail_detector_powered" to "detector_rail_on",
            "door_wood_lower" to "oak_door_bottom","door_wood_upper" to "oak_door_top","door_iron_lower" to "iron_door_bottom","door_iron_upper" to "iron_door_top","trapdoor" to "oak_trapdoor",
            "reeds" to "sugar_cane","waterlily" to "lily_pad","web" to "cobweb","mob_spawner" to "spawner","portal" to "nether_portal","ice_packed" to "packed_ice","slime" to "slime_block",
            "prismarine_rough" to "prismarine","prismarine_dark" to "dark_prismarine","sponge_wet" to "wet_sponge","stone_slab_top" to "smooth_stone","stone_slab_side" to "smooth_stone_slab_side",
            "anvil_base" to "anvil","anvil_top_damaged_0" to "anvil_top","anvil_top_damaged_1" to "chipped_anvil_top","anvil_top_damaged_2" to "damaged_anvil_top",
            "endframe_top" to "end_portal_frame_top","endframe_side" to "end_portal_frame_side","endframe_eye" to "end_portal_frame_eye",
            "melon_stem_disconnected" to "melon_stem","pumpkin_stem_disconnected" to "pumpkin_stem","piston_top_normal" to "piston_top",
            "comparator_off" to "comparator","repeater_off" to "repeater","dropper_front_horizontal" to "dropper_front","dispenser_front_horizontal" to "dispenser_front",
            "trip_wire_source" to "tripwire_hook","trip_wire" to "tripwire","nether_wart_block" to "nether_wart_block","magma" to "magma_block","bone_block_side" to "bone_block_side"))
    }
    private val items:Map<String,String> = buildMap {
        listOf("sword","shovel","pickaxe","axe","hoe").forEach{t->put("wood_$t","wooden_$t");put("gold_$t","golden_$t")}
        listOf("helmet","chestplate","leggings","boots").forEach{put("gold_$it","golden_$it")}
        val dyes=mapOf("black" to "ink_sac","red" to "red_dye","green" to "green_dye","brown" to "cocoa_beans","blue" to "lapis_lazuli","purple" to "purple_dye","cyan" to "cyan_dye",
            "silver" to "light_gray_dye","gray" to "gray_dye","pink" to "pink_dye","lime" to "lime_dye","yellow" to "yellow_dye","light_blue" to "light_blue_dye","magenta" to "magenta_dye",
            "orange" to "orange_dye","white" to "bone_meal")
        dyes.forEach{(c,n)->put("dye_powder_$c",n)}
        putAll(mapOf("apple_golden" to "golden_apple","bow_standing" to "bow","book_normal" to "book","book_writable" to "writable_book","book_written" to "written_book",
            "book_enchanted" to "enchanted_book","bucket_empty" to "bucket","bucket_water" to "water_bucket","bucket_lava" to "lava_bucket","bucket_milk" to "milk_bucket",
            "potion_bottle_drinkable" to "potion","potion_bottle_splash" to "splash_potion","potion_bottle_lingering" to "lingering_potion","potion_bottle_empty" to "glass_bottle",
            "seeds_wheat" to "wheat_seeds","seeds_melon" to "melon_seeds","seeds_pumpkin" to "pumpkin_seeds","fish_cod_raw" to "cod","fish_salmon_raw" to "salmon",
            "fish_cod_cooked" to "cooked_cod","fish_salmon_cooked" to "cooked_salmon","fish_clownfish_raw" to "tropical_fish","fish_pufferfish_raw" to "pufferfish",
            "porkchop_raw" to "porkchop","porkchop_cooked" to "cooked_porkchop","beef_raw" to "beef","beef_cooked" to "cooked_beef","chicken_raw" to "chicken","chicken_cooked" to "cooked_chicken",
            "mutton_raw" to "mutton","mutton_cooked" to "cooked_mutton","rabbit_raw" to "rabbit","rabbit_cooked" to "cooked_rabbit","potato_baked" to "baked_potato","potato_poisonous" to "poisonous_potato",
            "door_wood" to "oak_door","door_iron" to "iron_door","redstone_dust" to "redstone","reeds" to "sugar_cane","minecart_normal" to "minecart","minecart_chest" to "chest_minecart",
            "minecart_furnace" to "furnace_minecart","minecart_hopper" to "hopper_minecart","minecart_tnt" to "tnt_minecart","fireball" to "fire_charge","melon" to "melon_slice",
            "speckled_melon" to "glistering_melon_slice","gold_horse_armor" to "golden_horse_armor","netherbrick" to "nether_brick","slimeball" to "slime_ball","map_empty" to "map",
            "map_filled" to "filled_map","fishing_rod_uncast" to "fishing_rod","carrot_golden" to "golden_carrot","sign" to "oak_sign","boat" to "oak_boat","bed" to "red_bed",
            "fireworks" to "firework_rocket","fireworks_charge" to "firework_star","chorus_fruit_popped" to "popped_chorus_fruit","dragon_breath" to "dragon_breath","totem" to "totem_of_undying"))
    }
    private val stage=Regex("_stage_(\\d+)$")
    /** "assets/minecraft/textures/blocks/planks_oak.png" → "assets/minecraft/textures/block/oak_planks.png". Non-legacy paths are returned unchanged. */
    fun modern(path:String):String {
        val prefix="assets/minecraft/textures/"
        if(!path.startsWith(prefix))return path
        val rest=path.removePrefix(prefix);val folder=rest.substringBefore('/');val file=rest.substringAfterLast('/').removeSuffix(".png")
        return when(folder){
            "blocks"->prefix+"block/"+(blocks[file]?:file.replace(stage,"_stage$1"))+".png"
            "items"->prefix+"item/"+(items[file]?:file)+".png"
            else->path
        }
    }
}
