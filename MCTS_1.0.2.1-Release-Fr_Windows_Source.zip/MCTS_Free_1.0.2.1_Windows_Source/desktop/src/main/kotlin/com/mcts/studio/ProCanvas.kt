package com.mcts.studio

import com.mcts.studio.compat.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import com.mcts.core.CanvasGeometry
import com.mcts.core.MaterialDocument
import kotlin.math.*

/**
 * 1.0.1 drawing surface. Same geometry/hit-testing as 1.0.0 (CanvasGeometry), plus:
 * tools (pencil / white eraser / transparent erase / fill / picker / move), brush footprints,
 * long-press eyedropper, mouse wheel zoom, right/middle buttons, stylus side button and stylus-only mode.
 */
@Composable internal fun ProCanvas(model:StudioModel,view:PaintViewport,modifier:Modifier=Modifier){
    val c=LocalPro.current
    val doc=model.document;val channel=model.channel
    val pixels=remember(doc,model.revision,channel){doc.composite(channel)}
    val bitmap=remember(pixels){Bitmap.createBitmap(pixels,doc.width,doc.height,Bitmap.Config.ARGB_8888).asImageBitmap()}
    var viewport by remember{mutableStateOf(IntSize(1,1))}
    fun geometry()=CanvasGeometry(viewport.width.coerceAtLeast(1).toFloat(),viewport.height.coerceAtLeast(1).toFloat(),doc.width,doc.height,view.zoom,view.pan.x,view.pan.y)
    fun pixel(at:Offset):Pair<Int,Int>?{val g=geometry();val x=g.x(at.x);val y=g.y(at.y);return if(x>=0&&y>=0)x to y else null}
    val active=!model.busy
    val selected=model.selectedPixel
    val checkerLight=if(c.dark)Color(0xff2a2f36)else Color(0xffffffff)
    val checkerDark=if(c.dark)Color(0xff1f2329)else Color(0xffd5d9de)
    val description=model.p("canvas_description").format(doc.name,doc.width,doc.height)
    val scope=rememberCoroutineScope();val quiet=LocalQuiet.current
    // Windows: crosshair over the canvas, a hand while panning (Move tool, Space held).
    val cursor=if(model.tool==StudioModel.Tool.MOVE||model.spaceHeld)PointerIcon.Hand else PointerIcon.Crosshair
    // 1.0.2.1: the drawing is live content for the glass placed over it.
    Canvas(modifier.clip(RoundedCornerShape(4.dp)).glassSource().onSizeChanged{viewport=it}
        .pointerHoverIcon(cursor)
        .semantics{contentDescription=description}
        // Mouse wheel / trackpad scroll zooms around the pointer; hovering reports the pixel under the mouse.
        .pointerInput(doc){
            awaitPointerEventScope{
                while(true){
                    val event=awaitPointerEvent()
                    if(event.type==PointerEventType.Move||event.type==PointerEventType.Enter)event.changes.firstOrNull()?.let{view.hover=pixel(it.position)}
                    if(event.type==PointerEventType.Exit)view.hover=null
                    if(event.type==PointerEventType.Scroll){
                        val change=event.changes.firstOrNull()?:continue
                        val delta=change.scrollDelta.y
                        if(delta!=0f){
                            val old=view.zoom;val next=(old*(if(delta<0)1.15f else 1/1.15f)).coerceIn(.5f,256f)
                            val center=Offset(viewport.width/2f,viewport.height/2f);val at=change.position-center
                            view.pan=(view.pan-at)*(next/old)+at;view.scale(next)
                        }
                        change.consume()
                    }
                }
            }
        }
        .pointerInput(doc,channel,active){
            // Tool/settings are read per gesture (not keys): a temporary tool must not restart this coroutine mid-stroke.
            if(active)awaitEachGesture{
                val down=awaitFirstDown(requireUnconsumed=false)
                val start=down.position
                val type=down.type
                val buttons=currentEvent.buttons
                val mouse=type==PointerType.Mouse;val stylus=type==PointerType.Stylus||type==PointerType.Eraser
                // Decide what this gesture does before anything is painted.
                var temporary:StudioModel.Tool?=null
                var pan=model.spaceHeld||buttons.isTertiaryPressed||model.tool==StudioModel.Tool.MOVE
                var ignore=false
                fun secondary(action:StudioModel.PointerAction){when(action){
                    StudioModel.PointerAction.PICKER->temporary=StudioModel.Tool.PICKER
                    StudioModel.PointerAction.ERASE->temporary=StudioModel.Tool.ERASE
                    StudioModel.PointerAction.NONE->ignore=true}}
                if(mouse&&buttons.isSecondaryPressed)secondary(model.mouseRight)
                if(type==PointerType.Eraser)temporary=StudioModel.Tool.ERASE
                else if(stylus&&buttons.isSecondaryPressed)secondary(model.stylusButton)
                if(model.stylusOnly&&type==PointerType.Touch)pan=true
                if(temporary!=null)model.beginTemporaryTool(temporary!!)
                val tool=temporary?:model.tool
                val painting=!pan&&!ignore&&tool in setOf(StudioModel.Tool.PENCIL,StudioModel.Tool.ERASER,StudioModel.Tool.ERASE)
                var drawing=false;var transformed=false;var moved=false;var longPressed=false;var rawZoom=0f
                fun stroke(at:Offset){val cell=pixel(at);if(cell==null)model.paintPath(-1,-1)else model.paintPath(cell.first,cell.second)}
                try{
                    // Long press (finger only) = eyedropper without painting.
                    if(model.longPressPicker&&type==PointerType.Touch&&!pan&&!ignore){
                        val first=withTimeoutOrNull(450L){awaitPointerEvent()}
                        if(first==null){
                            longPressed=true
                            pixel(start)?.let{(x,y)->model.sample(x,y)}
                        }else{
                            val ch=first.changes.firstOrNull{it.id==down.id}
                            if(ch!=null&&(ch.position-start).getDistance()>viewConfiguration.touchSlop)moved=true
                            if(ch!=null&&!ch.pressed&&!moved){pixel(ch.position)?.let{(x,y)->model.tapCanvas(x,y)};return@awaitEachGesture}
                            if(first.changes.count{it.pressed}>1)transformed=true
                        }
                    }
                    do{
                        val event=awaitPointerEvent()
                        val pressed=event.changes.count{it.pressed}
                        val change=event.changes.firstOrNull{it.id==down.id}
                        if(pressed>1){
                            if(drawing){model.cancelStroke();drawing=false}
                            transformed=true
                            val old=view.zoom
                            // Raw (unresisted) zoom is tracked separately so stretching past the limit feels like a rubber band.
                            rawZoom=(if(rawZoom>0f)rawZoom else old)*event.calculateZoom()
                            val centroid=event.calculateCentroid(useCurrent=false)
                            if(centroid.isSpecified){
                                val center=Offset(viewport.width/2f,viewport.height/2f)
                                view.stretch(rawZoom);val next=view.zoom
                                view.pan=(view.pan-(centroid-center))*(next/old)+(centroid-center)+event.calculatePan()
                            }
                            event.changes.forEach{it.consume()}
                        }else if(change!=null&&!transformed&&!longPressed&&!ignore){
                            if(change.isConsumed){if(drawing){model.cancelStroke();drawing=false};transformed=true}
                            else{
                                if((change.position-start).getDistance()>viewConfiguration.touchSlop)moved=true
                                if(pan){view.pan+=change.position-change.previousPosition;change.consume()}
                                else if(painting&&moved){
                                    if(!drawing){pixel(start)?.let{(x,y)->model.beginStroke(x,y);drawing=true}}
                                    if(drawing){change.historical.forEach{stroke(it.position)};stroke(change.position)}
                                    change.consume()
                                }
                                if(!change.pressed&&!moved&&!pan){pixel(change.position)?.let{(x,y)->
                                    // A temporary picker (right button / side button) samples only; the picker TOOL returns to the pencil.
                                    if(temporary==StudioModel.Tool.PICKER)model.sample(x,y)else model.tapCanvas(x,y)
                                }}
                            }
                        }
                    }while(event.changes.any{it.pressed})
                }finally{
                    if(drawing)model.endStroke()
                    if(temporary!=null)model.endTemporaryTool()
                    if(transformed)scope.launch{view.settle(quiet)}
                }
            }
        }){
        val g=CanvasGeometry(size.width.coerceAtLeast(1f),size.height.coerceAtLeast(1f),doc.width,doc.height,view.zoom,view.pan.x,view.pan.y)
        // Transparent pixels show a checkerboard that uses the same geometry as painting and hit testing.
        val bx0=g.firstX();val bx1=g.lastX(size.width);val by0=g.firstY();val by1=g.lastY(size.height)
        val step=max(1,ceil(8.dp.toPx()/g.unit).toInt())
        if(bx0<=bx1&&by0<=by1)for(y in (by0/step*step)..by1 step step)for(x in (bx0/step*step)..bx1 step step){
            val left=max(g.left,g.screenX(x));val top=max(g.top,g.screenY(y))
            val right=min(g.screenX(doc.width),g.screenX(x+step));val bottom=min(g.screenY(doc.height),g.screenY(y+step))
            drawRect(if((x/step+y/step)%2==0)checkerLight else checkerDark,Offset(left,top),Size((right-left).coerceAtLeast(0f),(bottom-top).coerceAtLeast(0f)))
        }
        withTransform({translate(g.left,g.top);scale(g.unit,g.unit,pivot=Offset.Zero)}){drawImage(bitmap,dstSize=IntSize(doc.width,doc.height),filterQuality=FilterQuality.None)}
        val x0=g.firstX();val x1=g.lastX(size.width);val y0=g.firstY();val y1=g.lastY(size.height)
        if(model.pixelGrid&&x0<=x1&&y0<=y1&&g.unit>=3f){
            val alpha=(g.unit/28f).coerceIn(.08f,.34f);val line=(if(c.dark)Color(0xffc9ced6)else Color(0xff16191e)).copy(alpha=alpha)
            for(x in x0..x1+1)drawLine(line,Offset(g.screenX(x),max(0f,g.top)),Offset(g.screenX(x),min(size.height,g.screenY(doc.height))),strokeWidth=.7.dp.toPx())
            for(y in y0..y1+1)drawLine(line,Offset(max(0f,g.left),g.screenY(y)),Offset(min(size.width,g.screenX(doc.width)),g.screenY(y)),strokeWidth=.7.dp.toPx())
        }
        // Thin outline around the texture so a fully transparent texture is still findable.
        drawRect(c.line,Offset(g.left,g.top),Size(doc.width*g.unit,doc.height*g.unit),style=Stroke(1.dp.toPx()))
        val mirror=Color(0xffc93895)
        if(model.mirrorX)drawLine(mirror,Offset(g.screenX(doc.width)/2+g.left/2,max(0f,g.top)),Offset(g.screenX(doc.width)/2+g.left/2,min(size.height,g.screenY(doc.height))),strokeWidth=1.dp.toPx())
        if(model.mirrorY)drawLine(mirror,Offset(max(0f,g.left),g.screenY(doc.height)/2+g.top/2),Offset(min(size.width,g.screenX(doc.width)),g.screenY(doc.height)/2+g.top/2),strokeWidth=1.dp.toPx())
        selected?.let{(x,y)->
            // Brush footprint preview at the last touched pixel.
            val n=if(model.tool==StudioModel.Tool.FILL||model.tool==StudioModel.Tool.PICKER)1 else model.brushSize
            val startX=x-(n-1)/2;val startY=y-(n-1)/2
            drawRect(Color.White,Offset(g.screenX(startX),g.screenY(startY)),Size(g.unit*n,g.unit*n),style=Stroke(2.dp.toPx()))
            drawRect(c.acc,Offset(g.screenX(startX),g.screenY(startY)),Size(g.unit*n,g.unit*n),style=Stroke(1.dp.toPx()))
        }
    }
}

/** Bottom status pill: file, size, coordinates, tool, zoom. With "read pixel" on it is a polite live region. */
@Composable internal fun ProStatusBar(model:StudioModel,view:PaintViewport,modifier:Modifier=Modifier){
    val c=LocalPro.current
    val doc=model.document
    val revision=model.revision
    val pixel=view.hover?:model.selectedPixel
    val colorAt=remember(pixel,revision,doc){pixel?.let{(x,y)->doc.composite(MaterialDocument.Channel.COLOR).getOrNull(y*doc.width+x)}}
    val tool=model.p("tool_"+model.tool.name.lowercase())
    val coords=pixel?.let{"x ${it.first}  y ${it.second}"}?:"x –  y –"
    val hex=colorAt?.let{if((it ushr 24)==0)model.p("transparent") else "#"+Integer.toHexString(it).takeLast(6).uppercase()+if((it ushr 24)<255)" · ${((it ushr 24)*100/255)}%" else ""}
    val spoken=listOfNotNull(coords,hex,tool).joinToString(", ")
    Row(modifier.heightIn(min=30.dp).proSurface(GlassKind.BAR,9.dp,c.group).padding(horizontal=12.dp)
        .semantics(mergeDescendants=true){contentDescription=spoken;if(model.readPixel)liveRegion=LiveRegionMode.Polite},
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){
        val mono=MaterialTheme.typography.labelMedium.copy(fontFamily=ProMono)
        val file=remember(doc,model.pack.id){model.projectFiles.paths(model.pack).getProperty(com.mcts.core.ProjectStore.key(doc.kind,doc.name))?.substringAfterLast('/')?:(doc.name.substringAfterLast('/')+".png")}
        Text(file,style=mono,color=c.tx2,maxLines=1)
        Text("${doc.width}×${doc.height}",style=mono,color=c.tx3)
        Text(coords,style=mono,color=c.tx3)
        if(colorAt!=null)Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(5.dp)){
            Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).then(if((colorAt ushr 24)==0)Modifier.checker(2.5.dp)else Modifier.background(Color(colorAt))))
            Text(hex?:"",style=mono,color=c.tx3)
        }
        Text("${(view.zoom*100).roundToInt()}%",style=mono,color=c.tx3)
        Text(tool,style=MaterialTheme.typography.labelMedium,color=c.acc,maxLines=1)
    }
}
