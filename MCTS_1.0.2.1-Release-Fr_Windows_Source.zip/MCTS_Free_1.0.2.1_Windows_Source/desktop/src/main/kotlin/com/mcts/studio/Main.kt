package com.mcts.studio

import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.awtTransferable
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowPosition
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import com.mcts.studio.compat.DesktopDirs
import com.mcts.studio.compat.DesktopPlatform
import com.mcts.studio.compat.DesktopTitleBar
import com.mcts.studio.compat.DialogHost
import java.awt.Dimension
import java.awt.datatransfer.DataFlavor
import java.awt.event.WindowAdapter
import java.awt.event.WindowEvent
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * MCTS Free 1.0.2 for Windows. One window; dialogs, menus and the custom layout editor are drawn inside it
 * (Compose Desktop), so liquid glass, blur and the 1.0.2 motion behave exactly as on Android.
 */
@OptIn(ExperimentalComposeUiApi::class)
fun main() {
    // Template downloads use the Windows proxy settings (many users reach BMCLAPI / Mojang through one).
    System.setProperty("java.net.useSystemProxies", "true")
    // Crashes are written next to the data (no project content), so a report can include them.
    Thread.setDefaultUncaughtExceptionHandler { _, e ->
        runCatching { File(DesktopDirs.base, "crash.log").appendText("${java.time.LocalDateTime.now()} ${BuildConfig.VERSION_NAME}\n" + StringWriter().also { e.printStackTrace(PrintWriter(it)) } + "\n") }
        e.printStackTrace()
    }
    application {
        val model = remember { StudioModel(DesktopDirs.context) }
        // 1280×820 dp, or 92 % of the work area on small laptop screens (AWT bounds are in scaled units = dp).
        val work = remember { runCatching { java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().maximumWindowBounds }.getOrNull() }
        val w = minOf(1280f, (work?.width ?: 1280) * .92f); val h = minOf(820f, (work?.height ?: 820) * .92f)
        val state = rememberWindowState(size = DpSize(w.dp, h.dp), position = WindowPosition(Alignment.Center))
        var intro by remember { mutableStateOf(true) }
        Window(
            onCloseRequest = { model.saveBeforeExit(); model.clear(); exitApplication() },
            state = state,
            title = "MCTS Free",
            icon = mctsLogo?.let { BitmapPainter(it) },
        ) {
            DisposableEffect(window) {
                DialogHost.frame = window
                DesktopTitleBar.window = window
                window.minimumSize = Dimension(720, 520)
                fun readMotion() { model.systemReducedMotion = DesktopPlatform.systemAnimationsOff(); DesktopPlatform.refreshMetered() }
                readMotion()
                // Follow Windows "Animation effects" whenever the window comes back to the front (Android: on resume).
                val focus = object : WindowAdapter() {
                    override fun windowGainedFocus(e: WindowEvent?) { DesktopWindow.focused = true; readMotion(); DesktopTitleBar.refresh() }
                    override fun windowLostFocus(e: WindowEvent?) { DesktopWindow.focused = false }
                }
                window.addWindowFocusListener(focus)
                onDispose { window.removeWindowFocusListener(focus) }
            }
            val drop = remember {
                object : DragAndDropTarget {
                    override fun onDrop(event: DragAndDropEvent): Boolean {
                        val t = event.awtTransferable
                        if (!t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) return false
                        val file = (t.getTransferData(DataFlavor.javaFileListFlavor) as? List<*>)?.filterIsInstance<File>()?.firstOrNull { it.isFile } ?: return false
                        DesktopWindow.dropped = file
                        return true
                    }
                }
            }
            Box(Modifier.fillMaxSize().dragAndDropTarget(shouldStartDragAndDrop = { true }, target = drop)) {
                ProWorkspace(model)
                // 1.0.2: the promo's logo animation on every start; click anywhere to skip.
                if (intro) LogoIntro(BuildConfig.VERSION_NAME, model.motionOff) { intro = false }
            }
        }
    }
}
