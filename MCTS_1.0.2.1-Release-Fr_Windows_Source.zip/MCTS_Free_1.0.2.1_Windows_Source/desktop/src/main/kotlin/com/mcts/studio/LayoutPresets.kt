package com.mcts.studio

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

/**
 * 1.0.2 custom UI: every workspace block floats freely (move, resize, stack). Positions are fractions of the safe area,
 * so a preset survives rotation of the same orientation, other screen sizes and sharing between devices.
 * Portrait and landscape keep separate preset lists; "no active preset" = the responsive default layout.
 */
internal enum class Block(val key:String,val minW:Float,val minH:Float,val zh:String,val en:String,val ja:String,val fr:String,val es:String){
    BAR_LEFT("bar_left",56f,44f,"顶栏 · 左组","Top bar · left","上部バー・左","Barre · gauche","Barra · izquierda"),
    BAR_MID("bar_mid",56f,44f,"顶栏 · 中组","Top bar · centre","上部バー・中央","Barre · centre","Barra · centro"),
    BAR_RIGHT("bar_right",56f,44f,"顶栏 · 右组","Top bar · right","上部バー・右","Barre · droite","Barra · derecha"),
    SIDEBAR("sidebar",180f,120f,"素材 / 图层","Assets / layers","素材 / レイヤー","Ressources / calques","Recursos / capas"),
    PREVIEW("preview",120f,100f,"3D 预览","3D preview","3D プレビュー","Aperçu 3D","Vista 3D"),
    CANVAS("canvas",140f,120f,"画板","Canvas","キャンバス","Canevas","Lienzo"),
    COLOR("color",160f,100f,"调色","Colour","カラー","Couleur","Color"),
    TOOLS("tools",150f,80f,"工具","Tools","ツール","Outils","Herramientas"),
    HISTORY("history",150f,64f,"撤销 · 缩放","Undo · zoom","取り消し・ズーム","Annuler · zoom","Deshacer · zoom");
    fun label(language:Language)=when(language){Language.ZH->zh;Language.EN->en;Language.JA->ja;Language.FR->fr;Language.ES->es}
    companion object{fun of(key:String)=entries.firstOrNull{it.key==key}}
}

/** Fractions of the safe area (0..1). */
internal data class BlockRect(val x:Float,val y:Float,val w:Float,val h:Float,val hidden:Boolean=false)

internal data class LayoutSpec(val name:String,val blocks:Map<Block,BlockRect>,val order:List<Block>){
    fun rect(b:Block)=blocks[b]?:BlockRect(.3f,.3f,.3f,.3f)
    fun with(b:Block,r:BlockRect)=copy(blocks=blocks+(b to r))
    fun toTop(b:Block)=copy(order=order-b+b)
    fun toBottom(b:Block)=copy(order=listOf(b)+(order-b))
    fun json():JSONObject=JSONObject().put("name",name)
        .put("blocks",JSONObject().also{o->blocks.forEach{(b,r)->o.put(b.key,JSONArray(listOf(r.x.toDouble(),r.y.toDouble(),r.w.toDouble(),r.h.toDouble(),if(r.hidden)1 else 0)))}})
        .put("order",JSONArray(order.map{it.key}))
    companion object{
        fun parse(o:JSONObject):LayoutSpec{
            val b=o.getJSONObject("blocks");val map=LinkedHashMap<Block,BlockRect>()
            for(key in b.keys()){val block=Block.of(key)?:continue;val a=b.getJSONArray(key)
                fun f(i:Int)=a.getDouble(i).toFloat().also{if(it.isNaN()||it<-1f||it>2f)throw IOException("LAYOUT_INVALID")}
                map[block]=BlockRect(f(0),f(1),f(2).coerceAtLeast(.01f),f(3).coerceAtLeast(.01f),a.optInt(4,0)==1)}
            val order=(o.optJSONArray("order")?.let{a->(0 until a.length()).mapNotNull{Block.of(a.getString(it))}}?:emptyList()).distinct()
            val full=order+Block.entries.filter{it !in order}
            val name=o.optString("name","").trim().take(40).ifEmpty{"Layout"}
            return LayoutSpec(name,Block.entries.associateWith{map[it]?:defaultRect(it)},full)
        }
        private fun defaultRect(b:Block)=BlockRect(.35f,.35f,.3f,.3f,hidden=true)
    }
}

/**
 * Seed for a new preset: the 1.0.1 arrangement as floating blocks, computed for this safe area (dp).
 * Top-bar groups flow left to right and wrap when the screen is too narrow.
 */
internal fun seedLayout(name:String,w:Float,h:Float):LayoutSpec{
    val m=10f;val gap=8f
    val bars=listOf(Block.BAR_LEFT to (7*46f+8),Block.BAR_MID to (3*46f+8),Block.BAR_RIGHT to (9*46f+8))
    val rects=LinkedHashMap<Block,BlockRect>()
    fun put(b:Block,x:Float,y:Float,bw:Float,bh:Float)=rects.put(b,BlockRect(x/w,y/h,bw/w,bh/h))
    // bars: left, centre, right on one row when they fit, else wrap
    val barH=52f;var x=m;var y=6f
    val total=bars.sumOf{it.second.toDouble()}.toFloat()+gap*2+2*m
    if(total<=w){
        put(Block.BAR_LEFT,m,y,bars[0].second,barH);put(Block.BAR_MID,(w-bars[1].second)/2f,y,bars[1].second,barH);put(Block.BAR_RIGHT,w-m-bars[2].second,y,bars[2].second,barH)
        y+=barH+gap
    }else{
        for((b,bw) in bars){val ww=minOf(bw,w-2*m);if(x+ww>w-m){x=m;y+=barH+gap};put(b,x,y,ww,barH);x+=ww+gap}
        y+=barH+gap
    }
    val top=y;val bottom=h-m;val avail=bottom-top
    if(w>h){
        val sideW=minOf(328f,w*.27f);val toolW=minOf(236f,w*.22f)
        val previewH=minOf(210f,avail*.36f)
        put(Block.SIDEBAR,m,top,sideW,avail-previewH-gap)
        put(Block.PREVIEW,m,bottom-previewH,sideW,previewH)
        val tx=w-m-toolW
        // right column shares the height 42 / 32 / 26 % (panels scroll inside when short)
        val column=avail-2*gap
        val colorH=minOf(250f,column*.42f);val toolsH=minOf(200f,column*.32f)
        put(Block.COLOR,tx,top,toolW,colorH)
        put(Block.TOOLS,tx,top+colorH+gap,toolW,toolsH)
        put(Block.HISTORY,tx,top+colorH+toolsH+2*gap,toolW,column-colorH-toolsH)
        put(Block.CANVAS,m+sideW+gap,top,tx-gap-(m+sideW+gap),avail)
    }else{
        val canvasH=avail*.5f
        put(Block.CANVAS,m,top,w-2*m,canvasH)
        val y2=top+canvasH+gap;val rest=bottom-y2
        val half=(w-2*m-gap)/2f
        put(Block.TOOLS,m,y2,w-2*m,minOf(150f,rest*.38f))
        val y3=y2+minOf(150f,rest*.38f)+gap;val rest3=bottom-y3
        put(Block.COLOR,m,y3,half,rest3)
        put(Block.SIDEBAR,m+half+gap,y3,half,rest3*.62f)
        put(Block.HISTORY,m+half+gap,y3+rest3*.62f+gap,half,rest3*.38f-gap)
        put(Block.PREVIEW,w*.55f,top+12f,w*.4f,minOf(200f,canvasH*.45f))
        rects[Block.PREVIEW]=rects.getValue(Block.PREVIEW).copy(hidden=true)
    }
    return LayoutSpec(name,rects,listOf(Block.CANVAS,Block.SIDEBAR,Block.PREVIEW,Block.COLOR,Block.TOOLS,Block.HISTORY,Block.BAR_LEFT,Block.BAR_MID,Block.BAR_RIGHT))
}

/** Presets per orientation in files/layouts.json. Never throws on a damaged file: it starts over. */
internal class LayoutStore(private val file:File){
    class Slot(var active:String?=null,val presets:LinkedHashMap<String,LayoutSpec> = LinkedHashMap())
    private val slots=mapOf(true to Slot(),false to Slot())
    init{
        runCatching{
            val o=JSONObject(file.readText())
            for(land in listOf(true,false)){val s=o.optJSONObject(if(land)"landscape" else "portrait")?:continue
                val list=s.optJSONArray("presets")?:JSONArray()
                for(i in 0 until list.length())runCatching{LayoutSpec.parse(list.getJSONObject(i))}.getOrNull()?.let{slots.getValue(land).presets[it.name]=it}
                slots.getValue(land).active=s.optString("active","").takeIf{it.isNotBlank()&&it in slots.getValue(land).presets}}
        }
    }
    fun slot(landscape:Boolean)=slots.getValue(landscape)
    fun active(landscape:Boolean):LayoutSpec?=slot(landscape).let{s->s.active?.let{s.presets[it]}}
    fun names(landscape:Boolean)=slot(landscape).presets.keys.toList()
    fun put(landscape:Boolean,spec:LayoutSpec,activate:Boolean=true){val s=slot(landscape);s.presets[spec.name]=spec;if(activate)s.active=spec.name;save()}
    fun select(landscape:Boolean,name:String?){slot(landscape).active=name?.takeIf{it in slot(landscape).presets};save()}
    fun delete(landscape:Boolean,name:String){val s=slot(landscape);s.presets.remove(name);if(s.active==name)s.active=null;save()}
    fun rename(landscape:Boolean,old:String,next:String):Boolean{
        val s=slot(landscape);val n=next.trim().take(40);if(n.isEmpty()||n in s.presets)return false
        val spec=s.presets.remove(old)?:return false
        val rebuilt=LinkedHashMap<String,LayoutSpec>();rebuilt.putAll(s.presets);rebuilt[n]=spec.copy(name=n)
        s.presets.clear();s.presets.putAll(rebuilt);if(s.active==old)s.active=n;save();return true
    }
    fun uniqueName(landscape:Boolean,base:String):String{var i=1;while("$base $i" in slot(landscape).presets)i++;return "$base $i"}
    private fun save(){
        val o=JSONObject()
        for(land in listOf(true,false)){val s=slot(land)
            o.put(if(land)"landscape" else "portrait",JSONObject().put("active",s.active?:"").put("presets",JSONArray(s.presets.values.map{it.json()})))}
        val tmp=File(file.path+".tmp");tmp.writeText(o.toString())
        java.nio.file.Files.move(tmp.toPath(),file.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
    }
    companion object{
        /** Shareable file: one preset + the orientation it was made for. */
        fun export(spec:LayoutSpec,landscape:Boolean):ByteArray=JSONObject().put("mcts_layout",1).put("orientation",if(landscape)"landscape" else "portrait").put("preset",spec.json()).toString(2).toByteArray()
        fun import(bytes:ByteArray):Pair<LayoutSpec,Boolean>{
            if(bytes.size>256*1024)throw IOException("LAYOUT_INVALID")
            val o=runCatching{JSONObject(String(bytes,Charsets.UTF_8))}.getOrElse{throw IOException("LAYOUT_INVALID")}
            if(o.optInt("mcts_layout",0)!=1)throw IOException("LAYOUT_INVALID")
            return LayoutSpec.parse(o.getJSONObject("preset")) to (o.optString("orientation")=="landscape")
        }
    }
}
