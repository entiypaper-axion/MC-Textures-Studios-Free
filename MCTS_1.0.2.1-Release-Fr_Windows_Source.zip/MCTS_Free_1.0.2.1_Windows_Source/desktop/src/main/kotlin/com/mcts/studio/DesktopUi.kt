package com.mcts.studio

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.axion.pompreview.PreviewGeometry
import com.mcts.studio.compat.DesktopDirs
import com.mcts.studio.compat.argbImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

internal val LocalFreeDark = staticCompositionLocalOf { false }
internal val LocalQuiet = staticCompositionLocalOf { false }
internal val LocalTransparent = staticCompositionLocalOf { false }

private data class RenderKey(val frame: PreviewFrame, val mesh: PreviewGeometry.Result, val w: Int, val h: Int,
                             val yaw: Float, val pitch: Float, val distance: Float, val grid: Boolean)

/**
 * 3D block preview. Android draws it with OpenGL ES in basic mode (Free); Windows uses the CPU renderer in
 * [PreviewRenderer] with the identical camera, mesh, lighting and texture orientation.
 * Mouse: drag orbits (0.32° per dp), the wheel zooms (distance 2.55–8). Touch screens: one finger orbits, two pinch.
 */
@Composable
internal fun Preview(model: StudioModel, modifier: Modifier = Modifier) {
    val frame = remember(model.document, model.revision, model.previewFaceSet, model.chooseBlock, model.activeBlock, model.modelMesh) { model.preview() }
    val shape = if (model.chooseBlock) frame.shape else "minecraft:stone"
    // 1.0.2.1: the official model (with its own UVs) when there is one, otherwise the built-in shape.
    val quads = if (model.chooseBlock) model.modelMesh?.quads else null
    val mesh = remember(shape, quads) { runCatching { if (quads != null) PreviewGeometry.buildQuads(quads) else PreviewGeometry.build(shape) }.getOrNull() }
    var yaw by remember(model.previewAttempt) { mutableFloatStateOf(38f) }
    var pitch by remember(model.previewAttempt) { mutableFloatStateOf(24f) }
    var distance by remember(model.previewAttempt) { mutableFloatStateOf(4.25f) }
    var area by remember { mutableStateOf(IntSize(1, 1)) }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    val density = LocalDensity.current.density
    val currentFrame = rememberUpdatedState(frame)
    LaunchedEffect(mesh, model.previewAttempt) {
        if (mesh == null) { model.previewError(); return@LaunchedEffect }
        snapshotFlow {
            // Long side capped at 560 px (scaled up when drawn): a frame renders in a few ms on any PC.
            val scale = min(1f, 560f / max(area.width, area.height).coerceAtLeast(1))
            RenderKey(currentFrame.value, mesh, max(1, (area.width * scale).roundToInt()), max(1, (area.height * scale).roundToInt()), yaw, pitch, distance, model.pixelGrid)
        }.conflate().collect { k ->
            val pixels = withContext(Dispatchers.Default) {
                PreviewRenderer.render(k.mesh, k.frame.color, k.frame.size, k.w, k.h, PreviewRenderer.Camera(k.yaw, k.pitch, k.distance), k.grid)
            }
            image = runCatching { argbImageBitmap(pixels, k.w, k.h) }.getOrElse { model.previewError(); null }
        }
    }
    Box(modifier.background(Color(0xff060810))) {
        Box(Modifier.matchParentSize().onSizeChanged { area = it }
            .pointerHoverIcon(PointerIcon.Hand)
            .semantics { contentDescription = model.t("preview") + ": " + model.document.name }
            .pointerInput(model.previewAttempt) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent()
                        if (e.type == PointerEventType.Scroll) {
                            val d = e.changes.firstOrNull()?.scrollDelta?.y ?: 0f
                            if (d != 0f) distance = (distance * (if (d > 0) 1.1f else 1 / 1.1f)).coerceIn(2.55f, 8f)
                            e.changes.forEach { it.consume() }
                        }
                    }
                }
            }
            .pointerInput(model.previewAttempt, density) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var previousSpan = 0f
                    while (true) {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.filter { it.pressed }
                        if (pressed.isEmpty()) break
                        if (pressed.size >= 2) {
                            val a = pressed[0].position; val b = pressed[1].position
                            val span = sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y))
                            if (previousSpan > 0f && span > 1f) distance = (distance * (previousSpan / span)).coerceIn(2.55f, 8f)
                            previousSpan = span
                        } else {
                            previousSpan = 0f
                            val d = pressed[0].positionChange()
                            if (d != Offset.Zero) {
                                yaw += d.x / density * .32f
                                pitch = (pitch + d.y / density * .32f).coerceIn(-78f, 78f)
                            }
                        }
                        event.changes.forEach { it.consume() }
                    }
                }
            }) {
            image?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low) }
        }
        if (model.previewFailed) Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).padding(12.dp), verticalArrangement = Arrangement.Center) {
            Text(model.t("error_preview"), style = MaterialTheme.typography.bodySmall)
            ProButton(model.t("retry"), model::retryPreview, kind = ProKind.GHOST)
        }
    }
}

/** The app logo (Android: R.drawable.mcts_logo), bundled as assets/mcts_logo.png. */
internal val mctsLogo: ImageBitmap? by lazy {
    runCatching { org.jetbrains.skia.Image.makeFromEncoded(DesktopDirs.context.assets.bytes("mcts_logo.png")).toComposeImageBitmap() }.getOrNull()
}

@Composable
internal fun McTsLogo(modifier: Modifier = Modifier) {
    val logo = mctsLogo
    if (logo != null) Image(logo, null, modifier, filterQuality = FilterQuality.Medium) else Box(modifier)
}

/** Save dialog for packs: the suggested name keeps its .zip / .mcpack extension (Android: a MIME trick for DocumentsUI). */
internal class ExportPackDocument : com.mcts.studio.compat.ActivityResultContracts.CreateDocument("application/octet-stream") {
    companion object {
        fun mimeType(fileName: String): String =
            if (fileName.endsWith(".mcpack", ignoreCase = true)) "application/octet-stream" else "application/zip"
    }
}
