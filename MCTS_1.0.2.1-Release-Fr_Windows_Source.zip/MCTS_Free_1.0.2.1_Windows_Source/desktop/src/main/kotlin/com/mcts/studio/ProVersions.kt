package com.mcts.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp

/** Version lines newest first ("26.3", "26.2" … "1.6", "1.5", "1.0 – 1.4"). */
internal fun versionLines(java:Boolean):List<Pair<String,List<GameProfile>>> =
    offeredProfiles.filter{it.java==java}.groupBy{it.line}.toList()
        .sortedWith(compareByDescending<Pair<String,List<GameProfile>>>{it.second.first().parts.getOrElse(0){0}}.thenByDescending{it.second.first().parts.getOrElse(1){0}})
        .map{(line,list)->line to list.sortedWith(compareByDescending<GameProfile>{it.parts.getOrElse(1){0}}.thenByDescending{it.parts.getOrElse(2){0}})}

/**
 * 1.0.2 version picker: every Java release 1.0 – 26.3 and the matching Bedrock samples, grouped by line.
 * The selected line is open; others fold to one row. A search box filters by version text.
 */
@Composable internal fun ProVersionPicker(model:StudioModel,selected:GameProfile,onSelect:(GameProfile)->Unit,enabled:Boolean=true,trailing:(GameProfile)->String?={null}){
    val c=LocalPro.current
    var query by remember{mutableStateOf("")}
    val lines=remember(selected.java){versionLines(selected.java)}
    var open by remember(selected.java){mutableStateOf(setOf(selected.line))}
    LaunchedEffect(selected.id){open=open+selected.line}
    Column(verticalArrangement=Arrangement.spacedBy(4.dp)){
        ProField(query,{query=it.take(12)},Modifier.fillMaxWidth(),placeholder=model.p("version_search"),leading="search",mono=true,enabled=enabled)
        val q=query.trim()
        if(q.isNotEmpty()){
            val hits=lines.flatMap{it.second}.filter{it.version.startsWith(q)||it.version.contains(q)}
            if(hits.isEmpty())Text(model.p("version_none"),style=MaterialTheme.typography.bodySmall,color=c.tx3,modifier=Modifier.padding(8.dp))
            hits.take(40).forEach{p->ProRadioRow(p.label,p.id==selected.id,{onSelect(p)},trailing=trailing(p),enabled=enabled)}
            return@Column
        }
        lines.forEach{(line,list)->
            val expanded=line in open
            val cached=list.count{it.id in model.availableTemplates}
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp)).background(if(list.any{it.id==selected.id})c.raised else androidx.compose.ui.graphics.Color.Transparent)
                .clickable(enabled=enabled,role=Role.Button){open=if(expanded)open-line else open+line}
                .semantics{stateDescription=if(expanded)"expanded" else "collapsed"}
                .padding(horizontal=10.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
                ProIcon("chev_right",c.tx3,16.dp,Modifier.rotate(if(expanded)90f else 0f))
                Text((if(selected.java)"Java " else "Bedrock ")+line+if(list.size>1&&!line.contains('–'))".x" else "",style=MaterialTheme.typography.bodyMedium.copy(fontFamily=ProMono),color=c.tx,modifier=Modifier.weight(1f))
                if(list.first().texturePack)Text(model.p("texture_pack_badge"),style=MaterialTheme.typography.labelSmall,color=c.acc,
                    modifier=Modifier.clip(RoundedCornerShape(5.dp)).background(c.accSoft).padding(horizontal=6.dp,vertical=2.dp))
                Text(model.p("version_count").format(list.size)+if(cached>0)" · ✓$cached" else "",style=MaterialTheme.typography.labelSmall,color=c.tx3)
            }
            if(expanded)Column(Modifier.padding(start=14.dp),verticalArrangement=Arrangement.spacedBy(2.dp)){
                list.forEach{p->ProRadioRow(p.label,p.id==selected.id,{onSelect(p)},trailing=trailing(p),enabled=enabled)}
            }
        }
    }
}

/** Extra explanation under the picker for the old formats. */
@Composable internal fun ProVersionNotes(model:StudioModel,profile:GameProfile){
    val c=LocalPro.current
    if(profile.texturePack)ProNote(model.p(if(profile.atlas)"texture_pack_atlas_note" else "texture_pack_note"))
    if(profile.java&&profile.pair==null)Text(model.p("no_bedrock_pair"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
    profile.counterpart()?.let{Text(model.p("paired_with").format(it.label),style=MaterialTheme.typography.bodySmall,color=c.tx3)}
}
