package com.mcts.studio

import androidx.compose.ui.input.key.Key

/** Keyboard shortcuts (Windows keyboard). Codes are Compose [Key.keyCode] values so they survive layout/language changes; "ctrl" = Ctrl. */
enum class KeyAction(val zh: String, val en: String, val ja: String, val fr: String, val es: String) {
    PENCIL("画笔", "Pencil", "ペン", "Crayon", "Lápiz"),
    ERASER("橡皮（白色）", "Eraser (white)", "消しゴム（白）", "Gomme (blanc)", "Goma (blanco)"),
    ERASE("擦除（透明）", "Erase (transparent)", "消去（透明）", "Effacer (transparent)", "Borrar (transparente)"),
    FILL("填充", "Fill", "塗りつぶし", "Remplir", "Rellenar"),
    PICKER("吸管", "Eyedropper", "スポイト", "Pipette", "Cuentagotas"),
    MOVE("移动", "Move", "移動", "Déplacer", "Mover"),
    MIRROR("镜像", "Mirror", "ミラー", "Miroir", "Espejo"),
    GRID("网格", "Grid", "グリッド", "Grille", "Cuadrícula"),
    UNDO("撤销", "Undo", "元に戻す", "Annuler", "Deshacer"),
    REDO("重做", "Redo", "やり直す", "Rétablir", "Rehacer"),
    REDO_ALT("重做（备用）", "Redo (alternate)", "やり直す（予備）", "Rétablir (autre)", "Rehacer (alternativo)"),
    BRUSH_DOWN("笔刷变小", "Smaller brush", "ブラシを小さく", "Pinceau plus petit", "Pincel más pequeño"),
    BRUSH_UP("笔刷变大", "Larger brush", "ブラシを大きく", "Pinceau plus grand", "Pincel más grande"),
    SWAP("交换主副色", "Swap colours", "メイン色とサブ色を入替", "Inverser les couleurs", "Intercambiar colores"),
    SAVE("保存", "Save", "保存", "Enregistrer", "Guardar"),
    EXPORT("导出", "Export", "書き出し", "Exporter", "Exportar"),
    ZOOM_IN("放大", "Zoom in", "拡大", "Zoom avant", "Acercar"),
    ZOOM_OUT("缩小", "Zoom out", "縮小", "Zoom arrière", "Alejar"),
    FIT("适配", "Fit", "全体表示", "Ajuster", "Ajustar");
    fun label(language: Language) = when (language) { Language.ZH -> zh; Language.EN -> en; Language.JA -> ja; Language.FR -> fr; Language.ES -> es }
}

/** Key names for display (Compose key codes differ per platform, so labels come from this table). */
private val KEY_NAMES: Map<Long, String> by lazy {
    val m = HashMap<Long, String>()
    val letters = listOf(Key.A, Key.B, Key.C, Key.D, Key.E, Key.F, Key.G, Key.H, Key.I, Key.J, Key.K, Key.L, Key.M, Key.N, Key.O, Key.P, Key.Q, Key.R, Key.S, Key.T, Key.U, Key.V, Key.W, Key.X, Key.Y, Key.Z)
    letters.forEachIndexed { i, k -> m[k.keyCode] = ('A' + i).toString() }
    val digits = listOf(Key.Zero, Key.One, Key.Two, Key.Three, Key.Four, Key.Five, Key.Six, Key.Seven, Key.Eight, Key.Nine)
    digits.forEachIndexed { i, k -> m[k.keyCode] = i.toString() }
    m[Key.LeftBracket.keyCode] = "["; m[Key.RightBracket.keyCode] = "]"; m[Key.Equals.keyCode] = "="; m[Key.Minus.keyCode] = "-"
    m[Key.Spacebar.keyCode] = "Space"; m[Key.Plus.keyCode] = "+"; m[Key.Comma.keyCode] = ","; m[Key.Period.keyCode] = "."; m[Key.Slash.keyCode] = "/"
    m[Key.Semicolon.keyCode] = ";"; m[Key.Apostrophe.keyCode] = "'"; m[Key.Backslash.keyCode] = "\\"; m[Key.Grave.keyCode] = "`"
    m[Key.Tab.keyCode] = "Tab"; m[Key.Enter.keyCode] = "Enter"; m[Key.Backspace.keyCode] = "Backspace"; m[Key.Delete.keyCode] = "Delete"
    m[Key.DirectionUp.keyCode] = "↑"; m[Key.DirectionDown.keyCode] = "↓"; m[Key.DirectionLeft.keyCode] = "←"; m[Key.DirectionRight.keyCode] = "→"
    listOf(Key.F1, Key.F2, Key.F3, Key.F4, Key.F5, Key.F6, Key.F7, Key.F8, Key.F9, Key.F10, Key.F11, Key.F12).forEachIndexed { i, k -> m[k.keyCode] = "F${i + 1}" }
    m
}

data class KeyChord(val code: Long, val ctrl: Boolean = false, val shift: Boolean = false, val alt: Boolean = false) {
    fun label(): String {
        val name = KEY_NAMES[code] ?: "#$code"
        // "Shift+3" is shown as "#" (US layout), matching the shortcut list in the guide.
        if (shift && !ctrl && !alt && code == Key.Three.keyCode) return "#"
        return listOfNotNull(if (ctrl) "Ctrl" else null, if (alt) "Alt" else null, if (shift) "Shift" else null, name).joinToString("+")
    }
    fun encode() = "$code,${if (ctrl) 1 else 0},${if (shift) 1 else 0},${if (alt) 1 else 0}"
    companion object {
        fun decode(text: String): KeyChord? {
            val p = text.split(','); if (p.size != 4) return null
            val code = p[0].toLongOrNull() ?: return null
            return KeyChord(code, p[1] == "1", p[2] == "1", p[3] == "1")
        }
        /** Modifier keys alone can never be a shortcut. */
        fun isModifier(code: Long) = code in setOf(Key.CtrlLeft.keyCode, Key.CtrlRight.keyCode, Key.ShiftLeft.keyCode, Key.ShiftRight.keyCode,
            Key.AltLeft.keyCode, Key.AltRight.keyCode, Key.MetaLeft.keyCode, Key.MetaRight.keyCode, Key.Function.keyCode, Key.CapsLock.keyCode)
    }
}

class Keymap private constructor(private val map: Map<KeyAction, KeyChord>) {
    fun chord(action: KeyAction) = map[action]
    fun action(chord: KeyChord) = map.entries.firstOrNull { it.value == chord }?.key
    /** A chord belongs to one action only: binding it moves it away from any previous owner. */
    fun bind(action: KeyAction, chord: KeyChord) = Keymap(map.filterValues { it != chord } + (action to chord))
    fun save() = map.entries.joinToString(";") { "${it.key.name}=${it.value.encode()}" }
    companion object {
        fun defaults() = Keymap(mapOf(
            KeyAction.PENCIL to KeyChord(Key.B.keyCode), KeyAction.ERASER to KeyChord(Key.E.keyCode), KeyAction.ERASE to KeyChord(Key.E.keyCode, shift = true),
            KeyAction.FILL to KeyChord(Key.G.keyCode), KeyAction.PICKER to KeyChord(Key.I.keyCode), KeyAction.MOVE to KeyChord(Key.V.keyCode),
            KeyAction.MIRROR to KeyChord(Key.M.keyCode), KeyAction.GRID to KeyChord(Key.Three.keyCode, shift = true),
            KeyAction.UNDO to KeyChord(Key.Z.keyCode, ctrl = true), KeyAction.REDO to KeyChord(Key.Y.keyCode, ctrl = true), KeyAction.REDO_ALT to KeyChord(Key.Z.keyCode, ctrl = true, shift = true),
            KeyAction.BRUSH_DOWN to KeyChord(Key.LeftBracket.keyCode), KeyAction.BRUSH_UP to KeyChord(Key.RightBracket.keyCode), KeyAction.SWAP to KeyChord(Key.X.keyCode),
            KeyAction.SAVE to KeyChord(Key.S.keyCode, ctrl = true), KeyAction.EXPORT to KeyChord(Key.E.keyCode, ctrl = true),
            KeyAction.ZOOM_IN to KeyChord(Key.Equals.keyCode, ctrl = true), KeyAction.ZOOM_OUT to KeyChord(Key.Minus.keyCode, ctrl = true), KeyAction.FIT to KeyChord(Key.Zero.keyCode, ctrl = true)))
        fun load(text: String?): Keymap {
            if (text.isNullOrBlank()) return defaults()
            val parsed = text.split(';').mapNotNull { entry ->
                val k = entry.substringBefore('='); val v = entry.substringAfter('=', "")
                val action = KeyAction.entries.firstOrNull { it.name == k } ?: return@mapNotNull null
                KeyChord.decode(v)?.let { action to it }
            }.toMap()
            // Actions added in later versions fall back to their defaults.
            return Keymap(defaults().map.filterKeys { it !in parsed }.filterValues { it !in parsed.values } + parsed)
        }
    }
}
