package com.mcts.studio.compat

import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asComposeImageBitmap
import com.mcts.core.Png
import com.mcts.core.PngDecoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.Properties
import javax.imageio.ImageIO

/*
 * Windows (Compose Desktop) stand-ins for the handful of Android framework classes the shared 1.0.2 model code uses.
 * They keep StudioModel / Projects / TemplateStore line-for-line identical to the Android build: a "Uri" is a local
 * file chosen in the Windows file dialog, preferences are small properties files, assets are classpath resources.
 */

/** A local file picked by the user (Android: content:// Uri). */
class Uri private constructor(val file: File) {
    val lastPathSegment: String get() = file.name
    override fun toString() = file.toURI().toString()
    override fun equals(other: Any?) = other is Uri && other.file == file
    override fun hashCode() = file.hashCode()
    companion object { fun fromFile(file: File) = Uri(file.absoluteFile) }
}

class ContentResolver {
    fun openInputStream(uri: Uri): InputStream? = if (uri.file.isFile) FileInputStream(uri.file) else null
    /** "w"/"wt" truncate (the only modes the app uses). Writes go to a sibling temp file first, then replace the target. */
    fun openOutputStream(uri: Uri, mode: String = "w"): OutputStream? {
        val target = uri.file
        target.absoluteFile.parentFile?.mkdirs()
        val tmp = File(target.absoluteFile.parentFile, "." + target.name + ".part")
        val out = FileOutputStream(tmp)
        return object : OutputStream() {
            private var closed = false
            override fun write(b: Int) = out.write(b)
            override fun write(b: ByteArray, off: Int, len: Int) = out.write(b, off, len)
            override fun flush() = out.flush()
            override fun close() {
                if (closed) return
                closed = true
                out.close()
                try { Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING) }
                catch (e: IOException) { tmp.delete(); throw IOException("OUTPUT_PERMISSION", e) }
            }
        }
    }
}

/** Bundled assets (Android: app/src/main/assets) live on the classpath under /assets. */
class AssetManager {
    private val index: List<String> by lazy {
        javaClass.getResourceAsStream("/assets/asset-index.txt")?.bufferedReader(Charsets.UTF_8)?.use { r -> r.readLines().map { it.trim() }.filter { it.isNotEmpty() } } ?: emptyList()
    }
    fun open(name: String): InputStream = javaClass.getResourceAsStream("/assets/" + name.trimStart('/')) ?: throw IOException("ASSET_MISSING")
    fun exists(name: String) = javaClass.getResource("/assets/" + name.trimStart('/')) != null
    /** Direct children of [path] ("catalogue" → ["java_1165.json", …]), like AssetManager.list. */
    fun list(path: String): Array<String> {
        val prefix = path.trim('/').let { if (it.isEmpty()) "" else "$it/" }
        return index.filter { it.startsWith(prefix) }.map { it.removePrefix(prefix).substringBefore('/') }.distinct().toTypedArray()
    }
    fun bytes(name: String): ByteArray = open(name).use { it.readBytes() }
}

/** SharedPreferences backed by one .properties file per name; writes are atomic and immediate (files are tiny). */
class SharedPreferences internal constructor(private val file: File) {
    private val values = Properties()
    init { runCatching { if (file.isFile) FileInputStream(file).use { values.load(it) } } }
    @Synchronized fun getString(key: String, def: String?): String? = values.getProperty(key) ?: def
    @Synchronized fun getBoolean(key: String, def: Boolean) = values.getProperty(key)?.toBooleanStrictOrNull() ?: def
    @Synchronized fun getInt(key: String, def: Int) = values.getProperty(key)?.toIntOrNull() ?: def
    @Synchronized fun getLong(key: String, def: Long) = values.getProperty(key)?.toLongOrNull() ?: def
    @Synchronized fun getFloat(key: String, def: Float) = values.getProperty(key)?.toFloatOrNull() ?: def
    @Synchronized fun contains(key: String) = values.containsKey(key)
    fun edit() = Editor()
    inner class Editor {
        private val puts = LinkedHashMap<String, String?>()
        private var clear = false
        fun putString(key: String, value: String?) = apply { puts[key] = value }
        fun putBoolean(key: String, value: Boolean) = apply { puts[key] = value.toString() }
        fun putInt(key: String, value: Int) = apply { puts[key] = value.toString() }
        fun putLong(key: String, value: Long) = apply { puts[key] = value.toString() }
        fun putFloat(key: String, value: Float) = apply { puts[key] = value.toString() }
        fun remove(key: String) = apply { puts[key] = null }
        fun clear() = apply { clear = true }
        fun apply() { commit() }
        fun commit(): Boolean = synchronized(this@SharedPreferences) {
            if (clear) values.clear()
            for ((k, v) in puts) if (v == null) values.remove(k) else values.setProperty(k, v)
            runCatching {
                file.parentFile?.mkdirs()
                val tmp = File(file.path + ".tmp")
                FileOutputStream(tmp).use { values.store(it, "MCTS Free") }
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }.isSuccess
        }
    }
}

/** Android Context: private files, cache, assets, preferences. */
open class Context(val filesDir: File, val cacheDir: File) {
    val assets = AssetManager()
    val contentResolver = ContentResolver()
    private val prefs = HashMap<String, SharedPreferences>()
    init { filesDir.mkdirs(); cacheDir.mkdirs() }
    fun getSharedPreferences(name: String, @Suppress("UNUSED_PARAMETER") mode: Int): SharedPreferences =
        synchronized(prefs) { prefs.getOrPut(name) { SharedPreferences(File(File(filesDir, "prefs"), "$name.properties")) } }
}
open class Application(filesDir: File, cacheDir: File) : Context(filesDir, cacheDir)

/** ViewModel base: one main-thread scope (Swing EDT, where Compose Desktop runs), cancelled by [clear]. */
open class AndroidViewModel(private val application: Application) {
    val viewModelScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    @Suppress("UNCHECKED_CAST") fun <T : Application> getApplication(): T = application as T
    protected open fun onCleared() {}
    fun clear() { onCleared(); viewModelScope.cancel() }
}

object Log {
    fun e(tag: String, msg: String, t: Throwable? = null) { System.err.println("E/$tag: $msg"); t?.printStackTrace() }
    fun w(tag: String, msg: String, t: Throwable? = null) { System.err.println("W/$tag: $msg" + (t?.let { " (${it.javaClass.simpleName})" } ?: "")) }
    fun i(tag: String, msg: String) { println("I/$tag: $msg") }
    fun d(tag: String, msg: String) {}
}

class LruCache<K : Any, V : Any>(private val maxSize: Int) {
    private val map = object : LinkedHashMap<K, V>(16, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, V>?) = size > maxSize
    }
    @Synchronized fun get(key: K): V? = map[key]
    @Synchronized fun put(key: K, value: V): V? = map.put(key, value)
    @Synchronized fun remove(key: K): V? = map.remove(key)
    @Synchronized fun evictAll() = map.clear()
}

/** Non-premultiplied ARGB pixels (Android Bitmap ARGB_8888 as the app uses it). */
class Bitmap private constructor(val width: Int, val height: Int, private val pixels: IntArray) {
    enum class Config { ARGB_8888 }
    enum class CompressFormat { PNG }
    fun getPixels(dst: IntArray, offset: Int, stride: Int, x: Int, y: Int, w: Int, h: Int) {
        for (row in 0 until h) System.arraycopy(pixels, (y + row) * width + x, dst, offset + row * stride, w)
    }
    fun getPixel(x: Int, y: Int) = pixels[y * width + x]
    fun pixels(): IntArray = pixels
    fun recycle() {}
    fun compress(format: CompressFormat, quality: Int, out: OutputStream): Boolean = runCatching { out.write(Png.rgba(width, height, pixels)) }.isSuccess
    /** Compose image (unpremultiplied BGRA → Skia). */
    fun asImageBitmap(): ImageBitmap = argbImageBitmap(pixels, width, height)
    companion object {
        fun createBitmap(pixels: IntArray, width: Int, height: Int, config: Config = Config.ARGB_8888): Bitmap {
            require(width > 0 && height > 0 && pixels.size >= width * height)
            return Bitmap(width, height, pixels.copyOf(width * height))
        }
        fun createBitmap(width: Int, height: Int, config: Config): Bitmap = Bitmap(width, height, IntArray(width * height))
        /** Nearest-neighbour scale (the app only ever asks for filter = false). */
        fun createScaledBitmap(src: Bitmap, w: Int, h: Int, filter: Boolean): Bitmap {
            if (w == src.width && h == src.height) return src
            return Bitmap(w, h, IntArray(w * h) { i -> src.pixels[(i / w * src.height / h) * src.width + (i % w * src.width / w)] })
        }
        internal fun wrap(width: Int, height: Int, pixels: IntArray) = Bitmap(width, height, pixels)
    }
}

/** PNG through the core decoder (exact, same as Android); JPEG/BMP/GIF through ImageIO. */
object BitmapFactory {
    class Options { var inJustDecodeBounds = false; var inSampleSize = 1; var outWidth = -1; var outHeight = -1 }
    fun decodeStream(input: InputStream?): Bitmap? = decodeStream(input, null, null)
    fun decodeStream(input: InputStream?, @Suppress("UNUSED_PARAMETER") pad: Any?, options: Options?): Bitmap? {
        if (input == null) return null
        val bytes = runCatching { input.readBytes() }.getOrNull() ?: return null
        return decodeByteArray(bytes, 0, bytes.size, options)
    }
    fun decodeFile(path: String, options: Options? = null): Bitmap? = runCatching { File(path).readBytes() }.getOrNull()?.let { decodeByteArray(it, 0, it.size, options) }
    fun decodeByteArray(data: ByteArray, offset: Int, length: Int, options: Options? = null): Bitmap? {
        val bytes = if (offset == 0 && length == data.size) data else data.copyOfRange(offset, offset + length)
        val png = bytes.size > 8 && bytes[0] == 0x89.toByte() && bytes[1] == 'P'.code.toByte()
        if (options?.inJustDecodeBounds == true) {
            val size = (if (png) runCatching { PngDecoder.size(bytes) }.getOrNull() else null)
                ?: runCatching { ImageIO.createImageInputStream(bytes.inputStream()).use { s ->
                    val r = ImageIO.getImageReaders(s).asSequence().firstOrNull() ?: return@use null
                    try { r.input = s; intArrayOf(r.getWidth(0), r.getHeight(0)) } finally { r.dispose() } } }.getOrNull()
            options.outWidth = size?.get(0) ?: -1; options.outHeight = size?.get(1) ?: -1
            return null
        }
        var decoded: Bitmap? = null
        if (png) runCatching { PngDecoder.decode(bytes) }.getOrNull()?.let { decoded = Bitmap.wrap(it.width, it.height, it.argb) }
        if (decoded == null) {
            val image = runCatching { ImageIO.read(bytes.inputStream()) }.getOrNull() ?: return null
            val w = image.width; val h = image.height
            if (w <= 0 || h <= 0 || w.toLong() * h > 100_000_000L) return null
            decoded = Bitmap.wrap(w, h, image.getRGB(0, 0, w, h, null, 0, w))
        }
        val sample = (options?.inSampleSize ?: 1).coerceAtLeast(1)
        val b = decoded!!
        return if (sample > 1) Bitmap.createScaledBitmap(b, (b.width / sample).coerceAtLeast(1), (b.height / sample).coerceAtLeast(1), false) else b
    }
}

/** android.graphics.Color helpers used by the colour picker. */
object Colors {
    const val WHITE = 0xffffffff.toInt()
    const val BLACK = 0xff000000.toInt()
    const val TRANSPARENT = 0
    fun colorToHSV(color: Int, hsv: FloatArray) {
        val r = (color ushr 16 and 255) / 255f; val g = (color ushr 8 and 255) / 255f; val b = (color and 255) / 255f
        val max = maxOf(r, g, b); val min = minOf(r, g, b); val d = max - min
        var h = when {
            d == 0f -> 0f
            max == r -> 60f * (((g - b) / d) % 6f)
            max == g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }
        if (h < 0f) h += 360f
        hsv[0] = h; hsv[1] = if (max == 0f) 0f else d / max; hsv[2] = max
    }
    fun HSVToColor(hsv: FloatArray): Int = HSVToColor(255, hsv)
    fun HSVToColor(alpha: Int, hsv: FloatArray): Int {
        val h = ((hsv[0] % 360f) + 360f) % 360f; val s = hsv[1].coerceIn(0f, 1f); val v = hsv[2].coerceIn(0f, 1f)
        val c = v * s; val x = c * (1f - kotlin.math.abs((h / 60f) % 2f - 1f)); val m = v - c
        val (r, g, b) = when ((h / 60f).toInt()) {
            0 -> Triple(c, x, 0f); 1 -> Triple(x, c, 0f); 2 -> Triple(0f, c, x)
            3 -> Triple(0f, x, c); 4 -> Triple(x, 0f, c); else -> Triple(c, 0f, x)
        }
        fun ch(f: Float) = ((f + m) * 255f + .5f).toInt().coerceIn(0, 255)
        return (alpha.coerceIn(0, 255) shl 24) or (ch(r) shl 16) or (ch(g) shl 8) or ch(b)
    }
}

/** Non-premultiplied ARGB → Compose image through Skia (BGRA_8888, UNPREMUL). */
fun argbImageBitmap(pixels: IntArray, width: Int, height: Int): ImageBitmap {
    val bytes = ByteArray(width * height * 4)
    for (i in 0 until width * height) {
        val p = pixels[i]; val o = i * 4
        bytes[o] = p.toByte(); bytes[o + 1] = (p ushr 8).toByte(); bytes[o + 2] = (p ushr 16).toByte(); bytes[o + 3] = (p ushr 24).toByte()
    }
    val bitmap = org.jetbrains.skia.Bitmap()
    bitmap.allocPixels(org.jetbrains.skia.ImageInfo(width, height, org.jetbrains.skia.ColorType.BGRA_8888, org.jetbrains.skia.ColorAlphaType.UNPREMUL))
    bitmap.installPixels(bytes)
    bitmap.setImmutable()
    return bitmap.asComposeImageBitmap()
}

internal fun readAll(input: InputStream, limit: Long): ByteArray {
    val out = ByteArrayOutputStream(); val buf = ByteArray(16384); var total = 0L
    while (true) { val n = input.read(buf); if (n < 0) break; total += n; if (total > limit) throw IOException("APPEARANCE_LARGE"); out.write(buf, 0, n) }
    return out.toByteArray()
}
