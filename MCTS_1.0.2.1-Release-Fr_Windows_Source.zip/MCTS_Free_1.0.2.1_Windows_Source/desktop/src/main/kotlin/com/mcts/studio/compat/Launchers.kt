package com.mcts.studio.compat

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import java.awt.FileDialog
import java.awt.Frame
import java.io.File
import javax.swing.SwingUtilities

/**
 * Windows replacement for Android's document contracts: OpenDocument → native "Open" dialog, CreateDocument → native
 * "Save as" dialog (Windows asks before overwriting). The result is a file [Uri], so the model code is unchanged.
 */
interface DocumentContract<I>

object ActivityResultContracts {
    open class OpenDocument : DocumentContract<Array<String>>
    open class CreateDocument(val mimeType: String) : DocumentContract<String>
}

class DocumentLauncher<I> internal constructor(private val run: (I) -> Unit) {
    fun launch(input: I) = run(input)
}

/** Window that owns the dialogs (set by Main.kt). */
object DialogHost {
    @Volatile var frame: Frame? = null
    private val prefs by lazy { DesktopDirs.context.getSharedPreferences("dialogs", 0) }
    var lastDirectory: String?
        get() = prefs.getString("lastDirectory", null)?.takeIf { File(it).isDirectory }
        set(value) { if (value != null) prefs.edit().putString("lastDirectory", value).apply() }
    var busy = false

    /** Extensions for the Windows filter box ("*.png;*.jpg"). Empty = all files. */
    fun extensions(mimeTypes: Array<String>): List<String> {
        val out = LinkedHashSet<String>()
        for (m in mimeTypes) when {
            m == "*/*" -> {}
            m.startsWith("image/") -> out += listOf("png", "jpg", "jpeg", "bmp", "gif")
            m == "application/zip" || m == "application/octet-stream" -> out += listOf("zip", "mcpack")
            m == "application/json" -> out += listOf("json")
            m.startsWith("font/") -> out += listOf("ttf", "otf", "ttc")
        }
        return out.toList()
    }

    fun open(mimeTypes: Array<String>): File? {
        val dialog = FileDialog(frame, null, FileDialog.LOAD)
        val ext = extensions(mimeTypes)
        // The Windows dialog only filters through the file-name box; other systems use the filter.
        if (ext.isNotEmpty() && "*/*" !in mimeTypes) {
            dialog.file = ext.joinToString(";") { "*.$it" }
            dialog.setFilenameFilter { _, name -> ext.any { name.endsWith(".$it", ignoreCase = true) } }
        }
        lastDirectory?.let { dialog.directory = it }
        dialog.isMultipleMode = false
        dialog.isVisible = true
        val dir = dialog.directory ?: return null
        val name = dialog.file ?: return null
        lastDirectory = dir
        return File(dir, name).takeIf { it.isFile }
    }

    fun save(defaultName: String): File? {
        val dialog = FileDialog(frame, null, FileDialog.SAVE)
        dialog.file = defaultName
        lastDirectory?.let { dialog.directory = it }
        dialog.isVisible = true
        val dir = dialog.directory ?: return null
        var name = dialog.file ?: return null
        lastDirectory = dir
        // Keep the extension of the suggested name (".mctslayout.json", ".mcpack", ".zip", ".png").
        val wanted = when {
            defaultName.endsWith(".mctslayout.json", true) -> ".mctslayout.json"
            '.' in defaultName -> "." + defaultName.substringAfterLast('.')
            else -> ""
        }
        if (wanted.isNotEmpty() && !name.endsWith(wanted, ignoreCase = true) && !name.endsWith("." + wanted.substringAfterLast('.'), ignoreCase = true)) name += wanted
        return File(dir, name)
    }
}

@Composable
fun <I> rememberLauncherForActivityResult(contract: DocumentContract<I>, onResult: (Uri?) -> Unit): DocumentLauncher<I> {
    val callback = rememberUpdatedState(onResult)
    return remember {
        DocumentLauncher { input: I ->
            if (DialogHost.busy) return@DocumentLauncher
            DialogHost.busy = true
            // Leave the click handler first; the native dialog is modal and keeps the window painting.
            SwingUtilities.invokeLater {
                val file = try {
                    @Suppress("UNCHECKED_CAST")
                    when (contract) {
                        is ActivityResultContracts.OpenDocument -> DialogHost.open(input as Array<String>)
                        is ActivityResultContracts.CreateDocument -> DialogHost.save(input as String)
                        else -> null
                    }
                } catch (e: Exception) { Log.e("MCTS", "File dialog failed", e); null } finally { DialogHost.busy = false }
                callback.value(file?.let(Uri::fromFile))
            }
        }
    }
}
