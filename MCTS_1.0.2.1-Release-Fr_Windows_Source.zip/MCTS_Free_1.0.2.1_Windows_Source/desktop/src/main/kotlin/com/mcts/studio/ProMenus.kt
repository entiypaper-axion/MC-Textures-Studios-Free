package com.mcts.studio

import com.mcts.studio.compat.DesktopDirs
import com.mcts.studio.compat.DesktopPlatform
import com.mcts.studio.compat.Uri
import com.mcts.studio.compat.rememberLauncherForActivityResult
import com.mcts.studio.compat.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.io.File
import kotlin.math.roundToInt

private const val GITHUB="https://github.com/entiypaper-axion/MC-Textures-Studios-Free"
private const val QQ_CHANNEL="pd48299172"

/** Routes every top-bar item to its dialog (see the 1.0.1 function tree). */
@Composable internal fun ProDialogs(model:StudioModel,dialog:String?,setDialog:(String?)->Unit,view:PaintViewport,launchers:ProLaunchers,
                                    resolutionTexture:TemplateTexture?,pendingPack:Uri?,exportMeta:ExportMeta,setExportMeta:(ExportMeta)->Unit){
    // 1.0.2: close() lets the open dialog spring out first; it is removed when its exit animation finishes.
    val closing=remember(dialog){mutableStateOf(false)}
    val close={closing.value=true}
    val exit=remember(dialog){DialogExit(closing){setDialog(null)}}
    CompositionLocalProvider(LocalDialogExit provides exit){
    when(dialog){
        "projects"->ProjectsDialog(model,close)
        "import"->ImportDialog(model,close,launchers)
        "pack_import"->if(pendingPack==null)LaunchedEffect(Unit){setDialog(null)} else PackImportDialog(model,close,pendingPack)
        "export"->ExportDialog(model,close,launchers,exportMeta,setExportMeta)
        "brush"->BrushDialog(model,close)
        "delete"->DeleteDialog(model,close)
        "layout"->LayoutDialog(model,close,setDialog)
        "custom_ui"->ProDialog(model,model.p("custom_ui"),close,icon="ui_layout"){
            val area=model.workspaceArea
            ProLayoutSettings(model,area.landscape,{setDialog(null);model.startLayoutEdit(area.landscape,area.width,area.height)},{launchers.exportLayout(area.landscape)},launchers.importLayout)
        }
        "keys"->KeysDialog(model,close)
        "a11y"->A11yDialog(model,close)
        "guide"->GuideDialog(model,close,setDialog)
        "theme"->ThemeDialog(model,close)
        "language"->LanguageDialog(model,close)
        "feedback"->FeedbackDialog(model,close)
        "settings"->SettingsDialog(model,close,setDialog,launchers)
        "cache"->ProDialog(model,model.t("cache_manage"),close,icon="download"){ProTemplateCache(model)}
        "about"->ProDialog(model,model.t("about_notice"),close,icon="info"){ProAbout(model)}
        "resolution"->resolutionTexture?.let{ResolutionDialog(model,it,close)}
        "color"->ProDialog(model,model.p("color"),close,width=380.dp,icon="palette"){ProColorBlock(model)}
        "assets"->ProDialog(model,model.p("tab_assets"),close,icon="image"){Box(Modifier.fillMaxWidth().height(460.dp)){ProAssets(model){t->if(!model.openTemplateDefault(t))setDialog("resolution_phone:"+t.path) else close()}}}
        "layers"->ProDialog(model,model.p("tab_layers"),close,icon="layers"){Box(Modifier.fillMaxWidth().height(460.dp)){ProLayers(model,launchers.importLayer)}}
        "preview"->ProDialog(model,model.p("preview_3d"),close,icon="cube"){ProPreviewCard(model,360.dp)}
        null->Unit
        else->if(dialog.startsWith("resolution_phone:")){
            val path=dialog.removePrefix("resolution_phone:")
            val texture=model.templateTextures.firstOrNull{it.path==path}
            if(texture!=null)ResolutionDialog(model,texture,close) else LaunchedEffect(path){setDialog(null)}
        }
    }
    }
}

// ───────────── 项目 ─────────────
@Composable private fun ProjectsDialog(model:StudioModel,close:()->Unit){
    val c=LocalPro.current
    // Refresh once when the dialog opens; if a background save is running, wait for it.
    var fetched by remember{mutableStateOf(false)}
    LaunchedEffect(model.busy){if(!fetched&&!model.busy){fetched=true;model.refreshProjectInfo()}}
    var target by remember{mutableStateOf<PackProject?>(null)}
    var operation by remember{mutableStateOf("")}
    var name by remember{mutableStateOf("")}
    ProDialog(model,model.p("bar_project"),close,icon="project"){
        ProSection(model.p("current_project")){
            val info=model.projectInfo
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){
                DocumentThumb(model,44.dp)
                Column(Modifier.weight(1f)){
                    Text(model.pack.name,style=MaterialTheme.typography.titleMedium,color=c.tx)
                    Text(model.pack.profile.label,style=MaterialTheme.typography.bodySmall,color=c.tx3)
                }
                ProButton(model.p("save_now"),model::save,icon="save",kind=ProKind.PRIMARY,enabled=!model.busy)
            }
            if(info==null)Text(model.t("summary_loading"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
            else Column(verticalArrangement=Arrangement.spacedBy(2.dp)){
                InfoLine(model.p("info_edited"),"${info.edited}")
                InfoLine(model.p("info_documents"),"${info.documents}")
                InfoLine(model.p("info_template"),"${info.templateTextures}")
                InfoLine(model.p("info_size"),"%.1f MB".format(info.bytes/1048576f))
                InfoLine(model.p("info_resolution"),"${model.document.width}×${model.document.height}")
            }
        }
        ProSection(model.p("autosave")){
            ProSwitchRow(model.p("autosave_on"),model.autosave,{model.changeAutosave(enabled=it)},hint=model.p("autosave_hint"))
            if(model.autosave){
                val minutes=listOf(1,2,5,10)
                ProSegmented(minutes.map{model.p("minutes").format(it)},minutes.indexOf(model.autosaveMinutes),{model.changeAutosave(minutes=minutes[it])},Modifier.fillMaxWidth())
            }
        }
        ProSection(model.p("all_projects")){
            model.packs.forEach{project->
                val current=project.id==model.pack.id
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if(current)c.accSoft else c.raised).padding(10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(project.name,style=MaterialTheme.typography.bodyMedium,color=c.tx,maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text(project.profile.label+if(current)" · "+model.p("current") else "",style=MaterialTheme.typography.bodySmall,color=c.tx3)
                        }
                        if(!current)ProButton(model.p("open"),{model.openPack(project);close()},kind=ProKind.GHOST,enabled=!model.busy)
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        ProChip(model.t("project_rename"),target?.id==project.id&&operation=="rename",{target=project;operation="rename";name=project.name},enabled=!model.busy)
                        ProChip(model.t("project_copy"),target?.id==project.id&&operation=="copy",{target=project;operation="copy";name=project.name.take(72)+" (copy)"},enabled=!model.busy)
                        ProChip(model.t("project_delete"),target?.id==project.id&&operation=="delete",{target=project;operation="delete"},enabled=!model.busy)
                    }
                    if(target?.id==project.id){
                        if(operation=="delete")Text(model.t("project_delete_confirm"),style=MaterialTheme.typography.bodySmall,color=c.danger)
                        else ProField(name,{name=it.take(80)},Modifier.fillMaxWidth(),placeholder=model.t("project_name"))
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                            ProButton(model.t(when(operation){"rename"->"project_rename";"copy"->"project_copy";else->"project_delete"}),{
                                when(operation){"rename"->model.renamePack(project,name);"copy"->model.duplicatePack(project,name);"delete"->model.deletePack(project)};target=null
                            },kind=if(operation=="delete")ProKind.DANGER else ProKind.PRIMARY,enabled=!model.busy&&(operation=="delete"||name.isNotBlank()))
                            ProButton(model.t("cancel"),{target=null},kind=ProKind.GHOST)
                        }
                    }
                }
            }
        }
    }
}
@Composable private fun InfoLine(label:String,value:String){
    val c=LocalPro.current
    Row(Modifier.fillMaxWidth().semantics(mergeDescendants=true){}){Text(label,style=MaterialTheme.typography.bodySmall,color=c.tx2,modifier=Modifier.weight(1f));Text(value,style=MaterialTheme.typography.bodySmall.copy(fontFamily=ProMono),color=c.tx)}
}

// ───────────── 导入 ─────────────
@Composable private fun ImportDialog(model:StudioModel,close:()->Unit,launchers:ProLaunchers){
    ProDialog(model,model.p("bar_import"),close,icon="import"){
        ImportChoice(model,"layers",model.p("import_layer"),model.p("import_layer_hint")){close();launchers.importLayer()}
        ImportChoice(model,"image",model.p("import_replace"),model.p("import_replace_hint")){close();launchers.importReplace()}
        ImportChoice(model,"copy",model.p("import_clipboard"),model.p("import_clipboard_hint")){
            // Windows: a copied picture (Snipping Tool, browser "Copy image") or a copied image file.
            val file=WindowsIntegration.clipboardImage()
            if(file==null)model.message="clipboard_empty" else model.importPng(Uri.fromFile(file))
            close()
        }
        ImportChoice(model,"project",model.p("import_pack"),model.p("import_pack_hint")){close();launchers.importPack()}
    }
}
@Composable private fun ImportChoice(model:StudioModel,icon:String,title:String,hint:String,onClick:()->Unit){
    val c=LocalPro.current
    val (press,pressMod)=rememberPress(!model.busy)
    Row(Modifier.fillMaxWidth().then(pressMod).clip(RoundedCornerShape(12.dp)).background(c.raised).clickable(interactionSource=press.source,indication=LocalIndication.current,enabled=!model.busy,role=Role.Button,onClick=onClick).padding(12.dp),
        horizontalArrangement=Arrangement.spacedBy(12.dp),verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(c.group),contentAlignment=Alignment.Center){ProIcon(icon,c.acc,20.dp)}
        Column(Modifier.weight(1f)){Text(title,style=MaterialTheme.typography.bodyMedium,color=c.tx);Text(hint,style=MaterialTheme.typography.bodySmall,color=c.tx3)}
        ProIcon("chev_right",c.tx3,18.dp)
    }
}

@Composable private fun PackImportDialog(model:StudioModel,close:()->Unit,uri:Uri){
    val c=LocalPro.current
    val fileName=remember(uri){uri.lastPathSegment.ifBlank{"Imported pack"}}
    var name by remember(uri){mutableStateOf(fileName.substringBeforeLast('.').take(80))}
    var java by remember(uri){mutableStateOf(!fileName.endsWith(".mcpack",true))}
    var profileId by remember(uri){mutableStateOf(offeredProfiles.last{it.java}.id)}
    val profile=profileById(profileId)?:offeredProfiles.first()
    ProDialog(model,model.p("import_pack"),close,icon="import"){
        Text(fileName,style=MaterialTheme.typography.bodyMedium.copy(fontFamily=ProMono),color=c.tx2)
        ProLabel(model.p("project_name"))
        ProField(name,{name=it.take(80)},Modifier.fillMaxWidth(),placeholder=model.t("project_name"))
        ProLabel(model.p("pack_edition"))
        ProSegmented(listOf(model.p("java_edition"),model.p("bedrock_edition")),if(java)0 else 1,{java=it==0;profileId=offeredProfiles.last{p->p.java==java}.id},Modifier.fillMaxWidth())
        ProLabel(model.p("game_version"))
        ProVersionPicker(model,profile,{profileId=it.id},enabled=!model.busy){p->if(p.id in model.availableTemplates)"✓" else null}
        ProVersionNotes(model,profile)
        ProNote(model.p("import_pack_note"))
        if(profile.id !in model.availableTemplates)ProNote(model.p("import_pack_no_template"),icon="download")
        ProButton(model.p("import_pack_go"),{model.importPackArchive(uri,name,profile);close()},Modifier.fillMaxWidth(),icon="import",kind=ProKind.PRIMARY,enabled=!model.busy&&name.isNotBlank())
    }
}

// ───────────── 导出 ─────────────
@Composable private fun ExportDialog(model:StudioModel,close:()->Unit,launchers:ProLaunchers,meta:ExportMeta,setMeta:(ExportMeta)->Unit){
    val c=LocalPro.current
    var fetched by remember{mutableStateOf(false)}
    LaunchedEffect(model.busy){if(!fetched&&!model.busy){fetched=true;model.refreshExportCheck()}}
    var name by remember(model.pack.id){mutableStateOf(meta.name.ifEmpty{model.pack.name})}
    var description by remember(model.pack.id){mutableStateOf(meta.description.ifEmpty{"Made with MCTS Free"})}
    fun current()=meta.copy(name=name,description=description)
    ProDialog(model,model.p("export_title"),close,icon="export"){
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
            FormatCard(model.p("java_edition")+" · .zip",if(model.pack.profile.java)model.p("matches").format(model.pack.profile.label) else model.p("needs_java_project"),model.pack.profile.java,Modifier.weight(1f))
            FormatCard(model.p("bedrock_edition")+" · .mcpack",if(!model.pack.profile.java)model.p("matches").format(model.pack.profile.label) else model.p("needs_bedrock_project"),!model.pack.profile.java,Modifier.weight(1f))
        }
        ProLabel(model.p("pack_name"))
        ProField(name,{name=it.take(80);setMeta(current().copy(name=name))},Modifier.fillMaxWidth(),placeholder=model.pack.name)
        ProLabel(model.p("pack_description"))
        ProField(description,{description=it.take(240);setMeta(current().copy(description=description))},Modifier.fillMaxWidth())
        ProLabel(model.p("pack_icon"))
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
            ProChip(model.p("icon_template"),meta.icon==null,{setMeta(current().copy(icon=null))})
            ProChip(model.p("icon_current"),false,{setMeta(current().copy(icon=model.iconFromCurrentTexture()))})
            ProChip(model.p("icon_choose"),false,{setMeta(current());launchers.pickIcon()})
            if(meta.icon!=null)Text("✓ "+model.p("icon_set"),style=MaterialTheme.typography.labelMedium,color=c.acc)
        }
        // Pre-export check: never blocks, only explains.
        val check=model.exportCheck
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.raised).padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
            Text(model.p("export_check"),style=MaterialTheme.typography.labelLarge,color=c.tx)
            if(check==null)Text(model.t("summary_loading"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
            else{
                Text(model.p("check_counts").format(check.edited,check.unchanged),style=MaterialTheme.typography.bodySmall,color=c.tx2)
                if(check.edited==0)Text("• "+model.p("check_no_edits"),style=MaterialTheme.typography.bodySmall,color=c.danger)
                if(check.mixedSize.isNotEmpty())Text("• "+model.p("check_mixed").format(check.mixedSize.size,check.mixedSize.take(3).joinToString()),style=MaterialTheme.typography.bodySmall,color=c.tx2)
                if(check.newTransparency.isNotEmpty())Text("• "+model.p("check_transparent").format(check.newTransparency.size,check.newTransparency.take(3).joinToString()),style=MaterialTheme.typography.bodySmall,color=c.danger)
                if(check.clean)Text("✓ "+model.p("check_ok"),style=MaterialTheme.typography.bodySmall,color=c.acc)
            }
        }
        ProNote(model.t("free_export_color"))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            ProButton(model.p("save_to_file"),{setMeta(current());close();launchers.exportPack()},Modifier.weight(1f),icon="save",enabled=!model.busy)
            ProButton(model.p("export_share"),{
                setMeta(current());close()
                // Windows: straight into Minecraft (Java resourcepacks folder / Bedrock import), else Downloads.
                val java=model.pack.profile.java;val name=model.exportFileName()
                model.exportPack(null,current()){file->
                    runCatching{WindowsIntegration.sendToMinecraft(file,name,java)}.onSuccess{(sent,_)->
                        model.message=when(sent){WindowsIntegration.Sent.JAVA_RESOURCEPACKS->"win_sent_java";WindowsIntegration.Sent.BEDROCK_OPENED->"win_sent_bedrock";else->"win_saved_downloads"}
                    }.onFailure{model.message="win_send_failed"}
                }
            },Modifier.weight(1f),icon="share",kind=ProKind.PRIMARY,enabled=!model.busy)
        }
        ProButton(model.p("export_texture_png"),{close();launchers.exportTexture()},Modifier.fillMaxWidth(),icon="image",kind=ProKind.GHOST,enabled=!model.busy)
    }
}
@Composable private fun FormatCard(title:String,subtitle:String,on:Boolean,modifier:Modifier){
    val c=LocalPro.current
    Row(modifier.clip(RoundedCornerShape(12.dp)).background(if(on)c.accSoft else Color.Transparent).border(1.5.dp,if(on)c.acc else c.line,RoundedCornerShape(12.dp)).padding(12.dp)
        .semantics(mergeDescendants=true){selected=on},horizontalArrangement=Arrangement.spacedBy(10.dp)){
        Box(Modifier.padding(top=2.dp).size(16.dp).clip(RoundedCornerShape(50)).border(if(on)5.dp else 1.5.dp,if(on)c.acc else c.tx3,RoundedCornerShape(50)))
        Column{Text(title,style=MaterialTheme.typography.labelLarge,color=if(on)c.tx else c.tx3);Text(subtitle,style=MaterialTheme.typography.bodySmall,color=c.tx3)}
    }
}

@Composable internal fun ProExportSteps(model:StudioModel,onDone:()->Unit){
    val c=LocalPro.current
    ProDialog(model,model.t("export_how"),onDone,icon="export"){
        Text(model.t(if(model.exportedForJava)"export_java_steps" else "export_bedrock_steps"),style=MaterialTheme.typography.bodyMedium,color=c.tx)
        ProNote(model.t("export_verify"))
        ProButton(model.t("got_it"),onDone,kind=ProKind.PRIMARY)
    }
}

// ───────────── 画笔设置 ─────────────
@Composable private fun BrushDialog(model:StudioModel,close:()->Unit){
    val c=LocalPro.current
    ProDialog(model,model.p("bar_brush"),close,width=480.dp,icon="brush_settings"){
        ProSection(model.p("brush_size")){
            Row(verticalAlignment=Alignment.CenterVertically){
                ProSlider(model.brushSize.toFloat(),{model.changeBrushSize(it.roundToInt())},1f..8f,Modifier.weight(1f),steps=6,description=model.p("brush_size"))
                Text("${model.brushSize} px",style=MaterialTheme.typography.labelLarge.copy(fontFamily=ProMono),color=c.tx,modifier=Modifier.width(52.dp))
            }
            ProSegmented(listOf(model.p("shape_square"),model.p("shape_round")),if(model.roundBrush)1 else 0,{model.changeRoundBrush(it==1)},Modifier.fillMaxWidth())
            ProSwitchRow(model.p("pixel_perfect"),model.pixelPerfect,model::changePixelPerfect,hint=model.p("pixel_perfect_hint"))
        }
        ProSection(model.p("brush_opacity")){
            Row(verticalAlignment=Alignment.CenterVertically){
                ProSlider(model.brushAlpha.toFloat(),{model.changeBrushAlpha(it.roundToInt())},0f..255f,Modifier.weight(1f),description=model.p("brush_opacity"))
                Text("${model.brushAlpha*100/255}%",style=MaterialTheme.typography.labelLarge.copy(fontFamily=ProMono),color=c.tx,modifier=Modifier.width(52.dp))
            }
        }
        ProSection(model.t("mirror")){
            val options=listOf(model.p("mirror_off"),model.p("mirror_lr"),model.p("mirror_ud"),model.p("mirror_four"))
            val index=when{model.mirrorX&&model.mirrorY->3;model.mirrorX->1;model.mirrorY->2;else->0}
            ProSegmented(options,index,{when(it){0->model.setMirror(false,false);1->model.setMirror(true,false);2->model.setMirror(false,true);else->model.setMirror(true,true)}},Modifier.fillMaxWidth(),enabled=!model.busy)
        }
        ProSection(model.p("tool_fill")){
            ProSegmented(listOf(model.p("fill_contiguous"),model.p("fill_global")),if(model.fillContiguous)0 else 1,{model.changeFill(contiguous=it==0)},Modifier.fillMaxWidth())
            Row(verticalAlignment=Alignment.CenterVertically){
                Text(model.p("fill_tolerance"),style=MaterialTheme.typography.bodyMedium,color=c.tx2,modifier=Modifier.width(72.dp))
                ProSlider(model.fillTolerance.toFloat(),{model.changeFill(tolerance=it.roundToInt())},0f..100f,Modifier.weight(1f),description=model.p("fill_tolerance"))
                Text("${model.fillTolerance}%",style=MaterialTheme.typography.labelLarge.copy(fontFamily=ProMono),color=c.tx,modifier=Modifier.width(48.dp))
            }
        }
    }
}

// ───────────── 删除当前 ─────────────
@Composable private fun DeleteDialog(model:StudioModel,close:()->Unit){
    val c=LocalPro.current
    var confirm by remember{mutableStateOf<String?>(null)}
    ProDialog(model,model.p("bar_delete"),close,width=480.dp,icon="delete"){
        ImportChoice(model,"delete",model.p("delete_project"),model.p("delete_project_hint").format(model.pack.name)){confirm="project"}
        ImportChoice(model,"rotate",model.p("reset_texture"),model.p("reset_texture_hint")){confirm="texture"}
        when(confirm){
            "project"->{Text(model.t("project_delete_confirm"),style=MaterialTheme.typography.bodyMedium,color=c.danger)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ProButton(model.p("delete_project"),{model.deletePack(model.pack);close()},kind=ProKind.DANGER,enabled=!model.busy);ProButton(model.t("cancel"),{confirm=null},kind=ProKind.GHOST)}}
            "texture"->{Text(model.p("reset_texture_confirm"),style=MaterialTheme.typography.bodyMedium,color=c.danger)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ProButton(model.p("reset_texture"),{model.resetCurrentTexture();close()},kind=ProKind.DANGER,enabled=!model.busy&&model.currentTemplateTexture()!=null);ProButton(model.t("cancel"),{confirm=null},kind=ProKind.GHOST)}
                if(model.currentTemplateTexture()==null)Text(model.p("reset_texture_none"),style=MaterialTheme.typography.bodySmall,color=c.tx3)}
        }
    }
}

// ───────────── UI 布局 ─────────────
@Composable private fun LayoutDialog(model:StudioModel,close:()->Unit,setDialog:(String?)->Unit){
    ProDialog(model,model.p("bar_layout"),close,icon="ui_layout"){
        ProButton(model.p("custom_ui_open"),{setDialog("custom_ui")},Modifier.fillMaxWidth(),icon="ui_layout",kind=ProKind.PRIMARY)
        ProSection(model.p("layout_device")){
            val d=StudioModel.DeviceLayout.entries
            ProSegmented(listOf(model.p("auto"),model.p("phone"),model.p("tablet")),d.indexOf(model.deviceLayout),{model.changeDeviceLayout(d[it])},Modifier.fillMaxWidth())
        }
        ProSection(model.t("hand_mode")){
            val h=StudioModel.HandMode.entries
            ProSegmented(listOf(model.t("hand_auto"),model.t("hand_left"),model.t("hand_right")),h.indexOf(model.handMode),{model.changeHandMode(h[it])},Modifier.fillMaxWidth())
            Text(model.p("hand_hint_101"),style=MaterialTheme.typography.bodySmall,color=LocalPro.current.tx3)
        }
        ProSection(model.p("layout_sidebar")){
            val w=StudioModel.PanelWidth.entries
            ProSegmented(listOf(model.p("narrow"),model.p("standard"),model.p("wide")),w.indexOf(model.sidebarWidth),{model.changeSidebarWidth(w[it])},Modifier.fillMaxWidth())
        }
        ProSection(model.p("preview_3d")){
            val p=StudioModel.PreviewSize.entries
            ProSegmented(listOf(model.p("hidden"),model.p("standard"),model.p("large")),p.indexOf(model.previewSize),{model.changePreviewSize(p[it])},Modifier.fillMaxWidth())
        }
        ProSection(model.p("layout_toolbar")){
            ProSegmented(listOf(model.p("toolbar_full"),model.p("toolbar_compact")),if(model.compactToolbar)1 else 0,{model.changeCompactToolbar(it==1)},Modifier.fillMaxWidth())
        }
        ProSection(model.p("layout_scale")){
            val s=listOf(.9f,1f,1.15f)
            ProSegmented(listOf("90%","100%","115%"),s.indexOf(model.uiScale),{model.changeUiScale(s[it])},Modifier.fillMaxWidth(),mono=true)
        }
        ProButton(model.p("layout_reset"),{model.resetLayout()},icon="rotate",kind=ProKind.GHOST)
    }
}

// ───────────── 键鼠设置 ─────────────
@Composable private fun KeysDialog(model:StudioModel,close:()->Unit){
    val c=LocalPro.current
    var listening by remember{mutableStateOf<KeyAction?>(null)}
    val focus=remember{FocusRequester()}
    LaunchedEffect(listening){if(listening!=null)runCatching{focus.requestFocus()}}
    ProDialog(model,model.p("bar_keys"),close,width=600.dp,icon="keyboard_mouse"){
        ProSection(model.p("shortcuts")){
            Text(model.p("shortcuts_hint"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
            Column(Modifier.focusRequester(focus).focusable().onPreviewKeyEvent{event->
                val action=listening?:return@onPreviewKeyEvent false
                if(event.type!=KeyEventType.KeyDown)return@onPreviewKeyEvent true
                val code=event.key.keyCode
                if(event.key==Key.Escape){listening=null;return@onPreviewKeyEvent true}
                if(KeyChord.isModifier(code))return@onPreviewKeyEvent true
                model.bindKey(action,KeyChord(code,event.isCtrlPressed,event.isShiftPressed,event.isAltPressed));listening=null;true
            },verticalArrangement=Arrangement.spacedBy(4.dp)){
                KeyAction.entries.forEach{action->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(if(listening==action)c.accSoft else Color.Transparent).padding(horizontal=8.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically){
                        Text(action.label(model.language),style=MaterialTheme.typography.bodyMedium,color=c.tx,modifier=Modifier.weight(1f))
                        Text(if(listening==action)model.p("press_key") else model.keymap.chord(action)?.label()?:"—",style=MaterialTheme.typography.labelLarge.copy(fontFamily=ProMono),
                            color=if(listening==action)c.acc else c.tx2,modifier=Modifier.clip(RoundedCornerShape(6.dp)).background(c.raised).padding(horizontal=8.dp,vertical=3.dp))
                        Spacer(Modifier.width(8.dp))
                        ProButton(model.p("change"),{listening=if(listening==action)null else action},kind=ProKind.GHOST)
                    }
                }
            }
        }
        ProSection(model.p("mouse")){
            ProNote(model.p("mouse_hint"))
            Text(model.p("mouse_right"),style=MaterialTheme.typography.bodyMedium,color=c.tx2)
            PointerChoice(model,model.mouseRight,model::changeMouseRight)
        }
        ProSection(model.p("stylus")){
            Text(model.p("stylus_button"),style=MaterialTheme.typography.bodyMedium,color=c.tx2)
            PointerChoice(model,model.stylusButton,model::changeStylusButton)
            ProSwitchRow(model.p("stylus_only"),model.stylusOnly,model::changeStylusOnly,hint=model.p("stylus_only_hint"))
        }
        ProButton(model.p("input_reset"),{model.resetInput()},icon="rotate",kind=ProKind.GHOST)
    }
}
@Composable private fun PointerChoice(model:StudioModel,value:StudioModel.PointerAction,onChange:(StudioModel.PointerAction)->Unit){
    val a=StudioModel.PointerAction.entries
    ProSegmented(listOf(model.p("tool_picker"),model.p("tool_erase"),model.p("none")),a.indexOf(value),{onChange(a[it])},Modifier.fillMaxWidth())
}

// ───────────── 无障碍 ─────────────
@Composable private fun A11yDialog(model:StudioModel,close:()->Unit){
    ProDialog(model,model.p("bar_a11y"),close,icon="accessibility"){
        ProNote(model.p("a11y_screenreader"))
        ProSwitchRow(model.p("a11y_read_pixel"),model.readPixel,model::changeReadPixel,hint=model.p("a11y_read_pixel_hint"))
        ProSwitchRow(model.p("a11y_large"),model.largeUi,model::changeLargeUi,hint=model.p("a11y_large_hint"))
        ProSwitchRow(model.p("a11y_contrast"),model.strongContrast,model::changeStrongContrast,hint=model.p("a11y_contrast_hint"))
        ProSwitchRow(model.p("a11y_color_names"),model.colorNames,model::changeColorNames,hint=model.p("a11y_color_names_hint"))
        ProSwitchRow(model.p("a11y_motion"),model.reducedMotion,model::changeReducedMotion,hint=model.p("a11y_motion_hint"))
        ProSwitchRow(model.p("a11y_haptics"),model.haptics,model::changeHaptics,hint=model.p("a11y_haptics_hint"))
    }
}

// ───────────── 引导 ─────────────
@Composable private fun GuideDialog(model:StudioModel,close:()->Unit,setDialog:(String?)->Unit){
    val c=LocalPro.current
    var page by remember{mutableStateOf("menu")}
    ProDialog(model,model.p("bar_guide"),close,icon="guide"){
        when(page){
            "menu"->{
                ImportChoice(model,"guide",model.p("guide_replay"),model.p("guide_replay_hint")){close();model.replayGuide()}
                ImportChoice(model,"export",model.p("guide_export"),model.p("guide_export_hint")){page="export"}
                ImportChoice(model,"erase_alpha",model.p("guide_erase"),model.p("guide_erase_hint")){page="erase"}
                ImportChoice(model,"keyboard_mouse",model.p("guide_keys"),model.p("guide_keys_hint")){page="keys"}
                ImportChoice(model,"info",model.p("guide_faq"),model.p("guide_faq_hint")){page="faq"}
            }
            "export"->{
                ProSection(model.p("java_edition")){Text(model.t("export_java_steps"),style=MaterialTheme.typography.bodyMedium,color=c.tx)}
                ProSection(model.p("bedrock_edition")){Text(model.t("export_bedrock_steps"),style=MaterialTheme.typography.bodyMedium,color=c.tx)}
                ProNote(model.t("export_verify"))
            }
            "erase"->{
                Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){
                    EraseCard(model,model.p("tool_eraser"),model.p("guide_eraser_text"),false,Modifier.weight(1f))
                    EraseCard(model,model.p("tool_erase"),model.p("guide_erase_text"),true,Modifier.weight(1f))
                }
                ProNote(model.p("guide_erase_tip"))
            }
            "keys"->Column(verticalArrangement=Arrangement.spacedBy(3.dp)){KeyAction.entries.forEach{a->InfoLine(a.label(model.language),model.keymap.chord(a)?.label()?:"—")}
                InfoLine(model.p("space_drag"),"Space + drag");InfoLine(model.p("wheel_zoom"),"Wheel")}
            else->(1..5).forEach{i->ProSection(model.p("faq_q$i")){Text(model.p("faq_a$i"),style=MaterialTheme.typography.bodyMedium,color=c.tx2)}}
        }
        if(page!="menu")ProButton(model.p("back"),{page="menu"},icon="chev_down",kind=ProKind.GHOST)
    }
}
@Composable private fun EraseCard(model:StudioModel,title:String,text:String,transparent:Boolean,modifier:Modifier){
    val c=LocalPro.current
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(c.raised).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Row(horizontalArrangement=Arrangement.spacedBy(2.dp)){
            repeat(4){i->Box(Modifier.size(22.dp).then(
                if(i in 1..2)(if(transparent)Modifier.checker(5.5.dp)else Modifier.background(Color.White)) else Modifier.background(Color(0xff8c6a44))).border(1.dp,Color.Black.copy(alpha=.15f)))}
        }
        Text(title,style=MaterialTheme.typography.labelLarge,color=c.tx);Text(text,style=MaterialTheme.typography.bodySmall,color=c.tx2)
    }
}

/** First-run guide for the 1.0.1 layout. */
@Composable internal fun ProOnboarding(model:StudioModel,onDone:()->Unit){
    val c=LocalPro.current
    var step by remember{mutableIntStateOf(1)}
    ProDialog(model,model.p("onboard_title"),onDone,width=520.dp,icon="guide"){
        Text("$step / 5",style=MaterialTheme.typography.labelMedium.copy(fontFamily=ProMono),color=c.tx3)
        Text(model.p("onboard_$step"),style=MaterialTheme.typography.bodyLarge,color=c.tx,modifier=Modifier.semantics{liveRegion=LiveRegionMode.Polite})
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            if(step>1)ProButton(model.p("previous"),{step--},kind=ProKind.GHOST)
            ProButton(model.p(if(step<5)"next" else "done"),{if(step<5)step++ else onDone()},kind=ProKind.PRIMARY)
        }
    }
}

// ───────────── 主题 / 语言 ─────────────
@Composable private fun ThemeDialog(model:StudioModel,close:()->Unit){
    ProDialog(model,model.t("theme_mode"),close,width=420.dp,icon="theme_dark"){
        StudioModel.ThemeMode.entries.forEach{mode->
            ProRadioRow(model.t(when(mode){StudioModel.ThemeMode.SYSTEM->"theme_system";StudioModel.ThemeMode.LIGHT->"theme_light";StudioModel.ThemeMode.DARK->"theme_dark"}),model.themeMode==mode,{model.changeThemeMode(mode)})
        }
        ProNote(model.p("theme_hint"))
    }
}
@Composable private fun LanguageDialog(model:StudioModel,close:()->Unit){
    ProDialog(model,model.p("bar_language"),close,width=420.dp,icon="language"){
        Language.entries.forEach{language->
            ProRadioRow(when(language){Language.ZH->"中文";Language.EN->"English";Language.JA->"日本語";Language.FR->"Français";Language.ES->"Español"},model.language==language,{model.changeLanguage(language)})
        }
    }
}

// ───────────── 反馈 ─────────────
@Composable private fun FeedbackDialog(model:StudioModel,close:()->Unit){
    fun copy(@Suppress("UNUSED_PARAMETER") label:String,text:String){DesktopPlatform.copyText(text)}
    ProDialog(model,model.p("bar_feedback"),close,icon="feedback"){
        ProNote(model.p("feedback_hint"))
        ImportChoice(model,"copy",model.t("copy_diagnostics"),model.t("diagnostics_hint")){copy("MCTS diagnostics",model.diagnostics());model.message="diagnostics_copied"}
        ImportChoice(model,"share",model.p("feedback_github"),"github.com/entiypaper-axion/MC-Textures-Studios-Free/issues"){
            if(!DesktopPlatform.openUrl("$GITHUB/issues"))model.message="no_browser"
        }
        ImportChoice(model,"feedback",model.p("feedback_qq"),model.p("feedback_qq_hint").format(QQ_CHANNEL)){copy("QQ",QQ_CHANNEL);model.message="qq_copied"}
        ImportChoice(model,"image",model.p("feedback_screenshot"),model.p("feedback_screenshot_hint")){
            // Windows: the dialog closes first so the picture shows the editor; saved to Downloads, diagnostics copied.
            close();model.feedbackScreenshot()
        }
    }
}

// ───────────── 设置 ─────────────
@Composable private fun SettingsDialog(model:StudioModel,close:()->Unit,setDialog:(String?)->Unit,launchers:ProLaunchers){
    val c=LocalPro.current
    ProDialog(model,model.p("bar_settings"),close,icon="settings"){
        ProSection(model.p("settings_appearance")){
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                ProButton(model.t("theme_mode"),{setDialog("theme")},Modifier.weight(1f),icon="theme_dark")
                ProButton(model.p("bar_language"),{setDialog("language")},Modifier.weight(1f),icon="language")
            }
            ProFontSettings(model)
        }
        ProSection(model.p("glass_title")){ProGlassSettings(model,launchers){setDialog(null);model.glassPicking=true}}
        ProSection(model.p("custom_ui")){
            Text(model.p("custom_ui_hint"),style=MaterialTheme.typography.bodySmall,color=c.tx2)
            ProButton(model.p("custom_ui_open"),{setDialog("custom_ui")},Modifier.fillMaxWidth(),icon="ui_layout")
        }
        ProSection(model.p("settings_templates")){
            ProButton(model.t("cache_manage"),{setDialog("cache")},Modifier.fillMaxWidth(),icon="download")
            ProSwitchRow(model.p("metered_confirm"),model.meteredConfirm,model::changeMeteredConfirm,hint=model.p("metered_confirm_hint"))
            ProSwitchRow(model.t("choose_block"),model.chooseBlock,model::changeChooseBlock,hint=model.t("choose_block_hint"),enabled=!model.busy)
        }
        ProSection(model.p("settings_editing")){
            Text(model.p("default_resolution"),style=MaterialTheme.typography.bodyMedium,color=c.tx2)
            val res=listOf(0,16,32,64,128)
            ProSegmented(res.map{if(it==0)model.p("ask") else "$it×"},res.indexOf(model.defaultResolution).coerceAtLeast(0),{model.changeDefaultResolution(res[it])},Modifier.fillMaxWidth())
            Text(model.p("undo_limit"),style=MaterialTheme.typography.bodyMedium,color=c.tx2)
            val limits=listOf(0,50,100,200)
            ProSegmented(limits.map{if(it==0)model.p("unlimited") else "$it"},limits.indexOf(model.undoLimit),{model.changeUndoLimit(limits[it])},Modifier.fillMaxWidth())
            ProSwitchRow(model.p("long_press_picker"),model.longPressPicker,model::changeLongPressPicker,hint=model.p("long_press_picker_hint"))
            ProButton(model.t("restore"),{model.restorePrevious();close()},icon="clock",kind=ProKind.GHOST,enabled=!model.busy)
        }
        ProSection(model.p("settings_about")){
            InfoLine(model.p("version"),"MCTS Free ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            ProButton(model.t("about_notice"),{setDialog("about")},Modifier.fillMaxWidth(),icon="info")
            Text(model.t("free_offline"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
        }
    }
}

@Composable private fun ProFontSettings(model:StudioModel){
    val a=model.appearance;val c=LocalPro.current
    val fonts=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(model::importUiFont)}
    // (font picker: Windows filter shows .ttf/.otf/.ttc)
    Text(model.p("font"),style=MaterialTheme.typography.bodyMedium,color=c.tx2)
    val choices=listOf("system" to model.p("font_system"),"serif" to model.p("font_serif"),"mono" to model.p("font_mono"),"pixel" to "Monocraft","adventure" to model.p("font_wenkai"))+
        if(a.fontPath.isNotBlank())listOf("custom" to model.p("font_imported")) else emptyList()
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
        choices.forEach{(key,label)->ProChip(label,a.font==key,{a.chooseFont(key)},enabled=!model.busy)}
    }
    ProButton(model.p("font_import"),{fonts.launch(arrayOf("font/ttf","font/otf"))},icon="import",kind=ProKind.GHOST,enabled=!model.busy)
    ProGameFonts(model)
    Row(verticalAlignment=Alignment.CenterVertically){
        Text(model.p("text_size"),style=MaterialTheme.typography.bodyMedium,color=c.tx2,modifier=Modifier.width(72.dp))
        ProSlider(a.fontSize,a::size,.85f..1.4f,Modifier.weight(1f),description=model.p("text_size"))
        Text("${(a.fontSize*100).roundToInt()}%",style=MaterialTheme.typography.labelLarge.copy(fontFamily=ProMono),color=c.tx,modifier=Modifier.width(48.dp))
    }
}

/** 1.0.2.1 game fonts: Minecraft Java is built from the official client.jar; the others are imported font files. */
@Composable private fun ProGameFonts(model:StudioModel){
    val a=model.appearance;val c=LocalPro.current
    var importing by remember{mutableStateOf<String?>(null)}
    var confirmMetered by remember{mutableStateOf(false)}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->val key=importing;importing=null;if(uri!=null&&key!=null)model.importGameFont(key,uri)}
    val revision=a.gameFontRevision
    ProLabel(model.p("game_fonts"))
    for(key in listOf("minecraft_java","genshin","terraria","gta6")){
        val has=remember(revision,key){a.hasGameFont(key)}
        val selected=a.font=="game:$key"
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(c.raised.copy(alpha=.6f)).padding(10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
                Text(model.p("game_font_$key"),style=MaterialTheme.typography.bodyMedium,color=c.tx,modifier=Modifier.weight(1f))
                if(has)ProChip(model.p(if(selected)"game_font_in_use" else "game_font_use"),selected,{a.chooseFont(if(selected)"system" else "game:$key")},enabled=!model.busy)
                if(key=="minecraft_java")ProButton(model.p(if(has)"game_font_redownload" else "game_font_download"),{
                    if(model.meteredConfirm&&model.isMetered())confirmMetered=true else model.downloadMinecraftFont()
                },icon="download",kind=if(has)ProKind.GHOST else ProKind.SECONDARY,enabled=!model.busy&&model.minecraftFontProfile!=null)
                else ProButton(model.p(if(has)"game_font_replace" else "game_font_import"),{importing=key;picker.launch(arrayOf("font/ttf","font/otf"))},icon="import",kind=if(has)ProKind.GHOST else ProKind.SECONDARY,enabled=!model.busy)
                if(has)ProIconButton("delete",model.p("game_font_remove"),{a.removeGameFont(key)},size=32.dp,enabled=!model.busy)
            }
            Text(if(key=="minecraft_java")model.p("game_font_minecraft_java_note").format(model.minecraftFontProfile?.version?:"—") else model.p("game_font_${key}_note"),
                style=MaterialTheme.typography.bodySmall,color=c.tx3)
        }
    }
    if(confirmMetered)ProDialog(model,model.p("game_font_download"),{confirmMetered=false},icon="download"){
        Text(model.t("metered_notice"),style=MaterialTheme.typography.bodyMedium,color=c.tx)
        ProButton(model.p("game_font_download"),{confirmMetered=false;model.downloadMinecraftFont()},kind=ProKind.PRIMARY)
    }
}

@Composable internal fun ProTemplateCache(model:StudioModel){
    val c=LocalPro.current
    var pending by remember{mutableStateOf<GameProfile?>(null)}
    val revision=model.cacheRevision
    val sizes=remember(revision){gameProfiles.associateWith{model.projectFiles.templates.cacheBytes(it)}}
    if(sizes.values.none{it>0})Text(model.p("cache_empty"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
    gameProfiles.forEach{profile->
        val bytes=sizes[profile]?:0L
        if(bytes>0)Row(verticalAlignment=Alignment.CenterVertically){
            Text(profile.label,style=MaterialTheme.typography.bodyMedium,color=c.tx,modifier=Modifier.weight(1f))
            Text("%.1f MB".format(bytes/1048576f),style=MaterialTheme.typography.labelMedium.copy(fontFamily=ProMono),color=c.tx3)
            Spacer(Modifier.width(8.dp))
            ProButton(model.t("cache_delete"),{pending=profile},kind=ProKind.GHOST,enabled=!model.busy&&bytes>0)
        }
    }
    pending?.let{profile->
        ProNote(model.t("cache_confirm")+" "+profile.label)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            ProButton(model.t("cache_delete"),{pending=null;model.deleteTemplate(profile)},kind=ProKind.DANGER,enabled=!model.busy)
            ProButton(model.t("cancel"),{pending=null},kind=ProKind.GHOST)
        }
    }
}

@Composable internal fun ProAbout(model:StudioModel){
    val c=LocalPro.current
    val notice=remember{listOf("MINECRAFT_ASSETS_NOTICE.txt","THIRD_PARTY_NOTICES.md","fonts/LXGWWenKai-OFL.txt","fonts/Monocraft-OFL.txt").joinToString("\n\n"){name->runCatching{DesktopDirs.context.assets.open(name).bufferedReader().use{it.readText()}}.getOrDefault("")}}
    Text(model.t("unofficial"),style=MaterialTheme.typography.bodyMedium,color=c.tx)
    InfoLine(model.p("version"),"MCTS Free ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
    ProNote(model.p("mirror_notice"))
    ProButton("Minecraft EULA ↗",{DesktopPlatform.openUrl("https://www.minecraft.net/en-us/eula")},kind=ProKind.GHOST)
    SelectionContainer{Text(notice,style=MaterialTheme.typography.bodySmall,color=c.tx2)}
}

@Composable private fun ResolutionDialog(model:StudioModel,texture:TemplateTexture,close:()->Unit){
    val c=LocalPro.current
    val sizes=texture.sizes()
    var size by remember(texture.path){mutableIntStateOf(if(texture.width in sizes)texture.width else sizes.firstOrNull()?:16)}
    ProDialog(model,model.t("resolution"),close,width=480.dp,icon="grid"){
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){
            TemplateThumb(model,texture.path,48.dp)
            Text(model.assetName(texture.path),style=MaterialTheme.typography.bodyMedium,color=c.tx)
        }
        ProSegmented(sizes.map{"$it×"},sizes.indexOf(size),{size=sizes[it]},Modifier.fillMaxWidth(),mono=true)
        Text("${texture.width}×${texture.height} → $size×${size*texture.height/texture.width}",style=MaterialTheme.typography.bodySmall.copy(fontFamily=ProMono),color=c.tx3)
        ProNote(model.p("default_resolution_tip"))
        ProButton(model.t("edit"),{model.openTemplate(texture,size);close()},Modifier.fillMaxWidth(),kind=ProKind.PRIMARY,enabled=!model.busy&&sizes.isNotEmpty())
    }
}

/** Liquid glass (Android 13+, off by default): wallpaper, small-UI glass, tuning for big / small UI and per-element picking. */
@Composable private fun ProGlassSettings(model:StudioModel,launchers:ProLaunchers,startPicking:()->Unit){
    val c=LocalPro.current
    if(!LiquidGlass.supported){ProNote(model.p("glass_unsupported"));return}
    ProSwitchRow(model.p("glass_switch"),model.liquidGlass,model::changeLiquidGlass,hint=model.p("glass_hint"))
    if(!model.liquidGlass)return
    val has=model.appearance.wallpaperPath.isNotBlank()
    Text(model.p(if(has)"glass_wallpaper_set" else "glass_wallpaper_none"),style=MaterialTheme.typography.bodySmall,color=c.tx3)
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
        ProButton(model.p("glass_wallpaper_pick"),launchers.pickWallpaper,Modifier.weight(1f),icon="image",enabled=!model.busy)
        if(has)ProButton(model.p("glass_wallpaper_clear"),model::clearWallpaper,icon="delete",kind=ProKind.GHOST)
    }
    // 1.0.2.1
    ProSwitchRow(model.p("glass_small_switch"),model.glassSmall,model::changeGlassSmall,hint=model.p("glass_small_hint"))
    GlassTuningBlock(model,true,model.p("glass_big_title"),model.glassBigTuning)
    GlassTuningBlock(model,false,model.p("glass_small_title"),model.glassSmallTuning)
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
        ProButton(model.p("glass_pick"),startPicking,Modifier.weight(1f),icon="pointer")
        ProButton(model.p("glass_reset"),model::resetGlassTuning,icon="rotate",kind=ProKind.GHOST)
    }
    Text(model.p("glass_pick_note").format(model.glassOverrides.size),style=MaterialTheme.typography.bodySmall,color=c.tx3)
    if(model.glassOverrides.isNotEmpty())ProButton(model.p("glass_pick_clear"),model::clearGlassOverrides,Modifier.fillMaxWidth(),icon="delete",kind=ProKind.GHOST)
}

@Composable private fun GlassTuningBlock(model:StudioModel,big:Boolean,title:String,t:GlassTuning){
    val c=LocalPro.current
    ProLabel(title)
    @Composable fun row(label:String,value:Float,range:ClosedFloatingPointRange<Float>,shown:String,set:(Float)->GlassTuning){
        Row(verticalAlignment=Alignment.CenterVertically){
            Text(label,style=MaterialTheme.typography.bodySmall,color=c.tx2,modifier=Modifier.width(96.dp))
            ProSlider(value,{model.changeGlassTuning(big,set(it))},range,Modifier.weight(1f),description=title+" · "+label)
            Text(shown,style=MaterialTheme.typography.labelSmall.copy(fontFamily=ProMono),color=c.tx3,modifier=Modifier.width(44.dp))
        }
    }
    row(model.p("glass_blur"),t.blurDp,0f..GlassTuning.MAX_BLUR,"${t.blurDp.toInt()} dp"){t.copy(blurDp=it)}
    row(model.p("glass_opacity"),t.opacity,0f..2f,"${(t.opacity*100).toInt()}%"){t.copy(opacity=it)}
    row(model.p("glass_refraction"),t.refraction,0f..2f,"${(t.refraction*100).toInt()}%"){t.copy(refraction=it)}
    row(model.p("glass_highlight"),t.highlight,0f..2f,"${(t.highlight*100).toInt()}%"){t.copy(highlight=it)}
}
