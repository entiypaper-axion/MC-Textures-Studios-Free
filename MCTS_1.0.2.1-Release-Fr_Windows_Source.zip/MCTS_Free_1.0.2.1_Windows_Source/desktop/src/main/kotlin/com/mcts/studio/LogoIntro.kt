package com.mcts.studio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * 1.0.2 cold-start intro: the promo's opening — the 5 × 5 MCTS plate builds from falling cells (the "M" cells land white and
 * cool to mint), the plate gains its sides and glow, then slides into the lockup "MCTS · FREE · 1.0.2". Silent, ~3 s.
 * Tap anywhere to skip. With reduced motion the finished lockup shows briefly and fades.
 */
@Composable internal fun LogoIntro(version:String,reducedMotion:Boolean,onDone:()->Unit){
    val done by rememberUpdatedState(onDone)
    var t by remember{mutableFloatStateOf(if(reducedMotion)Intro.LOCKUP_END else 0f)}
    var exit by remember{mutableFloatStateOf(0f)}
    var skipping by remember{mutableStateOf(false)}
    LaunchedEffect(reducedMotion){
        var start=-1L;var exitStart=-1L
        while(true){
            val now=withFrameNanos{it}
            if(start<0)start=now
            val elapsed=(now-start)/1e9f
            if(!reducedMotion&&!skipping)t=min(Intro.LOCKUP_END+.6f,elapsed)
            val shouldExit=skipping||(if(reducedMotion)elapsed>.7f else elapsed>Intro.EXIT_AT)
            if(shouldExit){
                if(exitStart<0)exitStart=now
                val d=if(skipping).18f else .38f
                exit=((now-exitStart)/1e9f/d).coerceIn(0f,1f)
                if(exit>=1f){done();break}
            }
        }
    }
    val e=Intro.ease(exit)
    Box(Modifier.fillMaxSize().graphicsLayer{alpha=1f-e;scaleX=1f+.04f*e;scaleY=1f+.04f*e}.background(Intro.BG)
        .pointerInput(Unit){detectTapGestures{skipping=true}}
        .semantics{contentDescription="MCTS Free $version"}){
        Canvas(Modifier.fillMaxSize()){drawIntro(t)}
        val textAlpha=Intro.seg(t,2.05f,.35f)
        Column(Modifier.align(Alignment.BottomCenter).padding(bottom=56.dp).graphicsLayer{alpha=textAlpha;translationY=(1f-textAlpha)*12f},horizontalAlignment=Alignment.CenterHorizontally){
            Text("MC TEXTURES STUDIOS",style=TextStyle(color=Color(0xff8b939e),fontSize=12.sp,letterSpacing=3.sp,fontWeight=FontWeight.Medium))
            Spacer(Modifier.height(6.dp))
            Text(version,style=TextStyle(color=Intro.MINT,fontSize=13.sp,fontFamily=FontFamily.Monospace))
        }
    }
}

private object Intro {
    val BG=Color(0xff0b0e11); val MINT=Color(0xff5eeac0); val CELL=Color(0xff183531); val EDGE=Color(0xff0b1a18)
    val SIDE_L=Color(0xff0f2b26); val SIDE_R=Color(0xff0a1c19)
    const val LOCKUP_END=2.45f; const val EXIT_AT=2.95f
    val C30=cos(PI/6).toFloat()
    /** Cells of the "M" (x,y). */
    val M=setOf(0 to 0,0 to 1,0 to 2,0 to 3,0 to 4,4 to 0,4 to 1,4 to 2,4 to 3,4 to 4,1 to 1,3 to 1,2 to 2)
    /** Same hash as the promo, so the cells fall in the same order. */
    fun hash(a:Int,b:Int=0,c:Int=0):Float{
        var h=(a*374761393+b*668265263+c*1274126177)
        h=(h xor (h ushr 13))*1274126177;h=h xor (h ushr 16)
        return (h.toLong() and 0xffffffffL)/4294967296f
    }
    val drop=FloatArray(25){i->.08f+(hash(i%5,i/5,9)*14).toInt()*.055f}
    fun clamp(x:Float)=x.coerceIn(0f,1f)
    fun seg(t:Float,a:Float,d:Float)=clamp((t-a)/d)
    fun ease(x:Float)=clamp(x).let{it*it*(3-2*it)}
    fun eOut(x:Float)=1f-(1f-clamp(x)).pow(3)
    fun eBack(x:Float)=clamp(x).let{val c=1.9f;1f+(c+1f)*(it-1f).pow(3)+c*(it-1f).pow(2)}
    fun mix(a:Color,b:Color,t:Float)=Color(a.red+(b.red-a.red)*t,a.green+(b.green-a.green)*t,a.blue+(b.blue-a.blue)*t,1f)
    val GLYPHS=mapOf(
        'M' to listOf("X...X","XX.XX","X.X.X","X...X","X...X"),'C' to listOf(".XXX","X...","X...","X...",".XXX"),
        'T' to listOf("XXXXX","..X..","..X..","..X..","..X.."),'S' to listOf(".XXX","X...",".XX.","...X","XXX."),
        'F' to listOf("XXXX","X...","XXX.","X...","X..."),'R' to listOf("XXX.","X..X","XXX.","X.X.","X..X"),'E' to listOf("XXXX","X...","XXX.","X...","XXXX"))
    fun width(s:String,cell:Float)=s.sumOf{(GLYPHS.getValue(it)[0].length+1).toDouble()}.toFloat()*cell-cell
}

private fun DrawScope.quad(points:List<Offset>,fill:Color?,stroke:Color?=null,width:Float=1f,alpha:Float=1f){
    val p=Path().apply{moveTo(points[0].x,points[0].y);for(i in 1 until points.size)lineTo(points[i].x,points[i].y);close()}
    if(fill!=null)drawPath(p,fill,alpha=alpha)
    if(stroke!=null)drawPath(p,stroke,alpha=alpha,style=Stroke(width))
}

private fun DrawScope.pixelText(s:String,x:Float,y:Float,cell:Float,color:Color,lt:Float,stagger:Float=.008f){
    var cx=x;var k=0
    for(ch in s){val g=Intro.GLYPHS.getValue(ch)
        for(r in 0 until 5)for(c in g[0].indices)if(g[r][c]=='X'){
            val u=Intro.eBack(Intro.seg(lt,(k++)*stagger,.22f));if(u<=0f)continue
            val sz=(cell-cell*.12f)*u;val px=cx+c*cell+cell/2;val py=y+r*cell+cell/2
            drawRoundRect(color,Offset(px-sz/2,py-sz/2),Size(sz,sz),CornerRadius(cell*.1f))
        }
        cx+=(g[0].length+1)*cell}
}

private fun DrawScope.drawIntro(t:Float){
    val unit=min(size.width,size.height)
    val mv=Intro.ease(Intro.seg(t,1.35f,.5f))
    // lockup: plate on the left, "MCTS" + FREE badge on the right, centred as a group
    // Fit both the falling plate and the final lockup (plate + gap + "MCTS" = 22.9 cell units wide) on narrow phones.
    val bigS=min(unit*.085f,size.width*.7f/(10*Intro.C30));val smallS=min(unit*.048f,size.width*.86f/(10*Intro.C30+1.2f+21*.62f))
    val s=bigS+(smallS-bigS)*mv
    val textCell=smallS*.62f
    val textW=Intro.width("MCTS",textCell);val plateW=5*Intro.C30*smallS*2
    val groupW=plateW+smallS*1.2f+textW
    val lockCx=size.width/2-groupW/2+plateW/2
    val cx=size.width/2+(lockCx-size.width/2)*mv;val cy=size.height*.46f
    // halo
    val halo=Intro.seg(t,.9f,.7f)
    if(halo>0f)drawCircle(Brush.radialGradient(listOf(Intro.MINT.copy(alpha=.16f*halo),Color.Transparent),Offset(cx,cy),unit*.55f*(1f-mv*.4f)),unit*.55f,Offset(cx,cy))
    val ox=cx;val oy=cy-2.5f*s;val thick=.6f
    fun p(x:Float,y:Float,z:Float=0f)=Offset(ox+(x-y)*Intro.C30*s,oy+(x+y)*.5f*s-z*s)
    val side=Intro.seg(t,.95f,.3f)
    if(side>0f){
        quad(listOf(p(0f,5f),p(5f,5f),p(5f,5f,-thick),p(0f,5f,-thick)),Intro.SIDE_L,alpha=side)
        quad(listOf(p(5f,0f),p(5f,5f),p(5f,5f,-thick),p(5f,0f,-thick)),Intro.SIDE_R,alpha=side)
        quad(listOf(p(0f,0f),p(5f,0f),p(5f,5f),p(0f,5f)),Intro.CELL,alpha=side)
    }
    for(gy in 0 until 5)for(gx in 0 until 5){
        val st=Intro.drop[gy*5+gx];val u=Intro.eOut(Intro.seg(t,st,.32f));if(u<=0f)continue
        val z=(1f-u)*7f;val isM=(gx to gy) in Intro.M
        val land=Intro.seg(t,st+.3f,.28f)
        val color=if(isM)Intro.mix(Color.White,Intro.MINT,land) else Intro.CELL
        val x=gx.toFloat();val y=gy.toFloat()
        quad(listOf(p(x,y,z),p(x+1,y,z),p(x+1,y+1,z),p(x,y+1,z)),color,Intro.EDGE,max(1f,s*.03f),alpha=Intro.clamp(u*2f))
    }
    if(side>0f)quad(listOf(p(0f,0f),p(5f,0f),p(5f,5f),p(0f,5f)),null,Intro.MINT,max(1.5f,s*.05f),alpha=.6f*side)
    // wordmark
    val textX=lockCx+plateW/2+smallS*1.2f;val textY=cy-textCell*2.5f
    if(t>1.55f)pixelText("MCTS",textX,textY,textCell,Color.White,t-1.55f)
    val badge=Intro.eBack(Intro.seg(t,1.95f,.3f))
    if(badge>0f){
        val bc=textCell*.42f;val bw=Intro.width("FREE",bc)+bc*3;val bh=bc*8
        val bx=textX+textW-bw;val by=textY+textCell*5+textCell*.9f
        withTransform({scale(badge,badge,Offset(bx+bw/2,by+bh/2))}){
            drawRoundRect(Intro.MINT,Offset(bx,by),Size(bw,bh),CornerRadius(bc*1.4f),style=Stroke(max(1.5f,bc*.45f)))
            pixelText("FREE",bx+bc*1.5f,by+bc*1.5f,bc,Intro.MINT,99f)
        }
    }
}
