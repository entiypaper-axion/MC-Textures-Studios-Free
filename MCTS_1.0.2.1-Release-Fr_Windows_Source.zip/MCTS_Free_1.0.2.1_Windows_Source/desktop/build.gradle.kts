import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.compose")
}

group = "com.mcts.studio"
version = "1.0.2.1"

kotlin {
    jvmToolchain(17)
}

dependencies {
    // Compose Desktop 1.8.2 (Skia/Skiko renderer, Swing coroutine dispatcher included).
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.10.2")
    // Same org.json the Android framework ships (the shared model code uses it).
    implementation("org.json:json:20240303")
    // Windows: "Animation effects" setting and the dark title bar.
    implementation("net.java.dev.jna:jna:5.14.0")
}

// The core (pure Java, identical to the Android :core module) lives in src/main/java and is compiled with the app.
tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(17)
}

compose.desktop {
    application {
        mainClass = "com.mcts.studio.MainKt"
        jvmArgs += listOf("-Dfile.encoding=UTF-8", "-Xmx3g", "-Dsun.java2d.uiScale.enabled=true")

        nativeDistributions {
            // Installer only (no MSI / ZIP), as requested.
            targetFormats(TargetFormat.Exe)
            packageName = "MCTS Free"
            // Windows installers take MAJOR.MINOR.BUILD only: 1.0.2.1 is written as 1.0.21 (newer than 1.0.2, so it upgrades in place).
            packageVersion = "1.0.21"
            description = "MCTS Free – Minecraft resource pack texture editor"
            vendor = "MCTS"
            copyright = "© MCTS. Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft."
            licenseFile.set(project.file("../LICENSE_NOTICE.txt"))
            // Runtime image: only the JDK modules the app needs (AWT/Swing, logging, prefs, TLS ciphers, JNA).
            modules("java.desktop", "java.logging", "java.naming", "java.prefs", "java.net.http", "jdk.unsupported", "jdk.crypto.ec", "jdk.charsets", "jdk.localedata", "jdk.accessibility")
            windows {
                iconFile.set(project.file("icon.ico"))
                menuGroup = "MCTS"
                shortcut = true
                menu = true
                dirChooser = true
                // Installs for the current user (no administrator prompt); upgrades in place because of the fixed UUID.
                perUserInstall = true
                upgradeUuid = "7d3f6a2e-5b1c-4e0a-9c42-1f0d2a6b8e31"
                exePackageVersion = "1.0.21"
            }
        }

        buildTypes.release.proguard {
            isEnabled.set(false)
        }
    }
}
