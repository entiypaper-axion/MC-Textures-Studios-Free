@echo off
chcp 65001 >nul
rem Runs MCTS Free directly from the sources (no installer) - handy for testing.
cd /d "%~dp0"
call gradlew.bat --no-daemon :desktop:run
