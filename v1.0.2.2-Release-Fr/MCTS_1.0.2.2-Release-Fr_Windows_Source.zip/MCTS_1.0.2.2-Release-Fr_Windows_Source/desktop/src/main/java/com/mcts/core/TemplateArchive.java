package com.mcts.core;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Color-only cache builder. All output stays staged until fully validated. */
public final class TemplateArchive {
    public interface Control { void check()throws IOException;void progress(float fraction); }
    private static final Set<String> VANILLA_COLOR_NAMES=new HashSet<>(Arrays.asList(
        "textures/particle/sga_n.png","textures/particle/sga_s.png",
        "textures/blocks/piston_top_normal.png","textures/blocks/rail_normal.png",
        // 1.0 – 1.5.2 ship environment/light_normal.png: without it every old-version template failed validation.
        "textures/environment/light_normal.png",
        "textures/blocks/red_sandstone_normal.png","textures/blocks/sandstone_normal.png",
        "textures/entity/chest/double_normal.png","textures/items/book_normal.png",
        "textures/items/minecart_normal.png","textures/ui/buy_now_normal.png",
        "textures/ui/cell_image_normal.png","textures/ui/icon_rail_normal.png",
        "textures/ui/normal_normal.png","textures/ui/realms_plus_normal.png"));
    public static boolean isPbr(String name){
        String normalized=name.startsWith("assets/minecraft/")?name.substring("assets/minecraft/".length()):name;
        if(normalized.endsWith(".tga"))normalized=normalized.substring(0,normalized.length()-4)+".png";
        if(VANILLA_COLOR_NAMES.contains(normalized))return false;
        return name.endsWith(".texture_set.json")||name.matches(".*_(mer|mers|normal|n|s|height|heightmap)\\.(png|tga)$");
    }

    public static String texturePath(String original,String profile)throws IOException{
        String n=original.replace('\\','/');
        for(String part:n.split("/"))if(part.equals("..")||part.equals(".")||part.contains(":"))throw new IOException("TEMPLATE_INVALID");
        if(n.startsWith("/"))throw new IOException("TEMPLATE_INVALID");
        if(profile.startsWith("java_"))return n.startsWith("assets/minecraft/textures/")?n:null;
        // Mojang/bedrock-samples: <root>/resource_pack/textures/…; archived samples (bedrock.dev, 1.16.20 – 1.19.30): <root>/stable/resource/textures/…
        for(String marker:new String[]{"/stable/resource/textures/","/resource_pack/textures/"}){
            int index=n.indexOf(marker);if(index>=0)return "textures/"+n.substring(index+marker.length());
        }
        return null;
    }
    public static int build(File source,String profile,File output,Control control)throws IOException{
        File part=new File(output.getPath()+".building");Set<String> names=new HashSet<>();int count=0;long total=0;
        try(ZipFile zip=new ZipFile(source);FileOutputStream file=new FileOutputStream(part);ZipOutputStream out=new ZipOutputStream(file)){
            List<? extends ZipEntry> entries=Collections.list(zip.entries());entries.sort(Comparator.comparing(e->e.getName().endsWith(".tga")));
            int done=0;
            for(ZipEntry entry:entries){control.check();String name=texturePath(entry.getName(),profile);done++;control.progress((float)done/Math.max(1,entries.size()));
                if(entry.isDirectory()||name==null||isPbr(name)||!name.matches(".*\\.(png|tga|json|mcmeta)$"))continue;
                if(entry.getSize()<0||entry.getSize()>64L*1024*1024)throw new IOException("TEMPLATE_LARGE");
                total+=entry.getSize();if(total>512L*1024*1024)throw new IOException("TEMPLATE_LARGE");
                String target=name.endsWith(".tga")?name.substring(0,name.length()-4)+".png":name;
                if(!names.add(target))continue;
                byte[] bytes;
                try(InputStream in=zip.getInputStream(entry)){ByteArrayOutputStream data=new ByteArrayOutputStream();byte[] buffer=new byte[65536];int n;CRC32 crc=new CRC32();
                    while((n=in.read(buffer))!=-1){control.check();data.write(buffer,0,n);crc.update(buffer,0,n);if(data.size()>64*1024*1024)throw new IOException("TEMPLATE_LARGE");}
                    if(crc.getValue()!=entry.getCrc())throw new IOException("TEMPLATE_INVALID");bytes=data.toByteArray();
                }
                if(name.endsWith(".tga")){TgaDecoder.Image image=TgaDecoder.decode(new ByteArrayInputStream(bytes));bytes=Png.templateRgba(image.width,image.height,image.argb);}
                if(target.endsWith(".png")){
                    // Pinned Mojang samples ship this one legacy UI file as JPEG with a PNG extension.
                    boolean legacyJpeg=target.equals("textures/ui/inventory_warning_xbox.png")&&bytes.length>24&&(bytes[0]&255)==255&&(bytes[1]&255)==216&&(bytes[bytes.length-2]&255)==255&&(bytes[bytes.length-1]&255)==217;
                    if(!legacyJpeg)checkPng(bytes);count++;
                }
                out.putNextEntry(new ZipEntry(target));out.write(bytes);out.closeEntry();
            }
            if(count<100||names.stream().noneMatch(n->n.endsWith("/stone.png")))throw new IOException("TEMPLATE_INVALID");
            out.finish();out.flush();file.getFD().sync();
        }catch(Exception e){part.delete();throw e;}
        try{validate(part);Files.move(part.toPath(),output.toPath(),StandardCopyOption.REPLACE_EXISTING);return count;}finally{part.delete();}
    }
    /**
     * 1.0.2.1: block models for the 3D preview. Copies the official model / blockstate JSON of the same verified source
     * (Java: assets/minecraft/models + blockstates; Bedrock: resource_pack/models) into a small side archive, so partial
     * blocks show the game's own UVs. Returns the number of files; 0 = nothing to keep (pre-1.8 Java has no JSON models).
     */
    public static int extractModels(File source,String profile,File output,Control control)throws IOException{
        File part=new File(output.getPath()+".building");int count=0;long total=0;
        try(ZipFile zip=new ZipFile(source);FileOutputStream file=new FileOutputStream(part);ZipOutputStream out=new ZipOutputStream(file)){
            for(ZipEntry entry:Collections.list(zip.entries())){control.check();
                String target=modelPath(entry.getName(),profile);
                if(entry.isDirectory()||target==null||entry.getSize()<0||entry.getSize()>1024*1024)continue;
                total+=entry.getSize();if(total>64L*1024*1024)throw new IOException("TEMPLATE_LARGE");
                byte[] bytes;
                try(InputStream in=zip.getInputStream(entry)){ByteArrayOutputStream data=new ByteArrayOutputStream();byte[] buffer=new byte[16384];int n;
                    while((n=in.read(buffer))!=-1){data.write(buffer,0,n);if(data.size()>1024*1024)throw new IOException("TEMPLATE_LARGE");}
                    bytes=data.toByteArray();
                }
                out.putNextEntry(new ZipEntry(target));out.write(bytes);out.closeEntry();count++;
            }
            if(count==0)out.putNextEntry(new ZipEntry("empty"));
            out.finish();out.flush();file.getFD().sync();
        }catch(Exception e){part.delete();throw e;}
        try{if(count>0)Files.move(part.toPath(),output.toPath(),StandardCopyOption.REPLACE_EXISTING);return count;}finally{part.delete();}
    }
    static String modelPath(String original,String profile){
        String n=original.replace('\\','/');
        if(n.contains("..")||n.startsWith("/")||!n.endsWith(".json"))return null;
        if(profile.startsWith("java_"))return n.startsWith("assets/minecraft/models/")||n.startsWith("assets/minecraft/blockstates/")?n:null;
        for(String marker:new String[]{"/stable/resource/models/","/resource_pack/models/"}){
            int index=n.indexOf(marker);if(index>=0)return "resource_pack/models/"+n.substring(index+marker.length());
        }
        return null;
    }
    public static void validate(File file)throws IOException{
        int count=0;try(ZipFile z=new ZipFile(file)){
            for(ZipEntry e:Collections.list(z.entries())){String n=e.getName();if(isPbr(n)||n.endsWith(".tmp")||n.endsWith(".part")||n.contains("..")||n.startsWith("/"))throw new IOException("TEMPLATE_INVALID");
                if(n.endsWith(".png"))count++;
            }
        }if(count<100)throw new IOException("TEMPLATE_INVALID");
    }
    private static void checkPng(byte[] bytes)throws IOException{
        if(bytes.length<24)throw new IOException("TEMPLATE_INVALID");DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes));
        if(in.readLong()!=0x89504e470d0a1a0aL||in.readInt()!=13||in.readInt()!=0x49484452)throw new IOException("TEMPLATE_INVALID");
        int w=in.readInt(),h=in.readInt();if(w<1||h<1||w>16384||h>16384)throw new IOException("TEMPLATE_INVALID");
    }
}
