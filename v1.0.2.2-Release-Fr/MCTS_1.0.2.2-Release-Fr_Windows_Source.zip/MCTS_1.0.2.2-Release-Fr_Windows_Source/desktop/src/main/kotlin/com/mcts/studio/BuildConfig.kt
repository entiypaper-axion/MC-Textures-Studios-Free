package com.mcts.studio

/** Same values as the Android free flavor (versionName "1.0.2.1-Release" + "-Fr", versionCode 31021). */
object BuildConfig {
    const val VERSION_NAME = "1.0.2.2-Release-Fr"
    const val VERSION_CODE = 31022
    const val IS_FREE = true
    const val PLATFORM = "Windows"
}
