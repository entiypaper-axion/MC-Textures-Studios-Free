package com.mcts.studio

import com.mcts.studio.compat.Application
import com.mcts.studio.compat.BitmapFactory
import com.mcts.studio.compat.Uri
import com.mcts.studio.compat.Log
import androidx.compose.runtime.*
import com.mcts.studio.compat.AndroidViewModel
import com.mcts.core.*
import kotlinx.coroutines.*
import java.io.File
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class AssetItem(val key: String, val name: String, val kind: MaterialDocument.Kind, val size: String)
data class PreviewFrame(val color:Array<IntArray>,val normal:Array<IntArray>,val height:Array<ByteArray>,val mers:Array<IntArray>,val size:Int,val shape:String)

class StudioModel(application: Application) : AndroidViewModel(application) {
    val isFree=BuildConfig.IS_FREE
    val policy=EditionPolicy(isFree)
    fun allows(feature:EditionPolicy.Feature)=policy.allows(feature)
    private fun requireFeature(feature:EditionPolicy.Feature):Boolean {
        if(allows(feature))return true
        message="free_unavailable";return false
    }
    val channels get()=MaterialDocument.Channel.entries.filter{policy.allowsChannel(it)}
    override fun onCleared(){projectFiles.templates.cancel();super.onCleared()}
    /** Window closing: write the open documents synchronously (Android does this on pause). */
    fun saveBeforeExit(){runCatching{finishValue();endStroke();saveEditing()}.onFailure{Log.e("MCTS","Save on exit failed",it)}}
    private val preferences = application.getSharedPreferences("studio3",0)
    val appearance=Appearance(application)
    var successPulse by mutableIntStateOf(0); private set
    val projectFiles=Projects(application)
    var pack by mutableStateOf(runCatching{projectFiles.read(preferences.getString("pack","local")!!)}.getOrElse{projectFiles.legacy()}); private set
    var packs by mutableStateOf(projectFiles.list()); private set
    var showStart by mutableStateOf(isFree&&!preferences.getBoolean("editorVisited",false)&&packs.none{it.id!="local"}&&projectFiles.store(pack).list().isEmpty()); private set
    var downloading by mutableStateOf(false); private set
    var downloadStage by mutableStateOf("download_fetch"); private set
    var downloadBytes by mutableLongStateOf(0); private set
    var downloadTotal by mutableLongStateOf(0); private set
    var downloadError by mutableStateOf<String?>(null); private set
    var availableTemplates by mutableStateOf(gameProfiles.filter{projectFiles.templates.available(it)}.map{it.id}.toSet()); private set
    var templateProfileId by mutableStateOf(preferences.getString("templateProfile",pack.profile.id)!!.takeIf{id->gameProfiles.any{it.id==id}}?:pack.profile.id); private set
    fun rememberTemplateChoice(id:String){templateProfileId=id;preferences.edit().putString("templateProfile",id).apply()}
    fun showStartPage(){if(!busy)showStart=true}
    private fun rememberEditor(){showStart=false;preferences.edit().putBoolean("editorVisited",true).apply()}
    fun continueEditing(){if(!busy)rememberEditor()}
    var cacheRevision by mutableIntStateOf(0); private set
    fun deleteTemplate(profile:GameProfile)=task(celebrate=false){withContext(Dispatchers.IO){projectFiles.templates.deleteCache(profile)};refreshTemplates();cacheRevision++;message="cache_deleted"}
    /** Windows: the "metered connection" flag of the current network (cached, see DesktopPlatform.refreshMetered). */
    fun isMetered():Boolean=com.mcts.studio.compat.DesktopPlatform.metered
    fun cancelDownload(){projectFiles.templates.cancel()}
    private fun refreshTemplates(){availableTemplates=gameProfiles.filter{projectFiles.templates.available(it)}.map{it.id}.toSet()}
    fun prepareTemplate(profile:GameProfile)=task(celebrate=false){
        downloading=true;downloadError=null;downloadStage="download_fetch";downloadBytes=0;downloadTotal=0
        try {
            withContext(Dispatchers.IO){projectFiles.templates.download(profile){stage,fraction,bytes,total->
                javax.swing.SwingUtilities.invokeLater{downloadStage=stage;progress=fraction;downloadBytes=bytes;downloadTotal=total}
            }}
            refreshTemplates();message="download_ready"
        }catch(e:java.util.concurrent.CancellationException){downloadError="download_cancelled"}
        catch(e:Exception){downloadError=downloadErrorKey(e);lastErrorCode="DOWNLOAD_"+downloadError!!.removePrefix("download_").uppercase()}
        finally{downloading=false;refreshTemplates()}
    }
    /** 1.0.2.1: Minecraft Java font, generated on the device from the newest official client.jar (nothing bundled). */
    val minecraftFontProfile get()=gameProfiles.filter{it.java&&!it.texturePack&&projectFiles.templates.hasSource(it)}.maxWithOrNull{a,b->
        val x=a.parts;val y=b.parts;(0 until maxOf(x.size,y.size)).map{(x.getOrElse(it){0}).compareTo(y.getOrElse(it){0})}.firstOrNull{it!=0}?:0}
    fun downloadMinecraftFont()=task(celebrate=false){
        val profile=minecraftFontProfile?:throw IOException("TEMPLATE_UNAVAILABLE")
        downloading=true;downloadError=null;downloadStage="download_fetch";downloadBytes=0;downloadTotal=0
        try{
            val built=withContext(Dispatchers.IO){
                val jar=projectFiles.templates.fetchSource(profile){stage,fraction,bytes,total->
                    javax.swing.SwingUtilities.invokeLater{downloadStage=stage;progress=fraction*.9f;downloadBytes=bytes;downloadTotal=total}
                }
                val extra=HashMap<String,File>()
                try{
                    // 1.0.2.2: the jar's include/unifont.json is empty; Chinese etc. come from the asset index.
                    GameFonts.minecraftAssets.entries.forEachIndexed{i,entry->extra[entry.key]=projectFiles.templates.fetchPinned(entry.value,"font-asset-$i"){_,_,_,_->}}
                    val part=File(appearance.gameFontFile("minecraft_java").path+".build")
                    com.mcts.core.MinecraftFont.build(jar,extra,part){if(Thread.currentThread().isInterrupted)throw java.util.concurrent.CancellationException()}
                    part
                }finally{jar.delete();extra.values.forEach{it.delete()}}
            }
            appearance.useGameFont("minecraft_java",built)
            message="font_minecraft_ready"
        }catch(e:java.util.concurrent.CancellationException){downloadError="download_cancelled";message="download_cancelled"}
        catch(e:Exception){downloadError=if(e.message=="FONT_SOURCE")"font_minecraft_failed" else downloadErrorKey(e);lastErrorCode="FONT_"+(e.message?:"ERROR");message=downloadError}
        finally{downloading=false}
    }
    /** 1.0.2.2: one tap downloads (or builds) a game font and uses it. Open fonts come from the games' own repositories. */
    fun downloadGameFont(key:String){
        if(key=="minecraft_java"){downloadMinecraftFont();return}
        val row=GameFonts.open[key]?:return
        task(celebrate=false){
            downloading=true;downloadError=null;downloadStage="download_fetch";downloadBytes=0;downloadTotal=0
            try{
                val file=withContext(Dispatchers.IO){projectFiles.templates.fetchPinned(row,"font-$key"){_,_,_,_->}}
                appearance.useGameFont(key,file)
                message="font_game_ready"
            }catch(e:java.util.concurrent.CancellationException){downloadError="download_cancelled";message="download_cancelled"}
            catch(e:Exception){downloadError=downloadErrorKey(e);lastErrorCode="FONT_"+(e.message?:"ERROR");message=downloadError}
            finally{downloading=false}
        }
    }
    fun importGameFont(key:String,uri:Uri)=task{val file=withContext(Dispatchers.IO){appearance.prepareFont(uri)};appearance.useGameFont(key,file)}
    /** 1.0.2.1: the template was downloaded without model data (1.0.2); the preview offers to fetch it. */
    val templateModelsMissing get()=cacheRevision>=0&&modelMesh==null&&projectFiles.templates.needsModels(pack.profile)
    fun downloadTemplateModels()=task(celebrate=false){
        downloading=true;downloadError=null;downloadStage="download_fetch";downloadBytes=0;downloadTotal=0
        try {
            withContext(Dispatchers.IO){projectFiles.templates.downloadModels(pack.profile){stage,fraction,bytes,total->
                javax.swing.SwingUtilities.invokeLater{downloadStage=stage;progress=fraction;downloadBytes=bytes;downloadTotal=total}
            }}
            refreshModel();cacheRevision++;changed();message="models_ready"
        }catch(e:java.util.concurrent.CancellationException){downloadError="download_cancelled"}
        catch(e:Exception){downloadError=downloadErrorKey(e);lastErrorCode="DOWNLOAD_"+downloadError!!.removePrefix("download_").uppercase()}
        finally{downloading=false}
    }
    private fun downloadErrorKey(e:Exception)=when {
        e is java.net.UnknownHostException->"download_dns"
        e is java.net.SocketTimeoutException->"download_timeout"
        e is javax.net.ssl.SSLException->"download_tls"
        e.message?.contains("TEMPLATE_SPACE")==true->"download_space"
        e.message?.contains("ENOSPC")==true||e.message?.contains("No space left")==true->"error_space"
        e.message?.contains("TEMPLATE_HASH")==true||e.message?.contains("TEMPLATE_INVALID")==true->"download_invalid"
        e.message?.contains("TEMPLATE_MISSING")==true->"download_required"
        e.message?.contains("TEMPLATE_UNAVAILABLE")==true->"download_unavailable"
        else->"download_network"
    }
    var templateTextures by mutableStateOf<List<TemplateTexture>>(emptyList()); private set
    var previewFailed by mutableStateOf(false); private set
    var previewAttempt by mutableIntStateOf(0); private set
    fun previewError(){previewFailed=true}
    fun retryPreview(){previewFailed=false;previewAttempt++}
    var previewFaceSet by mutableStateOf<FaceMaps?>(null);private set
    var modelMesh by mutableStateOf<ModelMesh?>(null);private set
    var store=projectFiles.store(pack); private set
    var sampler by mutableStateOf(false); private set
    var panCanvas by mutableStateOf(false); private set
    var pixelGrid by mutableStateOf(preferences.getBoolean("pixelGrid",true)); private set
    enum class EditMode { PREVIEW, BOTH }
    var editMode by mutableStateOf(runCatching{if(isFree)EditMode.BOTH else EditMode.valueOf(preferences.getString("editMode","BOTH")!!)}.getOrDefault(EditMode.BOTH)); private set
    var previewPainting by mutableStateOf(false); private set
    var sunSheets by mutableStateOf(!isFree&&preferences.getBoolean("sunSheets",true)); private set
    var transparentUi by mutableStateOf(preferences.getBoolean("transparentUi",false)); private set
    var chooseBlock by mutableStateOf(preferences.getBoolean("chooseBlock",true)); private set
    fun changeEditMode(next:EditMode){if(!requireFeature(EditionPolicy.Feature.MODEL_PAINT))return;finishValue();document.endStroke();editMode=next;previewPainting=false;preferences.edit().putString("editMode",next.name).apply()}
    fun changePreviewPainting(next:Boolean){if(!requireFeature(EditionPolicy.Feature.MODEL_PAINT))return;finishValue();document.endStroke();previewPainting=next}
    fun changeSunSheets(next:Boolean){if(!requireFeature(EditionPolicy.Feature.GLASS))return;sunSheets=next;preferences.edit().putBoolean("sunSheets",next).apply()}
    fun changeTransparentUi(next:Boolean){transparentUi=next;preferences.edit().putBoolean("transparentUi",next).apply()}
    fun changeChooseBlock(next:Boolean){if(busy)return;chooseBlock=next;preferences.edit().putBoolean("chooseBlock",next).apply()}
    enum class ThemeMode { SYSTEM, LIGHT, DARK }
    var themeMode by mutableStateOf(runCatching{ThemeMode.valueOf(preferences.getString("themeMode","SYSTEM")!!)}.getOrDefault(ThemeMode.SYSTEM)); private set
    fun changeThemeMode(next:ThemeMode){themeMode=next;preferences.edit().putString("themeMode",next.name).apply()}
    enum class HandMode { AUTO, LEFT, RIGHT }
    var handMode by mutableStateOf(runCatching{HandMode.valueOf(preferences.getString("handMode","AUTO")!!)}.getOrDefault(HandMode.AUTO)); private set
    fun changeHandMode(next:HandMode){handMode=next;preferences.edit().putString("handMode",next.name).apply()}
    var mirrorX by mutableStateOf(preferences.getBoolean("mirrorX",false)); private set
    var mirrorY by mutableStateOf(preferences.getBoolean("mirrorY",false)); private set
    fun setMirror(x:Boolean,y:Boolean){if(busy)return;endStroke();mirrorX=x;mirrorY=y;preferences.edit().putBoolean("mirrorX",x).putBoolean("mirrorY",y).apply()}
    var showGestureHint by mutableStateOf(!preferences.getBoolean("gestureHintSeen",false)); private set
    fun dismissGestureHint(){showGestureHint=false;preferences.edit().putBoolean("gestureHintSeen",true).apply()}
    var exportGuidePending by mutableStateOf(false)
    var exportedForJava by mutableStateOf(false); private set
    var exportSummary by mutableStateOf<ExportSummary?>(null); private set
    fun refreshExportSummary()=task(celebrate=false,operation="export_summary"){
        exportSummary=null
        exportSummary=withContext(Dispatchers.IO){saveEditing();projectFiles.exportSummary(pack)}
    }
    var deletedProject by mutableStateOf<TrashedProject?>(null); private set
    private var deleteTimer:Job?=null
    fun renamePack(p:PackProject,name:String)=task(operation="project_rename"){
        val renamed=withContext(Dispatchers.IO){projectFiles.rename(p,name)}
        if(pack.id==p.id)pack=renamed
        packs=withContext(Dispatchers.IO){projectFiles.list()};message="project_renamed"
    }
    fun duplicatePack(p:PackProject,name:String)=task(operation="project_copy"){
        withContext(Dispatchers.IO){saveEditing();projectFiles.duplicate(p,name)}
        packs=withContext(Dispatchers.IO){projectFiles.list()};message="project_copied"
    }
    fun deletePack(p:PackProject)=task(operation="project_delete"){
        deleteTimer?.cancel()
        val old=deletedProject
        val removed=withContext(Dispatchers.IO){saveEditing();old?.let{projectFiles.purge(it)};projectFiles.trash(p)}
        deletedProject=removed
        packs=withContext(Dispatchers.IO){projectFiles.list()}
        if(pack.id==p.id){
            val next=packs.firstOrNull()?:withContext(Dispatchers.IO){projectFiles.create(t("blank_pack"),p.profile,false)}
            loadPack(next);packs=withContext(Dispatchers.IO){projectFiles.list()}
        }
        deleteTimer=viewModelScope.launch{
            delay(8000)
            if(deletedProject==removed){deletedProject=null;withContext(Dispatchers.IO){runCatching{projectFiles.purge(removed)}}}
        }
    }
    fun undoProjectDelete(){
        if(busy)return
        val removed=deletedProject?:return
        deleteTimer?.cancel()
        task(operation="project_restore"){
            val restored=withContext(Dispatchers.IO){projectFiles.restore(removed)}
            deletedProject=null;packs=withContext(Dispatchers.IO){projectFiles.list()};loadPack(restored);message="project_restored"
        }
    }
    var lastErrorCode by mutableStateOf("NONE"); private set
    private var currentOperation="startup"
    fun diagnostics():String=Diagnostics.report(BuildConfig.VERSION_NAME,BuildConfig.VERSION_CODE,com.mcts.studio.compat.DesktopPlatform.osName,com.mcts.studio.compat.DesktopPlatform.osVersion+" "+com.mcts.studio.compat.DesktopPlatform.osArch,com.mcts.studio.compat.DesktopPlatform.javaVersion,language.name,lastErrorCode)
    var workspaceLeft by mutableFloatStateOf(preferences.getFloat("workspaceLeft",.34f).coerceIn(.25f,.5f)); private set
    fun setGrid(next:Boolean){pixelGrid=next;preferences.edit().putBoolean("pixelGrid",next).apply()}
    fun resizeWorkspaceLeft(next:Float){workspaceLeft=next.coerceIn(.25f,.5f)}
    fun saveWorkspaceRatio(){preferences.edit().putFloat("workspaceLeft",workspaceLeft).apply()}
    fun toggleCanvasPan(){if(busy)return;finishValue();document.endStroke();panCanvas=!panCanvas;if(panCanvas)sampler=false}
    var previewRatio by mutableFloatStateOf(preferences.getFloat("split",.4f).coerceIn(.15f,.85f)); private set
    var language by mutableStateOf(runCatching { Language.valueOf(preferences.getString("language","ZH")!!) }.getOrDefault(Language.ZH))
        private set
    // Removed setting: ignore legacy persisted values so an upgrade cannot get stuck in it.
    val highContrast = false
    /** 1.0.2: animations are on by default (Free included); the a11y switch or the system "remove animations" turns them off. */
    var reducedMotion by mutableStateOf(preferences.getBoolean("motion",false)); private set
    var systemReducedMotion by mutableStateOf(false)
    /** Open dialogs (the workspace blurs behind them when liquid glass is on). */
    var dialogsOpen by mutableIntStateOf(0)
    /** Current safe-area size of the workspace (custom UI is per orientation). */
    internal var workspaceArea by mutableStateOf(WorkspaceArea(1280f,800f))
    val motionOff get()=reducedMotion||systemReducedMotion
    var document by mutableStateOf(MaterialDocument("stone",MaterialDocument.Kind.BLOCK,16,16)); private set
    var activeBlock by mutableStateOf<BlockAsset?>(null);private set
    private var blockDocuments:Map<String,MaterialDocument> = emptyMap()
    private data class PreviewPlanes(val revision:Long,val size:Int,val color:IntArray,val normal:IntArray,val height:ByteArray,val mers:IntArray)
    private val previewPlanes=java.util.IdentityHashMap<MaterialDocument,PreviewPlanes>()
    private val canvasStroke=SurfaceStroke()
    private var colorStrokeUsed=false
    private val surfaceStroke=SurfaceStroke()
    private var paintingDocument:MaterialDocument?=null
    private var paintingSurface=-1
    private var strokeLayerName:String?=null
    fun assetName(path:String)=projectFiles.catalogue(pack).label(path,language)
    fun blocks()=projectFiles.catalogue(pack).blocks
    private fun blockFor(doc:MaterialDocument)=projectFiles.paths(pack).getProperty(ProjectStore.key(doc.kind,doc.name))?.let{projectFiles.catalogue(pack).find(it)}
    private fun saveEditing(){
        (blockDocuments.values+document).distinct().forEach{doc->doc.endStroke();store.save(doc)}
    }
    private suspend fun attachBlock(doc:MaterialDocument,requested:BlockAsset?=null){
        val group=requested?:withContext(Dispatchers.IO){blockFor(doc)}
        val members=if(group==null)emptyMap()else withContext(Dispatchers.IO){
            val source=projectFiles.textures(pack).associateBy{it.path}
            val selectedPath=projectFiles.paths(pack).getProperty(ProjectStore.key(doc.kind,doc.name))
            group.paths.mapNotNull{path->val texture=source[path]
                if(path==selectedPath)path to doc
                else if(texture!=null&&texture.editable)path to projectFiles.openBoundTexture(pack,texture)
                else null
            }.toMap()
        }
        activeBlock=group;blockDocuments=members;previewPlanes.clear();surfaceStroke.reset();paintingDocument=null;paintingSurface=-1
        refreshModel(doc,group)
    }
    /** 1.0.2.1: project model archive first (Ultra), then the official models saved with the template. */
    private fun modelArchives()=listOf(projectFiles.models(pack),projectFiles.templates.models(pack.profile))
    private fun modelShape(doc:MaterialDocument,group:BlockAsset?)=when{
        group!=null->"minecraft:"+group.id
        doc.kind==MaterialDocument.Kind.ENTITY->"entity:"+doc.name
        else->previewFaceSet?.shape?:"minecraft:"+doc.name.substringAfterLast('/')
    }
    private suspend fun refreshModel(doc:MaterialDocument=document,group:BlockAsset?=activeBlock){
        val shape=modelShape(doc,group)
        modelMesh=withContext(Dispatchers.IO){runCatching{OfficialModels.mesh(modelArchives(),shape)}.getOrNull()}
    }
    fun openBlock(group:BlockAsset)=task{
        val next=withContext(Dispatchers.IO){
            saveEditing();val source=projectFiles.textures(pack)
            val texture=group.paths.mapNotNull{path->source.firstOrNull{it.path==path&&it.editable}}.firstOrNull()?:throw IOException("PNG_SIZE")
            projectFiles.openTexture(pack,texture,texture.width)
        }
        document=next;activeLayer=0;selectedPixel=null;previewFaceSet=null
        attachBlock(next,group);reloadAssets();changed()
    }
    var revision by mutableLongStateOf(0); private set
    var undoEnabled by mutableStateOf(false); private set
    var redoEnabled by mutableStateOf(false); private set
    var activeLayer by mutableIntStateOf(0); private set
    var channel by mutableStateOf(MaterialDocument.Channel.COLOR); private set
    var value by mutableIntStateOf(128); private set
    var rgb by mutableStateOf("bba88c"); private set
    val brushColor get()=0xff000000.toInt() or (rgb.toIntOrNull(16)?:0xbba88c)
    var selectedPixel by mutableStateOf<Pair<Int,Int>?>(null); private set
    var assets by mutableStateOf<List<AssetItem>>(emptyList()); private set
    var selection by mutableStateOf<Set<String>>(emptySet()); private set
    var busy by mutableStateOf(false); private set
    /** True while a background save (autosave) runs: the UI shows no progress bar for it. */
    var quietBusy by mutableStateOf(false); private set
    var progress by mutableFloatStateOf(0f); private set
    var message by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)
    // 1.0.1 has a new layout: everyone (including upgraders) sees the new five-step intro once.
    var showOnboarding by mutableStateOf(!preferences.getBoolean("onboarding101",false))
    private var job: Job? = null

    fun t(key: String):String {val k=if(isFree&&key in setOf("step1","step2","step3","whole_block_hint"))"free_$key" else key;return WordsWin.text(k,language)?:Words.text(k,language)}
    fun changeLanguage(next: Language) { language=next; preferences.edit().putString("language",next.name).apply() }
    fun chooseColor(color:Int){if(busy)return;finishValue();document.endStroke();selectedPixel=null;if(channel!=MaterialDocument.Channel.NORMAL)channel=MaterialDocument.Channel.COLOR;rgb=String.format("%06x",color and 0xffffff)}
    fun toggleSampler(){if(busy)return;finishValue();document.endStroke();sampler=!sampler;if(sampler)panCanvas=false}
    fun sample(x:Int,y:Int){
        if(busy||x !in 0 until document.width||y !in 0 until document.height)return
        val color=document.composite(channel)[y*document.width+x]
        finishValue();document.endStroke();selectedPixel=null
        if(channel==MaterialDocument.Channel.COLOR||channel==MaterialDocument.Channel.NORMAL)chooseColor(color)else value=color and 255
        sampler=false
    }
    fun resizePreview(v:Float){previewRatio=v.coerceIn(.15f,.85f)}
    fun saveRatio(){preferences.edit().putFloat("split",previewRatio).apply()}
    private fun savedSwatches():List<Int> = preferences.getString("swatches",null)?.split(',')?.mapNotNull{it.toLongOrNull(16)?.toInt()}?:listOf(0xffffffff.toInt(),0xff111827.toInt(),0xffef4444.toInt(),0xfff59e0b.toInt(),0xfffde047.toInt(),0xff22c55e.toInt(),0xff06b6d4.toInt(),0xff3b82f6.toInt(),0xffa855f7.toInt(),0xffec4899.toInt(),0xffbba88c.toInt(),0xff8080ff.toInt())
    private var colorHistory by mutableStateOf(preferences.getString("recentColors","")!!.split(',').mapNotNull{it.toLongOrNull(16)?.toInt()}.distinct().take(18))
    private var swatchRevision by mutableIntStateOf(0)
    fun recentColors():List<Int> { val observed=swatchRevision;return (colorHistory+savedSwatches()).distinct().take(18) }
    private fun rememberColor(){
        if(channel!=MaterialDocument.Channel.COLOR)return
        colorHistory=(listOf(brushColor)+colorHistory).distinct().take(18)
        preferences.edit().putString("recentColors",colorHistory.joinToString(","){Integer.toHexString(it)}).apply()
    }
    fun keepSwatch(){val c=0xff000000.toInt() or (rgb.toIntOrNull(16)?:0);preferences.edit().putString("swatches",(listOf(c)+savedSwatches().filter{it!=c}).take(18).joinToString(","){Integer.toHexString(it)}).apply();swatchRevision++}
    fun createPack(name:String,profile:GameProfile,template:Boolean)=task{
        val p=withContext(Dispatchers.IO){saveEditing();projectFiles.create(name,profile,template)}
        loadPack(p);packs=withContext(Dispatchers.IO){projectFiles.list()};rememberEditor()
    }
    fun openPack(p:PackProject)=task{withContext(Dispatchers.IO){saveEditing()};loadPack(p);rememberEditor()}
    private suspend fun loadPack(p:PackProject){
        val next=withContext(Dispatchers.IO){
            val s=projectFiles.store(p);val keys=s.list();val textures=projectFiles.textures(p)
            val first=textures.firstOrNull{it.editable&&it.path.endsWith("/stone.png")}?:textures.firstOrNull{it.editable}
            val doc=if(keys.isNotEmpty())s.open(keys.first())else if(first!=null)projectFiles.openTexture(p,first)else MaterialDocument("new_texture",MaterialDocument.Kind.BLOCK,16,16)
            Triple(s,doc,projectFiles.previewFaces(p,doc))
        }
        pack=p;store=next.first;document=next.second;previewFaceSet=next.third
        activeLayer=0;selection=emptySet();selectedPixel=null;sampler=false;channel=MaterialDocument.Channel.COLOR
        preferences.edit().putString("pack",p.id).apply();reloadAssets();attachBlock(document);changed()
    }
    fun openTemplate(texture:TemplateTexture,size:Int,group:BlockAsset?=activeBlock?.takeIf{texture.path in it.paths})=task{
        val next=withContext(Dispatchers.IO){saveEditing();val doc=projectFiles.openTexture(pack,texture,size);doc to projectFiles.previewFaces(pack,doc)}
        document=next.first;previewFaceSet=next.second
        activeLayer=0;selectedPixel=null;channel=MaterialDocument.Channel.COLOR;attachBlock(document,group);reloadAssets();changed()
    }
    fun exportPack(uri:Uri?,meta:ExportMeta=ExportMeta(),onReady:(File)->Unit={})=task(operation="export"){
        val out=File(getApplication<Application>().cacheDir,exportFileName())
        withContext(Dispatchers.IO){
            saveEditing();projectFiles.export(pack,out,isFree,meta)
            if(uri!=null)getApplication<Application>().contentResolver.openOutputStream(uri,"wt").use{dest->
                if(dest==null)throw IOException("OUTPUT_PERMISSION");out.inputStream().use{it.copyTo(dest)}
            }
        };progress=1f;message="exported";exportedForJava=pack.profile.java;exportGuidePending=true;onReady(out)
    }
    fun setMotion(next: Boolean) { if(!requireFeature(EditionPolicy.Feature.SPRING_MOTION))return;reducedMotion=next; preferences.edit().putBoolean("motion",next).apply() }
    fun completeGuide() { showOnboarding=false; preferences.edit().putBoolean("onboarding",true).putBoolean("onboarding101",true).apply() }
    fun selectChannel(next: MaterialDocument.Channel) { if(busy)return;if(!policy.allowsChannel(next)){message="free_unavailable";return}; finishValue(); document.endStroke(); channel=next; if(next==MaterialDocument.Channel.NORMAL)rgb="8080ff"; selectedPixel=null; changed() }
    fun selectLayer(index: Int) { if(!busy) { finishValue();document.endStroke();canvasStroke.reset(); activeLayer=index; selectedPixel=null; changed() } }
    fun toggleAsset(key: String) { if(!busy) selection=if(key in selection) selection-key else selection+key }
    private fun changed() { if(document.undoLimit!=undoLimit)document.setUndoLimit(undoLimit);activeLayer=activeLayer.coerceIn(0,document.layers.lastIndex); undoEnabled=document.canUndo();redoEnabled=document.canRedo();revision++ }
    private fun argb() = when(channel) {
        MaterialDocument.Channel.COLOR -> (brushAlpha.coerceIn(0,255) shl 24) or (rgb.toIntOrNull(16) ?: 0x8080ff)
        MaterialDocument.Channel.NORMAL -> 0xff000000.toInt() or (rgb.toIntOrNull(16) ?: 0x8080ff)
        else -> 0xff000000.toInt() or (value shl 16) or (value shl 8) or value
    }
    fun changeBrushRgb(next:String) {
        if(busy)return
        rgb=next.filter {it in "0123456789abcdefABCDEF"}.take(6)
        if(rgb.length==6) selectedPixel?.let { (x,y)->
            document.beginStroke(activeLayer,channel);paintMirrored(x,y);document.endStroke();rememberColor();changed()
        }
    }
    private fun paintMirrored(x:Int,y:Int){
        if(x !in 0 until document.width||y !in 0 until document.height)return
        if(tool==Tool.PENCIL)colorStrokeUsed=true
        val color=strokeColor()
        val offsets=brushFootprint
        var i=0
        while(i<offsets.size){SymmetryBrush.paint(document,x+offsets[i],y+offsets[i+1],color,mirrorX,mirrorY);i+=2}
    }
    /** Pencil = brush colour; Eraser = opaque white; Erase = fully transparent (alpha 0). */
    private fun strokeColor():Int=when(tool){
        Tool.ERASER->0xffffffff.toInt()
        Tool.ERASE->0
        else->argb()
    }
    private val strokeTrail=ArrayList<IntArray>()
    private fun pixelPerfectActive()=pixelPerfect&&brushSize==1&&!mirrorX&&!mirrorY
    fun beginStroke(x:Int,y:Int) { if(busy)return;colorStrokeUsed=false;canvasStroke.reset();strokeTrail.clear(); document.beginStroke(activeLayer,channel); paintPath(x,y) }
    fun paint(x:Int,y:Int) { if(busy)return; val before=document.revision;paintMirrored(x,y);selectedPixel=x to y;if(before!=document.revision)changed() }
    fun paintPath(x:Int,y:Int) {
        if(busy)return
        if(x !in 0 until document.width||y !in 0 until document.height){canvasStroke.reset();return}
        val before=document.revision
        for(point in canvasStroke.segment(x,y,0)){
            paintMirrored(point[0],point[1])
            if(pixelPerfectActive()){
                strokeTrail.add(point)
                if(strokeTrail.size>=3){
                    val a=strokeTrail[strokeTrail.size-3];val b=strokeTrail[strokeTrail.size-2];val c=strokeTrail[strokeTrail.size-1]
                    // Remove the elbow pixel of an L so diagonal lines stay one pixel wide.
                    if(PixelTools.isElbow(a[0],a[1],b[0],b[1],c[0],c[1])&&document.revertStrokePixel(b[0],b[1]))strokeTrail.removeAt(strokeTrail.size-2)
                }
                if(strokeTrail.size>8)strokeTrail.removeAt(0)
            }
        }
        selectedPixel=x to y
        if(before!=document.revision)changed()
    }
    fun cancelStroke(){document.cancelStroke();colorStrokeUsed=false;canvasStroke.reset();selectedPixel=null;changed()}

    fun endStroke() { strokeTrail.clear();canvasStroke.reset();paintingDocument?.endStroke();paintingDocument=null;paintingSurface=-1;strokeLayerName=null;surfaceStroke.reset();document.endStroke();if(colorStrokeUsed)rememberColor();colorStrokeUsed=false;changed() }
    fun previewStrokeBegin(x:Int,y:Int,face:Int,surface:Int):Boolean{
        if(busy)return false;if(!requireFeature(EditionPolicy.Feature.MODEL_PAINT))return false
        endStroke()
        if(sampler){selectPreviewFace(face);sample(x,(y*document.height/document.width).coerceIn(0,document.height-1));return false}
        strokeLayerName=document.layers[activeLayer].name
        previewStrokeMove(x,y,face,surface);return paintingDocument!=null
    }
    private fun selectPreviewFace(face:Int,forPainting:Boolean=false):MaterialDocument?{
        val group=activeBlock
        val doc=if(group!=null&&chooseBlock&&face in 1..6){
            val selected=blockDocuments.entries.firstOrNull{it.value===document}?.key
            val mesh=modelMesh?.takeIf{it.slots.isNotEmpty()}
            val path=if(mesh!=null)(if(mesh.overlays.getOrNull(face-1)==selected)selected else mesh.slots.getOrNull(face-1)?:return null)
                else if(group.overlays[face-1]==selected)selected else group.faces[face-1]
            blockDocuments[path]?:return null
        }else document
        if(document!==doc){
            document.endStroke();document=doc
            val named=strokeLayerName?.let{name->doc.layers.indexOfFirst{it.name==name}}?:-1
            activeLayer=if(forPainting&&named<0&&strokeLayerName!=null&&doc.layers.size<MaterialDocument.MAX_LAYERS)doc.addLayer(strokeLayerName!!)else if(named>=0)named else activeLayer.coerceAtMost(doc.layers.lastIndex)
            selectedPixel=null
        }
        return doc
    }
    fun previewStrokeMove(x:Int,y:Int,face:Int,surface:Int){
        if(busy)return;if(!requireFeature(EditionPolicy.Feature.MODEL_PAINT))return
        if(surface<0||x<0||y<0){surfaceStroke.reset();paintingSurface=-1;return}
        val target=selectPreviewFace(face,true)?:run{surfaceStroke.reset();paintingSurface=-1;return}
        if(paintingDocument!==target){paintingDocument?.endStroke();target.beginStroke(activeLayer,channel);paintingDocument=target;surfaceStroke.reset()}
        if(paintingSurface!=surface){surfaceStroke.reset();paintingSurface=surface}
        // Never join UV coordinates from two different physical faces, even if they share a texture.
        for(point in surfaceStroke.segment(x,y,surface)){
            val px=point[0].coerceIn(0,target.width-1);val py=(point[1]*target.height/target.width).coerceIn(0,target.height-1)
            target.paint(px,py,argb());selectedPixel=px to py
        }
        changed()
    }
    fun changeBrushValue(next:Int) {
        if(busy)return; value=next.coerceIn(0,255)
        selectedPixel?.let { (x,y) ->
            if(!sliderEditing) { document.beginStroke(activeLayer,channel); sliderEditing=true }
            document.paint(x,y,argb()); changed()
        }
    }
    private var sliderEditing=false
    fun finishValue() { document.finishOpacity();if(sliderEditing) { document.endStroke(); sliderEditing=false; changed() } }
    fun undo() { if(!busy) { finishValue();endStroke();document.undo();selectedPixel=null;changed() } }
    fun redo() { if(!busy) { finishValue();endStroke();document.redo();selectedPixel=null;changed() } }
    fun fill() { if(!busy) guarded { document.fill(activeLayer,channel,argb());rememberColor();changed() } }
    fun addLayer() { if(!busy) guarded { activeLayer=document.addLayer("${t("layers")} ${document.layers.size+1}"); changed() } }
    fun visibility(index:Int,next:Boolean) { if(!busy) { document.setVisible(index,next); changed() } }
    fun opacity(next:Float) { if(!busy) { document.previewOpacity(activeLayer,next); changed() } }
    fun finishOpacity(){document.finishOpacity();changed()}
    private fun guarded(block:()->Unit) { try { block() } catch(e:Exception) { fail(e) } }
    fun save() = task(operation="save") { withContext(Dispatchers.IO) { saveEditing() }; reloadAssets(); message="saved" }
    fun create(name:String,kind:MaterialDocument.Kind,size:Int) = task {
        val next=MaterialDocument(name,kind,size,size)
        withContext(Dispatchers.IO) {
            if(ProjectStore.key(kind,name) in store.list()) throw IOException("EXISTS")
            saveEditing(); store.save(next)
        }
        document=next; activeLayer=0; selectedPixel=null; reloadAssets(); changed()
    }
    fun open(key:String) = task {
        val next=withContext(Dispatchers.IO) { saveEditing();val doc=store.open(key);doc to projectFiles.previewFaces(pack,doc) }
        document=next.first;previewFaceSet=next.second
        activeLayer=0; selectedPixel=null;attachBlock(document); changed()
    }
    fun restorePrevious() = task {
        val key=ProjectStore.key(document.kind,document.name)
        val old=withContext(Dispatchers.IO) {
            val versions=store.versions(key)
            if(versions.isEmpty()) null else store.openVersion(key,versions.first())
        }
        if(old==null) message="no_history" else {
            // Preserve current work before replacing the editor with a historical snapshot.
            withContext(Dispatchers.IO) { saveEditing() }
            document=old;activeLayer=0;selectedPixel=null;attachBlock(document,activeBlock);changed()
        }
    }
    fun importPng(uri:Uri) = task {
        val pixels=withContext(Dispatchers.IO) {
            val resolver=getApplication<Application>().contentResolver
            val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
            resolver.openInputStream(uri).use { BitmapFactory.decodeStream(it,null,bounds) }
            if(bounds.outWidth!=document.width || bounds.outHeight!=document.height) throw IOException("PNG_SIZE")
            val bitmap=resolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) } ?: throw IOException("PNG_SIZE")
            try { IntArray(document.width*document.height).also { bitmap.getPixels(it,0,document.width,0,0,document.width,document.height) } }
            finally { bitmap.recycle() }
        }
        activeLayer=document.addLayer("PNG"); document.replacePlane(activeLayer,MaterialDocument.Channel.COLOR,pixels); changed()
    }
    fun batchFill() = task {
        val targets=selection.toList(); if(targets.isEmpty()) return@task
        val selectedChannel=channel; val color=argb()
        withContext(Dispatchers.IO) {
            saveEditing()
            for((index,key) in targets.withIndex()) {
                currentCoroutineContext().ensureActive()
                val item=store.open(key); item.fill(0,selectedChannel,color); store.save(item)
                withContext(Dispatchers.Main) { progress=(index+1f)/targets.size }
            }
        }
        document=withContext(Dispatchers.IO) { store.open(ProjectStore.key(document.kind,document.name)) };attachBlock(document,activeBlock); reloadAssets(); changed()
    }
    fun exportBoth(uri:Uri?,javaFormat:Int,onReady:(File)->Unit = {}) = task {
        val file=File(getApplication<Application>().cacheDir,"mcts-dual-export.zip")
        withContext(Dispatchers.IO) {
            saveEditing()
            val keys=selection.ifEmpty { store.list().toSet() }.toList()
            val bedrock=File.createTempFile("bedrock-",".mcpack",getApplication<Application>().cacheDir)
            val java=File.createTempFile("java-",".zip",getApplication<Application>().cacheDir)
            try {
                PackExport.export(store,keys,PackExport.Target.BEDROCK_VV,javaFormat,bedrock.outputStream(),null)
                withContext(Dispatchers.Main) { progress=.45f }
                PackExport.export(store,keys,PackExport.Target.JAVA_LABPBR,javaFormat,java.outputStream(),null)
                withContext(Dispatchers.Main) { progress=.9f }
                ZipOutputStream(file.outputStream()).use { zip ->
                    listOf("pack.mcpack" to bedrock,"pack-java.zip" to java).forEach { (name,input) ->
                        zip.putNextEntry(ZipEntry(name)); input.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
                    }
                }
                if(uri!=null) getApplication<Application>().contentResolver.openOutputStream(uri,"wt").use { out ->
                    if(out==null) throw IOException("OUTPUT_PERMISSION")
                    file.inputStream().use { it.copyTo(out) }
                }
            } finally { bedrock.delete(); java.delete() }
        }
        progress=1f; message="saved"; onReady(file)
    }
    private suspend fun reloadAssets() {
        assets=withContext(Dispatchers.IO) { store.list().map { key ->
            val doc=store.open(key); AssetItem(key,doc.name,doc.kind,"${doc.width} × ${doc.height}")
        } }
        templateTextures=withContext(Dispatchers.IO){projectFiles.textures(pack).filter{!isFree||!it.pbr}}
    }
    private fun task(celebrate:Boolean=true,operation:String="edit",block:suspend ()->Unit) {
        if(busy)return
        finishValue();document.endStroke();changed();busy=true;quietBusy=operation=="autosave";progress=0f;error=null;currentOperation=operation
        job=viewModelScope.launch {
            try { block(); if(celebrate)successPulse++ }
            catch(cancelled:CancellationException) { throw cancelled }
            catch(e:Exception) { fail(e) }
            finally { busy=false;quietBusy=false }
        }
    }
    fun importUiFont(uri:Uri)=task { val file=withContext(Dispatchers.IO){appearance.prepareFont(uri)};appearance.useFont(file) }
    fun importBackground(uri:Uri)=task { val file=withContext(Dispatchers.IO){appearance.prepareImage(uri)};appearance.useImage(file) }
    fun importVideoBackground(uri:Uri){if(!requireFeature(EditionPolicy.Feature.VIDEO_WALLPAPER))return;task {val file=withContext(Dispatchers.IO){appearance.prepareVideo(uri)};appearance.useVideo(file)}}
    fun importModelArchive(uri:Uri){if(!requireFeature(EditionPolicy.Feature.MODEL_IMPORT))return;task{
        withContext(Dispatchers.IO){projectFiles.importModels(pack,uri)}
        refreshModel()
        changed();message="models_ready"
    }}
    fun downloadOfficialModels(){if(!requireFeature(EditionPolicy.Feature.MODEL_IMPORT))return;task{
        withContext(Dispatchers.IO){OfficialDownload.fetch(pack.profile,projectFiles.models(pack))}
        refreshModel()
        changed();message="models_ready"
    }}
    private fun fail(e:Exception) {
        Log.e("MCTS","Operation failed",e)
        if(e.message?.startsWith("TEMPLATE_")==true)refreshTemplates()
        error=when {
            e.message?.startsWith("TEMPLATE_")==true -> downloadErrorKey(e)
            e is SecurityException || e.message?.contains("OUTPUT_PERMISSION")==true -> "error_permission"
            e.message?.contains("TEMPLATE_SPACE")==true||e.message?.contains("ENOSPC")==true || e.message?.contains("No space left")==true -> "error_space"
            e.message?.contains("FONT_INVALID")==true -> "error_font"
            e.message?.contains("BACKGROUND_INVALID")==true -> "error_background"
            e.message?.contains("VIDEO_INVALID")==true -> "error_video"
            e.message?.contains("MODEL_")==true -> "error_model"
            e.message?.contains("APPEARANCE_LARGE")==true -> "error_appearance_large"
            e.message?.contains("PNG_SIZE")==true -> "error_png"
            e.message?.contains("PACK_ATLAS")==true -> "error_pack_atlas"
            e.message?.contains("LAYOUT_INVALID")==true -> "error_layout"
            e.message?.contains("PACK_MAP")==true -> "error_pack_invalid"
            e.message?.contains("PACK_EDITION")==true -> "error_pack_edition"
            e.message?.contains("PACK_EMPTY")==true -> "error_pack_empty"
            e.message?.contains("PACK_LARGE")==true -> "error_pack_large"
            e.message?.contains("PACK_INVALID")==true -> "error_pack_invalid"
            e.message?.contains("NO_TEMPLATE_PATH")==true -> "error_no_template"
            e.message?.contains("EXISTS")==true -> "error_exists"
            e.message?.contains("LIMIT")==true || e.message?.contains("TOO_LARGE")==true -> "error_limit"
            e is IllegalArgumentException -> "error_input"
            else -> "error_io"
        }
        lastErrorCode=currentOperation.uppercase()+"_"+error!!.removePrefix("error_").uppercase()
        // Error codes only; diagnostic text never includes exception messages or paths.
    }

    // ───────────────────────── 1.0.1: tools, layout, input, accessibility ─────────────────────────
    enum class Tool { PENCIL, ERASER, ERASE, FILL, PICKER, MOVE }
    enum class CanvasAlign { LEFT, CENTER, RIGHT }
    enum class DeviceLayout { AUTO, PHONE, TABLET }
    enum class PanelWidth { NARROW, STANDARD, WIDE }
    enum class PreviewSize { HIDDEN, NORMAL, LARGE }
    enum class PointerAction { PICKER, ERASE, NONE }
    private fun <T:Enum<T>> pref(key:String,default:T,values:Array<T>):T=runCatching{val n=preferences.getString(key,default.name);values.first{it.name==n}}.getOrDefault(default)
    private fun put(key:String,value:Any){preferences.edit().apply{when(value){is Boolean->putBoolean(key,value);is Int->putInt(key,value);is Float->putFloat(key,value);is Enum<*>->putString(key,value.name);else->putString(key,value.toString())}}.apply()}

    var tool by mutableStateOf(Tool.PENCIL); private set
    fun selectTool(next:Tool){
        if(busy)return
        finishValue();document.endStroke()
        tool=next;sampler=next==Tool.PICKER;panCanvas=next==Tool.MOVE
    }
    var brushSize by mutableIntStateOf(preferences.getInt("brushSize",1).coerceIn(1,PixelTools.MAX_BRUSH)); private set
    var roundBrush by mutableStateOf(preferences.getBoolean("roundBrush",false)); private set
    private var footprintKey=0
    private var footprintCache=IntArray(2)
    internal val brushFootprint:IntArray get(){val key=brushSize*2+(if(roundBrush)1 else 0);if(key!=footprintKey){footprintKey=key;footprintCache=PixelTools.brushOffsets(brushSize,roundBrush)};return footprintCache}
    fun changeBrushSize(next:Int){brushSize=next.coerceIn(1,PixelTools.MAX_BRUSH);put("brushSize",brushSize)}
    fun changeRoundBrush(next:Boolean){roundBrush=next;put("roundBrush",next)}
    var brushAlpha by mutableIntStateOf(preferences.getInt("brushAlpha",255).coerceIn(0,255)); private set
    fun changeBrushAlpha(next:Int){brushAlpha=next.coerceIn(0,255);put("brushAlpha",brushAlpha)}
    var secondaryRgb by mutableStateOf(preferences.getString("rgb2","ffffff")!!.takeIf{it.matches(Regex("[0-9a-fA-F]{6}"))}?:"ffffff"); private set
    fun swapColors(){if(busy)return;val a=rgb;chooseColor(0xff000000.toInt() or (secondaryRgb.toIntOrNull(16)?:0xffffff));secondaryRgb=a;put("rgb2",a)}
    var fillContiguous by mutableStateOf(preferences.getBoolean("fillContiguous",true)); private set
    var fillTolerance by mutableIntStateOf(preferences.getInt("fillTolerance",0).coerceIn(0,100)); private set
    fun changeFill(contiguous:Boolean=fillContiguous,tolerance:Int=fillTolerance){fillContiguous=contiguous;fillTolerance=tolerance.coerceIn(0,100);put("fillContiguous",fillContiguous);put("fillTolerance",fillTolerance)}
    var pixelPerfect by mutableStateOf(preferences.getBoolean("pixelPerfect",false)); private set
    fun changePixelPerfect(next:Boolean){pixelPerfect=next;put("pixelPerfect",next)}
    /** Fill tool: one undo step; uses the active layer's own pixels to find the region. */
    fun fillAt(x:Int,y:Int){
        if(busy||x !in 0 until document.width||y !in 0 until document.height)return
        guarded{
            val mask=PixelTools.fillMask(document.layerPixels(activeLayer,channel),document.width,document.height,x,y,fillTolerance,fillContiguous)
            val color=argb()
            document.beginStroke(activeLayer,channel)
            for(i in mask.indices)if(mask[i])document.paint(i%document.width,i/document.width,color)
            document.endStroke();selectedPixel=x to y;rememberColor();changed()
        }
    }
    /** Single tap on the canvas: what it does depends on the active tool. */
    fun tapCanvas(x:Int,y:Int){
        when(tool){
            Tool.FILL->fillAt(x,y)
            Tool.PICKER->{sample(x,y);tool=Tool.PENCIL}
            Tool.MOVE->Unit
            else->{beginStroke(x,y);endStroke()}
        }
    }
    /** Temporary tool for one gesture (mouse right button, stylus side button). Always paired with [endTemporaryTool]. */
    private var savedTool:Tool?=null
    fun beginTemporaryTool(temporary:Tool){if(savedTool==null)savedTool=tool;tool=temporary}
    fun endTemporaryTool(){savedTool?.let{tool=it;sampler=it==Tool.PICKER;panCanvas=it==Tool.MOVE};savedTool=null}

    var canvasAlign by mutableStateOf(pref("canvasAlign",CanvasAlign.CENTER,CanvasAlign.entries.toTypedArray())); private set
    fun changeCanvasAlign(next:CanvasAlign){canvasAlign=next;put("canvasAlign",next)}
    var deviceLayout by mutableStateOf(pref("deviceLayout",DeviceLayout.AUTO,DeviceLayout.entries.toTypedArray())); private set
    fun changeDeviceLayout(next:DeviceLayout){deviceLayout=next;put("deviceLayout",next)}
    var sidebarWidth by mutableStateOf(pref("sidebarWidth",PanelWidth.STANDARD,PanelWidth.entries.toTypedArray())); private set
    fun changeSidebarWidth(next:PanelWidth){sidebarWidth=next;put("sidebarWidth",next)}
    var previewSize by mutableStateOf(pref("previewSize",PreviewSize.NORMAL,PreviewSize.entries.toTypedArray())); private set
    fun changePreviewSize(next:PreviewSize){previewSize=next;put("previewSize",next)}
    var compactToolbar by mutableStateOf(preferences.getBoolean("compactToolbar",false)); private set
    fun changeCompactToolbar(next:Boolean){compactToolbar=next;put("compactToolbar",next)}
    var uiScale by mutableFloatStateOf(preferences.getFloat("uiScale",1f).let{v->listOf(.9f,1f,1.15f).minByOrNull{kotlin.math.abs(it-v)}!!}); private set
    fun changeUiScale(next:Float){uiScale=next;put("uiScale",next)}
    var labelMode by mutableStateOf(preferences.getBoolean("labelMode",false)); private set
    fun toggleLabelMode(){labelMode=!labelMode;put("labelMode",labelMode)}
    fun resetLayout(){
        changeCanvasAlign(CanvasAlign.CENTER);changeDeviceLayout(DeviceLayout.AUTO);changeSidebarWidth(PanelWidth.STANDARD);changePreviewSize(PreviewSize.NORMAL)
        changeCompactToolbar(false);changeUiScale(1f);changeHandMode(HandMode.AUTO);if(labelMode)toggleLabelMode();message="layout_reset_done"
    }

    var autosave by mutableStateOf(preferences.getBoolean("autosave",true)); private set
    var autosaveMinutes by mutableIntStateOf(preferences.getInt("autosaveMinutes",2).let{if(it in listOf(1,2,5,10))it else 2}); private set
    fun changeAutosave(enabled:Boolean=autosave,minutes:Int=autosaveMinutes){autosave=enabled;autosaveMinutes=minutes;put("autosave",enabled);put("autosaveMinutes",minutes)}
    private var savedRevision=-1L
    /** Quiet save: no message, no celebration; skipped when nothing changed since the last save. */
    fun autosaveNow(){if(busy||document.isStroking||document.revision==savedRevision)return;val target=document.revision;task(celebrate=false,operation="autosave"){withContext(Dispatchers.IO){saveEditing()};savedRevision=target}}
    fun goHome(){if(busy)return;task(celebrate=false,operation="save"){withContext(Dispatchers.IO){saveEditing()};savedRevision=document.revision;showStart=true}}
    var undoLimit by mutableIntStateOf(preferences.getInt("undoLimit",0).let{if(it in listOf(0,50,100,200))it else 0}); private set
    fun changeUndoLimit(next:Int){undoLimit=next;put("undoLimit",next);document.setUndoLimit(next);changed()}
    var defaultResolution by mutableIntStateOf(preferences.getInt("defaultResolution",0).let{if(it in listOf(0,16,32,64,128,256,512))it else 0}); private set
    fun changeDefaultResolution(next:Int){defaultResolution=next;put("defaultResolution",next)}
    var longPressPicker by mutableStateOf(preferences.getBoolean("longPressPicker",true)); private set
    fun changeLongPressPicker(next:Boolean){longPressPicker=next;put("longPressPicker",next)}
    var meteredConfirm by mutableStateOf(preferences.getBoolean("meteredConfirm",true)); private set
    fun changeMeteredConfirm(next:Boolean){meteredConfirm=next;put("meteredConfirm",next)}

    // Keyboard, mouse, stylus
    var keymap by mutableStateOf(Keymap.load(preferences.getString("keymap",null))); private set
    fun bindKey(action:KeyAction,chord:KeyChord){keymap=keymap.bind(action,chord);preferences.edit().putString("keymap",keymap.save()).apply()}
    fun resetInput(){keymap=Keymap.defaults();preferences.edit().remove("keymap").apply();changeMouseRight(PointerAction.PICKER);changeStylusButton(PointerAction.ERASE);changeStylusOnly(false);message="input_reset_done"}
    var mouseRight by mutableStateOf(pref("mouseRight",PointerAction.PICKER,PointerAction.entries.toTypedArray())); private set
    fun changeMouseRight(next:PointerAction){mouseRight=next;put("mouseRight",next)}
    var stylusButton by mutableStateOf(pref("stylusButton",PointerAction.ERASE,PointerAction.entries.toTypedArray())); private set
    fun changeStylusButton(next:PointerAction){stylusButton=next;put("stylusButton",next)}
    var stylusOnly by mutableStateOf(preferences.getBoolean("stylusOnly",false)); private set
    fun changeStylusOnly(next:Boolean){stylusOnly=next;put("stylusOnly",next)}
    var spaceHeld by mutableStateOf(false)

    // Accessibility
    var largeUi by mutableStateOf(preferences.getBoolean("largeUi",false)); private set
    fun changeLargeUi(next:Boolean){largeUi=next;put("largeUi",next)}
    var strongContrast by mutableStateOf(preferences.getBoolean("strongContrast",false)); private set
    fun changeStrongContrast(next:Boolean){strongContrast=next;put("strongContrast",next)}
    var colorNames by mutableStateOf(preferences.getBoolean("colorNames",false)); private set
    fun changeColorNames(next:Boolean){colorNames=next;put("colorNames",next)}
    var readPixel by mutableStateOf(preferences.getBoolean("readPixel",false)); private set
    fun changeReadPixel(next:Boolean){readPixel=next;put("readPixel",next)}
    var haptics by mutableStateOf(preferences.getBoolean("haptics",true)); private set
    fun changeHaptics(next:Boolean){haptics=next;put("haptics",next)}
    fun changeReducedMotion(next:Boolean){reducedMotion=next;preferences.edit().putBoolean("motion",next).apply()}

    // ---------------- 1.0.2: liquid glass ----------------
    /** Off by default. Windows: always available (Skia runtime shader); a GPU/driver failure falls back to the 1.0.1 surfaces. */
    var liquidGlass by mutableStateOf(preferences.getBoolean("liquidGlass",false)); private set
    val glassActive get()=liquidGlass&&LiquidGlass.supported
    fun changeLiquidGlass(next:Boolean){if(next&&!LiquidGlass.supported){message="glass_unsupported";return};liquidGlass=next;put("liquidGlass",next)}
    // 1.0.2.1: glass on small UI (global switch), tuning for big / small UI, per-element switches.
    var glassSmall by mutableStateOf(preferences.getBoolean("glassSmall",true)); private set
    fun changeGlassSmall(next:Boolean){glassSmall=next;put("glassSmall",next)}
    private fun loadTuning(key:String,d:GlassTuning)=GlassTuning(preferences.getFloat("$key.blur",d.blurDp),preferences.getFloat("$key.opacity",d.opacity),
        preferences.getFloat("$key.refraction",d.refraction),preferences.getFloat("$key.highlight",d.highlight))
    private fun saveTuning(key:String,t:GlassTuning){preferences.edit().putFloat("$key.blur",t.blurDp).putFloat("$key.opacity",t.opacity)
        .putFloat("$key.refraction",t.refraction).putFloat("$key.highlight",t.highlight).apply()}
    internal var glassBigTuning by mutableStateOf(loadTuning("glassBig",GlassTuning.BIG)); private set
    internal var glassSmallTuning by mutableStateOf(loadTuning("glassSmallTuning",GlassTuning.SMALL)); private set
    internal fun changeGlassTuning(big:Boolean,t:GlassTuning){
        val v=t.copy(blurDp=t.blurDp.coerceIn(0f,GlassTuning.MAX_BLUR),opacity=t.opacity.coerceIn(0f,2f),refraction=t.refraction.coerceIn(0f,2f),highlight=t.highlight.coerceIn(0f,2f))
        if(big){glassBigTuning=v;saveTuning("glassBig",v)}else{glassSmallTuning=v;saveTuning("glassSmallTuning",v)}
    }
    fun resetGlassTuning(){changeGlassTuning(true,GlassTuning.BIG);changeGlassTuning(false,GlassTuning.SMALL)}
    var glassOverrides by mutableStateOf(loadOverrides()); private set
    private fun loadOverrides():Map<String,Boolean> = runCatching{
        val o=org.json.JSONObject(preferences.getString("glassOverrides","{}")?:"{}")
        o.keys().asSequence().associateWith{o.optBoolean(it)}
    }.getOrDefault(emptyMap())
    fun toggleGlassElement(id:String,on:Boolean){
        glassOverrides=glassOverrides+(id to on)
        preferences.edit().putString("glassOverrides",org.json.JSONObject(glassOverrides).toString()).apply()
    }
    fun clearGlassOverrides(){glassOverrides=emptyMap();preferences.edit().remove("glassOverrides").apply();message="glass_pick_cleared"}
    /** Layout editor: tap elements to switch their glass. */
    var glassPicking by mutableStateOf(false)
    fun importWallpaper(uri:Uri)=task(celebrate=false){val file=withContext(Dispatchers.IO){appearance.prepareImage(uri)};appearance.useWallpaper(file)}
    fun clearWallpaper(){appearance.clearWallpaper()}

    // ---------------- 1.0.2: custom UI ----------------
    internal val layouts=LayoutStore(File(application.filesDir,"layouts.json"))
    var layoutRevision by mutableIntStateOf(0); private set
    /** Working copy while the layout editor is open (null = not editing). */
    internal var layoutEditing by mutableStateOf<LayoutSpec?>(null); private set
    var layoutEditLandscape by mutableStateOf(true); private set
    private var layoutArea=Pair(1280f,800f)
    internal fun customLayout(landscape:Boolean):LayoutSpec?{layoutRevision;return layouts.active(landscape)}
    fun startLayoutEdit(landscape:Boolean,widthDp:Float,heightDp:Float){
        if(showStart&&packs.isNotEmpty())continueEditing()
        layoutArea=widthDp to heightDp;layoutEditLandscape=landscape
        layoutEditing=layouts.active(landscape)?:seedLayout(layouts.uniqueName(landscape,p("layout_mine")),widthDp,heightDp)
    }
    internal fun updateLayoutEdit(spec:LayoutSpec){if(layoutEditing!=null)layoutEditing=spec}
    fun reseedLayoutEdit(){layoutEditing?.let{layoutEditing=seedLayout(it.name,layoutArea.first,layoutArea.second)}}
    fun finishLayoutEdit(){layoutEditing?.let{runCatching{layouts.put(layoutEditLandscape,it)}.onFailure{message="layout_save_failed"}};layoutEditing=null;glassPicking=false;layoutRevision++}
    fun cancelLayoutEdit(){layoutEditing=null;glassPicking=false}
    /** Next "edit" starts from a fresh copy of the 1.0.1 arrangement. */
    fun newLayoutPreset(landscape:Boolean){layouts.select(landscape,null);layoutRevision++}
    fun selectLayout(landscape:Boolean,name:String?){layouts.select(landscape,name);layoutRevision++}
    fun deleteLayout(landscape:Boolean,name:String){layouts.delete(landscape,name);layoutRevision++}
    fun renameLayout(landscape:Boolean,old:String,next:String)=layouts.rename(landscape,old,next).also{if(it)layoutRevision++ else message="layout_name_taken"}
    fun exportLayout(uri:Uri,landscape:Boolean)=task(celebrate=false){
        val spec=layouts.active(landscape)?:throw IOException("LAYOUT_INVALID")
        withContext(Dispatchers.IO){getApplication<Application>().contentResolver.openOutputStream(uri)?.use{it.write(LayoutStore.export(spec,landscape))}?:throw IOException("LAYOUT_INVALID")}
        message="layout_exported"
    }
    fun importLayout(uri:Uri)=task(celebrate=false){
        val bytes=withContext(Dispatchers.IO){getApplication<Application>().contentResolver.openInputStream(uri)?.use{input->
            val out=java.io.ByteArrayOutputStream();val buf=ByteArray(8192)
            while(true){val n=input.read(buf);if(n<0)break;out.write(buf,0,n);if(out.size()>256*1024)throw IOException("LAYOUT_INVALID")};out.toByteArray()}?:throw IOException("LAYOUT_INVALID")}
        val (spec,landscape)=LayoutStore.import(bytes)
        val name=if(spec.name in layouts.names(landscape))layouts.uniqueName(landscape,spec.name) else spec.name
        layouts.put(landscape,spec.copy(name=name));layoutRevision++
        message=if(landscape)"layout_imported_landscape" else "layout_imported_portrait"
    }
    /** Windows feedback: capture the window a moment after the dialog closed. */
    fun feedbackScreenshot(){viewModelScope.launch{delay(450);val file=withContext(Dispatchers.IO){runCatching{WindowsIntegration.feedbackScreenshot(diagnostics())}.getOrNull()};message=if(file!=null)"win_screenshot_saved" else "screenshot_failed"}}
    fun toggleTheme(dark:Boolean){changeThemeMode(if(dark)ThemeMode.LIGHT else ThemeMode.DARK)}
    fun replayGuide(){showOnboarding=true}

    // Import / export extras
    fun importReplace(uri:Uri)=task {
        val pixels=withContext(Dispatchers.IO) {
            val resolver=getApplication<Application>().contentResolver
            val bitmap=resolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) } ?: throw IOException("PNG_SIZE")
            try {
                val w=bitmap.width;val h=bitmap.height
                // Same aspect ratio required; any size is resampled (nearest) to the editing size.
                if(w*document.height!=h*document.width)throw IOException("PNG_SIZE")
                val source=IntArray(w*h);bitmap.getPixels(source,0,w,0,0,w,h)
                IntArray(document.width*document.height){i->source[(i/document.width*h/document.height)*w+(i%document.width*w/document.width)]}
            } finally { bitmap.recycle() }
        }
        document.replacePlane(activeLayer,MaterialDocument.Channel.COLOR,pixels);message="texture_replaced";changed()
    }
    fun importPackArchive(uri:Uri,name:String,profile:GameProfile)=task(operation="pack_import"){
        val created=withContext(Dispatchers.IO){
            val staging=File(getApplication<Application>().cacheDir,"pack-import.zip")
            try{
                getApplication<Application>().contentResolver.openInputStream(uri)?.use{input->staging.outputStream().use{out->
                    val buffer=ByteArray(64*1024);var total=0L
                    while(true){val n=input.read(buffer);if(n<0)break;total+=n;if(total>PackImport.MAX_TOTAL)throw IOException("PACK_LARGE");out.write(buffer,0,n)}
                }}?:throw IOException("PACK_INVALID")
                saveEditing()
                projectFiles.importPack(staging,name,profile)
            }finally{staging.delete()}
        }
        loadPack(created.first);packs=withContext(Dispatchers.IO){projectFiles.list()};rememberEditor()
        message="pack_imported"
    }
    var exportCheck by mutableStateOf<ExportCheck?>(null); private set
    fun refreshExportCheck()=task(celebrate=false,operation="export_check"){
        exportCheck=null
        exportCheck=withContext(Dispatchers.IO){saveEditing();projectFiles.exportCheck(pack)}
    }
    fun exportFileName()=pack.name.replace(Regex("[\\\\/:*?\"<>|]"),"_").trim().ifEmpty{"MCTS_Project"}.take(60)+if(pack.profile.java)".zip" else ".mcpack"
    fun currentTexturePng():ByteArray=Png.rgba(document.width,document.height,document.composite(MaterialDocument.Channel.COLOR))
    fun exportTexture(uri:Uri)=task(operation="export"){
        val bytes=currentTexturePng()
        withContext(Dispatchers.IO){getApplication<Application>().contentResolver.openOutputStream(uri,"wt").use{out->if(out==null)throw IOException("OUTPUT_PERMISSION");out.write(bytes)}}
        message="texture_exported"
    }
    /** Optional custom pack icon (any square-ish PNG/JPEG, scaled to 128×128 nearest). */
    fun loadIcon(uri:Uri,onReady:(ByteArray)->Unit)=task(celebrate=false){
        val bytes=withContext(Dispatchers.IO){
            val bitmap=getApplication<Application>().contentResolver.openInputStream(uri).use{BitmapFactory.decodeStream(it)}?:throw IOException("PNG_SIZE")
            try{val w=bitmap.width;val h=bitmap.height;val src=IntArray(w*h);bitmap.getPixels(src,0,w,0,0,w,h);Png.rgba(128,128,IntArray(128*128){i->src[(i/128*h/128)*w+(i%128*w/128)]})}finally{bitmap.recycle()}
        }
        onReady(bytes)
    }
    fun iconFromCurrentTexture():ByteArray{
        val n=128;val px=document.composite(MaterialDocument.Channel.COLOR)
        return Png.rgba(n,n,IntArray(n*n){i->px[(i/n*document.height/n)*document.width+(i%n*document.width/n)]})
    }
    fun resetCurrentTexture()=task(operation="reset_texture"){
        val fresh=withContext(Dispatchers.IO){saveEditing();projectFiles.resetTexture(pack,document)}
        document=fresh;activeLayer=0;selectedPixel=null;attachBlock(document,activeBlock);reloadAssets();message="texture_reset";changed()
    }
    var projectInfo by mutableStateOf<ProjectInfo?>(null); private set
    fun refreshProjectInfo()=task(celebrate=false,operation="project_info"){projectInfo=null;projectInfo=withContext(Dispatchers.IO){saveEditing();projectFiles.info(pack)}}
    /** Template texture tap: open directly at the default editing size when it applies, otherwise ask. */
    /** The template texture the current document was opened from (null for blank/legacy documents). */
    fun currentTemplateTexture():TemplateTexture?{val path=projectFiles.paths(pack).getProperty(ProjectStore.key(document.kind,document.name))?:return null;return templateTextures.firstOrNull{it.path==path}}
    fun openTemplateDefault(texture:TemplateTexture):Boolean{
        val size=defaultResolution
        if(size==0||size !in texture.sizes())return false
        openTemplate(texture,size);return true
    }
    private var neutralSize=0
    private var neutralNormal=IntArray(0)
    private var neutralHeight=ByteArray(0)
    private var neutralMers=IntArray(0)
    fun preview():PreviewFrame {
        val size=document.width;val group=activeBlock.takeIf{chooseBlock}
        if(neutralSize!=size){neutralSize=size;neutralNormal=IntArray(size*size){0xff8080ff.toInt()};neutralHeight=ByteArray(size*size);neutralMers=IntArray(size*size){0xff0000ff.toInt()}}
        fun square(doc:MaterialDocument,pixels:IntArray)=IntArray(size*size){i->pixels[(i/size*doc.height/size).coerceAtMost(doc.height-1)*doc.width+(i%size*doc.width/size).coerceAtMost(doc.width-1)]}
        fun planes(doc:MaterialDocument):PreviewPlanes{
            previewPlanes[doc]?.takeIf{it.revision==doc.revision&&it.size==size}?.let{return it}
            val c=square(doc,doc.composite(MaterialDocument.Channel.COLOR))
            val n=if(isFree)neutralNormal else square(doc,doc.composite(MaterialDocument.Channel.NORMAL))
            val h=if(isFree)neutralHeight else square(doc,doc.composite(MaterialDocument.Channel.HEIGHT)).let{p->ByteArray(p.size){p[it].toByte()}}
            val m=if(isFree)neutralMers else{
                val metal=square(doc,doc.composite(MaterialDocument.Channel.METALNESS));val emission=square(doc,doc.composite(MaterialDocument.Channel.EMISSIVE));val rough=square(doc,doc.composite(MaterialDocument.Channel.ROUGHNESS));val sss=square(doc,doc.composite(MaterialDocument.Channel.SUBSURFACE))
                for(i in metal.indices)metal[i]=((sss[i]and 255)shl 24)or((metal[i]and 255)shl 16)or((emission[i]and 255)shl 8)or(rough[i]and 255)
                metal
            }
            return PreviewPlanes(doc.revision,size,c,n,h,m).also{previewPlanes[doc]=it}
        }
        val colors=Array(6){IntArray(0)};val normals=Array(6){IntArray(0)};val heights=Array(6){ByteArray(0)};val mers=Array(6){IntArray(0)}
        // 1.0.2.1: with an official model, slot k shows the k-th texture the model uses (door top and bottom, grass side…);
        // without one, the six slots are the block's six directions as before.
        val mesh=modelMesh.takeIf{chooseBlock&&it!=null&&it.slots.isNotEmpty()}
        for(face in 0..5){
            val slotPath=mesh?.slots?.getOrNull(face)
            val doc=if(mesh!=null)(slotPath?.let{blockDocuments[it]}?:document) else group?.faces?.get(face)?.let{blockDocuments[it]}?:document
            val data=planes(doc)
            val tinted=if(mesh!=null)mesh.tints[face] else group?.tints?.get(face)==true
            val overlayPath=if(mesh!=null)mesh.overlays.getOrNull(face) else group?.overlays?.get(face)
            val c=if(tinted||overlayPath!=null)data.color.copyOf()else data.color
            if(tinted){
                val key=(group?.id?:"")+(slotPath?:"")
                val tint=if(key.contains("leaves")||key.contains("vine"))0x77ab2f else 0x91bd59
                for(i in c.indices){val p=c[i];c[i]=(p and 0xff000000.toInt())or(((p ushr 16 and 255)*(tint ushr 16 and 255)/255)shl 16)or(((p ushr 8 and 255)*(tint ushr 8 and 255)/255)shl 8)or((p and 255)*(tint and 255)/255)}
            }
            val overlay=overlayPath?.let{blockDocuments[it]}
            if(overlay!=null){val pixels=planes(overlay).color;for(i in c.indices){
                val above=pixels[i];val alpha=above ushr 24;val below=c[i];val tint=0x91bd59
                fun blend(shift:Int)=(((above ushr shift and 255)*(tint ushr shift and 255)/255)*alpha+(below ushr shift and 255)*(255-alpha))/255
                c[i]=0xff000000.toInt()or(blend(16)shl 16)or(blend(8)shl 8)or blend(0)
            }}
            colors[face]=c
            normals[face]=data.normal;heights[face]=data.height;mers[face]=data.mers
        }
        val shape=if(group!=null)"minecraft:"+group.id else when(document.kind){MaterialDocument.Kind.BLOCK->"minecraft:"+document.name.substringAfterLast('/');MaterialDocument.Kind.ITEM->"item:"+document.name;MaterialDocument.Kind.UI->"ui:"+document.name;MaterialDocument.Kind.PARTICLE->"particle:"+document.name
            // Java 1.14 and older drew chests upside down (their textures were flipped in 1.15).
            else->"entity:"+entityShape()+if(pack.profile.java&&pack.profile.format<5)"#legacy" else ""}
        return PreviewFrame(colors,normals,heights,mers,size,shape)
    }
    /** 1.0.2.2: "chest/normal" (from the texture's path) instead of "normal", so chests, shulker boxes, beds and signs get their model. */
    private val entityShapes=HashMap<String,String>()
    private fun entityShape():String=entityShapes.getOrPut(pack.id+"|"+document.kind+"|"+document.name){
        runCatching{projectFiles.paths(pack).getProperty(ProjectStore.key(document.kind,document.name))}.getOrNull()
            ?.substringAfter("textures/entity/","")?.removeSuffix(".png")?.ifBlank{null}?:document.name
    }

    // Runs last: every property above (undoLimit, tool, …) is initialised before the first task()/changed().
    init {
        document.fill(0,MaterialDocument.Channel.COLOR,0xffbba88c.toInt()); document.clearHistory()
        task(celebrate=false) {
            val keys=store.list()
            val loaded=withContext(Dispatchers.IO) { if(keys.isEmpty()) { saveEditing(); document } else store.open(keys.first()) }
            document=loaded;previewFaceSet=withContext(Dispatchers.IO){projectFiles.previewFaces(pack,loaded)}
            reloadAssets();attachBlock(document); changed()
        }
    }
}
