package com.mcts.studio

import org.json.JSONArray
import org.json.JSONObject

/**
 * 1.0.2.2 game fonts that can be fetched automatically: official files (Minecraft) or open-licence fonts from the games'
 * own repositories. Every file is pinned by size and hash; nothing is downloaded from third-party font sites.
 */
internal object GameFonts {
    /** Keys shown under Settings → Font → Game fonts, in order. */
    val keys = listOf("minecraft_java", "openttd", "wesnoth")

    private fun row(size: Long, hashKey: String, hash: String, vararg urls: String) =
        JSONObject().put("size_bytes", size).put(hashKey, hash).put("url", urls[0]).put("urls", JSONArray(urls.toList()))
    private fun asset(size: Long, sha1: String) = row(size, "source_sha1", sha1,
        "https://resources.download.minecraft.net/${sha1.take(2)}/$sha1",
        "https://bmclapi2.bangbang93.com/assets/${sha1.take(2)}/$sha1")

    /**
     * Minecraft's real unifont. Since 1.20 the client.jar only carries an empty include/unifont.json; the launcher downloads
     * the real one and unifont.zip from the asset index (these are the 26.3 objects, SHA-1 = object name).
     */
    val minecraftAssets: Map<String, JSONObject> = linkedMapOf(
        "assets/minecraft/font/include/unifont.json" to asset(3993, "402ded0eebd448033ef415e861a17513075f80e7"),
        "assets/minecraft/font/unifont.zip" to asset(1559654, "ccd5ac4767ce0a9c71d1dd62f2dc25449789b5dd"),
    )

    /** Open-licence fonts shipped by open-source games. */
    val open: Map<String, JSONObject> = linkedMapOf(
        // OpenTTD 14+: OpenTTD Sans (SIL OFL 1.1), from OpenTTD's own release.
        "openttd" to row(162144, "source_sha256", "6985166015817f17e21e304c4b385eb8c2a8e02dc3f298868b17b0bb8ed6c430",
            "https://github.com/OpenTTD/OpenTTD-TTF/releases/download/0.9/OpenTTD-Sans.ttf"),
        // The Battle for Wesnoth 1.18: title font Oldania ADF Std Bold (GPL 2 with font exception), from the 1.18.5 tag.
        "wesnoth" to row(41608, "source_sha256", "391347432ee995482148c0e42f0c192b55b829d1cc35ebd4d93a55bba7a5d5d2",
            "https://raw.githubusercontent.com/wesnoth/wesnoth/1.18.5/fonts/OldaniaADFStd-Bold.otf"),
    )
}
