# MCTS Free 1.0.2.2-Release-Fr

Built on 1.0.2.1-Release-Fr. versionCode 31022, versionName `1.0.2.2-Release` + `-Fr`. Same package name and the same
CI signing key as the public 1.0.2.1, so 1.0.2.1 upgrades in place. Windows: installer version 1.0.22 (upgrades 1.0.21).

## Game fonts: one tap, downloaded automatically
- Settings → Font → Game fonts now has **Download and use** for every entry. Each file is pinned by size and hash.
- **Minecraft: Java Edition** — Chinese (and the other non-Latin scripts) now use the game's own dot-matrix glyphs.
  - Cause of the old bug: since 1.20 the client.jar only carries an *empty* `font/include/unifont.json`; the launcher
    downloads the real one and `font/unifont.zip` from the asset index. The font was built from the jar alone, so it only had
    the Latin bitmap glyphs and Chinese fell back to the system font.
  - Fix: the two asset objects of 26.3 are downloaded too (Mojang's resources server, BMCLAPI as mirror, SHA-1 checked) and
    passed to `MinecraftFont.build(jar, extra, …)`.
- **OpenTTD** — OpenTTD Sans, the UI font of OpenTTD 14+ (SIL OFL 1.1), from OpenTTD's own GitHub release 0.9.
- **The Battle for Wesnoth** — Oldania ADF Std Bold, Wesnoth 1.18's title font (GPL 2 with font exception), from the
  game's own repository at tag 1.18.5.
- Genshin Impact, Terraria and GTA 6 were removed: their fonts are commercial (or do not exist yet) and have no official
  download. A previously imported font keeps working; any font can still be imported under "Import font".

## Fixes
- **1.0 – 1.5.2 templates** could not be downloaded ("download failed verification"). The old client.jar contains
  `environment/light_normal.png`, which matched the PBR name pattern, so every texture-pack template was rejected.
  It is now on the list of vanilla colour textures.
- **Windows: importing a wallpaper or a background image always failed** ("cannot read this image"): saving the scaled image
  used the 512 px texture encoder. It now uses the template encoder (up to 16 M pixels).
- Entity textures (chests, shulker boxes …) now pass their folder to the preview explicitly ("entity:chest/normal").
  The preview already resolved them correctly; this only makes the face set consistent.

## Verification
- The capture harness (Compose UI test, real UI on Linux) downloaded the 1.0 – 1.5.2 templates, opened a 1.2.5 project,
  imported a wallpaper on the desktop build and rendered chest / shulker / Christmas-chest previews.
- The font change is checked by the same harness: the generated Minecraft font is applied and Chinese text is captured.
