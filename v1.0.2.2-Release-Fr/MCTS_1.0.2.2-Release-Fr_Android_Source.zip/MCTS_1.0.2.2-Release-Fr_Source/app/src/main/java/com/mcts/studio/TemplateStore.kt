package com.mcts.studio

import android.content.Context
import com.mcts.core.LegacyPack
import com.mcts.core.TemplateArchive
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.concurrent.CancellationException

/**
 * Downloaded templates are local files, never APK assets.
 * Each source is pinned by one of: source_sha256 (verified by us), source_sha1 (Mojang's own object hash,
 * also part of the piston-data URL), or an immutable commit-addressed GitHub URL (archive validated on build).
 */
class TemplateStore @JvmOverloads constructor(context:Context,private val connect:(URL)->HttpURLConnection={it.openConnection() as HttpURLConnection},private val freeSpace:()->Long={context.filesDir.usableSpace}) {
    private val root=File(context.filesDir,"templates-v1").apply{mkdirs()}
    private val rows=context.assets.open("templates/sources.json").bufferedReader().use{JSONArray(it.readText())}.let{a->(0 until a.length()).associate{a.getJSONObject(it).let{it.getString("profile") to it}}}
    @Volatile private var cancelled=false
    @Volatile private var connection:HttpURLConnection?=null
    fun available(profile:GameProfile):Boolean {
        val file=archive(profile);val marker=File(root,"${profile.id}.ready.json")
        return file.isFile&&runCatching{val m=JSONObject(marker.readText());m.getLong("size")==file.length()&&m.getInt("schema")==1}.getOrDefault(false)
    }
    fun archive(profile:GameProfile)=File(root,"${profile.id}.zip")
    /** Official block models of the same download (1.0.2.1); missing for templates downloaded by 1.0.2 or before 1.8. */
    fun models(profile:GameProfile)=File(root,"${profile.id}.models.zip")
    fun expectedSize(profile:GameProfile)=rows[profile.id]?.optLong("size_bytes",-1L)?:-1L
    fun partialBytes(profile:GameProfile)=File(root,"${profile.id}.source.download").length()
    fun cacheBytes(profile:GameProfile)=root.listFiles()?.filter{it.name.startsWith(profile.id+".")}?.sumOf{it.length()}?:0L
    @Synchronized fun deleteCache(profile:GameProfile){root.listFiles()?.filter{it.name.startsWith(profile.id+".")}?.forEach{if(!it.delete())throw IOException("TEMPLATE_CACHE_DELETE")}}
    fun cancel(){cancelled=true;connection?.disconnect()}
    private fun check(){if(cancelled||Thread.currentThread().isInterrupted)throw CancellationException("Template download cancelled")}
    private fun digest(file:File,cancellable:Boolean=false,algorithm:String="SHA-256"):String {val md=MessageDigest.getInstance(algorithm);file.inputStream().use{input->val bytes=ByteArray(65536);while(true){if(cancellable)check();val n=input.read(bytes);if(n<0)break;md.update(bytes,0,n)}};return md.digest().joinToString(""){"%02x".format(it)}}
    /** Validate on the IO thread before using a cached template. */
    fun verifiedArchive(profile:GameProfile):File {
        val file=archive(profile)
        if(!available(profile))throw IOException("TEMPLATE_MISSING")
        val marker=File(root,"${profile.id}.ready.json")
        try{val expected=JSONObject(marker.readText()).getString("sha256");if(digest(file)!=expected)throw IOException("TEMPLATE_INVALID");TemplateArchive.validate(file);return file}
        catch(e:Exception){if(e !is CancellationException)marker.delete();throw e}
    }
    /** Downloads one pinned source to [source] (resumable, three attempts per mirror, verified by its pin). */
    private fun fetch(row:JSONObject,source:File,update:(String,Float,Long,Long)->Unit){
        val urls=row.optJSONArray("urls")?.let{a->(0 until a.length()).map{URL(a.getString(it))}}?:listOf(URL(row.getString("url")))
        if(urls.isEmpty()||urls.any{it.protocol!="https"})throw IOException("TEMPLATE_INVALID")
        val expected=row.optLong("size_bytes",-1L)
        fun matches(file:File):Boolean=when{
            row.has("source_sha256")->digest(file,true)==row.getString("source_sha256")
            row.has("source_sha1")->digest(file,true,"SHA-1")==row.getString("source_sha1")
            row.optString("pin")=="commit"->true
            else->throw IOException("TEMPLATE_INVALID")
        }
        fun space(total:Long){if(total>0&&freeSpace()<total*2L)throw IOException("TEMPLATE_SPACE")}
        check();space(expected)
        var complete=source.isFile&&expected>0&&source.length()==expected&&matches(source)
        var failure:IOException?=null
        // Three attempts per pinned URL; partial files survive process death and reconnects.
        outer@ for(url in urls){
            if(complete)break
            for(attempt in 0..2){
                check()
                if(attempt>0){update("download_retry",0f,source.length(),expected);repeat(attempt*4){check();Thread.sleep(100)}}
                try {
                    val c=connect(url);connection=c
                    c.connectTimeout=20000;c.readTimeout=30000;c.setRequestProperty("Accept-Encoding","identity");c.setRequestProperty("User-Agent","MCTS/"+BuildConfig.VERSION_NAME)
                    val previous=source.takeIf{it.isFile}?.length()?:0L
                    if(previous>0)c.setRequestProperty("Range","bytes=$previous-")
                    val status=c.responseCode
                    if(status==416){source.delete();throw IOException("TEMPLATE_NETWORK")}
                    if(status !in listOf(200,206))throw IOException(if(status==404)"TEMPLATE_UNAVAILABLE" else "TEMPLATE_HTTP")
                    var offset=if(status==206&&previous>0&&c.getHeaderField("Content-Range")?.startsWith("bytes $previous-")==true)previous else 0L
                    if(status==206&&offset==0L)throw IOException("TEMPLATE_HTTP")
                    val length=c.contentLengthLong;val total=if(length>0)offset+length else expected
                    if(total>512L*1024*1024)throw IOException("TEMPLATE_LARGE")
                    if(expected>0&&total>0&&total!=expected)throw IOException("TEMPLATE_INVALID")
                    space(total)
                    c.inputStream.use{input->FileOutputStream(source,offset>0).use{out->
                        val bytes=ByteArray(65536);var synced=offset
                        while(true){check();val n=input.read(bytes);if(n<0)break;out.write(bytes,0,n);offset+=n
                            if(offset>512L*1024*1024)throw IOException("TEMPLATE_LARGE")
                            if(offset-synced>2L*1024*1024){out.fd.sync();synced=offset}
                            update("download_fetch",if(total>0)(offset.toFloat()/total*.75f).coerceAtMost(.75f)else 0f,offset,total)
                        };out.fd.sync()
                    }}
                    if(total>0&&offset!=total)throw IOException("TEMPLATE_NETWORK")
                    update("download_verify",.77f,0,0)
                    if(!matches(source)){source.delete();throw IOException("TEMPLATE_HASH")}
                    complete=true;break@outer
                }catch(e:IOException){
                    check();failure=e
                    if(e.message=="TEMPLATE_SPACE"||e.message=="TEMPLATE_LARGE"||e.message=="TEMPLATE_INVALID")throw e
                    // A wrong hash will not fix itself by re-downloading from the same mirror: try the next one.
                    if(e.message=="TEMPLATE_UNAVAILABLE"||e.message=="TEMPLATE_HASH")break
                }finally{connection?.disconnect();connection=null}
            }
        }
        if(!complete)throw (failure?:IOException("TEMPLATE_NETWORK"))
    }
    /** Whether the pinned official source of [profile] is known (sources.json). */
    fun hasSource(profile:GameProfile)=rows.containsKey(profile.id)
    /** 1.0.2.1: fetches the pinned official file of [profile] (SHA-1 checked) for another use (the Minecraft font). The caller deletes it. */
    @Synchronized fun fetchSource(profile:GameProfile,report:(String,Float,Long,Long)->Unit):File{
        cancelled=false
        val row=rows[profile.id]?:throw IOException("TEMPLATE_INVALID")
        val source=File(root,"${profile.id}.font.download")
        try{fetch(row,source,report);return source}
        catch(e:IOException){source.delete();if(cancelled)throw CancellationException("Template download cancelled");throw e}
        finally{connection?.disconnect();connection=null}
    }
    /** 1.0.2.2: one pinned extra file (font assets, game fonts): same mirrors, resume and hash check as the templates. */
    @Synchronized fun fetchPinned(row:JSONObject,name:String,report:(String,Float,Long,Long)->Unit):File{
        cancelled=false
        val dest=File(root,"$name.download")
        try{fetch(row,dest,report);return dest}
        catch(e:IOException){dest.delete();if(cancelled)throw CancellationException("Template download cancelled");throw e}
        finally{connection?.disconnect();connection=null}
    }
    /** Java 1.8+ templates downloaded before 1.0.2.1 have no model data; the preview then uses built-in shapes. */
    fun needsModels(profile:GameProfile):Boolean=profile.java&&!profile.texturePack&&profile.parts.let{it.getOrElse(0){0}>1||it.getOrElse(1){0}>=8}&&
        available(profile)&&!models(profile).isFile&&!File(root,"${profile.id}.models.none").isFile
    /** Fetches the same pinned source again (SHA-1 checked) and keeps only the model JSON. */
    @Synchronized fun downloadModels(profile:GameProfile,report:(String,Float,Long,Long)->Unit){
        cancelled=false
        val row=rows[profile.id]?:throw IOException("TEMPLATE_INVALID")
        val source=File(root,"${profile.id}.source.download")
        try{
            fetch(row,source){stage,f,b,t->report(stage,f*.95f,b,t)}
            val control=object:TemplateArchive.Control{
                override fun check(){this@TemplateStore.check()}
                override fun progress(fraction:Float){}
            }
            if(TemplateArchive.extractModels(source,profile.id,models(profile),control)==0)File(root,"${profile.id}.models.none").writeText("0")
            report("download_ready",1f,0,0)
        }catch(e:IOException){if(cancelled)throw CancellationException("Template download cancelled");throw e}
        finally{connection?.disconnect();connection=null;source.delete();File(root,"${profile.id}.models.zip.building").delete()}
    }
    /** Java 1.0 – 1.4.7 name their atlas tiles after the 1.5.2 split textures, so that jar is fetched once as a reference. */
    private val namingReference="java_1_5_2"
    @Synchronized fun download(profile:GameProfile,report:(String,Float,Long,Long)->Unit) {
        cancelled=false
        if(available(profile)){runCatching{verifiedArchive(profile)}.onSuccess{return}}
        val row=rows[profile.id]?:throw IOException("TEMPLATE_INVALID")
        val source=File(root,"${profile.id}.source.download")
        var last=0L
        fun update(stage:String,fraction:Float,bytes:Long=0,total:Long=0){val now=System.nanoTime();if(now-last>100_000_000L||fraction==1f){last=now;report(stage,fraction,bytes,total)}}
        try {
            var reference:File?=null
            if(profile.atlas){
                val refRow=rows[namingReference]?:throw IOException("TEMPLATE_INVALID")
                val ref=File(root,"$namingReference.reference.jar")
                if(!(ref.isFile&&ref.length()==refRow.optLong("size_bytes",-1L)&&digest(ref,true,"SHA-1")==refRow.optString("source_sha1"))){
                    val part=File(root,"$namingReference.reference.download")
                    fetch(refRow,part){stage,f,b,t->update(stage,f*.2f,b,t)}
                    Files.move(part.toPath(),ref.toPath(),StandardCopyOption.REPLACE_EXISTING)
                }
                reference=ref
            }
            fetch(row,source){stage,f,b,t->update(stage,if(profile.atlas).2f+f*.8f else f,b,t)}
            update("download_verify",.77f)
            val dest=archive(profile)
            val control=object:TemplateArchive.Control {
                override fun check(){this@TemplateStore.check()}
                override fun progress(fraction:Float){update("download_prepare",.8f+fraction*.19f)}
            }
            if(profile.texturePack)LegacyPack.buildTemplate(source,reference,profile.atlas,dest,control)
            else{
                TemplateArchive.build(source,profile.id,dest,control)
                // Best effort: the preview falls back to built-in shapes without it.
                runCatching{TemplateArchive.extractModels(source,profile.id,models(profile),control)}
            }
            val marker=File(root,"${profile.id}.ready.json");val temp=File(root,"${profile.id}.ready.part")
            FileOutputStream(temp).use{out->out.write(JSONObject().put("schema",1).put("size",dest.length()).put("sha256",digest(dest)).toString().toByteArray());out.fd.sync()}
            Files.move(temp.toPath(),marker.toPath(),StandardCopyOption.REPLACE_EXISTING)
            source.delete();report("download_ready",1f,0,0)
        }catch(e:IOException){if(cancelled)throw CancellationException("Template download cancelled");throw e}
        finally{connection?.disconnect();connection=null;File(root,"${profile.id}.zip.building").delete();File(root,"${profile.id}.ready.part").delete()}
    }
}
