package com.axion.pompreview;

import java.util.ArrayList;
import java.util.Locale;

/** Generates game-like preview meshes for common Bedrock non-full blocks and entities. */
final class PreviewGeometry {
    static final int FLOATS_PER_VERTEX = 15;

    static final class Result {
        final float[] vertices;
        final String label;
        final int partCount;

        Result(float[] vertices, String label, int partCount) {
            this.vertices = vertices;
            this.label = label;
            this.partCount = partCount;
        }

        int vertexCount() { return vertices.length / FLOATS_PER_VERTEX; }
    }

    private static final class Cuboid {
        final float x0, y0, z0, x1, y1, z1;
        final boolean fullTextureUv;
        Cuboid(float x0, float y0, float z0, float x1, float y1, float z1, boolean fullTextureUv) {
            this.x0 = Math.min(x0, x1); this.y0 = Math.min(y0, y1); this.z0 = Math.min(z0, z1);
            this.x1 = Math.max(x0, x1); this.y1 = Math.max(y0, y1); this.z1 = Math.max(z0, z1);
            this.fullTextureUv = fullTextureUv;
        }
    }

    private static final class Quad {
        final float[] points;
        Quad(float... values) { points = values; }
    }

    private static final class Shape {
        final ArrayList<Cuboid> boxes = new ArrayList<Cuboid>();
        final ArrayList<Quad> quads = new ArrayList<Quad>();
        String label = "完整方块";

        Shape label(String value) { label = value; return this; }
        Shape box(float x0, float y0, float z0, float x1, float y1, float z1) {
            boxes.add(new Cuboid(x0, y0, z0, x1, y1, z1, false)); return this;
        }
        Shape boxFullUv(float x0, float y0, float z0, float x1, float y1, float z1) {
            boxes.add(new Cuboid(x0, y0, z0, x1, y1, z1, true)); return this;
        }
        Shape quad(float... points) { quads.add(new Quad(points)); return this; }
        int partCount() { return boxes.size() + quads.size(); }
    }

    private PreviewGeometry() { }

    static Result build(String rawId) {
        Shape shape = resolve(rawId == null ? "" : rawId.toLowerCase(Locale.ROOT));
        return buildShape(shape);
    }
    static Result buildBoxes(float[] cuboids){
        if(cuboids==null||cuboids.length==0||cuboids.length%6!=0||cuboids.length>6*256)throw new IllegalArgumentException("INVALID_MODEL");
        Shape shape=new Shape().label("项目模型");
        for(int i=0;i<cuboids.length;i+=6)shape.box(cuboids[i],cuboids[i+1],cuboids[i+2],cuboids[i+3],cuboids[i+4],cuboids[i+5]);
        return buildShape(shape);
    }
    private static Result buildShape(Shape shape){
        float[] bounds = bounds(shape);
        float centerX = (bounds[0] + bounds[3]) * 0.5f;
        float centerY = (bounds[1] + bounds[4]) * 0.5f;
        float centerZ = (bounds[2] + bounds[5]) * 0.5f;
        float longest = Math.max(0.001f, Math.max(bounds[3] - bounds[0],
            Math.max(bounds[4] - bounds[1], bounds[5] - bounds[2])));
        // A one-block object always uses the same world scale. Multi-block models
        // are fitted only when they exceed that envelope, so buttons, conduits and
        // other small parts do not get inflated into apparent full blocks.
        float scale = 2.0f / Math.max(16.0f, longest);
        FloatCollector output = new FloatCollector(Math.max(36,
            shape.boxes.size() * 36 + shape.quads.size() * 12) * FLOATS_PER_VERTEX);
        for (Cuboid box : shape.boxes) emitBox(output, box, centerX, centerY, centerZ, scale);
        for (Quad quad : shape.quads) emitQuadDoubleSided(
            output, quad, centerX, centerY, centerZ, scale
        );
        return new Result(output.toArray(), shape.label, shape.partCount());
    }

    static String shapeLabel(String id) { return resolve(id == null ? "" : id.toLowerCase(Locale.ROOT)).label; }

    private static Shape resolve(String id) {
        String name = id;
        int colon = name.indexOf(':');
        if (colon >= 0) name = name.substring(colon + 1);

        if (id.startsWith("entity:boat/") || name.contains("_boat") || name.startsWith("boat_")) {
            return name.contains("raft") ? raft(name.contains("chest")) : boat(name.contains("chest"));
        }
        if (id.startsWith("entity:bed/") || name.equals("bed")) return bed();
        if (id.startsWith("entity:chest/") || name.contains("chest")) return chest();
        if (id.startsWith("entity:shulker/") || name.contains("shulker_box")) return shulker();
        if (id.startsWith("item:") || id.startsWith("ui:") || id.startsWith("particle:"))return tile().label(id.startsWith("item:")?"物品贴图":id.startsWith("ui:")?"UI 贴图":"粒子贴图");
        if (id.startsWith("entity:"))return tile().label("实体纹理（缺少模型定义）");
        // Texture-set-only entries still represent block materials. A planar
        // fallback flattened the bundled template and unmapped vanilla blocks.
        if (id.startsWith("texture:")) return full().label("纹理方块");

        if (name.contains("double_slab")) return full();
        if (name.endsWith("_slab") || name.contains("stone_block_slab")) return slab();
        if (name.endsWith("_stairs")) return stairs();
        if (name.contains("coral_wall_fan")) return wallFan();
        if (name.endsWith("_wall_sign") || name.equals("wall_sign")) return wallSign();
        if (name.endsWith("_hanging_sign")) return hangingSign();
        if (name.endsWith("_standing_sign") || name.equals("standing_sign")) return standingSign();
        if (name.equals("standing_banner")) return banner();
        if (name.equals("wall_banner")) return wallBanner();
        if (name.endsWith("_fence_gate") || name.equals("fence_gate")) return fenceGate();
        if (name.endsWith("_fence") || name.equals("fence")) return fence();
        if ((name.endsWith("_wall") || name.equals("cobblestone_wall"))
            && !name.contains("banner")) return wall();
        if (name.contains("glass_pane") || name.equals("iron_bars") || name.equals("copper_bars")) return pane();
        if (name.endsWith("_trapdoor") || name.equals("trapdoor")) return trapdoor();
        if (name.endsWith("_door") || name.equals("wooden_door") || name.equals("iron_door")) return door();
        if (name.endsWith("_button") || name.equals("stone_button")) return button();
        if (name.endsWith("_pressure_plate")) return pressurePlate();
        if (name.endsWith("_carpet") || name.equals("carpet") || name.equals("moss_carpet")) return carpet();
        if (name.contains("snow_layer")) return snowLayer();
        if (name.endsWith("rail") || name.equals("rail")) return rail();
        if (name.equals("redstone_wire") || name.equals("tripwire")) return rail();
        if (name.equals("ladder") || name.equals("vine")) return wallPlane(name.equals("ladder") ? "梯子" : "藤蔓");
        if (name.equals("glow_lichen") || name.equals("sculk_vein")) return wallPlane("贴面附着物");
        if (name.equals("frame") || name.equals("glow_frame")) return itemFrame();
        if (name.equals("end_portal_frame")) return endPortalFrame();
        if (name.equals("end_portal")) return horizontalPortal();
        if (name.equals("portal")) return verticalPortal();
        if (name.contains("lantern")) return lantern();
        if (isTorch(name)) return torch();
        if (name.contains("campfire")) return campfire();
        if (name.contains("candle_cake")) return candleCake();
        if (name.contains("candle")) return candles();
        if (name.equals("flower_pot") || name.equals("decorated_pot")) return flowerPot();
        if (name.contains("cauldron")) return cauldron();
        if (name.equals("composter")) return composter();
        if (name.equals("hopper")) return hopper();
        if (name.contains("anvil")) return anvil();
        if (name.equals("brewing_stand")) return brewingStand();
        if (name.equals("grindstone")) return grindstone();
        if (name.equals("bell")) return bell();
        if (name.equals("enchanting_table")) return enchantingTable();
        if (name.equals("lectern")) return lectern();
        if (name.equals("stonecutter") || name.equals("stonecutter_block")) return stonecutter();
        if (name.contains("cake")) return cake();
        if (name.equals("scaffolding")) return scaffolding();
        if (name.endsWith("chain") || name.equals("chain")) return chain();
        if (name.contains("sea_pickle")) return seaPickles();
        if (name.contains("turtle_egg") || name.equals("dragon_egg") || name.contains("sniffer_egg")) return egg();
        if (name.contains("end_rod") || name.contains("lightning_rod")) return rod();
        if (name.contains("amethyst_cluster") || name.contains("amethyst_bud")) return crystal();
        if (name.equals("pointed_dripstone")) return pointedDripstone();
        if (name.equals("conduit")) return smallCube("导管");
        if (name.equals("heavy_core")) return smallCube("沉重核心");
        if (name.contains("skull") || name.endsWith("_head") || name.equals("head")) return head();
        if (name.equals("cocoa")) return cocoa();
        if (name.equals("pistonarmcollision") || name.equals("piston_head")) return pistonHead();
        if (name.equals("chorus_plant")) return chorusPlant();
        if (name.equals("chorus_flower")) return chorusFlower();
        if (name.equals("big_dripleaf")) return dripleaf(true);
        if (name.equals("small_dripleaf_block")) return dripleaf(false);
        if (name.equals("reeds") || name.equals("sugar_cane")) return reeds();
        if (name.equals("bamboo")) return bamboo();
        if (name.contains("shelf")) return shelf();
        if (name.equals("fire") || name.equals("soul_fire") || name.equals("cobweb")) {
            return crossPlant(16).label(name.equals("cobweb") ? "蜘蛛网" : "火焰交叉面");
        }
        if (name.equals("cactus")) return new Shape().label("仙人掌").box(1, 0, 1, 15, 16, 15);
        if (name.equals("farmland") || name.contains("dirt_path") || name.equals("grass_path")) {
            return new Shape().label("15/16 高方块").box(0, 0, 0, 16, 15, 16);
        }
        if (name.contains("daylight_detector") || name.contains("repeater") || name.contains("comparator")) {
            return new Shape().label("低矮红石部件").box(0, 0, 0, 16, 2, 16);
        }
        if (name.equals("lever") || name.contains("tripwire_hook")) return lever();
        if (name.contains("sculk_sensor")) return sculkSensor();
        if (name.contains("coral_fan")) return floorFan();
        if (isCrossPlant(name)) return crossPlant(name.contains("double") || name.contains("sunflower") ? 32 : 16);
        return full();
    }

    private static Shape full() { return new Shape().box(0, 0, 0, 16, 16, 16); }
    private static Shape slab() { return new Shape().label("半砖").box(0, 0, 0, 16, 8, 16); }
    private static Shape stairs() {
        return new Shape().label("楼梯").box(0, 0, 0, 16, 8, 16).box(0, 8, 8, 16, 16, 16);
    }
    private static Shape wall() {
        return new Shape().label("墙").box(4, 0, 4, 12, 16, 12)
            .box(0, 0, 5, 16, 13, 11).box(5, 0, 0, 11, 13, 16);
    }
    private static Shape fence() {
        return new Shape().label("栅栏").box(6, 0, 6, 10, 16, 10)
            .box(0, 6, 7, 16, 9, 9).box(0, 12, 7, 16, 15, 9)
            .box(7, 6, 0, 9, 9, 16).box(7, 12, 0, 9, 15, 16);
    }
    private static Shape fenceGate() {
        return new Shape().label("栅栏门").box(0, 0, 6, 3, 16, 10)
            .box(13, 0, 6, 16, 16, 10).box(3, 5, 7, 13, 8, 9)
            .box(3, 11, 7, 13, 14, 9);
    }
    private static Shape pane() {
        return new Shape().label("玻璃板/栏杆").box(7, 0, 0, 9, 16, 16)
            .box(0, 0, 7, 16, 16, 9);
    }
    private static Shape door() { return new Shape().label("双格高门").box(0, 0, 7, 16, 32, 10); }
    private static Shape trapdoor() { return new Shape().label("活板门").box(0, 0, 0, 16, 3, 16); }
    private static Shape pressurePlate() { return new Shape().label("压力板").boxFullUv(1, 0, 1, 15, 1, 15); }
    private static Shape button() { return new Shape().label("按钮 · 当前贴图").boxFullUv(6, 6, 14, 10, 10, 16); }
    private static Shape carpet() { return new Shape().label("地毯").box(0, 0, 0, 16, 1, 16); }
    private static Shape snowLayer() { return new Shape().label("雪层").box(0, 0, 0, 16, 2, 16); }
    private static Shape rail() { return new Shape().label("铁轨").box(0, 0, 0, 16, 0.35f, 16); }
    private static Shape tile() { return new Shape().label("纹理平面").quad(0, 0, 8, 16, 0, 8, 16, 16, 8, 0, 16, 8); }
    private static Shape wallPlane(String label) {
        return new Shape().label(label).quad(0, 0, 15.8f, 16, 0, 15.8f, 16, 16, 15.8f, 0, 16, 15.8f);
    }
    private static Shape wallFan() {
        return new Shape().label("墙面珊瑚扇").quad(1, 1, 15.5f, 15, 1, 15.5f, 15, 15, 13, 1, 15, 13);
    }
    private static Shape standingSign() {
        return new Shape().label("告示牌").box(7, 0, 7, 9, 10, 9).box(1, 9, 7, 15, 17, 9);
    }
    private static Shape wallSign() { return new Shape().label("墙上告示牌").box(1, 4, 14.5f, 15, 12, 16); }
    private static Shape banner() {
        return new Shape().label("旗帜").box(7, 0, 7, 9, 16, 9)
            .quad(2, 8, 7.6f, 14, 8, 7.6f, 14, 28, 7.6f, 2, 28, 7.6f);
    }
    private static Shape wallBanner() {
        return new Shape().label("墙上旗帜")
            .quad(2, 1, 15.6f, 14, 1, 15.6f, 14, 21, 15.6f, 2, 21, 15.6f);
    }
    private static Shape hangingSign() {
        return new Shape().label("悬挂告示牌").box(2, 2, 7, 14, 11, 9)
            .box(3, 11, 7.4f, 5, 16, 8.6f).box(11, 11, 7.4f, 13, 16, 8.6f);
    }
    private static Shape chest() {
        return new Shape().label("箱子").box(1, 0, 1, 15, 10, 15)
            .box(1, 10, 1, 15, 14, 15).box(7, 7, 14.5f, 9, 11, 16);
    }
    private static Shape shulker() {
        return new Shape().label("潜影盒").box(0, 0, 0, 16, 8, 16).box(0, 8.5f, 0, 16, 16, 16);
    }
    private static Shape bed() {
        return new Shape().label("双格床").box(0, 3, 0, 16, 9, 32)
            .box(1, 0, 1, 4, 3, 4).box(12, 0, 1, 15, 3, 4)
            .box(1, 0, 28, 4, 3, 31).box(12, 0, 28, 15, 3, 31);
    }
    private static Shape lantern() {
        return new Shape().label("灯笼").box(4, 2, 4, 12, 12, 12)
            .box(5, 12, 5, 11, 14, 11).box(6, 14, 6, 10, 16, 10);
    }
    private static Shape torch() {
        return new Shape().label("火把").box(7, 0, 7, 9, 13, 9).box(6.5f, 13, 6.5f, 9.5f, 16, 9.5f);
    }
    private static Shape campfire() {
        return new Shape().label("营火").box(1, 0, 6, 15, 3, 10).box(6, 0, 1, 10, 3, 15)
            .quad(3, 3, 3, 13, 3, 13, 13, 16, 13, 3, 16, 3)
            .quad(13, 3, 3, 3, 3, 13, 3, 16, 13, 13, 16, 3);
    }
    private static Shape candles() {
        return new Shape().label("蜡烛组").box(4, 0, 5, 6, 11, 7).box(9, 0, 9, 11, 14, 11)
            .box(9, 0, 4, 11, 8, 6).box(5, 0, 10, 7, 6, 12);
    }
    private static Shape cake() { return new Shape().label("蛋糕").box(1, 0, 1, 15, 8, 15); }
    private static Shape candleCake() { return cake().label("蜡烛蛋糕").box(7, 8, 7, 9, 15, 9); }
    private static Shape flowerPot() {
        return new Shape().label("花盆").box(5, 0, 5, 11, 2, 11).box(4, 2, 4, 12, 6, 12)
            .box(3, 6, 3, 13, 8, 13);
    }
    private static Shape cauldron() {
        return new Shape().label("炼药锅").box(0, 0, 0, 16, 3, 16)
            .box(0, 3, 0, 3, 16, 16).box(13, 3, 0, 16, 16, 16)
            .box(3, 3, 0, 13, 16, 3).box(3, 3, 13, 13, 16, 16);
    }
    private static Shape composter() {
        return new Shape().label("堆肥桶").box(0, 0, 0, 16, 3, 16)
            .box(0, 3, 0, 3, 16, 16).box(13, 3, 0, 16, 16, 16)
            .box(3, 3, 0, 13, 16, 3).box(3, 3, 13, 13, 16, 16);
    }
    private static Shape hopper() {
        return new Shape().label("漏斗").box(0, 10, 0, 16, 16, 16)
            .box(3, 5, 3, 13, 10, 13).box(6, 0, 6, 10, 5, 10);
    }
    private static Shape anvil() {
        return new Shape().label("铁砧").box(2, 0, 3, 14, 3, 13)
            .box(5, 3, 5, 11, 11, 11).box(0, 11, 3, 16, 16, 13);
    }
    private static Shape brewingStand() {
        return new Shape().label("酿造台").box(2, 0, 2, 14, 2, 14)
            .box(7, 2, 7, 9, 15, 9).box(4, 7, 7, 12, 9, 9);
    }
    private static Shape grindstone() {
        return new Shape().label("砂轮").box(2, 0, 5, 5, 12, 11).box(11, 0, 5, 14, 12, 11)
            .box(4, 5, 3, 12, 13, 13);
    }
    private static Shape bell() {
        return new Shape().label("钟").box(3, 2, 3, 13, 12, 13).box(2, 0, 2, 14, 3, 14)
            .box(7, 12, 7, 9, 16, 9);
    }
    private static Shape enchantingTable() {
        return new Shape().label("附魔台").box(0, 0, 0, 16, 12, 16).box(3, 13, 3, 13, 15, 13);
    }
    private static Shape lectern() {
        return new Shape().label("讲台").box(3, 0, 3, 13, 3, 13).box(6, 3, 6, 10, 13, 10)
            .box(2, 12, 2, 14, 15, 14);
    }
    private static Shape stonecutter() {
        return new Shape().label("切石机").box(0, 0, 0, 16, 9, 16)
            .box(2, 9, 7, 14, 14, 9);
    }
    private static Shape scaffolding() {
        return new Shape().label("脚手架").box(0, 0, 0, 2, 16, 2).box(14, 0, 0, 16, 16, 2)
            .box(0, 0, 14, 2, 16, 16).box(14, 0, 14, 16, 16, 16).box(0, 14, 0, 16, 16, 16);
    }
    private static Shape chain() {
        return new Shape().label("锁链").box(7, 0, 6.5f, 9, 16, 9.5f).box(6.5f, 0, 7, 9.5f, 16, 9);
    }
    private static Shape seaPickles() {
        return new Shape().label("海泡菜").box(3, 0, 3, 6, 7, 6).box(10, 0, 9, 13, 10, 12)
            .box(9, 0, 3, 12, 5, 6).box(4, 0, 10, 7, 8, 13);
    }
    private static Shape egg() {
        return new Shape().label("蛋").box(4, 0, 4, 12, 10, 12).box(5, 10, 5, 11, 14, 11);
    }
    private static Shape rod() {
        return new Shape().label("杆状方块").box(6.5f, 0, 6.5f, 9.5f, 16, 9.5f);
    }
    private static Shape crystal() {
        return new Shape().label("紫晶芽/簇").box(6, 0, 6, 10, 13, 10)
            .box(4, 4, 7, 12, 8, 9).box(7, 4, 4, 9, 8, 12);
    }
    private static Shape lever() {
        return new Shape().label("拉杆/挂钩").box(5, 0, 5, 11, 3, 11).box(7, 3, 7, 9, 13, 9);
    }
    private static Shape sculkSensor() {
        return new Shape().label("幽匿感测体").box(0, 0, 0, 16, 8, 16)
            .box(2, 8, 2, 4, 16, 4).box(12, 8, 2, 14, 16, 4)
            .box(2, 8, 12, 4, 16, 14).box(12, 8, 12, 14, 16, 14);
    }
    private static Shape itemFrame() {
        return new Shape().label("物品展示框").box(1, 1, 14.8f, 15, 15, 16)
            .box(3, 3, 14.4f, 13, 13, 14.8f);
    }
    private static Shape endPortalFrame() {
        return new Shape().label("末地传送门框架").box(0, 0, 0, 16, 13, 16)
            .box(5, 13, 5, 11, 16, 11);
    }
    private static Shape horizontalPortal() {
        return new Shape().label("水平传送门面")
            .quad(0, 0.2f, 0, 16, 0.2f, 0, 16, 0.2f, 16, 0, 0.2f, 16);
    }
    private static Shape verticalPortal() {
        return new Shape().label("竖直传送门面")
            .quad(0, 0, 8, 16, 0, 8, 16, 32, 8, 0, 32, 8);
    }
    private static Shape smallCube(String label) {
        return new Shape().label(label + " · 当前贴图").boxFullUv(4, 4, 4, 12, 12, 12);
    }
    private static Shape head() {
        return new Shape().label("头颅").box(4, 0, 4, 12, 8, 12);
    }
    private static Shape cocoa() {
        return new Shape().label("可可果").box(4, 3, 9, 12, 13, 16);
    }
    private static Shape pistonHead() {
        return new Shape().label("活塞头").box(6, 0, 6, 10, 12, 10)
            .box(0, 12, 0, 16, 16, 16);
    }
    private static Shape chorusPlant() {
        return new Shape().label("紫颂植株").box(6, 0, 6, 10, 16, 10)
            .box(0, 6, 6, 16, 10, 10).box(6, 6, 0, 10, 10, 16);
    }
    private static Shape chorusFlower() {
        return new Shape().label("紫颂花").box(3, 0, 3, 13, 13, 13)
            .box(5, 13, 5, 11, 16, 11);
    }
    private static Shape dripleaf(boolean large) {
        Shape result = new Shape().label(large ? "大型垂滴叶" : "小型垂滴叶")
            .box(7, 0, 7, 9, large ? 13 : 9, 9);
        return result.box(1, large ? 12 : 8, 1, 15, large ? 15 : 11, 15);
    }
    private static Shape reeds() {
        return new Shape().label("甘蔗").box(3, 0, 3, 5, 16, 5)
            .box(8, 0, 9, 10, 16, 11).box(12, 0, 4, 14, 16, 6);
    }
    private static Shape bamboo() {
        return new Shape().label("竹子").box(7, 0, 7, 9, 16, 9)
            .quad(2, 7, 2, 14, 7, 14, 14, 13, 14, 2, 13, 2)
            .quad(14, 7, 2, 2, 7, 14, 2, 13, 14, 14, 13, 2);
    }
    private static Shape shelf() {
        return new Shape().label("置物架").box(0, 3, 8, 16, 13, 16)
            .box(0, 0, 14, 2, 16, 16).box(14, 0, 14, 16, 16, 16);
    }
    private static Shape pointedDripstone() {
        return new Shape().label("滴水石锥").box(7, 0, 7, 9, 16, 9)
            .box(6, 0, 6, 10, 7, 10).box(5, 0, 5, 11, 3, 11);
    }
    private static Shape floorFan() {
        return new Shape().label("地面珊瑚扇").quad(1, 0.3f, 1, 15, 0.3f, 15, 15, 10, 15, 1, 10, 1)
            .quad(15, 0.3f, 1, 1, 0.3f, 15, 1, 10, 15, 15, 10, 1);
    }
    private static Shape crossPlant(float height) {
        return new Shape().label("交叉植物模型")
            .quad(0, 0, 0, 16, 0, 16, 16, height, 16, 0, height, 0)
            .quad(16, 0, 0, 0, 0, 16, 0, height, 16, 16, height, 0);
    }
    private static Shape boat(boolean withChest) {
        Shape shape = new Shape().label(withChest ? "运输船" : "船")
            .box(1, 0, 2, 15, 3, 26).box(0, 3, 2, 3, 10, 24)
            .box(13, 3, 2, 16, 10, 24).box(3, 3, 22, 13, 10, 27);
        if (withChest) shape.box(3, 3, 8, 13, 12, 18);
        return shape;
    }
    private static Shape raft(boolean withChest) {
        Shape shape = new Shape().label(withChest ? "运输竹筏" : "竹筏")
            .box(0, 1, 0, 16, 3, 28).box(1, 0, 1, 3, 4, 27).box(13, 0, 1, 15, 4, 27);
        if (withChest) shape.box(3, 3, 9, 13, 12, 19);
        return shape;
    }

    private static boolean isTorch(String name) {
        return (name.endsWith("torch") || name.contains("_torch"))
            && !name.contains("torchflower");
    }

    private static boolean isCrossPlant(String name) {
        if (name.endsWith("_block") || name.equals("dried_kelp_block")) return false;
        return name.contains("sapling") || name.contains("flower") || name.contains("tallgrass")
            || name.equals("double_plant") || name.contains("crop") || name.contains("wheat")
            || name.contains("carrots") || name.contains("potatoes") || name.contains("beetroot")
            || name.contains("roots") || name.contains("fungus") || name.contains("mushroom")
            || name.contains("bush") || name.contains("seagrass") || name.contains("kelp")
            || name.contains("cave_vines") || name.contains("weeping_vines")
            || name.contains("twisting_vines") || (name.contains("coral") && !name.contains("block"));
    }

    private static float[] bounds(Shape shape) {
        float minX = Float.POSITIVE_INFINITY, minY = minX, minZ = minX;
        float maxX = Float.NEGATIVE_INFINITY, maxY = maxX, maxZ = maxX;
        for (Cuboid box : shape.boxes) {
            minX = Math.min(minX, box.x0); minY = Math.min(minY, box.y0); minZ = Math.min(minZ, box.z0);
            maxX = Math.max(maxX, box.x1); maxY = Math.max(maxY, box.y1); maxZ = Math.max(maxZ, box.z1);
        }
        for (Quad quad : shape.quads) for (int i = 0; i < 4; ++i) {
            minX = Math.min(minX, quad.points[i * 3]); minY = Math.min(minY, quad.points[i * 3 + 1]);
            minZ = Math.min(minZ, quad.points[i * 3 + 2]); maxX = Math.max(maxX, quad.points[i * 3]);
            maxY = Math.max(maxY, quad.points[i * 3 + 1]); maxZ = Math.max(maxZ, quad.points[i * 3 + 2]);
        }
        if (Float.isNaN(minX) || Float.isInfinite(minX)) {
            return new float[] { 0, 0, 0, 16, 16, 16 };
        }
        return new float[] { minX, minY, minZ, maxX, maxY, maxZ };
    }

    private static void emitBox(FloatCollector out, Cuboid b, float cx, float cy, float cz, float scale) {
        float uX0=b.x0/16f,uX1=b.x1/16f,uY0=b.y0/16f,uY1=b.y1/16f,uZ0=b.z0/16f,uZ1=b.z1/16f;
        if (b.fullTextureUv) {
            uX0=0f;uX1=1f;uY0=0f;uY1=1f;uZ0=0f;uZ1=1f;
        }
        face(out,cx,cy,cz,scale, b.x0,b.y0,b.z1, b.x1,b.y0,b.z1, b.x1,b.y1,b.z1, b.x0,b.y1,b.z1,
            0,0,1, 1,0,0, 0,1,0, uX0,uY0,uX1,uY1);
        face(out,cx,cy,cz,scale, b.x1,b.y0,b.z0, b.x0,b.y0,b.z0, b.x0,b.y1,b.z0, b.x1,b.y1,b.z0,
            0,0,-1, -1,0,0, 0,1,0, uX0,uY0,uX1,uY1);
        face(out,cx,cy,cz,scale, b.x1,b.y0,b.z1, b.x1,b.y0,b.z0, b.x1,b.y1,b.z0, b.x1,b.y1,b.z1,
            1,0,0, 0,0,-1, 0,1,0, uZ0,uY0,uZ1,uY1);
        face(out,cx,cy,cz,scale, b.x0,b.y0,b.z0, b.x0,b.y0,b.z1, b.x0,b.y1,b.z1, b.x0,b.y1,b.z0,
            -1,0,0, 0,0,1, 0,1,0, uZ0,uY0,uZ1,uY1);
        face(out,cx,cy,cz,scale, b.x0,b.y1,b.z1, b.x1,b.y1,b.z1, b.x1,b.y1,b.z0, b.x0,b.y1,b.z0,
            0,1,0, 1,0,0, 0,0,-1, uX0,uZ0,uX1,uZ1);
        face(out,cx,cy,cz,scale, b.x0,b.y0,b.z0, b.x1,b.y0,b.z0, b.x1,b.y0,b.z1, b.x0,b.y0,b.z1,
            0,-1,0, 1,0,0, 0,0,1, uX0,uZ0,uX1,uZ1);
    }

    private static void emitQuadDoubleSided(FloatCollector out, Quad q, float cx, float cy, float cz, float scale) {
        float[] p=q.points;
        float[] tangent=normalize(p[3]-p[0],p[4]-p[1],p[5]-p[2]);
        float[] bitangent=normalize(p[9]-p[0],p[10]-p[1],p[11]-p[2]);
        float[] normal=normalize(tangent[1]*bitangent[2]-tangent[2]*bitangent[1],
            tangent[2]*bitangent[0]-tangent[0]*bitangent[2], tangent[0]*bitangent[1]-tangent[1]*bitangent[0]);
        face(out,cx,cy,cz,scale,p[0],p[1],p[2],p[3],p[4],p[5],p[6],p[7],p[8],p[9],p[10],p[11],
            normal[0],normal[1],normal[2],tangent[0],tangent[1],tangent[2],bitangent[0],bitangent[1],bitangent[2],0,0,1,1);
        face(out,cx,cy,cz,scale,p[3],p[4],p[5],p[0],p[1],p[2],p[9],p[10],p[11],p[6],p[7],p[8],
            -normal[0],-normal[1],-normal[2],-tangent[0],-tangent[1],-tangent[2],bitangent[0],bitangent[1],bitangent[2],0,0,1,1);
    }

    private static void face(FloatCollector o,float cx,float cy,float cz,float s,
        float x0,float y0,float z0,float x1,float y1,float z1,float x2,float y2,float z2,float x3,float y3,float z3,
        float nx,float ny,float nz,float tx,float ty,float tz,float bx,float by,float bz,float u0,float v0,float u1,float v1) {
        vertex(o,x0,y0,z0,cx,cy,cz,s,nx,ny,nz,u0,v0,tx,ty,tz,bx,by,bz);
        vertex(o,x1,y1,z1,cx,cy,cz,s,nx,ny,nz,u1,v0,tx,ty,tz,bx,by,bz);
        vertex(o,x2,y2,z2,cx,cy,cz,s,nx,ny,nz,u1,v1,tx,ty,tz,bx,by,bz);
        vertex(o,x0,y0,z0,cx,cy,cz,s,nx,ny,nz,u0,v0,tx,ty,tz,bx,by,bz);
        vertex(o,x2,y2,z2,cx,cy,cz,s,nx,ny,nz,u1,v1,tx,ty,tz,bx,by,bz);
        vertex(o,x3,y3,z3,cx,cy,cz,s,nx,ny,nz,u0,v1,tx,ty,tz,bx,by,bz);
    }

    private static void vertex(FloatCollector o,float x,float y,float z,float cx,float cy,float cz,float s,
        float nx,float ny,float nz,float u,float v,float tx,float ty,float tz,float bx,float by,float bz) {
        o.add((x-cx)*s);o.add((y-cy)*s);o.add((z-cz)*s);o.add(nx);o.add(ny);o.add(nz);
        o.add(u);o.add(v);o.add(tx);o.add(ty);o.add(tz);o.add(bx);o.add(by);o.add(bz);
        o.add(ny>.5f?1f:ny<-.5f?3f:nz>.5f?2f:nz<-.5f?4f:nx<-.5f?5f:6f);
    }

    private static float[] normalize(float x,float y,float z) {
        float length=(float)Math.sqrt(x*x+y*y+z*z);
        return length<0.00001f?new float[]{0,1,0}:new float[]{x/length,y/length,z/length};
    }

    private static final class FloatCollector {
        float[] values; int cursor;
        FloatCollector(int capacity){values=new float[Math.max(64,capacity)];}
        void add(float value){if(cursor>=values.length){float[] n=new float[values.length*2];System.arraycopy(values,0,n,0,cursor);values=n;}values[cursor++]=value;}
        float[] toArray(){float[] out=new float[cursor];System.arraycopy(values,0,out,0,cursor);return out;}
    }
}
