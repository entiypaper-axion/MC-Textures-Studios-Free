package com.mcts.studio

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.*
import com.mcts.core.CanvasGeometry
import com.mcts.core.MaterialDocument
import kotlin.math.*

internal class PaintViewport {
    var zoom by mutableFloatStateOf(1f)
    var pan by mutableStateOf(Offset.Zero)
    fun fit(){zoom=1f;pan=Offset.Zero}
    fun scale(v:Float){zoom=v.coerceIn(.5f,256f)}
}

@Composable internal fun PaintSurface(model:StudioModel,view:PaintViewport,channel:MaterialDocument.Channel,modifier:Modifier=Modifier){
    val doc=model.document;val pixels=remember(doc,model.revision,channel){doc.composite(channel)}
    val bitmap=remember(pixels){Bitmap.createBitmap(pixels,doc.width,doc.height,Bitmap.Config.ARGB_8888).asImageBitmap()}
    var viewport by remember{mutableStateOf(IntSize(1,1))}
    val paint=remember{Paint(Paint.ANTI_ALIAS_FLAG).apply{typeface=Typeface.create(Typeface.MONOSPACE,Typeface.BOLD);textAlign=Paint.Align.CENTER}}
    val active=!model.busy&&channel==model.channel
    fun geometry()=CanvasGeometry(viewport.width.coerceAtLeast(1).toFloat(),viewport.height.coerceAtLeast(1).toFloat(),doc.width,doc.height,view.zoom,view.pan.x,view.pan.y)
    fun pixel(at:Offset):Pair<Int,Int>?{val g=geometry();val x=g.x(at.x);val y=g.y(at.y);return if(x>=0&&y>=0)x to y else null}
    val selected=model.selectedPixel
    val dark=LocalFreeDark.current
    val canvasBackground=if(dark)Color(0xff17282c)else Color(0xffdce9e5)
    val checkerLight=if(dark)Color(0xff32464b)else Color(0xfff8faf9)
    val checkerDark=if(dark)Color(0xff223439)else Color(0xffd1dddb)
    Column(modifier){
        if(model.isFree&&model.showGestureHint){
            Text(model.t("gesture_hint"),style=MaterialTheme.typography.bodySmall)
            SpringTextButton(model::dismissGestureHint){Text(model.t("got_it"))}
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),verticalAlignment=Alignment.CenterVertically){
            Text("${doc.width}×${doc.height} · ${"%.1f".format(view.zoom)}×",style=MaterialTheme.typography.labelSmall)
            SpringTextButton({view.scale(view.zoom/1.5f)}){Text("−")};SpringTextButton({view.fit()}){Text(model.w("适配","Fit","全体"))};SpringTextButton({view.scale(view.zoom*1.5f)}){Text("+")}
            SpringTextButton({model.setGrid(!model.pixelGrid)}){Text(model.w("网格","Grid","格子")+if(model.pixelGrid)" ✓" else "")}
        }
        if(channel!=MaterialDocument.Channel.COLOR){
            val value=selected?.let{(x,y)->pixels[y*doc.width+x]}
            val text=if(value==null)model.w("放大查看每格数值 · 吸管读取原值","Zoom for cell values · eyedropper reads originals","拡大して各画素の値を表示")else if(channel==MaterialDocument.Channel.NORMAL)"(${selected!!.first},${selected.second})  R ${(value ushr 16)and 255}  G ${(value ushr 8)and 255}  B ${value and 255}"else "(${selected!!.first},${selected.second})  ${model.t(channel.name)}: ${value and 255}"
            Text(text,style=MaterialTheme.typography.labelSmall,maxLines=2)
        }
        Canvas(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(16.dp)).background(canvasBackground)
            .onSizeChanged{viewport=it}.semantics{contentDescription="${model.t("edit")}: ${doc.name}, ${model.t(channel.name)}, ${doc.width} × ${doc.height}"}
            .pointerInput(doc,channel,active,model.panCanvas,model.sampler){
                if(active)awaitEachGesture {
                    val down=awaitFirstDown(requireUnconsumed=false)
                    val start=down.position
                    val sampleMode=model.sampler
                    var drawing=false;var transformed=false;var moved=false
                    fun stroke(at:Offset){val cell=pixel(at);if(cell==null)model.paintPath(-1,-1)else model.paintPath(cell.first,cell.second)}
                    try {
                        do {
                            val event=awaitPointerEvent()
                            val pressed=event.changes.count{it.pressed}
                            val change=event.changes.firstOrNull{it.id==down.id}
                            if(pressed>1){
                                if(drawing){model.cancelStroke();drawing=false}
                                transformed=true
                                val old=view.zoom;val next=(old*event.calculateZoom()).coerceIn(.5f,256f)
                                val centroid=event.calculateCentroid(useCurrent=false)
                                if(centroid.isSpecified){
                                    val center=Offset(viewport.width/2f,viewport.height/2f)
                                    view.pan=(view.pan-(centroid-center))*(next/old)+(centroid-center)+event.calculatePan()
                                    view.scale(next)
                                }
                                event.changes.forEach{it.consume()}
                            }else if(change!=null&&!transformed){
                                if(change.isConsumed){if(drawing){model.cancelStroke();drawing=false};transformed=true}
                                else {
                                    if((change.position-start).getDistance()>viewConfiguration.touchSlop)moved=true
                                    if(model.panCanvas){
                                        view.pan+=change.position-change.previousPosition
                                        change.consume()
                                    }else if(!sampleMode&&moved){
                                        if(!drawing){pixel(start)?.let{(x,y)->model.beginStroke(x,y);drawing=true}}
                                        if(drawing){change.historical.forEach{stroke(it.position)};stroke(change.position)}
                                        change.consume()
                                    }
                                    if(!change.pressed&&!moved&&!model.panCanvas){pixel(change.position)?.let{(x,y)->
                                        if(sampleMode)model.sample(x,y)else{model.beginStroke(x,y);drawing=true}
                                    }}
                                }
                            }
                        }while(event.changes.any{it.pressed})
                    }finally{if(drawing)model.endStroke()}
                }
            }){
            val g=CanvasGeometry(size.width.coerceAtLeast(1f),size.height.coerceAtLeast(1f),doc.width,doc.height,view.zoom,view.pan.x,view.pan.y)
            // Checkerboard uses the same geometry as texture and hit testing.
            val bx0=g.firstX();val bx1=g.lastX(size.width);val by0=g.firstY();val by1=g.lastY(size.height)
            val step=max(1,ceil(8.dp.toPx()/g.unit).toInt())
            for(y in (by0/step*step)..by1 step step)for(x in (bx0/step*step)..bx1 step step){
                val left=max(g.left,g.screenX(x));val top=max(g.top,g.screenY(y))
                val right=min(g.screenX(doc.width),g.screenX(x+step));val bottom=min(g.screenY(doc.height),g.screenY(y+step))
                drawRect(if((x/step+y/step)%2==0)checkerLight else checkerDark,Offset(left,top),Size((right-left).coerceAtLeast(0f),(bottom-top).coerceAtLeast(0f)))
            }
            // Destination and hit testing share the exact same centred transform.
            withTransform({translate(g.left,g.top);scale(g.unit,g.unit,pivot=Offset.Zero)}){drawImage(bitmap,dstSize=IntSize(doc.width,doc.height),filterQuality=FilterQuality.None)}
            val x0=g.firstX();val x1=g.lastX(size.width);val y0=g.firstY();val y1=g.lastY(size.height)
            if(model.pixelGrid&&x0<=x1&&y0<=y1){
                val alpha=(g.unit/28f).coerceIn(.08f,.38f);val line=(if(dark)Color(0xffb9cecc)else Color(0xff173d44)).copy(alpha=alpha)
                for(x in x0..x1+1)drawLine(line,Offset(g.screenX(x),max(0f,g.top)),Offset(g.screenX(x),min(size.height,g.screenY(doc.height))),strokeWidth=if(g.unit<4f).45f else .7.dp.toPx())
                for(y in y0..y1+1)drawLine(line,Offset(max(0f,g.left),g.screenY(y)),Offset(min(size.width,g.screenX(doc.width)),g.screenY(y)),strokeWidth=if(g.unit<4f).45f else .7.dp.toPx())
            }
            val normal=channel==MaterialDocument.Channel.NORMAL
            if(channel!=MaterialDocument.Channel.COLOR&&g.unit>=(if(normal)42.dp else 26.dp).toPx()){
                paint.textSize=min(13.dp.toPx(),g.unit*(if(normal).18f else .28f));paint.setShadowLayer(2f,0f,1f,android.graphics.Color.WHITE)
                for(y in y0..y1)for(x in x0..x1){val c=pixels[y*doc.width+x];val r=(c ushr 16)and 255;val green=(c ushr 8)and 255;val b=c and 255
                    paint.color=if(r*.299f+green*.587f+b*.114f>135f)android.graphics.Color.BLACK else android.graphics.Color.WHITE
                    paint.setShadowLayer(1.5f,0f,1f,if(paint.color==android.graphics.Color.BLACK)android.graphics.Color.WHITE else android.graphics.Color.BLACK)
                    val lines=if(normal)listOf("R$r","G$green","B$b")else listOf(b.toString());val h=paint.fontSpacing
                    lines.forEachIndexed{i,line->drawContext.canvas.nativeCanvas.drawText(line,g.screenX(x)+g.unit/2,g.screenY(y)+g.unit/2+(i-(lines.size-1)/2f)*h-(paint.ascent()+paint.descent())/2,paint)}
                }
            }
            if(model.mirrorX)drawLine(Color(0xffc93895),Offset(g.screenX(doc.width/2),max(0f,g.top)),Offset(g.screenX(doc.width/2),min(size.height,g.screenY(doc.height))),strokeWidth=1.dp.toPx())
            if(model.mirrorY)drawLine(Color(0xffc93895),Offset(max(0f,g.left),g.screenY(doc.height/2)),Offset(min(size.width,g.screenX(doc.width)),g.screenY(doc.height/2)),strokeWidth=1.dp.toPx())
            selected?.let{(x,y)->drawRect(Color.White,Offset(g.screenX(x),g.screenY(y)),Size(g.unit,g.unit),style=Stroke(2.dp.toPx()));drawRect(Color(0xff127f90),Offset(g.screenX(x),g.screenY(y)),Size(g.unit,g.unit),style=Stroke(1.dp.toPx()))}
        }
    }
}
