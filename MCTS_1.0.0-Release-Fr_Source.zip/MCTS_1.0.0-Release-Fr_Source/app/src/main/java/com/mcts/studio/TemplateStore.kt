package com.mcts.studio

import android.content.Context
import com.mcts.core.TemplateArchive
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.concurrent.CancellationException

/** Downloaded templates are local files, never APK assets. Published source hashes pin each archive. */
class TemplateStore @JvmOverloads constructor(context:Context,private val connect:(URL)->HttpURLConnection={it.openConnection() as HttpURLConnection},private val freeSpace:()->Long={context.filesDir.usableSpace}) {
    private val root=File(context.filesDir,"templates-v1").apply{mkdirs()}
    private val rows=context.assets.open("templates/sources.json").bufferedReader().use{JSONArray(it.readText())}.let{a->(0 until a.length()).associate{a.getJSONObject(it).let{it.getString("profile") to it}}}
    @Volatile private var cancelled=false
    @Volatile private var connection:HttpURLConnection?=null
    fun available(profile:GameProfile):Boolean {
        val file=archive(profile);val marker=File(root,"${profile.id}.ready.json")
        return file.isFile&&runCatching{val m=JSONObject(marker.readText());m.getLong("size")==file.length()&&m.getInt("schema")==1}.getOrDefault(false)
    }
    fun archive(profile:GameProfile)=File(root,"${profile.id}.zip")
    fun expectedSize(profile:GameProfile)=rows[profile.id]?.optLong("size_bytes",-1L)?:-1L
    fun partialBytes(profile:GameProfile)=File(root,"${profile.id}.source.download").length()
    fun cacheBytes(profile:GameProfile)=root.listFiles()?.filter{it.name.startsWith(profile.id+".")}?.sumOf{it.length()}?:0L
    @Synchronized fun deleteCache(profile:GameProfile){root.listFiles()?.filter{it.name.startsWith(profile.id+".")}?.forEach{if(!it.delete())throw IOException("TEMPLATE_CACHE_DELETE")}}
    fun cancel(){cancelled=true;connection?.disconnect()}
    private fun check(){if(cancelled||Thread.currentThread().isInterrupted)throw CancellationException("Template download cancelled")}
    private fun digest(file:File,cancellable:Boolean=false):String {val md=MessageDigest.getInstance("SHA-256");file.inputStream().use{input->val bytes=ByteArray(65536);while(true){if(cancellable)check();val n=input.read(bytes);if(n<0)break;md.update(bytes,0,n)}};return md.digest().joinToString(""){"%02x".format(it)}}
    /** Validate on the IO thread before using a cached template. */
    fun verifiedArchive(profile:GameProfile):File {
        val file=archive(profile)
        if(!available(profile))throw IOException("TEMPLATE_MISSING")
        val marker=File(root,"${profile.id}.ready.json")
        try{val expected=JSONObject(marker.readText()).getString("sha256");if(digest(file)!=expected)throw IOException("TEMPLATE_INVALID");TemplateArchive.validate(file);return file}
        catch(e:Exception){if(e !is CancellationException)marker.delete();throw e}
    }
    @Synchronized fun download(profile:GameProfile,report:(String,Float,Long,Long)->Unit) {
        cancelled=false
        if(available(profile)){runCatching{verifiedArchive(profile)}.onSuccess{return}}
        val row=rows[profile.id]?:throw IOException("TEMPLATE_INVALID")
        val urls=row.optJSONArray("urls")?.let{a->(0 until a.length()).map{URL(a.getString(it))}}?:listOf(URL(row.getString("url")))
        if(urls.isEmpty()||urls.any{it.protocol!="https"})throw IOException("TEMPLATE_INVALID")
        val source=File(root,"${profile.id}.source.download")
        val expected=row.optLong("size_bytes",-1L)
        var last=0L
        fun update(stage:String,fraction:Float,bytes:Long=0,total:Long=0){val now=System.nanoTime();if(now-last>100_000_000L||fraction==1f){last=now;report(stage,fraction,bytes,total)}}
        fun space(total:Long){if(total>0&&freeSpace()<total*2L)throw IOException("TEMPLATE_SPACE")}
        try {
            check();space(expected)
            var complete=source.isFile&&(expected<=0||source.length()==expected)&&digest(source,true)==row.getString("source_sha256")
            var failure:IOException?=null
            // Three attempts per pinned URL; partial files survive process death and reconnects.
            outer@ for(url in urls){
                if(complete)break
                for(attempt in 0..2){
                    check()
                    if(attempt>0){report("download_retry",0f,source.length(),expected);repeat(attempt*4){check();Thread.sleep(100)}}
                    try {
                        val c=connect(url);connection=c
                        c.connectTimeout=20000;c.readTimeout=30000;c.setRequestProperty("Accept-Encoding","identity");c.setRequestProperty("User-Agent","MCTS/3.0.9-Fr")
                        val previous=source.takeIf{it.isFile}?.length()?:0L
                        if(previous>0)c.setRequestProperty("Range","bytes=$previous-")
                        val status=c.responseCode
                        if(status==416){source.delete();throw IOException("TEMPLATE_NETWORK")}
                        if(status !in listOf(200,206))throw IOException(if(status==404)"TEMPLATE_UNAVAILABLE" else "TEMPLATE_HTTP")
                        var offset=if(status==206&&previous>0&&c.getHeaderField("Content-Range")?.startsWith("bytes $previous-")==true)previous else 0L
                        if(status==206&&offset==0L)throw IOException("TEMPLATE_HTTP")
                        val length=c.contentLengthLong;val total=if(length>0)offset+length else expected
                        if(total>512L*1024*1024)throw IOException("TEMPLATE_LARGE")
                        if(expected>0&&total>0&&total!=expected)throw IOException("TEMPLATE_INVALID")
                        space(total)
                        c.inputStream.use{input->FileOutputStream(source,offset>0).use{out->
                            val bytes=ByteArray(65536);var synced=offset
                            while(true){check();val n=input.read(bytes);if(n<0)break;out.write(bytes,0,n);offset+=n
                                if(offset>512L*1024*1024)throw IOException("TEMPLATE_LARGE")
                                if(offset-synced>2L*1024*1024){out.fd.sync();synced=offset}
                                update("download_fetch",if(total>0)(offset.toFloat()/total*.75f).coerceAtMost(.75f)else 0f,offset,total)
                            };out.fd.sync()
                        }}
                        if(total>0&&offset!=total)throw IOException("TEMPLATE_NETWORK")
                        update("download_verify",.77f)
                        if(digest(source,true)!=row.getString("source_sha256")){source.delete();throw IOException("TEMPLATE_HASH")}
                        complete=true;break@outer
                    }catch(e:IOException){
                        check();failure=e
                        if(e.message=="TEMPLATE_SPACE"||e.message=="TEMPLATE_LARGE"||e.message=="TEMPLATE_INVALID")throw e
                        if(e.message=="TEMPLATE_UNAVAILABLE")break
                    }finally{connection?.disconnect();connection=null}
                }
            }
            if(!complete)throw (failure?:IOException("TEMPLATE_NETWORK"))
            update("download_verify",.77f)
            val dest=archive(profile)
            TemplateArchive.build(source,profile.id,dest,object:TemplateArchive.Control {
                override fun check(){this@TemplateStore.check()}
                override fun progress(fraction:Float){update("download_prepare",.8f+fraction*.19f)}
            })
            val marker=File(root,"${profile.id}.ready.json");val temp=File(root,"${profile.id}.ready.part")
            FileOutputStream(temp).use{out->out.write(JSONObject().put("schema",1).put("size",dest.length()).put("sha256",digest(dest)).toString().toByteArray());out.fd.sync()}
            Files.move(temp.toPath(),marker.toPath(),StandardCopyOption.REPLACE_EXISTING)
            source.delete();report("download_ready",1f,0,0)
        }catch(e:IOException){if(cancelled)throw CancellationException("Template download cancelled");throw e}
        finally{connection?.disconnect();connection=null;File(root,"${profile.id}.zip.building").delete();File(root,"${profile.id}.ready.part").delete()}
    }
}
