package com.mcts.studio

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.zip.ZipFile

/** Reads a model archive chosen by the owner into private project storage. No game JAR ships in the APK. */
internal object OfficialModels {
    private fun ZipFile.find(suffix:String)=entries().asSequence().firstOrNull{!it.isDirectory&&it.name.endsWith(suffix)}
    private fun ZipFile.json(suffix:String):JSONObject?{
        val entry=find(suffix)?:return null
        if(entry.size !in 1..262_144)return null
        return runCatching{JSONObject(getInputStream(entry).bufferedReader().use{it.readText()})}.getOrNull()
    }
    fun boxes(archive:File,shape:String):FloatArray?{
        if(!archive.isFile)return null
        val name=shape.substringAfter(':').substringAfterLast('/')
        return ZipFile(archive).use{zip->
            if(shape.startsWith("entity:"))bedrock(zip,name)?:javaBlock(zip,name)
            else javaBlock(zip,name)?:bedrock(zip,name)
        }
    }
    private fun javaBlock(zip:ZipFile,id:String):FloatArray?{
        val state=zip.json("assets/minecraft/blockstates/$id.json")
        val variants=state?.optJSONObject("variants")
        val candidate=variants?.let{v->
            val keys=v.keys().asSequence().toList()
            val variant=v.opt(keys.firstOrNull{it.isEmpty()}?:keys.firstOrNull().orEmpty())
            if(variant is JSONArray)variant.optJSONObject(0)?.optString("model") else (variant as? JSONObject)?.optString("model")
        }?.substringAfter(':')?:"block/$id"
        fun elements(model:String,depth:Int):JSONArray?{
            if(depth>8||!model.matches(Regex("[a-z0-9_/-]+")))return null
            val obj=zip.json("assets/minecraft/models/${model}.json")?:return null
            obj.optJSONArray("elements")?.let{return it}
            return obj.optString("parent").takeIf{it.isNotBlank()}?.let{elements(it.substringAfter(':'),depth+1)}
        }
        val list=elements(candidate,0)?:return null
        val output=ArrayList<Float>()
        for(i in 0 until minOf(list.length(),256)){
            val box=list.optJSONObject(i)?:continue
            val start=box.optJSONArray("from")?:continue;val end=box.optJSONArray("to")?:continue
            if(start.length()!=3||end.length()!=3)continue
            for(axis in 0..2)output.add(start.optDouble(axis).toFloat())
            for(axis in 0..2)output.add(end.optDouble(axis).toFloat())
        }
        return output.takeIf{it.isNotEmpty()}?.toFloatArray()
    }
    private fun bedrock(zip:ZipFile,id:String):FloatArray?{
        val obj=zip.json("resource_pack/models/entity/$id.geo.json")?:zip.json("resource_pack/models/entity/$id.json")?:return null
        val geometries=obj.optJSONArray("minecraft:geometry")?:return null
        val bones=geometries.optJSONObject(0)?.optJSONArray("bones")?:return null
        val output=ArrayList<Float>()
        for(i in 0 until bones.length()){
            val cubes=bones.optJSONObject(i)?.optJSONArray("cubes")?:continue
            for(j in 0 until cubes.length()){
                val cube=cubes.optJSONObject(j)?:continue
                val origin=cube.optJSONArray("origin")?:continue;val size=cube.optJSONArray("size")?:continue
                if(origin.length()!=3||size.length()!=3)continue
                val from=FloatArray(3){axis->origin.optDouble(axis).toFloat()}
                val to=FloatArray(3){axis->from[axis]+size.optDouble(axis).toFloat()}
                output.addAll(from.toList());output.addAll(to.toList())
                if(output.size>=1536)break
            }
            if(output.size>=1536)break
        }
        return output.takeIf{it.isNotEmpty()}?.toFloatArray()
    }
}
