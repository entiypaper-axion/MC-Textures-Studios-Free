package com.mcts.studio

import android.content.Context
import android.net.Uri
import android.graphics.BitmapFactory
import com.mcts.core.*
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.Properties
import java.util.zip.*

data class GameProfile(val id:String,val java:Boolean,val version:String,val format:Int,val pair:String,val vv:Boolean=false) {
    val label get()=(if(java)"Java " else "Bedrock ")+version
}
val gameProfiles=listOf(
    GameProfile("java_1165",true,"1.16.5",6,"1.16.200"),GameProfile("java_1201",true,"1.20.1",15,"1.20.0"),GameProfile("java_1211",true,"1.21.1",34,"1.21.20"),GameProfile("java_12111",true,"1.21.11",75,"1.21.130"),GameProfile("java_262",true,"26.2",88,"26.30"),
    GameProfile("bedrock_116200",false,"1.16.200",6,"1.16.5"),GameProfile("bedrock_1200",false,"1.20.0",15,"1.20.1"),GameProfile("bedrock_12120",false,"1.21.20",34,"1.21.1"),GameProfile("bedrock_121130",false,"1.21.130",75,"1.21.11",true),GameProfile("bedrock_2630",false,"26.30",88,"26.2",true))
data class PackProject(val id:String,val name:String,val profile:GameProfile,val header:String,val module:String)
data class TemplateTexture(val path:String,val width:Int,val height:Int) {
    val editable get()=width in 16..512&&height in 16..512&&(width and (width-1))==0&&(height and (height-1))==0
    val category get()=TemplateCategory.of(path)
    val pbr get()=TemplateArchive.isPbr(path)
    fun sizes()=listOf(16,32,64,128,256,512).filter{width>0&&it*height%width==0}.filter{n->val h=n*height/width;h in 16..512&&(h and(h-1))==0}
}
data class FaceMaps(val top:IntArray,val side:IntArray,val bottom:IntArray,val role:Int,val shape:String)
data class ExportSummary(val edited:Int,val unchanged:Int) { val total get()=edited+unchanged }
data class TrashedProject(val project:PackProject,val token:String)
class Projects(private val context:Context) {
    val templates=TemplateStore(context)
    private val textureIndex=java.util.concurrent.ConcurrentHashMap<String,List<TemplateTexture>>()
    private val catalogues=mutableMapOf<String,BlockCatalogue>()
    fun catalogue(p:PackProject)=synchronized(catalogues){catalogues.getOrPut(p.profile.id){BlockCatalogue(context.assets,p.profile.id)}}

    private val root=File(context.filesDir,"projects").apply{mkdirs()}
    fun folder(id:String):File {require(id=="local"||id.matches(Regex("[a-f0-9-]{36}")));return File(root,id)}
    fun store(p:PackProject)=ProjectStore(folder(p.id).toPath())
    fun models(p:PackProject)=File(folder(p.id),"model-data.zip")
    fun importModels(p:PackProject,uri:Uri){
        val dir=folder(p.id);val staging=File(dir,"model-data.part")
        try{
            context.contentResolver.openInputStream(uri)?.use{input->staging.outputStream().use{out->
                val buffer=ByteArray(64*1024);var total=0L
                while(true){val n=input.read(buffer);if(n<0)break;total+=n;if(total>250L*1024*1024)throw IOException("MODEL_LARGE");out.write(buffer,0,n)}
            }}?:throw IOException("MODEL_INVALID")
            ZipFile(staging).use{zip->if(zip.entries().asSequence().none{it.name.endsWith(".geo.json")||it.name.contains("assets/minecraft/models/block/")})throw IOException("MODEL_INVALID")}
            java.nio.file.Files.move(staging.toPath(),models(p).toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        }finally{staging.delete()}
    }
    fun read(id:String):PackProject {
        val j=JSONObject(File(folder(id),"project.json").readText())
        return PackProject(id,j.getString("name"),gameProfiles.first{it.id==j.getString("profile")},j.getString("header"),j.getString("module"))
    }
    private fun write(p:PackProject) {
        val dir=folder(p.id).apply{mkdirs()};val tmp=File(dir,"project.tmp")
        tmp.writeText(JSONObject().put("name",p.name).put("profile",p.profile.id).put("header",p.header).put("module",p.module).toString())
        java.nio.file.Files.move(tmp.toPath(),File(dir,"project.json").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
    }
    fun legacy():PackProject {
        if(File(folder("local"),"project.json").exists())return read("local")
        return PackProject("local","My textures",gameProfiles[8],UUID.randomUUID().toString(),UUID.randomUUID().toString()).also{write(it)}
    }
    fun list()=root.listFiles()?.filter{it.isDirectory&&File(it,"project.json").exists()}?.mapNotNull{runCatching{read(it.name)}.getOrNull()}?.sortedBy{it.name}?:emptyList()
    fun create(name:String,profile:GameProfile,template:Boolean):PackProject {
        require(name.trim().isNotEmpty()&&name.length<=80)
        val p=PackProject(UUID.randomUUID().toString(),name.trim(),profile,UUID.randomUUID().toString(),UUID.randomUUID().toString())
        val dir=folder(p.id).apply{mkdirs()}
        try {
            if(template){
                val cache=templates.verifiedArchive(profile)
                val staging=File(dir,"base.part")
                cache.inputStream().use{input->java.io.FileOutputStream(staging).use{output->input.copyTo(output);output.fd.sync()}}
                java.nio.file.Files.move(staging.toPath(),File(dir,"base.zip").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
            }
            write(p);return p
        }catch(e:Exception){dir.deleteRecursively();throw e}
    }
    fun rename(p:PackProject,name:String):PackProject {
        require(name.trim().isNotEmpty()&&name.length<=80)
        return p.copy(name=name.trim()).also{write(it)}
    }
    /** Copy local documents and the prepared template. Never change the source pack UUIDs. */
    fun duplicate(p:PackProject,name:String):PackProject {
        require(name.trim().isNotEmpty()&&name.length<=80)
        val copy=p.copy(id=UUID.randomUUID().toString(),name=name.trim(),header=UUID.randomUUID().toString(),module=UUID.randomUUID().toString())
        val staging=File(root,"copy-${copy.id}")
        try{
            folder(p.id).copyRecursively(staging,overwrite=false)
            File(staging,"project.json").writeText(JSONObject().put("name",copy.name).put("profile",copy.profile.id).put("header",copy.header).put("module",copy.module).toString())
            java.nio.file.Files.move(staging.toPath(),folder(copy.id).toPath())
            return copy
        }finally{staging.deleteRecursively()}
    }
    private val trash=File(context.filesDir,"project-trash").apply{mkdirs();listFiles()?.filter{System.currentTimeMillis()-it.lastModified()>24*60*60*1000L}?.forEach{it.deleteRecursively()}}
    fun trash(p:PackProject):TrashedProject {
        val token=UUID.randomUUID().toString()
        java.nio.file.Files.move(folder(p.id).toPath(),File(trash,token).toPath())
        File(trash,token).setLastModified(System.currentTimeMillis())
        textureIndex.remove(p.id)
        return TrashedProject(p,token)
    }
    fun restore(deleted:TrashedProject):PackProject {
        require(deleted.token.matches(Regex("[a-f0-9-]{36}")))
        java.nio.file.Files.move(File(trash,deleted.token).toPath(),folder(deleted.project.id).toPath())
        textureIndex.remove(deleted.project.id)
        return read(deleted.project.id)
    }
    fun purge(deleted:TrashedProject){
        require(deleted.token.matches(Regex("[a-f0-9-]{36}")))
        if(!File(trash,deleted.token).deleteRecursively())throw IOException("PROJECT_DELETE")
    }
    /** A stored template can be opened without having any changed pixels. Count actual edits. */
    fun exportSummary(p:PackProject):ExportSummary {
        val bindings=paths(p);val s=store(p)
        val file=File(folder(p.id),"base.zip")
        val base=if(file.exists())ZipFile(file)else null
        try{
            val originals=base?.entries()?.asSequence()?.filter{!it.isDirectory&&it.name.endsWith(".png")&&!TemplateArchive.isPbr(it.name)}?.map{it.name}?.toSet()?:emptySet()
            val edited=mutableSetOf<String>()
            for(key in s.list()){
                val doc=s.open(key);val path=bindings.getProperty(key)?:PackExport.path(doc,if(p.profile.java)PackExport.Target.JAVA_LABPBR else PackExport.Target.BEDROCK_VV)+".png"
                val entry=base?.getEntry(path)
                var different=true
                if(entry!=null){
                    val bitmap=base.getInputStream(entry).use{BitmapFactory.decodeStream(it)}
                    if(bitmap!=null)try{
                        if(bitmap.width==doc.width&&bitmap.height==doc.height){
                            val pixels=IntArray(doc.width*doc.height);bitmap.getPixels(pixels,0,doc.width,0,0,doc.width,doc.height)
                            different=!pixels.contentEquals(doc.composite(MaterialDocument.Channel.COLOR))
                        }
                    }finally{bitmap.recycle()}
                }
                if(different)edited.add(path)
            }
            return ExportSummary(edited.size,(originals-edited).size)
        }finally{base?.close()}
    }
    fun textures(p:PackProject):List<TemplateTexture> {
        textureIndex[p.id]?.let{return it}
        val file=File(folder(p.id),"base.zip");if(!file.exists())return emptyList()
        val result=mutableListOf<TemplateTexture>()
        ZipFile(file).use{zip->zip.entries().asSequence().filter{it.name.endsWith(".png")}.forEach{entry->
            zip.getInputStream(entry).use{input->
                val b=java.io.DataInputStream(input)
                if(entry.size>=24&&b.readLong()==0x89504e470d0a1a0aUL.toLong()&&b.readInt()==13&&b.readInt()==0x49484452)
                    result.add(TemplateTexture(entry.name,b.readInt(),b.readInt()))
            }
        }};return result.sortedBy{it.path}.also{textureIndex[p.id]=it}
    }
    fun paths(p:PackProject)=Properties().also{v->File(folder(p.id),"paths.properties").takeIf{it.exists()}?.inputStream()?.use{v.load(it)}}
    /** Preview loading must not resize or overwrite another edited face. */
    fun openBoundTexture(p:PackProject,t:TemplateTexture):MaterialDocument {
        val key=paths(p).entries.firstOrNull{it.value==t.path}?.key?.toString()
        if(key!=null && key in store(p).list())return store(p).open(key)
        return openTexture(p,t)
    }
    fun openTexture(p:PackProject,t:TemplateTexture,targetSize:Int=t.width):MaterialDocument {
        require(t.editable&&targetSize in t.sizes())
        val targetHeight=targetSize*t.height/t.width
        val raw=t.path.substringAfter("textures/").removeSuffix(".png")
        val name=if(raw.matches(Regex("[a-z0-9_][a-z0-9_/-]{0,95}")))raw else "template_"+UUID.nameUUIDFromBytes(t.path.toByteArray()).toString()
        val kind=when(raw.substringBefore('/')){"block","blocks"->MaterialDocument.Kind.BLOCK;"item","items"->MaterialDocument.Kind.ITEM;"gui","ui"->MaterialDocument.Kind.UI;"particle"->MaterialDocument.Kind.PARTICLE;else->MaterialDocument.Kind.ENTITY}
        val s=store(p);val key=ProjectStore.key(kind,name)
        if(key in s.list()){
            val existing=s.open(key)
            if(existing.width==targetSize&&existing.height==targetHeight)return existing
            val resized=existing.resized(targetSize,targetHeight);s.save(resized);return resized
        }
        val doc=MaterialDocument(name,kind,targetSize,targetHeight)
        ZipFile(File(folder(p.id),"base.zip")).use{zip->
            val bitmap=zip.getInputStream(zip.getEntry(t.path)).use{BitmapFactory.decodeStream(it)}?:error("PNG_SIZE")
            try{val source=IntArray(t.width*t.height);bitmap.getPixels(source,0,t.width,0,0,t.width,t.height)
                val pixels=IntArray(targetSize*targetHeight){i->source[(i/targetSize*t.height/targetHeight)*t.width+(i%targetSize*t.width/targetSize)]}
                doc.replacePlane(0,MaterialDocument.Channel.COLOR,pixels);doc.clearHistory()}
            finally{bitmap.recycle()}
        }
        val paths=paths(p).apply{setProperty(key,t.path)};val tmp=File(folder(p.id),"paths.tmp")
        tmp.outputStream().use{paths.store(it,"Original texture paths")}
        java.nio.file.Files.move(tmp.toPath(),File(folder(p.id),"paths.properties").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        s.save(doc);return doc
    }
    fun previewFaces(p:PackProject,doc:MaterialDocument):FaceMaps?{
        val base=File(folder(p.id),"base.zip");if(!base.isFile)return null
        val path=paths(p).getProperty(ProjectStore.key(doc.kind,doc.name))?:return null
        val prefix=path.substringBeforeLast('/')+'/';val file=path.substringAfterLast('/').removeSuffix(".png")
        val stripped=file.replace(Regex("(_top|_bottom|_side|_front|_back|_north|_south|_east|_west)(_overlay)?$"),"")
        val role=when{file.endsWith("_top")->1;file.endsWith("_bottom")->3;file.contains("_side")->2;else->0}
        val shape=when(doc.kind){
            MaterialDocument.Kind.BLOCK->"minecraft:"+if(stripped=="grass")"grass_block" else stripped
            MaterialDocument.Kind.ITEM->"item:$stripped"
            MaterialDocument.Kind.UI->"ui:$stripped"
            MaterialDocument.Kind.PARTICLE->"particle:$stripped"
            else->"entity:$stripped"
        }
        val empty=IntArray(doc.width*doc.height)
        ZipFile(base).use{zip->
            fun read(vararg names:String):IntArray?{
                val entry=names.firstNotNullOfOrNull{n->zip.getEntry(prefix+n+".png")}
                    ?:return null
                val bitmap=zip.getInputStream(entry).use{BitmapFactory.decodeStream(it)}?:return null
                try{
                    val raw=IntArray(bitmap.width*bitmap.height);bitmap.getPixels(raw,0,bitmap.width,0,0,bitmap.width,bitmap.height)
                    return IntArray(doc.width*doc.height){i->raw[(i/doc.width*bitmap.height/doc.height)*bitmap.width+(i%doc.width*bitmap.width/doc.width)]}
                }finally{bitmap.recycle()}
            }
            val selected=doc.composite(MaterialDocument.Channel.COLOR)
            val top=read(stripped+"_top",file)?:selected
            val side=read(stripped+"_side",stripped+"_side_carried",file)?:selected
            val bottom=read(stripped+"_bottom",if(stripped=="grass"||stripped=="grass_block")"dirt" else file)?:selected
            return FaceMaps(top,side,bottom,role,shape)
        }
    }
    @JvmOverloads fun export(p:PackProject,output:File,colorOnly:Boolean=false) {
        val s=store(p);val keys=s.list();val bindings=paths(p)
        val target=if(p.profile.java)PackExport.Target.JAVA_LABPBR else PackExport.Target.BEDROCK_VV
        val edited=File.createTempFile("edited-",".zip",context.cacheDir)
        try {
            PackExport.export(s,keys,target,p.profile.format,edited.outputStream(),null,colorOnly)
            val remap=mutableMapOf<String,String>()
            for(key in keys){val original=bindings.getProperty(key)?:continue;val doc=s.open(key);val old=PackExport.path(doc,target);val path=original.removeSuffix(".png")
                for(suffix in listOf(".png","_n.png","_s.png","_normal.png","_mers.png",".texture_set.json"))remap[old+suffix]=path+suffix
            }
            ZipOutputStream(output.outputStream()).use{out->
                val names=mutableSetOf<String>()
                fun put(name:String,bytes:ByteArray){check(names.add(name));out.putNextEntry(ZipEntry(name));out.write(bytes);out.closeEntry()}
                val info=if(p.profile.java){val fmt=JSONObject().put("description",p.name)
                    if(p.profile.format>=65){fmt.put("min_format",JSONArray(listOf(p.profile.format,0)));fmt.put("max_format",JSONArray(listOf(p.profile.format,0)))}else fmt.put("pack_format",p.profile.format)
                    "pack.mcmeta" to JSONObject().put("pack",fmt)
                }else {
                    val engine=if(p.profile.version=="26.30")listOf(1,26,30)else p.profile.version.split('.').map{it.toInt()}
                    val header=JSONObject().put("name",p.name).put("description","MCTS resource pack").put("uuid",p.header).put("version",JSONArray(listOf(1,0,0))).put("min_engine_version",JSONArray(engine))
                    val module=JSONObject().put("type","resources").put("uuid",p.module).put("version",JSONArray(listOf(1,0,0)))
                    val manifest=JSONObject().put("format_version",2).put("header",header).put("modules",JSONArray().put(module))
                    if(p.profile.vv&&!colorOnly)manifest.put("capabilities",JSONArray(listOf("pbr")))
                    "manifest.json" to manifest
                };put(info.first,info.second.toString(2).toByteArray())
                ZipFile(edited).use{zip->zip.entries().asSequence().forEach{entry->
                    if(entry.name in listOf("manifest.json","pack.mcmeta","mcts_export_report.txt"))return@forEach
                    if(!p.profile.java&&!p.profile.vv&&!entry.name.endsWith(".png"))return@forEach
                    if(!p.profile.java&&!p.profile.vv&&(entry.name.endsWith("_mers.png")||entry.name.endsWith("_normal.png")))return@forEach
                    val name=remap[entry.name]?:entry.name
                    var bytes=zip.getInputStream(entry).use{it.readBytes()}
                    if(name.endsWith(".texture_set.json")){
                        val stem=name.substringAfterLast('/').removeSuffix(".texture_set.json")
                        bytes=JSONObject().put("format_version","1.21.30").put("minecraft:texture_set",JSONObject().put("color",stem).put("normal",stem+"_normal").put("metalness_emissive_roughness_subsurface",stem+"_mers")).toString().toByteArray()
                    };put(name,bytes)
                }}
                val base=File(folder(p.id),"base.zip")
                if(base.exists())ZipFile(base).use{zip->zip.entries().asSequence().filter{!it.isDirectory&&it.name !in names&&(!colorOnly||!TemplateArchive.isPbr(it.name))}.forEach{entry->
                    names.add(entry.name);out.putNextEntry(ZipEntry(entry.name));zip.getInputStream(entry).use{it.copyTo(out)};out.closeEntry()
                }}
                put("mcts_export_report.txt",("MCTS ${BuildConfig.VERSION_NAME} · ${p.profile.label}\nAll edits and untouched template textures. Original model/animation behavior is supplied by the game.\n"+
                    if(colorOnly)"Color-only resource pack. No normal, height, MER or LabPBR maps generated." else if(!p.profile.java&&!p.profile.vv)"Historical Bedrock: color resources only. PBR remains in the local project. No RenderDragon shader binaries generated." else "Material preview is not an in-game compatibility test. No shader binary compilation.").toByteArray())
            }
        }finally{edited.delete()}
    }
}
