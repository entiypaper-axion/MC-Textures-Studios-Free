package com.mcts.studio

import android.content.res.AssetManager
import org.json.JSONObject

internal fun Language.catalogueIndex()=when(this){Language.EN->0;Language.ZH->1;Language.JA->2;Language.FR->3;Language.ES->4}

/** Compact semantic index: texture paths and labels, never game executables/models. */
data class BlockAsset(val id:String,val names:List<String>,val faces:List<String>,val paths:List<String>,val overlays:List<String?>,val tints:List<Boolean>) {
    fun label(language:Language)= "$id · ${names.getOrElse(language.catalogueIndex()){names.first()}}"
    val category get()=TemplateCategory.of("textures/block/$id.png").let { category->
        if(category==TemplateCategory.SINGLE_BLOCK&&faces.distinct().size>1)TemplateCategory.MULTI_BLOCK else category
    }
}
class BlockCatalogue(assets:AssetManager,profile:String){
    private val json=assets.open("catalogue/$profile.json").bufferedReader().use{JSONObject(it.readText())}
    val blocks:List<BlockAsset>
    private val labels=json.getJSONObject("labels")
    init {
        val array=json.getJSONArray("groups")
        val directions=listOf("up","south","down","north","west","east")
        blocks=(0 until array.length()).map{index->val o=array.getJSONObject(index)
            val names=o.getJSONArray("names");val paths=o.getJSONArray("paths");val faces=o.getJSONObject("faces")
            val overlays=o.optJSONObject("overlays");val tints=o.optJSONObject("tints")
            BlockAsset(o.getString("id"),(0 until names.length()).map{names.getString(it)},directions.map{faces.getString(it)},(0 until paths.length()).map{paths.getString(it)},directions.map{overlays?.optString(it)?.takeIf{p->p.isNotBlank()}},directions.map{tints?.optBoolean(it,false)?:false})
        }
    }
    fun find(path:String):BlockAsset?{
        val raw=path.substringAfterLast('/').removeSuffix(".png")
        val stem=raw.replace(Regex("_(top|bottom|side|front|back|overlay)$"),"")
        val aliases=mapOf("grass" to "grass_block","log_oak" to "oak_log","log_spruce" to "spruce_log","log_birch" to "birch_log","planks_oak" to "oak_planks")
        val id=aliases[stem]?:stem
        return blocks.firstOrNull{it.id==raw&&path in it.paths}?:blocks.firstOrNull{it.id==id&&path in it.paths}?:blocks.filter{path in it.paths}.minByOrNull{if(it.category==TemplateCategory.PARTIAL_BLOCK)10+it.paths.size else it.paths.size}
    }
    fun label(path:String,language:Language):String{
        val original=path.substringAfterLast('/').removeSuffix(".png")
        val names=labels.optJSONArray(path)
        val name=names?.optString(language.catalogueIndex())?.takeIf{it.isNotBlank()}?:original.replace('_',' ')
        return "$original · $name"
    }
}
