package com.mcts.studio
import android.graphics.Bitmap
import androidx.compose.ui.graphics.luminance
import com.mcts.core.*
import java.io.File
import java.util.zip.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ReleasePolishTest {
    @Test fun reflectedStrokeIsOneUndoOnRectangularTexture(){
        val doc=MaterialDocument("mirror",MaterialDocument.Kind.ENTITY,16,32)
        val before=doc.composite(MaterialDocument.Channel.COLOR).clone()
        doc.beginStroke(0,MaterialDocument.Channel.COLOR)
        SymmetryBrush.paint(doc,2,3,0xff12abcd.toInt(),true,true)
        SymmetryBrush.paint(doc,4,5,0xff12abcd.toInt(),true,true)
        doc.endStroke()
        val after=doc.composite(MaterialDocument.Channel.COLOR).clone()
        listOf(2 to 3,13 to 3,2 to 28,13 to 28,4 to 5,11 to 26).forEach{(x,y)->assertEquals(0xff12abcd.toInt(),after[y*16+x])}
        doc.undo();assertArrayEquals(before,doc.composite(MaterialDocument.Channel.COLOR));assertFalse(doc.canUndo())
        doc.redo();assertArrayEquals(after,doc.composite(MaterialDocument.Channel.COLOR))
        SymmetryBrush.paint(doc,-1,3,0xff000000.toInt(),true,true)
        assertArrayEquals(after,doc.composite(MaterialDocument.Channel.COLOR))
    }
    @Test fun renameDuplicateDeleteAndRestoreKeepProjectsIndependent(){
        val projects=Projects(RuntimeEnvironment.getApplication())
        val p=projects.create("Original",gameProfiles[2],false)
        val doc=MaterialDocument("stone",MaterialDocument.Kind.BLOCK,16,16)
        doc.fill(0,MaterialDocument.Channel.COLOR,0xff765432.toInt());projects.store(p).save(doc)
        val renamed=projects.rename(p,"Renamed")
        assertEquals(p.id,renamed.id);assertEquals("Renamed",projects.read(p.id).name)
        val copy=projects.duplicate(renamed,"Copy")
        assertNotEquals(p.id,copy.id);assertNotEquals(p.header,copy.header);assertNotEquals(p.module,copy.module)
        val key=ProjectStore.key(doc.kind,doc.name)
        assertArrayEquals(doc.composite(MaterialDocument.Channel.COLOR),projects.store(copy).open(key).composite(MaterialDocument.Channel.COLOR))
        val changed=projects.store(copy).open(key);changed.fill(0,MaterialDocument.Channel.COLOR,0xffeeeeee.toInt());projects.store(copy).save(changed)
        assertArrayEquals(doc.composite(MaterialDocument.Channel.COLOR),projects.store(renamed).open(key).composite(MaterialDocument.Channel.COLOR))
        val removed=projects.trash(renamed)
        assertFalse(projects.list().any{it.id==p.id});assertTrue(projects.list().any{it.id==copy.id})
        assertEquals(p.id,projects.restore(removed).id)
        assertArrayEquals(doc.composite(MaterialDocument.Channel.COLOR),projects.store(renamed).open(key).composite(MaterialDocument.Channel.COLOR))
        projects.purge(projects.trash(copy));assertFalse(projects.folder(copy.id).exists())
        try{projects.rename(renamed," ");fail("Blank name accepted")}catch(expected:IllegalArgumentException){}
    }
    @Test fun exportSummaryCountsActualPixelChangesAndNewFiles(){
        val projects=Projects(RuntimeEnvironment.getApplication())
        val p=projects.create("Summary",gameProfiles[2],false)
        val bitmap=Bitmap.createBitmap(16,16,Bitmap.Config.ARGB_8888);bitmap.eraseColor(0xffaabbcc.toInt())
        val bytes=java.io.ByteArrayOutputStream().also{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}.toByteArray();bitmap.recycle()
        val path="assets/minecraft/textures/block/stone.png"
        ZipOutputStream(File(projects.folder(p.id),"base.zip").outputStream()).use{out->for(name in listOf(path,path.replace("stone","dirt"))){out.putNextEntry(ZipEntry(name));out.write(bytes);out.closeEntry()}}
        val texture=TemplateTexture(path,16,16)
        val doc=projects.openTexture(p,texture)
        assertEquals(ExportSummary(0,2),projects.exportSummary(p))
        doc.beginStroke(0,MaterialDocument.Channel.COLOR);doc.paint(0,0,0xff445566.toInt());doc.endStroke();projects.store(p).save(doc)
        assertEquals(ExportSummary(1,1),projects.exportSummary(p))
        projects.store(p).save(MaterialDocument("extra",MaterialDocument.Kind.ITEM,16,16))
        assertEquals(ExportSummary(2,1),projects.exportSummary(p))
        val file=File(RuntimeEnvironment.getApplication().cacheDir,"summary.zip");projects.export(p,file,true)
        ZipFile(file).use{assertEquals(3,it.entries().asSequence().count{e->e.name.endsWith(".png")})}
    }
    @Test fun diagnosticsContainOnlyAllowedFieldsAndThemeColorsHaveContrast(){
        val diagnostic=Diagnostics.report("1.0.0-Release-Fr",31000,"Maker","Model","15",35,"EN","EXPORT_PERMISSION")
        assertTrue(diagnostic.contains("EXPORT_PERMISSION"));assertTrue(diagnostic.contains("API 35"))
        assertFalse(diagnostic.contains("/data/"));assertFalse(diagnostic.contains("project.json"))
        val scheme=freeDarkColors()
        for(bg in listOf(scheme.surface,scheme.background,scheme.primaryContainer,scheme.surfaceContainerHigh)){
            val contrast=(scheme.onSurface.luminance()+.05f)/(bg.luminance()+.05f)
            assertTrue("Dark theme text contrast=$contrast",contrast>=4.5f)
        }
    }
}
