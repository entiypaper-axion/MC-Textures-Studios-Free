import groovy.json.JsonSlurper
import java.util.zip.ZipFile
import java.util.zip.CRC32
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.mcts.studio"
    compileSdk = 35
    defaultConfig {
        // Free suffix gives an independent ID. Keep it and the signing key stable for upgrades.
        applicationId = "com.axion.pompreview.studio3"
        minSdk = 26
        targetSdk = 35
        versionCode = 31000
        versionName = "1.0.0-Release"
    }
    flavorDimensions += "edition"
    productFlavors {
        create("free") {
            dimension="edition"
            applicationIdSuffix=".free"
            versionNameSuffix="-Fr"
            buildConfigField("boolean","IS_FREE","true")
            manifestPlaceholders["appLabel"]="MCTS Free"
        }
    }
    buildFeatures { compose = true; buildConfig = true }
    testOptions { unitTests.isIncludeAndroidResources = true }
    signingConfigs.getByName("debug") {
        enableV1Signing=true;enableV2Signing=true;enableV3Signing=true
        System.getenv("MCTS_SIGNING_KEY")?.let {
            storeFile=file(it);storePassword=System.getenv("MCTS_SIGNING_PASSWORD")
            keyAlias="mcts";keyPassword=System.getenv("MCTS_SIGNING_PASSWORD")
        }
    }
    buildTypes.getByName("release") {
        isDebuggable=false
        isMinifyEnabled=false
        signingConfig=signingConfigs.getByName("debug")
    }
    androidResources { ignoreAssetsPattern = "!*.tmp:!*.part:!.git:!.svn:!CVS:!*~" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(project(":core"))
    implementation(platform("androidx.compose:compose-bom:2025.04.01"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("dev.chrisbanes.haze:haze:1.6.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
    testImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}

val verifyTemplateAssets by tasks.registering {
    doLast {
        val dir=file("src/main/assets/templates")
        check(dir.listFiles()?.map{it.name}?.toSet()==setOf("sources.json")) { "Official textures or staging files must not be bundled." }
        val records=JsonSlurper().parse(file("src/main/assets/templates/sources.json")) as List<*>
        check(records.size==10)
        records.forEach{val row=it as Map<*,*>;check((row["urls"] as List<*>).isNotEmpty());check((row["urls"] as List<*>).all{(it as String).startsWith("https://")});check((row["size_bytes"] as Number).toLong() in 1..512L*1024*1024);check((row["url"] as String).startsWith("https://"));check((row["source_sha256"] as String).matches(Regex("[a-f0-9]{64}")))}
        check(file("src/main/assets/fonts/LXGWWenKai-Regular.ttf").length()<8L*1024*1024){"Font must be subset from actual app text."}
        logger.lifecycle("Verified 10 pinned download sources; no bundled official texture ZIPs.")
    }
}
tasks.named("preBuild").configure { dependsOn(verifyTemplateAssets) }
tasks.matching { it.name.matches(Regex("assemble(Full|Free)(Release|Debug)")) }.configureEach {
    doLast {
        val edition=if(name.contains("Full"))"full" else "free"
        val variant=if(name.endsWith("Release"))"release" else "debug"
        val apk=layout.buildDirectory.file("outputs/apk/$edition/$variant/app-$edition-$variant.apk").get().asFile
        ZipFile(apk).use{zip->
            check(zip.entries().asSequence().none{it.name.endsWith(".tmp")||it.name.endsWith(".part")})
            check(zip.entries().asSequence().none{it.name.startsWith("assets/templates/")&&it.name.endsWith(".zip")})
        }
        logger.lifecycle("Verified $edition APK: no bundled official textures; zero staging files.")
    }
}
