package com.mcts.core;

import java.util.*;

/** Renderer-independent document. Never exposes writable source or baseline arrays. */
public final class MaterialDocument {
    public enum Kind { BLOCK, ITEM, ENTITY, MODEL_TEXTURE, ATTACHABLE_TEXTURE, FLIPBOOK, PARTICLE, UI }
    /** Normal XY use DirectX orientation; roughness is perceptual, not squared. */
    public enum Channel { COLOR, NORMAL, HEIGHT, METALNESS, EMISSIVE, ROUGHNESS, SUBSURFACE, AO, F0, POROSITY }
    public static final int MAX_LAYERS = 16;
    private static final long HISTORY_BUDGET = 32L * 1024 * 1024;
    public final int width, height;
    public final String name;
    public final Kind kind;
    private final List<Layer> layers = new ArrayList<>();
    private final Deque<Change> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
    private long historyBytes, revision;
    private Stroke stroke;
    private Layer opacityTarget;
    private float opacityBefore;
    private final EnumMap<Channel, CachedPlane> composites = new EnumMap<>(Channel.class);
    private static final class CachedPlane {
        final long revision; final int[] pixels;
        CachedPlane(long revision, int[] pixels) { this.revision=revision; this.pixels=pixels; }
    }

    public static final class Layer {
        public final String name;
        boolean visible = true;
        float opacity = 1f;
        final EnumMap<Channel, int[]> planes = new EnumMap<>(Channel.class);
        Layer(String name) { this.name = name; }
        public boolean isVisible() { return visible; }
        public float getOpacity() { return opacity; }
    }

    public MaterialDocument(String name, Kind kind, int width, int height) {
        if (name == null || !name.matches("[a-z0-9_][a-z0-9_/-]{0,95}") || name.contains(".."))
            throw new IllegalArgumentException("INVALID_NAME");
        if (!validSize(width) || !validSize(height)) throw new IllegalArgumentException("INVALID_SIZE");
        this.name = name; this.kind = Objects.requireNonNull(kind); this.width = width; this.height = height;
        layers.add(new Layer("Base"));
    }

    private static boolean validSize(int value) { return value >= 16 && value <= 512 && (value & (value-1)) == 0; }
    public long getRevision() { return revision; }
    public List<Layer> getLayers() { return Collections.unmodifiableList(layers); }
    public boolean canUndo() { return !undo.isEmpty(); }
    public boolean canRedo() { return !redo.isEmpty(); }
    public long getHistoryBytes() { return historyBytes; }

    public int addLayer(String name) {
        endStroke();
        if (layers.size() == MAX_LAYERS) throw new IllegalStateException("LAYER_LIMIT");
        final Layer layer = new Layer(name); final int at = layers.size();
        layers.add(layer);
        record(new Change(128) {
            void back() { layers.remove(layer); }
            void forward() { layers.add(at, layer); }
        });
        return at;
    }

    public void setVisible(int layerIndex, final boolean value) {
        endStroke(); final Layer layer = layers.get(layerIndex); final boolean old = layer.visible;
        if (old == value) return;
        layer.visible = value;
        record(new Change(32) {
            void back() { layer.visible = old; }
            void forward() { layer.visible = value; }
        });
    }

    public void setOpacity(int layerIndex, float opacity) {
        endStroke(); final Layer layer = layers.get(layerIndex);
        final float old = layer.opacity, value = Math.max(0f, Math.min(1f, opacity));
        if (!Float.isFinite(opacity)) throw new IllegalArgumentException("INVALID_OPACITY");
        if (old == value) return;
        layer.opacity = value;
        record(new Change(32) {
            void back() { layer.opacity = old; }
            void forward() { layer.opacity = value; }
        });
    }

    /** Live opacity feedback with one history item for the entire slider gesture. */
    public void previewOpacity(int index,float value) {
        if(!Float.isFinite(value))throw new IllegalArgumentException("INVALID_OPACITY");
        Layer layer=layers.get(index);
        if(opacityTarget!=layer){endStroke();opacityTarget=layer;opacityBefore=layer.opacity;}
        float next=Math.max(0f,Math.min(1f,value));
        if(next!=layer.opacity){layer.opacity=next;revision++;}
    }
    public void finishOpacity() {
        if(opacityTarget==null)return;
        final Layer layer=opacityTarget;final float before=opacityBefore,after=layer.opacity;opacityTarget=null;
        if(before!=after)record(new Change(32){void back(){layer.opacity=before;}void forward(){layer.opacity=after;}});
    }

    /** One complete drag is one undo item, not one item per touch event. */
    public void beginStroke(int layer, Channel channel) {
        endStroke(); stroke = new Stroke(layers.get(layer), channel, width*height);
    }
    public void paint(int x, int y, int argb) {
        if (stroke == null) throw new IllegalStateException("NO_STROKE");
        if (x < 0 || y < 0 || x >= width || y >= height) return;
        int i = y * width + x;
        int[] plane = plane(stroke.layer, stroke.channel);
        if (plane[i] == argb) return;
        if (!stroke.touched.get(i)) { stroke.touched.set(i); stroke.before[i]=plane[i]; }
        plane[i] = argb;
        revision++;
    }
    public void endStroke() {
        finishOpacity();
        if (stroke == null) return;
        final Stroke current = stroke; stroke = null;
        if (current.touched.isEmpty()) return;
        final int[] indices = new int[current.touched.cardinality()], before = new int[indices.length], after = new int[indices.length];
        final int[] plane = plane(current.layer, current.channel);
        int position = 0;
        for (int i=current.touched.nextSetBit(0); i>=0; i=current.touched.nextSetBit(i+1)) {
            indices[position]=i; before[position]=current.before[i]; after[position]=plane[i]; position++;
        }
        record(new Change(64L + indices.length * 12L) {
            void apply(int[] values) { for (int i=0;i<indices.length;i++) plane[indices[i]] = values[i]; }
            void back() { apply(before); }
            void forward() { apply(after); }
        });
    }

    /** A gesture that turns into a pinch must leave no stray paint or undo item. */
    public void cancelStroke() {
        if (stroke == null) return;
        final Stroke current=stroke; stroke=null;
        int[] pixels=plane(current.layer,current.channel);
        for(int i=current.touched.nextSetBit(0);i>=0;i=current.touched.nextSetBit(i+1))pixels[i]=current.before[i];
        if(!current.touched.isEmpty())revision++;
    }

    /** Full-plane commands use primitive snapshots, avoiding boxed pixel maps. */
    public void fill(int layerIndex, Channel channel, int argb) {
        int[] pixels = new int[width * height]; Arrays.fill(pixels, argb);
        replacePlane(layerIndex, channel, pixels);
    }
    public void replacePlane(int layerIndex, final Channel channel, int[] pixels) {
        endStroke(); if (pixels.length != width*height) throw new IllegalArgumentException("PIXEL_COUNT");
        final Layer layer = layers.get(layerIndex);
        final int[] old = layer.planes.get(channel);
        final int[] replacement = pixels.clone();
        if (Arrays.equals(old, replacement)) return;
        layer.planes.put(channel, replacement);
        record(new Change(64L + (replacement.length + (old == null ? 0 : old.length))*4L) {
            void back() { if (old == null) layer.planes.remove(channel); else layer.planes.put(channel, old); }
            void forward() { layer.planes.put(channel, replacement); }
        });
    }

    public void undo() {
        endStroke(); if (undo.isEmpty()) return;
        Change change = undo.removeLast(); change.back(); redo.addLast(change); revision++;
    }
    public void redo() {
        endStroke(); if (redo.isEmpty()) return;
        Change change = redo.removeLast(); change.forward(); undo.addLast(change); revision++;
    }
    public void clearHistory() { endStroke(); undo.clear(); redo.clear(); historyBytes = 0; }
    private void record(Change change) {
        for (Change abandoned : redo) historyBytes -= abandoned.bytes;
        redo.clear(); undo.addLast(change); historyBytes += change.bytes; revision++;
        while (historyBytes > HISTORY_BUDGET && undo.size() > 1) historyBytes -= undo.removeFirst().bytes;
    }

    public int[] composite(Channel channel) {
        CachedPlane cached=composites.get(channel);
        if(cached!=null && cached.revision==revision)return cached.pixels.clone();
        int[] result = new int[width*height]; Arrays.fill(result, defaultPixel(channel));
        for (Layer layer : layers) {
            int[] source = layer.planes.get(channel);
            if (!layer.visible || layer.opacity <= 0 || source == null) continue;
            for (int i=0;i<result.length;i++) result[i] = over(result[i], source[i], layer.opacity);
        }
        composites.put(channel,new CachedPlane(revision,result));
        return result.clone();
    }
    /** Resample every layer and channel with nearest-neighbour pixels, preserving editable layers. */
    public MaterialDocument resized(int newWidth, int newHeight) {
        MaterialDocument out=new MaterialDocument(name,kind,newWidth,newHeight);
        out.layers.clear();
        for(Layer source:layers){
            Layer layer=new Layer(source.name);layer.visible=source.visible;layer.opacity=source.opacity;
            for(Map.Entry<Channel,int[]> plane:source.planes.entrySet()){
                int[] pixels=new int[newWidth*newHeight],old=plane.getValue();
                for(int y=0;y<newHeight;y++)for(int x=0;x<newWidth;x++)
                    pixels[y*newWidth+x]=old[(y*height/newHeight)*width+x*width/newWidth];
                layer.planes.put(plane.getKey(),pixels);
            }
            out.layers.add(layer);
        }
        return out;
    }
    static int over(int dst, int src, float opacity) {
        float sa = (src >>> 24) / 255f * opacity, da = (dst >>> 24) / 255f;
        float alpha = sa + da * (1-sa);
        if (alpha <= 0) return 0;
        int out = Math.round(alpha * 255) << 24;
        for (int shift=16; shift>=0; shift-=8) {
            float value = (((src >>> shift)&255)*sa + ((dst >>> shift)&255)*da*(1-sa))/alpha;
            out |= Math.min(255, Math.round(value)) << shift;
        }
        return out;
    }
    static int defaultPixel(Channel channel) {
        switch (channel) {
            case COLOR: return 0;
            case NORMAL: return 0xff8080ff;
            case HEIGHT: return 0xff808080;
            case ROUGHNESS: return 0xffbfbfbf;
            case AO: return 0xffffffff;
            case F0: return 0xff0a0a0a;
            default: return 0xff000000;
        }
    }
    private int[] plane(Layer layer, Channel channel) {
        int[] existing = layer.planes.get(channel);
        if (existing == null) { existing = new int[width*height]; layer.planes.put(channel, existing); }
        return existing;
    }
    void restoreLayer(String name, boolean visible, float opacity, Map<Channel,int[]> planes) {
        if (layers.size() >= MAX_LAYERS) throw new IllegalArgumentException("LAYER_LIMIT");
        Layer layer = new Layer(name); layer.visible = visible; layer.opacity = opacity;
        for (Map.Entry<Channel,int[]> entry : planes.entrySet()) layer.planes.put(entry.getKey(), entry.getValue().clone());
        layers.add(layer);
    }
    void clearLayersForRestore() { layers.clear(); }
    private abstract static class Change {
        final long bytes;
        Change(long bytes) { this.bytes = bytes; }
        abstract void back(); abstract void forward();
    }
    private static final class Stroke {
        final Layer layer; final Channel channel;
        final int[] before;
        final BitSet touched=new BitSet();
        Stroke(Layer layer, Channel channel, int count) { this.layer = layer; this.channel = channel; before=new int[count]; }
    }
}
