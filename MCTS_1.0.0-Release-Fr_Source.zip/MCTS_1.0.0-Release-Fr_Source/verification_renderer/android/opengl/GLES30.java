package android.opengl;
import java.nio.*;
import java.util.*;
public class GLES30 {
public static final int GL_ARRAY_BUFFER=1;
public static final int GL_BACK=2;
public static final int GL_COLOR_BUFFER_BIT=3;
public static final int GL_COMPILE_STATUS=4;
public static final int GL_CULL_FACE=5;
public static final int GL_DEPTH_BUFFER_BIT=6;
public static final int GL_DEPTH_TEST=7;
public static final int GL_DYNAMIC_DRAW=8;
public static final int GL_FLOAT=9;
public static final int GL_FRAGMENT_SHADER=10;
public static final int GL_LEQUAL=11;
public static final int GL_LINK_STATUS=12;
public static final int GL_NEAREST=13;
public static final int GL_REPEAT=14;
public static final int GL_RGBA=15;
public static final int GL_RGBA8=16;
public static final int GL_TEXTURE0=17;
public static final int GL_TEXTURE1=18;
public static final int GL_TEXTURE2=19;
public static final int GL_TEXTURE_2D_ARRAY=20;
public static final int GL_TEXTURE_MAG_FILTER=21;
public static final int GL_TEXTURE_MIN_FILTER=22;
public static final int GL_TEXTURE_WRAP_S=23;
public static final int GL_TEXTURE_WRAP_T=24;
public static final int GL_TRIANGLES=25;
public static final int GL_UNSIGNED_BYTE=26;
public static final int GL_VERTEX_SHADER=27;
 public static int next=1,bound,storageCalls,faceCalls;
 public static final Map<Integer,byte[][]> data=new HashMap<>();
 public static void glGenTextures(int n,int[] out,int at){for(int i=0;i<n;i++)out[at+i]=next++;}
 public static void glGenBuffers(int n,int[] out,int at){glGenTextures(n,out,at);}
 public static void glGenVertexArrays(int n,int[] out,int at){glGenTextures(n,out,at);}
 public static void glBindTexture(int target,int id){bound=id;}
 public static void glTexImage3D(int target,int level,int format,int width,int height,int depth,int border,int rgba,int type,Buffer bytes){storageCalls++;data.put(bound,new byte[depth][]);}
 public static void glTexSubImage3D(int target,int level,int x,int y,int layer,int width,int height,int depth,int rgba,int type,Buffer bytes){faceCalls++;ByteBuffer b=((ByteBuffer)bytes).duplicate();byte[] pixels=new byte[b.remaining()];b.get(pixels);data.get(bound)[layer]=pixels;}
 public static int glCreateShader(int type){return next++;}
 public static int glCreateProgram(){return next++;}
 public static int glGetUniformLocation(int program,String name){return 1;}
 public static void glGetShaderiv(int shader,int name,int[] out,int at){out[at]=1;}
 public static void glGetProgramiv(int program,int name,int[] out,int at){out[at]=1;}
 public static String glGetShaderInfoLog(int shader){return "";}
 public static String glGetProgramInfoLog(int program){return "";}
 public static void glClearColor(float a,float b,float c,float d){}
 public static void glEnable(int a){}
 public static void glDepthFunc(int a){}
 public static void glCullFace(int a){}
 public static void glBindVertexArray(int a){}
 public static void glBindBuffer(int a,int b){}
 public static void glBufferData(int a,int b,Buffer c,int d){}
 public static void glEnableVertexAttribArray(int a){}
 public static void glVertexAttribPointer(int a,int b,int c,boolean d,int e,int f){}
 public static void glTexParameteri(int a,int b,int c){}
 public static void glUseProgram(int a){}
 public static void glUniform1i(int a,int b){}
 public static void glUniform1f(int a,float b){}
 public static void glUniform3f(int a,float b,float c,float d){}
 public static void glUniformMatrix4fv(int a,int b,boolean c,float[] d,int e){}
 public static void glViewport(int a,int b,int c,int d){}
 public static void glClear(int a){}
 public static void glActiveTexture(int a){}
 public static void glDrawArrays(int a,int b,int c){}
 public static void glShaderSource(int a,String b){}
 public static void glCompileShader(int a){}
 public static void glDeleteShader(int a){}
 public static void glAttachShader(int a,int b){}
 public static void glLinkProgram(int a){}
 public static void glDeleteProgram(int a){}
}