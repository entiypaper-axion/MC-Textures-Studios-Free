package android.opengl; public class Matrix {
 public static void setIdentityM(float[] a,int at){for(int i=0;i<16;i++)a[at+i]=i%5==0?1:0;}
 public static void perspectiveM(float[] a,int at,float fov,float aspect,float near,float far){}
 public static void setLookAtM(float[] a,int at,float x,float y,float z,float cx,float cy,float cz,float ux,float uy,float uz){}
 public static void multiplyMM(float[] a,int at,float[] b,int bt,float[] c,int ct){}
}