package com.axion.pompreview;
import android.opengl.GLES30;
import java.util.*;

/** Runs the production upload scheduler against a recording GLES adapter. */
public final class RendererUploadTest {
    static int checks;
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);checks++;}
    public static void main(String[] args){
        PomRenderer renderer=new PomRenderer();renderer.setBasic(true);renderer.onSurfaceCreated(null,null);
        for(int size:new int[]{16,256,512}){
            int[][] color=new int[6][size*size],normal=new int[6][size*size],mer=new int[6][size*size];byte[][] height=new byte[6][size*size];
            for(int face=0;face<6;face++){Arrays.fill(color[face],0xff000000|((face+1)*0x123456));Arrays.fill(normal[face],0xff8080ff);Arrays.fill(mer[face],0xff0000ff);}
            renderer.setMaterialFaces(color,normal,height,mer,size);renderer.onDrawFrame(null);
            int initialStorage=GLES30.storageCalls,initialFaces=GLES30.faceCalls;
            renderer.setMaterialFaces(color,normal,height,mer,size);renderer.onDrawFrame(null);
            check(initialFaces==GLES30.faceCalls,"Unchanged frame uploaded textures");
            color[2][0]=0xffeeaaff;renderer.setMaterialFaces(color,normal,height,mer,size);renderer.onDrawFrame(null);
            check(GLES30.faceCalls==initialFaces+1,"Single changed face did not produce a single upload");
            check(GLES30.storageCalls==initialStorage,"Brush move reallocated texture storage");
            boolean found=false;
            for(byte[][] layers:GLES30.data.values()){
                byte[] pixels=layers[2];int at=(size-1)*size*4;
                if(pixels!=null && (pixels[at]&255)==0xee && (pixels[at+1]&255)==0xaa && (pixels[at+2]&255)==0xff)found=true;
            }
            check(found,"Edited pixel was not uploaded with correct row orientation");
        }
        // EGL context replacement must upload existing material again.
        int calls=GLES30.faceCalls;renderer.onSurfaceCreated(null,null);renderer.onDrawFrame(null);
        check(GLES30.faceCalls==calls+18,"Context recreation lost material maps");
        System.out.println("PASS: "+checks+" production renderer checks: changed faces, no-op suppression, size changes, row orientation, context recreation.");
    }
}
