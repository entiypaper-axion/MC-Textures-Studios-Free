# MCTS 1.0.0-Release-Fr — Free

本压缩包对应本次签名 Release APK 的完整工程。旧 README / VALIDATION 文件为历史记录；请以本页和 VALIDATION_CURRENT.md 为准。

- applicationId：`com.axion.pompreview.studio3.free`
- versionName：`1.0.0-Release-Fr`
- versionCode：`31000`
- 与另外两个版本共存；同版本线使用此前的签名，可直接升级。

## 本次完成

- 增加跟随系统、浅色、深色三种模式，记住选择；开始页、工作台、画板、弹层与导航栏统一适配。主题只改变界面，不修改贴图像素。
- 下载时显示四张原创像素示意卡；解释下载来源与原因。保留已有空间检查、续传、重试、备用地址、流量提醒与缓存管理。
- 导出完成后显示 Java / 基岩版的游戏导入步骤。
- 横向、纵向镜像绘画，可同时启用；一个镜像笔划仍是一条撤销记录。
- 自动记录实际绘画用过的最近颜色，同时保留手动保存色板。
- 首次画板手势提示，可关闭，之后不再自动出现。
- 项目重命名、独立复制、确认删除；删除后提供 8 秒撤销。
- 导出前显示实际修改或新增的颜色贴图数量，以及保持原版的数量。
- 保存、导出错误给出下一步建议；关于页可复制版本、系统、设备、最近错误码，不含项目内容和文件路径。
- 左手 / 右手单手布局，主要操作置于画板下方；优化大字体、窄屏与至少 48dp 的常用触控区域。
- 修复全屏绘画撤销 / 重做按钮状态不更新；基岩版保存文件保持 `.mcpack`。

Free 保留颜色编辑与实时模型预览；不增加 MER 编辑、模型绘画、动态壁纸或透明玻璃。
APK 不内置官方模板纹理，首次使用所选模板时联网下载，完成后可离线编辑。
官方 Java 资源由手机从 Mojang 源下载；基岩资源的具体来源与旧版本归档情况见应用声明与 sources.json。此项目不提供自建素材镜像。
界面支持中文、英语、日语、法语、西班牙语；内置字体按应用实际文字裁剪，动态输入缺字由系统字体回退。
## 构建

JDK 17、Android SDK Platform 35、Build Tools 35.0.0；Gradle 8.11.1 / Android Gradle Plugin 8.9.1 / Kotlin 2.1.20。
设置自己的 ANDROID_HOME，或生成本地 local.properties。网络需要可访问 Google Maven 与 Maven Central。

```sh
chmod +x gradlew
./gradlew :app:assembleFreeRelease :app:testFreeReleaseUnitTest
bash test-core.sh
```

APK 输出：`app/build/outputs/apk/free/release/app-free-release.apk`。
Free 的其他验证可运行 `bash test-free-polish.sh`，需要设置 ANDROID_HOME。
签名通过 MCTS_SIGNING_KEY 和 MCTS_SIGNING_PASSWORD 环境变量传入，别名为 mcts。
源码不包含签名私钥或密码；没有这些变量时会使用本机的开发密钥，不能覆盖本次正式签名的安装包。

第三方许可与游戏资源声明保留在工程 / assets 中；MCTS 是非官方工具，与 Mojang / Microsoft 无隶属关系。

详细测试记录见 [VALIDATION_CURRENT.md](VALIDATION_CURRENT.md)。
