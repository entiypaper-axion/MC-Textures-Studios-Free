import com.mcts.core.MaterialDocument;

public final class ResizeTest {
    public static void main(String[] args){
        MaterialDocument doc=new MaterialDocument("grass_block_top",MaterialDocument.Kind.BLOCK,16,16);
        int layer=doc.addLayer("Highlights");doc.beginStroke(layer,MaterialDocument.Channel.COLOR);
        doc.paint(1,2,0xff18bb44);doc.endStroke();
        doc.beginStroke(layer,MaterialDocument.Channel.HEIGHT);doc.paint(1,2,0xffe0e0e0);doc.endStroke();
        MaterialDocument hd=doc.resized(512,512);
        if(hd.getLayers().size()!=2||!"Highlights".equals(hd.getLayers().get(1).name)||hd.canUndo())throw new AssertionError("layers/history");
        int[] color=hd.composite(MaterialDocument.Channel.COLOR),height=hd.composite(MaterialDocument.Channel.HEIGHT);
        for(int y=64;y<96;y++)for(int x=32;x<64;x++){
            if(color[y*512+x]!=0xff18bb44)throw new AssertionError("color");
            if(height[y*512+x]!=0xffe0e0e0)throw new AssertionError("height");
        }
        MaterialDocument tiny=hd.resized(16,16);
        if(tiny.composite(MaterialDocument.Channel.COLOR)[2*16+1]!=0xff18bb44||doc.width!=16)throw new AssertionError("round-trip");
        System.out.println("PASS: layer-preserving 16→512→16 color/height resize");
    }
}
