"""Compile and render production GLES shaders on host Mesa; not an Android device test."""
import ctypes as C,os,pathlib,re,json,struct
os.environ.setdefault('MESA_SHADER_CACHE_DIR','/tmp/mcts-mesa-cache');os.environ.setdefault('EGL_PLATFORM','surfaceless');os.environ.setdefault('LIBGL_ALWAYS_SOFTWARE','1')
E=C.CDLL('libEGL.so.1');P=C.c_void_p;I=C.c_int;U=C.c_uint;F=C.c_float
E.eglGetDisplay.argtypes=[P];E.eglGetDisplay.restype=P
E.eglInitialize.argtypes=[P,C.POINTER(I),C.POINTER(I)];E.eglInitialize.restype=U
E.eglChooseConfig.argtypes=[P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I)];E.eglChooseConfig.restype=U
E.eglBindAPI.argtypes=[U];E.eglBindAPI.restype=U
E.eglCreatePbufferSurface.argtypes=[P,P,C.POINTER(I)];E.eglCreatePbufferSurface.restype=P
E.eglCreateContext.argtypes=[P,P,P,C.POINTER(I)];E.eglCreateContext.restype=P
E.eglMakeCurrent.argtypes=[P,P,P,P];E.eglMakeCurrent.restype=U
E.eglGetProcAddress.argtypes=[C.c_char_p];E.eglGetProcAddress.restype=P
D=E.eglGetDisplay(None);major=I();minor=I();assert E.eglInitialize(D,C.byref(major),C.byref(minor)), 'EGL initialize'
attrs=(I*9)(0x3033,1,0x3040,0x40,0x3024,8,0x3025,16,0x3038);config=P();count=I();assert E.eglChooseConfig(D,attrs,C.byref(config),1,C.byref(count))and count.value>0
assert E.eglBindAPI(0x30a0)
surface=E.eglCreatePbufferSurface(D,config,(I*5)(0x3057,128,0x3056,128,0x3038));context=E.eglCreateContext(D,config,None,(I*3)(0x3098,3,0x3038));assert surface and context and E.eglMakeCurrent(D,surface,surface,context)
def fn(name,result,args):
 addr=E.eglGetProcAddress(name.encode());assert addr,name
 return C.CFUNCTYPE(result,*args)(addr)
create=fn('glCreateShader',U,[U]);source=fn('glShaderSource',None,[U,I,C.POINTER(C.c_char_p),C.POINTER(I)]);compile=fn('glCompileShader',None,[U]);get=fn('glGetShaderiv',None,[U,U,C.POINTER(I)]);log=fn('glGetShaderInfoLog',None,[U,I,C.POINTER(I),C.c_char_p])
root=pathlib.Path(__file__).resolve().parents[1];java=(root/'app/src/main/java/com/axion/pompreview/PomRenderer.java').read_text()
def shader(name,kind):
 segment=java.split('private static final String '+name+' =',1)[1]
 if name=='VERTEX_SHADER':segment=segment.split('private static final String FRAGMENT_SHADER',1)[0]
 text=''.join(json.loads(token)for token in re.findall(r'"(?:\\.|[^"\\])*"',segment)).encode()
 obj=create(kind);ptr=C.c_char_p(text);source(obj,1,C.byref(ptr),None);compile(obj);status=I();get(obj,0x8b81,C.byref(status))
 if not status.value:
  message=C.create_string_buffer(10000);log(obj,10000,None,message);raise AssertionError(message.value.decode())
 return obj
v=shader('VERTEX_SHADER',0x8b31);f=shader('FRAGMENT_SHADER',0x8b30)
program=fn('glCreateProgram',U,[])();attach=fn('glAttachShader',None,[U,U]);attach(program,v);attach(program,f);fn('glLinkProgram',None,[U])(program)
status=I();fn('glGetProgramiv',None,[U,U,C.POINTER(I)])(program,0x8b82,C.byref(status))
if not status.value:
 message=C.create_string_buffer(10000);fn('glGetProgramInfoLog',None,[U,I,C.POINTER(I),C.c_char_p])(program,10000,None,message);raise AssertionError(message.value.decode())
fn('glUseProgram',None,[U])(program);uniform=fn('glGetUniformLocation',I,[U,C.c_char_p]);u1f=fn('glUniform1f',None,[I,F]);u1i=fn('glUniform1i',None,[I,I]);u3f=fn('glUniform3f',None,[I,F,F,F]);umat=fn('glUniformMatrix4fv',None,[I,I,U,C.POINTER(F)])
def loc(name):return uniform(program,name.encode())
identity=(F*16)(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)
umat(loc('uMvp'),1,0,identity);umat(loc('uModel'),1,0,identity);u3f(loc('uCameraPosition'),0,0,4);u3f(loc('uLightDirection'),0,0,1)
for name,val in [('uGrid',16),('uEditing',1),('uBasic',1),('uEffectStrength',1),('uRoughnessScale',1),('uPomDepth',.055),('uShowGrid',0)]:u1f(loc(name),val)
gen=fn('glGenTextures',None,[I,C.POINTER(U)]);active=fn('glActiveTexture',None,[U]);bind=fn('glBindTexture',None,[U,U]);param=fn('glTexParameteri',None,[U,U,I]);tex=fn('glTexImage3D',None,[U,I,I,I,I,I,I,U,U,P])
facecolors=[(255,40,20,255),(20,255,40,255),(20,40,255,255),(255,255,20,255),(255,20,255,255),(20,255,255,255)]
for unit,name in enumerate(['uAlbedo','uNormalHeight','uMers']):
 obj=U();gen(1,C.byref(obj));active(0x84c0+unit);bind(0x8c1a,obj.value)
 for pname,val in [(0x2801,0x2600),(0x2800,0x2600),(0x2802,0x2901),(0x2803,0x2901)]:param(0x8c1a,pname,val)
 data=b''.join(bytes(facecolors[i]if unit==0 else (128,128,255,128)if unit==1 else (0,0,255,255))*256 for i in range(6));buf=C.create_string_buffer(data);tex(0x8c1a,0,0x8058,16,16,6,0,0x1908,0x1401,buf);u1i(loc(name),unit)
vao=U();fn('glGenVertexArrays',None,[I,C.POINTER(U)])(1,C.byref(vao));fn('glBindVertexArray',None,[U])(vao.value)
vbo=U();fn('glGenBuffers',None,[I,C.POINTER(U)])(1,C.byref(vbo));fn('glBindBuffer',None,[U,U])(0x8892,vbo.value);buffer=fn('glBufferData',None,[U,C.c_ssize_t,P,U]);enable=fn('glEnableVertexAttribArray',None,[U]);attr=fn('glVertexAttribPointer',None,[U,I,U,U,I,P]);read=fn('glReadPixels',None,[I,I,I,I,U,U,P]);draw=fn('glDrawArrays',None,[U,I,I]);fn('glViewport',None,[I,I,I,I])(0,0,128,128)
quad=[(-1,-1,0,0),(1,-1,1,0),(1,1,1,1),(-1,-1,0,0),(1,1,1,1),(-1,1,0,1)]
for index,(components,offset)in enumerate([(3,0),(3,3),(2,6),(3,8),(3,11),(1,14)]):enable(index);attr(index,components,0x1406,0,60,P(offset*4))
def render(face,grid=0,basic=1):
 values=[]
 for x,y,u,v in quad:values.extend([x,y,0,0,0,1,u,v,1,0,0,0,1,0,float(face)])
 data=struct.pack('<'+'f'*len(values),*values);buf=C.create_string_buffer(data);buffer(0x8892,len(data),buf,0x88e0);u1f(loc('uShowGrid'),grid);u1f(loc('uBasic'),basic);draw(4,0,6)
 pixels=(C.c_ubyte*(128*128*4))();read(0,0,128,128,0x1908,0x1401,pixels);return bytes(pixels)
checks=0
for face in range(1,7):
 pixels=render(face);pos=(64*128+64)*4;actual=pixels[pos:pos+4];assert max(abs(actual[i]-facecolors[face-1][i])for i in range(4))<=2,(face,actual);checks+=1
plain=render(1);grid=render(1,1)
center=(4*128+4)*4;edge=(4*128+8)*4
assert grid[center:center+3]==plain[center:center+3], 'grid crosses pixel centers';checks+=1
assert grid[edge]<plain[edge], 'grid misses pixel edges';checks+=1
assert any(render(1,0,0)), 'PBR render empty';checks+=1
assert fn('glGetError',U,[])()==0
print('PASS:',checks,'production GLES shader, six-face array binding, pixel-edge grid and PBR render checks on Mesa')
