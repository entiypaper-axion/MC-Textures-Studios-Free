package com.axion.pompreview;

/** Geometric regression: a touch must land on the visible 3D texture pixel. */
public final class PreviewPickTest {
    private static void check(boolean yes){if(!yes)throw new AssertionError("3D hit test mismatch");}
    public static void main(String[] args){
        PreviewGeometry.Result cube=PreviewGeometry.build("minecraft:stone");
        int assertions=0;
        for(int size:new int[]{16,32,64,128,256,512}){
            int[] middle=PreviewHitTest.pick(cube.vertices,15,size,0,0,4.25f,1024,768,512,384);
            check(middle!=null&&middle[0]==size/2&&middle[1]==size/2&&middle[2]==2);assertions++;
            check(PreviewHitTest.pick(cube.vertices,15,size,0,0,4.25f,1024,768,0,0)==null);assertions++;
            int[] rotated=PreviewHitTest.pick(cube.vertices,15,size,40,25,4.25f,1024,768,512,384);
            check(rotated!=null&&rotated[0]>=0&&rotated[0]<size&&rotated[1]>=0&&rotated[1]<size);assertions++;
        }
        PreviewGeometry.Result plant=PreviewGeometry.build("minecraft:dandelion");
        check(PreviewHitTest.pick(plant.vertices,15,16,40,25,4.25f,1024,768,512,384)!=null);assertions++;
        System.out.println("PASS: "+assertions+" 3D touch, rotation, grid-size and transparent-plant checks");
    }
}
