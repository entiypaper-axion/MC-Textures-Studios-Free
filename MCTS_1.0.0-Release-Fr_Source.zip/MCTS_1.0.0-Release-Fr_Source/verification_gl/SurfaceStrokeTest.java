import com.mcts.core.*;
import java.nio.file.*;
import java.util.*;

/** Regression of UV jumps on shared textures, crossings and leaving the visible model. */
public final class SurfaceStrokeTest {
    static int checks;
    static void check(boolean yes,String why){if(!yes)throw new AssertionError(why);checks++;}
    public static void main(String[] args)throws Exception{
        for(int size:new int[]{16,32,64,128,256,512}){
            MaterialDocument doc=new MaterialDocument("grass_block_side",MaterialDocument.Kind.BLOCK,size,size);
            int layer=doc.addLayer("Paint");SurfaceStroke path=new SurfaceStroke();doc.beginStroke(layer,MaterialDocument.Channel.COLOR);
            int[][] events={{0,0,0},{2,2,0},{size-1,size-1,1},{0,size-1,2},{-1,-1,-1},{size-1,0,2}};
            for(int[] event:events)for(int[] point:path.segment(event[0],event[1],event[2]))doc.paint(point[0],point[1],0xffee2244);
            doc.endStroke();int[] pixels=doc.composite(MaterialDocument.Channel.COLOR);long painted=Arrays.stream(pixels).filter(v->v==0xffee2244).count();
            check(painted==6,"Cross-face UVs filled extra pixels: "+painted);
            check(pixels[(size/2)*size+size/2]!=0xffee2244,"Center incorrectly filled");
            doc.undo();check(Arrays.stream(doc.composite(MaterialDocument.Channel.COLOR)).noneMatch(v->v==0xffee2244),"Sparse drag undo");doc.redo();
            Path root=Files.createTempDirectory("mcts-cross-face-");ProjectStore store=new ProjectStore(root);String key=store.save(doc);
            check(Arrays.stream(store.open(key).composite(MaterialDocument.Channel.COLOR)).filter(v->v==0xffee2244).count()==6,"Sparse pixels lost on save");
        }
        // Top/side/bottom use separate documents; one color operation never replaces another face's plane.
        MaterialDocument top=new MaterialDocument("grass_block_top",MaterialDocument.Kind.BLOCK,16,16),bottom=new MaterialDocument("dirt",MaterialDocument.Kind.BLOCK,16,16);
        top.beginStroke(0,MaterialDocument.Channel.COLOR);top.paint(3,4,0xff112233);top.endStroke();
        bottom.beginStroke(0,MaterialDocument.Channel.COLOR);bottom.paint(5,6,0xff556677);bottom.endStroke();
        check(top.composite(MaterialDocument.Channel.COLOR)[6*16+5]!=0xff556677,"Documents contaminated");
        check(bottom.composite(MaterialDocument.Channel.COLOR)[4*16+3]!=0xff112233,"Opposite face contaminated");
        System.out.println("PASS: "+checks+" cross-face, shared-texture, model-gap, persistence and isolated-face checks");
    }
}
